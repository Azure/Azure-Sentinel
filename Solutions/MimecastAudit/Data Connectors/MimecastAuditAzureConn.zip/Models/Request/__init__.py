# trigger times in minutes
GET_AUDIT_EVENTS_TRIGGER_TIME = 5
