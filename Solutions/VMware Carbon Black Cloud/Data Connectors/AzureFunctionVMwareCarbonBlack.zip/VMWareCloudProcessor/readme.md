# QueueTrigger - PowerShell

The `QueueTrigger` makes it incredibly easy to react to new Queues inside of [Azure Queue Storage](https://azure.microsoft.com/en-us/services/storage/queues/).
This sample demonstrates a simple use case of processing data from a given Queue using PowerShell.

## How it works

For a `QueueTrigger` to work, you provide a path which dictates where the queue messages are located inside your container.

## Learn more

<TODO> Documentation
