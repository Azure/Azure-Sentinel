Param (
    [String] $JSONFileCondiguration = ".\Config\CollectExchSecConfiguration.json",
    $Instance = "Default",
    $AdditionalName = ""
)

$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
$jsonConfig = Get-Content $JSONFileCondiguration | ConvertFrom-Json

function Read-RequiredValue {
    param(
        [Parameter(Mandatory=$true)]
        [string] $Prompt
    )

    do {
        $value = Read-Host -Prompt $Prompt
        if ([string]::IsNullOrWhiteSpace($value)) {
            Write-Host "A value is required. Retry."
        }
    } while ([string]::IsNullOrWhiteSpace($value))

    return $value.Trim()
}

function Set-ConfigurationProperty {
    param(
        [Parameter(Mandatory=$true)]
        [psobject] $InputObject,

        [Parameter(Mandatory=$true)]
        [string] $Name,

        [Parameter(Mandatory=$true)]
        [object] $Value
    )

    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -eq $property) {
        $InputObject | Add-Member -MemberType NoteProperty -Name $Name -Value $Value
    }
    else {
        $property.Value = $Value
    }
}

function Save-ConfigurationWithBackup {
    param(
        [Parameter(Mandatory=$true)]
        [psobject] $Configuration,

        [Parameter(Mandatory=$true)]
        [string] $Path
    )

    $configurationFile = Get-Item -LiteralPath $Path -ErrorAction Stop
    $backupTimestamp = Get-Date -Format "yy-MM-dd-HHmm"
    $backupFileName = "$($configurationFile.BaseName)-$backupTimestamp$($configurationFile.Extension)"
    $backupPath = Join-Path -Path $configurationFile.DirectoryName -ChildPath $backupFileName
    $backupSequence = 1

    while (Test-Path -LiteralPath $backupPath) {
        $backupFileName = "$($configurationFile.BaseName)-$backupTimestamp-$backupSequence$($configurationFile.Extension)"
        $backupPath = Join-Path -Path $configurationFile.DirectoryName -ChildPath $backupFileName
        $backupSequence++
    }

    Copy-Item -LiteralPath $configurationFile.FullName -Destination $backupPath -ErrorAction Stop
    Write-Host "Configuration backup created: $backupPath"

    Write-Host "Saving information into $($configurationFile.FullName)"
    $jsonContent = $Configuration | ConvertTo-Json -Depth 20 -ErrorAction Stop
    $jsonContent | Set-Content -LiteralPath $configurationFile.FullName -ErrorAction Stop
}

# Ask questions
$UpdateConfigurationOnly = Read-Host -Prompt "Do you ONLY want to update CollectExchSecConfiguration.json (only necessary if the Scheduled Task is already configured, for example, to switch to Azure Monitor Log Ingestion API)? (Y/N, default N)"
if ([string]::IsNullOrWhiteSpace($UpdateConfigurationOnly)) {
    $UpdateConfigurationOnly = "N"
}
else {
    $UpdateConfigurationOnly = $UpdateConfigurationOnly.Trim().ToUpperInvariant()
}

while ($UpdateConfigurationOnly -notin @("Y", "N")) {
    Write-Host "Value $UpdateConfigurationOnly not accepted. Enter Y or N."
    $UpdateConfigurationOnly = Read-Host -Prompt "Do you only want to update CollectExchSecConfiguration.json (for example, to switch to Azure Monitor Log Ingestion API)? (Y/N, default N)"
    if ([string]::IsNullOrWhiteSpace($UpdateConfigurationOnly)) {
        $UpdateConfigurationOnly = "N"
    }
    else {
        $UpdateConfigurationOnly = $UpdateConfigurationOnly.Trim().ToUpperInvariant()
    }
}

if ($UpdateConfigurationOnly -eq "Y") {
    $IngestionAPI = "AM"
    Write-Host "Configuration-only update selected. Azure Monitor Log Ingestion API will be configured."
}
else {
    $IngestionAPI = Read-Host -Prompt "Which ingestion API do you want to use? Azure Monitor Log Ingestion API (AM, default) or legacy Log Analytics API (LA)"
    if ([string]::IsNullOrWhiteSpace($IngestionAPI)) {
        $IngestionAPI = "AM"
    }
    else {
        $IngestionAPI = $IngestionAPI.Trim().ToUpperInvariant()
    }

    while ($IngestionAPI -notin @("AM", "LA")) {
        Write-Host "Value $IngestionAPI not accepted. Enter AM or LA."
        $IngestionAPI = Read-Host -Prompt "Which ingestion API do you want to use? Azure Monitor Log Ingestion API (AM, default) or legacy Log Analytics API (LA)"
        if ([string]::IsNullOrWhiteSpace($IngestionAPI)) {
            $IngestionAPI = "AM"
        }
        else {
            $IngestionAPI = $IngestionAPI.Trim().ToUpperInvariant()
        }
    }
}

if ($IngestionAPI -eq "AM") {
    Set-ConfigurationProperty -InputObject $jsonConfig.LogCollection -Name "SentinelLogIngestionAPIActivated" -Value "true"
    Set-ConfigurationProperty -InputObject $jsonConfig.LogCollection -Name "ExportDomainsInformation" -Value $true
    Set-ConfigurationProperty -InputObject $jsonConfig.Advanced -Name "MaximalSentinelPacketSizeMb" -Value 0.9
    if ($null -ne $jsonConfig.Global.PSObject.Properties["ExportDomainsInformation"]) {
        $jsonConfig.Global.PSObject.Properties.Remove("ExportDomainsInformation")
    }
    if ($UpdateConfigurationOnly -eq "Y") {
        Set-ConfigurationProperty -InputObject $jsonConfig.LogCollection -Name "TogetherMode" -Value "false"
    }
    $DataCollectionEndpointURI = Read-RequiredValue -Prompt "Azure Monitor Data Collection Endpoint URI"
    Set-ConfigurationProperty -InputObject $jsonConfig.LogCollection -Name "DataCollectionEndpointURI" -Value $DataCollectionEndpointURI
    $DCRImmutableId = Read-RequiredValue -Prompt "Data Collection Rule immutable ID"
    Set-ConfigurationProperty -InputObject $jsonConfig.LogCollection -Name "DCRImmutableId" -Value $DCRImmutableId

    $UseManagedIdentity = Read-Host -Prompt "Use managed identity for Azure Monitor authentication? (Y/N, default N)"
    if ([string]::IsNullOrWhiteSpace($UseManagedIdentity)) {
        $UseManagedIdentity = "N"
    }
    else {
        $UseManagedIdentity = $UseManagedIdentity.Trim().ToUpperInvariant()
    }

    while ($UseManagedIdentity -notin @("Y", "N")) {
        Write-Host "Value $UseManagedIdentity not accepted. Enter Y or N."
        $UseManagedIdentity = Read-Host -Prompt "Use managed identity for Azure Monitor authentication? (Y/N, default N)"
        if ([string]::IsNullOrWhiteSpace($UseManagedIdentity)) {
            $UseManagedIdentity = "N"
        }
        else {
            $UseManagedIdentity = $UseManagedIdentity.Trim().ToUpperInvariant()
        }
    }

    $UseManagedIdentityValue = if ($UseManagedIdentity -eq "Y") { "true" } else { "false" }
    Set-ConfigurationProperty -InputObject $jsonConfig.LogCollection -Name "UseManagedIdentity" -Value $UseManagedIdentityValue
    if ($UseManagedIdentity -eq "N") {
        $TargetLogTenantID = Read-RequiredValue -Prompt "Entra tenant ID used for ingestion authentication"
        Set-ConfigurationProperty -InputObject $jsonConfig.LogCollection -Name "TargetLogTenantID" -Value $TargetLogTenantID
        $TargetLogAppID = Read-RequiredValue -Prompt "Entra application (client) ID"
        Set-ConfigurationProperty -InputObject $jsonConfig.LogCollection -Name "TargetLogAppID" -Value $TargetLogAppID
        $TargetLogCertificateThumbprint = Read-RequiredValue -Prompt "Certificate thumbprint"
        Set-ConfigurationProperty -InputObject $jsonConfig.LogCollection -Name "TargetLogCertificateThumbprint" -Value $TargetLogCertificateThumbprint
    }
}
else {
    $jsonConfig.LogCollection.SentinelLogIngestionAPIActivated = "false"
    $jsonConfig.LogCollection.UseManagedIdentity = "false"
    $jsonConfig.LogCollection.WorkspaceId = Read-RequiredValue -Prompt "Log Analytics Workspace ID"
    $jsonConfig.LogCollection.WorkspaceKey = Read-RequiredValue -Prompt "Log Analytics Workspace Key"
}

if ($UpdateConfigurationOnly -eq "Y") {
    Save-ConfigurationWithBackup -Configuration $jsonConfig -Path $JSONFileCondiguration
    Write-Host "Configuration-only update completed. Environment and scheduled task configuration were skipped."
    return
}

$jsonConfig.Global.EnvironmentIdentification = Read-Host -Prompt "Specific name to identify the environment. You can leave it by default and the forest name will be used"

$InstanceType = Read-Host -Prompt "Do you want to process default analysis ('Def', default) or the IIS IoC analysis ('IoC') ? (Default Value: 'Def')
"
if ([string]::IsNullOrWhiteSpace($InstanceType)) {
    $InstanceType = "Def"
    Write-Host "No value entered. Default analysis ('Def') selected."
}
$validated = $false
while (-not $validated)
{
    if ($InstanceType -ne 'Def' -and $InstanceType -ne 'IoC')
    {
        Write-Host "Value $InstanceType not accepted. Retry"
        $InstanceType = Read-Host -Prompt "Do you want to process default analysis ('Def', default) or the IIS IoC analysis ('IoC') ? (No value entered. 'Def')"
        if ([string]::IsNullOrWhiteSpace($InstanceType)) {
            $InstanceType = "Def"
    
        }
    }
    else  { $validated = $true }
}

if ($InstanceType -eq 'IoC') 
{
    if ($Instance -ne 'Default') { Write-Host "For IIS IoC type, the instance $Instance will be renamed to IIS-IoC. (Only 1 instance processing IIS-IoC can be created)" }
    $Instance = 'IIS-IoCs'
    $jsonConfig.Global.ESIProcessingType = "On-Premises"
}
else {
    $InstanceType = Read-Host -Prompt "Is an instance for On-Premises (OP) or Online (OL) ? default : 'OP'"
    if ([string]::IsNullOrWhiteSpace($InstanceType)) {
        $InstanceType = "OP"
        Write-Host "No value entered. On-Premises instance ('OP') selected."
    }
    $validated = $false
    while (-not $validated)
    {
        if ($InstanceType -ne 'OP' -and $InstanceType -ne 'OL')
        {
            Write-Host "Value $InstanceType not accepted. Retry"
            $InstanceType = Read-Host -Prompt "Is an instance for On-Premises (OP) or Online (OL) ? default : 'OP'"
            if ([string]::IsNullOrWhiteSpace($InstanceType)) {
                $InstanceType = "OP"
                Write-Host "No value entered. On-Premises instance ('OP') selected."
            }
        }
        else  { $validated = $true }
    }

    if ($InstanceType -eq 'OL') { $jsonConfig.Global.ESIProcessingType = "Online" }
    else {$jsonConfig.Global.ESIProcessingType = "On-Premises"}

    $Script:ExchangeType = $InstanceType
}

if ($Script:ExchangeType -eq 'OP')
{
    $InstanceType = Read-Host -Prompt "What is the Exchange BIN Path ? (Default : 'c:\\Program Files\\Microsoft\\Exchange Server\\V15\\bin')"
    $validated = $false
    
    if (-not [String]::IsNullOrEmpty($InstanceType))
    {
        $jsonConfig.Advanced.ExchangeServerBinPath = $InstanceType
    }
}

Save-ConfigurationWithBackup -Configuration $jsonConfig -Path $JSONFileCondiguration

# Creating Scheduled Task
Write-Host "Schedule Task Creation ..."

$DailyHour = Read-Host -Prompt "At which hour the instance $Instance can be executed each day ? (format : hh:mmAM or hh:mmPM)"
$validated = $false
while (-not $validated)
{
    if ($DailyHour -notmatch "^[0-9]{1,2}:[0-9]{1,2}(AM|PM)$")
    {
        Write-Host "Value $DailyHour not accepted. Retry"
        $DailyHour = Read-Host -Prompt "At which hour the instance $Instance can be executed each day ? (format : hh:mmAM or hh:mmPM)"
    }
    else  { $validated = $true }
}

$TaskUserAccount = Read-Host -Prompt "What is the account (in UPN format svc@contoso.com) used to launch the instance $Instance ?"
$TaskUserPass = Read-Host -Prompt "What is the Password of the user $TaskUserAccount used to launch the instance $Instance ?" -AsSecureString
$PwdPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($TaskUserPass)
$PlainTextPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto($PwdPointer)
[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($PwdPointer)

$scriptExecute = $scriptFolder + "\CollectExchSecIns.ps1"
if ($Instance -ne "Default")
{
    $scriptExecute += " -InstanceName '$Instance'"
}
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "$scriptExecute"
$trigger = New-ScheduledTaskTrigger -Daily -At $DailyHour
$STSet = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 23) -MultipleInstances IgnoreNew -RestartCount 5 -RestartInterval (New-TimeSpan -Hours 1)

$TaskName = "ESI - Exchange Security Configuration Collector - $Instance"
if ($AdditionalName -ne "") { $TaskName += " - $AdditionalName" }

Register-ScheduledTask -TaskName $TaskName -Trigger $trigger -User $TaskUserAccount -Password $PlainTextPassword -Action $action -Settings $STSet

Read-Host -Prompt "Press any key to continue ..."