<#
UI.Sections.ps1
UPDATE (Execute button scope fix):
 - Event handlers for Execute-type questions now use param($sender,$e).
 - All dependent controls (result label, updates textbox, question reference) are stored in $sender.Tag.
 - Removed direct references to outer-scope variables ($btnExec / $lblRes / $txtUpd) inside handlers.
 - Same pattern applied in:
     * Wizard (Build-QuestionControl) for Execute questions.
     * Standard section rendering (Add-QuestionPanel) for Execute questions.
The rest of the file retains previously added Execute support (button + result & updates panels).
#>

param(
    [System.Windows.Forms.FlowLayoutPanel]$SectionsFlow,
    [System.Windows.Forms.Panel]$RightHost
)

$script:MandatoryPlaceholder = 'UNCONFIGUREDENTRY'

function Is-PlaceholderQuestion {
    param($Question)
    if (-not $Question) { return $false }
    if ($Question.IsComplex) {
        return (ScanComplexQuestionForPlaceholders -Question $Question -Placeholder $script:MandatoryPlaceholder)
    }
    if ($Question.IsArray) {
    return $null -ne ($Question.ArrayItems | Where-Object { $_ -like "*$script:MandatoryPlaceholder*" })
    }
    return ($Question.Value -like "*$script:MandatoryPlaceholder*")
}

function Ensure-SectionsGlobals {

    if (-not (Get-Variable -Name __SectionsFlowForButtons -Scope Script -ErrorAction SilentlyContinue)) {
        Set-Variable -Name __SectionsFlowForButtons -Scope Script -Value $null
    }
    if (-not (Get-Variable -Name SectionRefreshTimer -Scope Global -ErrorAction SilentlyContinue)) {
        $Global:SectionRefreshTimer = New-Object System.Windows.Forms.Timer
        $Global:SectionRefreshTimer.Interval = 350
        $Global:PendingSectionRefresh = $false
        $Global:SectionRefreshTimer.Add_Tick({
            try {
                $flowVar = Get-Variable -Name __SectionsFlowForButtons -Scope Script -ErrorAction SilentlyContinue
                $flowForButtons = if ($flowVar) { $flowVar.Value } else { $null }
                if ($Global:PendingSectionRefresh) {
                    $Global:PendingSectionRefresh = $false
                    if ($Global:AppState.CurrentSectionCode) {
                        Render-Section -SectionCode $Global:AppState.CurrentSectionCode -SkipResetTimer
                    }
                    if ($flowForButtons) {
                        Build-SectionButtons -Container $flowForButtons
                    }
                }
            } catch {}
        })
        $Global:SectionRefreshTimer.Start()
    }
    if ($SectionsFlow) { $script:__SectionsFlowForButtons = $SectionsFlow }
}
Ensure-SectionsGlobals

function Schedule-SectionRefresh { Ensure-SectionsGlobals; $Global:PendingSectionRefresh=$true }

$Global:QuestionPanelBaseWidth = 350
$Global:QuestionPanelMinWidth  = 300
$Global:QuestionPanelMargin    = 12

function Remove-SetupTags {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return $Text }
    return ($Text -replace '\[Setup=(Enabled|Disabled)\]','').Trim()
}

function Section-HasQuestionsForFilter {
    param($Section,[string]$Filter)
    $internal = FilterToInternal $Filter
    foreach ($q in $Section.Collection) { if ($q.SetupStatus -eq $internal) { return $true } }
    foreach ($sub in $Section.WizardSectionCode) {
        foreach ($q in $sub.Collection) { if ($q.SetupStatus -eq $internal) { return $true } }
    }
    return $false
}

function FilterToInternal {
    param([string]$FilterMode)
    switch ($FilterMode) {
        'Initial Setup' { 'Enabled' }
        'Configuration' { 'Disabled' }
        default         { 'Enabled' }
    }
}

# Global helper for Boolean segmented toggle visuals (ON/OFF)
function Set-BoolPanelVisual {
    param(
        [Parameter(Mandatory)][System.Windows.Forms.Panel]$Panel,
        [Parameter(Mandatory)][bool]$Value
    )
    if (-not $Panel -or $Panel.IsDisposed) { return }
    $lblOn  = $null
    $lblOff = $null
    foreach ($c in $Panel.Controls) {
        if ($c -is [System.Windows.Forms.Label]) {
            if ($c.Text -eq 'ON') { $lblOn = $c }
            elseif ($c.Text -eq 'OFF') { $lblOff = $c }
        }
    }
    if (-not $lblOn -or -not $lblOff) { return }
    $activeColor   = [System.Drawing.Color]::FromArgb(0,122,204)
    $inactiveBack  = [System.Drawing.Color]::White
    $inactiveFore  = [System.Drawing.Color]::FromArgb(0,122,204)
    if ($Value) {
        $lblOn.BackColor  = $activeColor;  $lblOn.ForeColor  = [System.Drawing.Color]::White
        $lblOff.BackColor = $inactiveBack; $lblOff.ForeColor = $inactiveFore
    } else {
        $lblOff.BackColor = $activeColor;  $lblOff.ForeColor = [System.Drawing.Color]::White
        $lblOn.BackColor  = $inactiveBack; $lblOn.ForeColor  = $inactiveFore
    }
}

function Build-SectionButtons {
    param($Container)
    Ensure-SectionsGlobals
    $Container.Controls.Clear()
    $filterUI = $Global:AppState.SetupFilter
    $visibleCodes = New-Object System.Collections.Generic.List[string]

    foreach ($sec in ($Global:AppState.Sections | Sort-Object Index)) {
        $conditionPass = Evaluate-Condition -Condition $sec.Condition
        $hasForFilter  = Section-HasQuestionsForFilter -Section $sec -Filter $filterUI
        if (-not $hasForFilter) { continue }
        if ($filterUI -eq 'Initial Setup' -and -not $conditionPass) { continue }

        $btn = New-Object System.Windows.Forms.Button
        $btn.Text = "$($sec.Index). $($sec.Title)"
        $btn.Width= $Container.ClientSize.Width - 30
        $btn.Height=36
        $btn.Tag = $sec.Code
        $btn.Margin='3,3,3,3'

        if ($conditionPass) {
            $btn.Enabled = $true
            $btn.BackColor = [System.Drawing.Color]::FromArgb(240,240,240)
            $btn.Add_Click({
                param($src,$ea)
                Invoke-Safely -Context "OpenSection:$($src.Tag)" -Code {
                    $Global:AppState.CurrentEditorMode='Sections'
                    $Global:AppState.CurrentSectionCode=$src.Tag
                    Render-Section -SectionCode $src.Tag
                    Log-And-Telemetry -Action "open_section" -Message "Section opened" -Data @{ code=$src.Tag; filter=$Global:AppState.SetupFilter }
                }
            })
        } else {
            $btn.Enabled = $false
            $btn.BackColor = [System.Drawing.Color]::FromArgb(225,225,225)
            $btn.ForeColor = [System.Drawing.Color]::Gray
        }
        $visibleCodes.Add($sec.Code) | Out-Null
        $Container.Controls.Add($btn)
    }

    if ($Global:AppState.CurrentSectionCode -and -not ($visibleCodes -contains $Global:AppState.CurrentSectionCode)) {
        if ($visibleCodes.Count -gt 0) {
            $Global:AppState.CurrentSectionCode = $visibleCodes[0]
            Render-Section -SectionCode $Global:AppState.CurrentSectionCode
        } else {
            $Global:AppState.CurrentSectionCode = $null
            Clear-RightPanel
        }
    }

    if (Get-Command Update-MandatoryIndicators -ErrorAction SilentlyContinue) { Update-MandatoryIndicators }
}

function Clear-RightPanel { $RightHost.Controls.Clear() }

# ------------ Wizard Support (with Execute scoping fix) ------------

function Show-SectionWizard {
    param(
        [Parameter(Mandatory)][SetupSection]$SectionCode
    )

    $sec = $SectionCode

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Wizard - $($sec.Title)"
    $dlg.Width=800; $dlg.Height=800
    $dlg.StartPosition='CenterParent'
    $dlg.Font = New-Object System.Drawing.Font("Segoe UI",9)

    $info = New-Object System.Windows.Forms.Label
    $info.Text = "Configure values for '$($sec.Title)'. Conditions apply dynamically."
    $info.AutoSize=$true
    $info.Location='10,10'
    $dlg.Controls.Add($info)

    $scroll = New-Object System.Windows.Forms.FlowLayoutPanel
    $scroll.Location='10,40'
    $scroll.Width=$dlg.ClientSize.Width-40
    $scroll.Height=$dlg.ClientSize.Height-120
    $scroll.Anchor='Top,Bottom,Left,Right'
    $scroll.AutoScroll=$true
    $dlg.Controls.Add($scroll)

    $btnOK = New-Object System.Windows.Forms.Button -Property @{ Text='OK'; Width=120; Location=(New-Object System.Drawing.Point(10, ($dlg.ClientSize.Height-70))); Anchor='Bottom,Left' }
    $btnCancel = New-Object System.Windows.Forms.Button -Property @{ Text='Cancel'; Width=120; Location=(New-Object System.Drawing.Point(140, ($dlg.ClientSize.Height-70))); Anchor='Bottom,Left' }
    $dlg.Controls.AddRange(@($btnOK,$btnCancel))

    $widgets = @()

    function Build-QuestionControl {
        param($q,[int]$y)

    # Hauteur de base (Execute plus haut après rendu spécifique)
    $baseHeight = 140
    $baseWidth  = $Global:QuestionPanelBaseWidth

    $p = New-Object System.Windows.Forms.Panel
    # Tag drapeau IsWizard pour éviter Get-Command sur Refresh-WizardVisibility dans les handlers enfants
    $p.Tag = @{ IsWizard = $true }
        $p.Width = $baseWidth
        $p.Height = $baseHeight
        #$p.Location = New-Object System.Drawing.Point(0,$y)
        $p.BorderStyle='FixedSingle'

        $lbl = New-Object System.Windows.Forms.Label
        $lbl.Text = $q.Question
        $lbl.Font = New-Object System.Drawing.Font("Segoe UI",9,[System.Drawing.FontStyle]::Bold)
        $lbl.AutoSize=$true
        $lbl.Location='6,6'
        $p.Controls.Add($lbl)

        $curY = 28
        if ($q.Description) {
            $ld = New-Object System.Windows.Forms.Label
            $ld.Text=$q.Description
            $ld.AutoSize=$false
            $ld.Width=$p.Width-12
            $ld.Height = 36
            $ld.Location='6,26'
            $ld.ForeColor=[System.Drawing.Color]::FromArgb(90,90,90)
            $p.Controls.Add($ld)
            $curY += 40
        }

        $valueCtrl = $null

    # Rendu factorisé (inclut Execute désormais)
    $renderRes = Render-QuestionValueControls -Question $q -ParentPanel $p -StartY $curY -Wizard
    $valueCtrl = $renderRes.Control
    if ($renderRes.HeightDelta -gt 0) { $p.Height += $renderRes.HeightDelta }

        $valLbl = New-Object System.Windows.Forms.Label
        $valLbl.ForeColor=[System.Drawing.Color]::Red
        $valLbl.AutoSize=$false
        $valLbl.Width = $p.Width-12
        $valLbl.Height=30
        $valLbl.Location=New-Object System.Drawing.Point(6,($p.Height-34))
        if (-not $q.IsValid) { $valLbl.Text=$q.ValidationMessage }
        $p.Controls.Add($valLbl)

        if ($q.ValueType -ne 'Execute') {
            Mark-QuestionControl -Question $q -Control $valueCtrl -Init
        }

        return @{ Question=$q; Panel=$p; Control=$valueCtrl; Validation=$valLbl }
    }

    $allQs = @()
    foreach ($q in ($sec.Collection | Sort-Object Index)) { $allQs += $q }

    $y=0
    foreach ($q in $allQs) {
        $entry = Build-QuestionControl -q $q -y $y
        $widgets += $entry
        $y += ($entry.Panel.Height + 8)
        $scroll.Controls.Add($entry.Panel)
    }

    function Refresh-WizardVisibility {
        $offset=0
        foreach ($w in $widgets) {
            $q=$w.Question
            $show = if ($Global:AppState.ShowHiddenQuestions) { $true } else { (-not $q.Hidden) }
            if ($show) { $show = Evaluate-Condition -Condition $q.Condition }
            $w.Panel.Visible=$show
            if ($show) {
                $w.Panel.Location = New-Object System.Drawing.Point(0,$offset)
                $offset += ($w.Panel.Height + 8)
            }
            if ($w.Validation) {
                if (-not $q.IsValid) { $w.Validation.Text=$q.ValidationMessage } else { $w.Validation.Text="" }
            }
        }
    }

    Refresh-WizardVisibility

    $btnCancel.Add_Click({ $dlg.DialogResult=[System.Windows.Forms.DialogResult]::Cancel; $dlg.Close() })
    $btnOK.Add_Click({
        $dlg.DialogResult=[System.Windows.Forms.DialogResult]::OK
        $dlg.Close()
    })

    # --- Enforce Read-Only mode inside the Wizard (new) ---
    if ($Global:AppState.ReadOnly) {
        # Indicate read-only in title
        if ($dlg.Text -notmatch 'Read-Only') { $dlg.Text += ' (Read-Only)' }
        # Transform buttons: OK becomes Close, hide Cancel (no changes possible)
        $btnOK.Text = 'Close'
        $btnCancel.Visible = $false
        # Disable all interactive changing controls inside the scroll panel
        foreach ($panel in $scroll.Controls) {
            foreach ($c in $panel.Controls) {
                switch ($c.GetType().FullName) {
                    'System.Windows.Forms.TextBox' {
                        # Keep visual but prevent edits
                        if ($c.PSObject.Properties.Name -contains 'ReadOnly') { $c.ReadOnly = $true }
                        else { $c.Enabled = $false }
                    }
                    'System.Windows.Forms.ComboBox' { $c.Enabled = $false }
                    'System.Windows.Forms.ListBox'  { $c.Enabled = $false }
                    'System.Windows.Forms.Button' {
                        # Disable every button that is not the Close button (main form buttons handled outside loop)
                        if ($c -ne $btnOK -and $c -ne $btnCancel) { $c.Enabled = $false }
                    }
                    default { }
                }
            }
        }
    }

    [void]$dlg.ShowDialog($Global:AppState.MainForm)
    if ($dlg.DialogResult -eq [System.Windows.Forms.DialogResult]::OK) {
        Push-UndoSnapshot
        Render-Section -SectionCode $Global:AppState.CurrentSectionCode
        Update-MandatoryIndicators
    }
}

function Get-QuestionObject {
    param([string]$SectionCode,[string]$QuestionCode)
    $key="$SectionCode|$QuestionCode"
    if ($Global:AppState.QuestionsLookup.ContainsKey($key)) { return $Global:AppState.QuestionsLookup[$key] }
    return $null
}

# ------------ Rendering (Execute fix in Add-QuestionPanel) ------------

function Render-Section {
    param([string]$SectionCode,[switch]$SkipResetTimer)
    Ensure-SectionsGlobals
    if (-not $SkipResetTimer) { $Global:PendingSectionRefresh = $false }
    Clear-RightPanel
    if (-not $Global:AppState.SectionLookup.ContainsKey($SectionCode)) { return }
    $sec = $Global:AppState.SectionLookup[$SectionCode]
    $filterUI = $Global:AppState.SetupFilter
    $internal = FilterToInternal $filterUI

    $legend = New-Object System.Windows.Forms.Panel
    $legend.Height=52
    $legend.Dock='Top'
    

    $lblMode = New-Object System.Windows.Forms.Label
    $lblMode.Text="View Mode: $filterUI"
    $lblMode.AutoSize=$true
    $lblMode.Location=(New-Object System.Drawing.Point((6),(6)))
    $lblMode.Font=New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
    $legend.Controls.Add($lblMode)

    $colors = @(
        @{ Label='Initial Setup'; Color=[System.Drawing.Color]::FromArgb(240,248,255) },
        @{ Label='Configuration'; Color=[System.Drawing.Color]::LightBlue },
        @{ Label='Modified'; Color=[System.Drawing.Color]::Yellow },
        @{ Label='Mandatory Missing'; Color=[System.Drawing.Color]::LightCoral }
    )
    $x=6
    foreach ($c in $colors) {
        $p = New-Object System.Windows.Forms.Panel
        $p.Width=14;$p.Height=14
        $p.BackColor=$c.Color
        $p.Location=(New-Object System.Drawing.Point(($x),(32)))
        $legend.Controls.Add($p)
        $lbl = New-Object System.Windows.Forms.Label
        $lbl.Text=" $($c.Label)"
        $lbl.AutoSize=$true
        $lbl.Location=(New-Object System.Drawing.Point(($x+16),(28)))
        $legend.Controls.Add($lbl)
        $x += ($lbl.PreferredWidth + 40)
    }

    $headerPanel = New-Object System.Windows.Forms.Panel
    $headerPanel.AutoSize=$true
    $headerPanel.Dock='Top'
    $RightHost.Controls.Add($headerPanel)
    $RightHost.Controls.Add($legend)

    $lblTitle = New-Object System.Windows.Forms.Label
    $lblTitle.Text=(Remove-SetupTags $sec.Title)
    $lblTitle.Font=New-Object System.Drawing.Font("Segoe UI",14,[System.Drawing.FontStyle]::Bold)
    $lblTitle.AutoSize=$true
    $lblTitle.Location=(New-Object System.Drawing.Point((4),(4)))
    $headerPanel.Controls.Add($lblTitle)

    if ($sec.Description) {
        $lblDesc = New-Object System.Windows.Forms.Label
        $lblDesc.Text=(Remove-SetupTags $sec.Description)
        $lblDesc.AutoSize=$true
        #$lblDesc.Width = $RightHost.ClientSize.Width - 30
        #$lblDesc.Height=50
        $lblDesc.Location=(New-Object System.Drawing.Point((4),(36)))
        $lblDesc.ForeColor=[System.Drawing.Color]::FromArgb(70,70,70)
        $headerPanel.Controls.Add($lblDesc)
    }

    $startY = if ($sec.Description) { 130 } else { 100 }

    $flow = New-Object System.Windows.Forms.FlowLayoutPanel
    $flow.Location=(New-Object System.Drawing.Point((0),($headerPanel.Location.Y + $headerPanel.Height + 4)))
    $flow.AutoScroll=$true
    $flow.WrapContents=$true
    $flow.Width=$RightHost.ClientSize.Width - 10
    $flow.Height= $RightHost.ClientSize.Height - $flow.Location.Y - 10
    $flow.Anchor='Top,Bottom,Left,Right'
    $RightHost.Controls.Add($flow)

    $allQuestions = @()
    foreach ($q in ($sec.Collection | Sort-Object Index)) {
        if ($q.SetupStatus -eq $internal) { $allQuestions += $q }
    }

    foreach ($sub in $sec.WizardSectionCode | Sort-Object Index) {
        if (-not (Evaluate-Condition -Condition $sub.Condition)) { continue }
        $subQs = $sub.Collection | Where-Object {$_.SetupStatus -eq $internal }
        if ($subQs.Count -gt 0) {
            $p = New-Object System.Windows.Forms.Panel
            $p.BorderStyle='FixedSingle'
            $p.Margin='6,6,6,6'
            $p.Padding='4,4,4,4'
            $p.Width =  $Global:QuestionPanelBaseWidth
            $p.Height = 180
            $p.BackColor = [System.Drawing.Color]::FromArgb(240,248,255)
            $lblSub = New-Object System.Windows.Forms.Label
            $lblSub.Text="[Sub Section] - " + (Remove-SetupTags $sub.Title)
            $lblSub.Font=New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
            $lblSub.AutoSize=$true
            $lblSub.Location=(New-Object System.Drawing.Point((6),(6)))
            $p.Controls.Add($lblSub)
            if ($sub.Description) {
                $ld = New-Object System.Windows.Forms.Label
                $ld.Text=(Remove-SetupTags $sub.Description)
                $ld.AutoSize=$false
                $ld.Width=$Global:QuestionPanelBaseWidth-12
                $ld.Height=32
                $ld.Location=(New-Object System.Drawing.Point((6),(26)))
                $ld.ForeColor=[System.Drawing.Color]::FromArgb(90,90,90)
                $p.Controls.Add($ld)
            }
            $wizardButton = New-Object System.Windows.Forms.Button
            $wizardButton.Text = 'Wizard...'
            $wizardButton.Width=70
            $wizardButton.Height= 24
            $wizardButton.Location = New-Object System.Drawing.Point(($p.Width - 190), 70)
            $wizardButton.Tag = @{ Type='Wizard'; Section=$sub }
            $p.Controls.Add($wizardButton)
            $wizardButton.Add_Click({
                param($src,$ea)
                $meta=$src.Tag
                if ($meta.Section) { Show-SectionWizard -SectionCode $meta.Section }
            })
            $flow.Controls.Add($p)
        }
    }

    foreach ($q in $allQuestions) {
        $show = if ($Global:AppState.ShowHiddenQuestions) { $true } else { (-not $q.Hidden) }
        if ($show) { $show = Evaluate-Condition -Condition $q.Condition }
        if (-not $show) { continue }
        Add-QuestionPanel -Flow $flow -Question $q
    }
    Adjust-QuestionPanelWidths -Flow $flow
    $RightHost.Tag = @{ Flow=$flow }

    if (Get-Command Update-MandatoryIndicators -ErrorAction SilentlyContinue) { Update-MandatoryIndicators }
}

function Add-QuestionPanel {
    param([System.Windows.Forms.FlowLayoutPanel]$Flow,$Question)

    $Question.IsPlaceholder = Is-PlaceholderQuestion $Question
    $panel = New-Object System.Windows.Forms.Panel
    $panel.BorderStyle='FixedSingle'
    $panel.Margin='6,6,6,6'
    $panel.Padding='4,4,4,4'
    if ($Question.ValueType -eq 'Execute') {
        $panel.Height=260
    } else {
        if ($Question.IsComplex) {
            $panel.Height = 190
        } elseif ($Question.IsArray) {
            $panel.Height = 230
        } else {
            $panel.Height = 180
        }
    }
    # Reserve space for configuration code path textbox (24px) if a code exists
    $hasConfigCode = -not [string]::IsNullOrWhiteSpace($Question.ConfigurationCode)
    if ($hasConfigCode) { $panel.Height += 28 }
    $panel.Width  = $Global:QuestionPanelBaseWidth
    # Tag étendu pour usage uniforme (IsWizard=false sur panneaux standards)
    $panel.Tag = [ordered]@{ Question=$Question; IsWizard=$false }
    $panel.BackColor = if ($Question.SetupStatus -eq 'Disabled') { [System.Drawing.Color]::LightBlue } else { [System.Drawing.Color]::FromArgb(240,248,255) }

    $lblQ = New-Object System.Windows.Forms.Label
    $lblQ.Text=$Question.Question
    $lblQ.Font=New-Object System.Drawing.Font("Segoe UI",9,[System.Drawing.FontStyle]::Bold)
    $lblQ.AutoSize=$true
    $lblQ.Location='4,4'
    $panel.Controls.Add($lblQ)

    $y=24
    if ($Question.Description) {
        $lblD = New-Object System.Windows.Forms.Label
        $lblD.Text=$Question.Description
        $lblD.AutoSize=$false
        $lblD.Width = $panel.Width - 12
        $lblD.Height=38
        $lblD.Location='4,24'
        $lblD.ForeColor=[System.Drawing.Color]::FromArgb(100,100,100)
        $panel.Controls.Add($lblD)
        $y += 44
    }

    $ctrl = $null

    # Rendu factorisé désormais pour tous les types
    $renderStd = Render-QuestionValueControls -Question $Question -ParentPanel $panel -StartY $y
    $ctrl = $renderStd.Control
    if ($renderStd.HeightDelta -gt 0) { $y += $renderStd.HeightDelta }
    if ($Global:AppState.ReadOnly -and $ctrl -is [System.Windows.Forms.Control]) { if ($ctrl -isnot [System.Windows.Forms.Button]) { $ctrl.Enabled=$true } }

    $btnRestore = $null
    if ($Question.ValueType -ne 'Execute') {
        $btnRestore = New-Object System.Windows.Forms.Button
        $btnRestore.Text='Restore'
        $btnRestore.Width=70
        $btnRestore.Location=(New-Object System.Drawing.Point(($panel.Width - 85),($ctrl.Location.Y)))
        $btnRestore.Tag=$Question
        $panel.Controls.Add($btnRestore)
        $btnRestore.Enabled = ($Question.IsComplex -or $Question.Value -ne $Question.OriginalValue)

        $btnRestore.Add_Click({
            param($src,$ea)
            $q=$src.Tag
            Invoke-Safely -Context "question_restore:$($q.Code)" -Code {
                if ($q.IsComplex) {
                    if ($q.ComplexKind -eq 'ObjectArray') { $q.ComplexItems.Clear() }
                    elseif ($q.ComplexKind -eq 'ObjectMap') { $q.ComplexMap.Clear() }
                } elseif ($q.IsArray) {
                    $q.ArrayItems.Clear()
                    ($q.OriginalValue -split ';' | Where-Object {$_}) | ForEach-Object { [void]$q.ArrayItems.Add($_) }
                    $q.Value=($q.ArrayItems -join ';')
                } else {
                    $q.Value=$q.OriginalValue
                }
                Validate-Question $q
                Set-Dirty; Push-UndoSnapshot; Schedule-SectionRefresh
                $binding = $Global:AppState.ControlBindings["$($q.SectionCode)|$($q.Code)"]
                if ($binding) { Mark-QuestionControl -Question $q -Control $binding.Control -Init }
            }
        })
    }

    $valLabel = New-Object System.Windows.Forms.Label
    $valLabel.ForeColor=[System.Drawing.Color]::Red
    $valLabel.AutoSize=$false
    $valLabel.Width = $panel.Width - 12
    $valLabel.Height=30
    $valLabel.Location=(New-Object System.Drawing.Point(4,($panel.Height-36)))
    if (-not $Question.IsValid) { $valLabel.Text=$Question.ValidationMessage }
    $panel.Controls.Add($valLabel)

    $Global:AppState.ControlBindings["$($Question.SectionCode)|$($Question.Code)"] = @{
        Control=$ctrl; Restore=$btnRestore; Panel=$panel; Validation=$valLabel; Wizard=$false
    }
    if ($Question.ValueType -ne 'Execute') {
        Mark-QuestionControl -Question $Question -Control $ctrl -Init
    }

    # Add configuration code path textbox at bottom if applicable
    if ($hasConfigCode) {
        $codeLabel = New-Object System.Windows.Forms.Label
        $codeLabel.Text = 'Path:'
        $codeLabel.AutoSize = $true
        $codeLabel.Font = New-Object System.Drawing.Font('Segoe UI',7,[System.Drawing.FontStyle]::Regular)
        $codeLabel.ForeColor = [System.Drawing.Color]::FromArgb(90,90,90)
        $codeLabel.Location = New-Object System.Drawing.Point(4, ($panel.Height - 24))
        $panel.Controls.Add($codeLabel)

        $codeBox = New-Object System.Windows.Forms.TextBox
        $codeBox.ReadOnly = $true
        $codeBox.BorderStyle = 'FixedSingle'
        $codeBox.Font = New-Object System.Drawing.Font('Consolas',8,[System.Drawing.FontStyle]::Regular)
        $codeBox.Text = $Question.ConfigurationCode
        $codeBox.Location = New-Object System.Drawing.Point(40, ($panel.Height - 28))
        $codeBox.Width = $panel.Width - 48
        $codeBox.Anchor = 'Left,Right,Bottom'
        $codeBox.TabStop = $false
        # Context menu copy
        $cm = New-Object System.Windows.Forms.ContextMenuStrip
        $miCopy = $cm.Items.Add('Copy')
        # Stocke une référence du textbox dans le menu pour éviter la capture d'une variable locale périssable
        $miCopy.Tag = $codeBox
        $miCopy.Add_Click({
            param($src,$ea)
            $tb = $src.Tag
            if ($tb -and -not $tb.IsDisposed) {
                try { [Windows.Forms.Clipboard]::SetText($tb.Text) } catch {}
            }
        })
        # Double-clic = copie rapide (utilise directement $sender au lieu d'une variable fermée)
    $codeBox.Add_DoubleClick({ param($src,$ea) try { [Windows.Forms.Clipboard]::SetText($src.Text) } catch {} })
        # Raccourci clavier Ctrl+C (copie tout le chemin même sans sélection)
        $codeBox.Add_KeyDown({
            param($src,$ea)
            if ($ea.Control -and $ea.KeyCode -eq [System.Windows.Forms.Keys]::C) {
                try { [Windows.Forms.Clipboard]::SetText($src.Text) } catch {}
                $ea.SuppressKeyPress = $true
            }
        })
        $codeBox.ContextMenuStrip = $cm
        # Repositionnement pour éviter le recouvrement par le label de validation (valLabel)
        if ($valLabel) {
            $valY = $valLabel.Location.Y
            # Si le label de validation est tout en bas (position par défaut), on remonte le chemin juste au-dessus
            if ($valY -ge ($panel.Height - 40)) {
                $newCodeBoxY = [Math]::Max($valY - 26, 50)
                $codeBox.Location = New-Object System.Drawing.Point(40, $newCodeBoxY)
                $codeLabel.Location = New-Object System.Drawing.Point(4, ([Math]::Max($newCodeBoxY - 12,4)))
            }
        }
        $panel.Controls.Add($codeBox)
    }

    $Flow.Controls.Add($panel)
}

function Mark-QuestionControl {
    param($Question,[System.Windows.Forms.Control]$Control,[switch]$Init)
    if ($Question.ValueType -eq 'Execute') { return }
    $changed = ($Question.Value -ne $Question.OriginalValue)
    $isPlaceholder = $Question.IsPlaceholder
    $isInputLike = (
        $Control -is [System.Windows.Forms.TextBox] -or 
        $Control -is [System.Windows.Forms.MaskedTextBox] -or 
        $Control -is [System.Windows.Forms.ComboBox] -or 
        ($Control -is [System.Windows.Forms.Panel] -and $Control.Tag -and ($Control.Tag.Type -in @('BooleanSwitch','YesNoSwitch')))
    )
    if ($isPlaceholder -and $isInputLike) {
        $Control.BackColor=[System.Drawing.Color]::LightCoral
        if ($Control.Text) { $Control.Text = "" }
    } elseif ($changed) {
        if ($isInputLike) { $Control.BackColor=[System.Drawing.Color]::Yellow }
    } else {
        if ($Question.SetupStatus -eq 'Disabled') {
            if ($isInputLike) { $Control.BackColor=[System.Drawing.Color]::LightBlue }
        } else {
            if ($isInputLike) { $Control.BackColor=[System.Drawing.Color]::FromArgb(240,248,255) }
        }
    }
    $binding=$Global:AppState.ControlBindings["$($Question.SectionCode)|$($Question.Code)"]
    if ($binding) {
        if ($binding.Restore) { $binding.Restore.Enabled=$changed }
        if (-not $Question.IsValid) { $binding.Validation.Text=$Question.ValidationMessage } else { $binding.Validation.Text="" }
    }
    if (-not $Init) { Set-Dirty }
}

function Refresh-SectionIfNeeded { Schedule-SectionRefresh }

function Adjust-QuestionPanelWidths {
    param([System.Windows.Forms.FlowLayoutPanel]$Flow)
    if (-not $Flow) { return }
    $usable = $RightHost.ClientSize.Width - 40
    $base = $Global:QuestionPanelBaseWidth
    $columns = [math]::Max(1, [math]::Floor($usable / ($base + $Global:QuestionPanelMargin)))
    $newWidth = [math]::Max($Global:QuestionPanelMinWidth, [math]::Floor(($usable - ($columns * $Global:QuestionPanelMargin)) / $columns))
    foreach ($c in $Flow.Controls) {
        $c.Width = $newWidth
        foreach ($inner in $c.Controls) {
            if ($inner -is [System.Windows.Forms.TextBox] -or
                $inner -is [System.Windows.Forms.ComboBox] -or
                $inner -is [System.Windows.Forms.ListBox]) {
                if ($inner.Width -gt ($c.Width - 140)) { $inner.Width = $c.Width - 140 }
            }
        }
    }
}

function Handle-RightPanelResize {
    param([System.Windows.Forms.Panel]$RightHostParam)
    $tag = $RightHostParam.Tag
    if ($tag -and $tag.Flow) { Adjust-QuestionPanelWidths -Flow $tag.Flow }
}

function Open-ArrayEditor {
    param($Question)
    if (-not $Question) { return }
    try { Add-Type -AssemblyName Microsoft.VisualBasic -ErrorAction SilentlyContinue } catch {}
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text="Array Editor - $($Question.Code)"
    $dlg.Width=560; $dlg.Height=470
    $dlg.StartPosition='CenterParent'
    $list = New-Object System.Windows.Forms.ListBox
    $list.Location=(New-Object System.Drawing.Point((10),(10))); $list.Width=360; $list.Height=340
    foreach ($i in $Question.ArrayItems) { [void]$list.Items.Add($i) }
    $dlg.Controls.Add($list)
    $listBox = $list
    $btnAdd     = New-Object System.Windows.Forms.Button -Property @{ Text="Add";      Location=(New-Object System.Drawing.Point(390,10));  Width=140 }
    $btnEdit    = New-Object System.Windows.Forms.Button -Property @{ Text="Edit";     Location=(New-Object System.Drawing.Point(390,50));  Width=140 }
    $btnRemove  = New-Object System.Windows.Forms.Button -Property @{ Text="Remove";   Location=(New-Object System.Drawing.Point(390,90));  Width=140 }
    $btnUp      = New-Object System.Windows.Forms.Button -Property @{ Text="Up";       Location=(New-Object System.Drawing.Point(390,130)); Width=140 }
    $btnDown    = New-Object System.Windows.Forms.Button -Property @{ Text="Down";     Location=(New-Object System.Drawing.Point(390,170)); Width=140 }
    $btnOK      = New-Object System.Windows.Forms.Button -Property @{ Text="OK";       Location=(New-Object System.Drawing.Point(390,300)); Width=140 }
    $btnCancel  = New-Object System.Windows.Forms.Button -Property @{ Text="Cancel";   Location=(New-Object System.Drawing.Point(390,340)); Width=140 }
    $dlg.Controls.AddRange(@($btnAdd,$btnEdit,$btnRemove,$btnUp,$btnDown,$btnOK,$btnCancel))

    $isRO = ($Global:AppState -and $Global:AppState.ReadOnly)
    if ($isRO) {
        if ($dlg.Text -notmatch 'Read-Only') { $dlg.Text += ' (Read-Only)' }
        foreach ($b in @($btnAdd,$btnEdit,$btnRemove,$btnUp,$btnDown)) { $b.Enabled = $false }
        $list.Enabled = $true
        $list.BackColor = [System.Drawing.Color]::FromArgb(235,235,235)
        $btnOK.Text = 'Close'
        $btnCancel.Visible = $false
    }
    $btnAdd.Add_Click({
    if ($isRO) { return }
        $val = [Microsoft.VisualBasic.Interaction]::InputBox("Enter new value","Add Item","")
        if ($null -ne $val -and ($val.Trim()).Length -gt 0) {
            [void]$listBox.Items.Add($val.Trim())
            $listBox.SelectedIndex = $listBox.Items.Count - 1
        }
    })
    $editCurrent = {
        if ($listBox.SelectedIndex -lt 0) { return }
        $cur = [string]$listBox.SelectedItem
        $val = [Microsoft.VisualBasic.Interaction]::InputBox("Edit value","Edit Item",$cur)
        if ($null -ne $val -and ($val.Trim()).Length -gt 0) {
            $idx = $listBox.SelectedIndex
            $listBox.Items[$idx] = $val.Trim()
            $listBox.SelectedIndex = $idx
        }
    }
    $btnEdit.Add_Click($editCurrent)
    $listBox.Add_DoubleClick($editCurrent)
    $btnRemove.Add_Click({
    if ($isRO) { return }
        if ($listBox.SelectedIndex -ge 0) {
            $idx = $listBox.SelectedIndex
            $listBox.Items.RemoveAt($idx)
            if ($listBox.Items.Count -gt 0) {
                $listBox.SelectedIndex = [Math]::Min($idx, $listBox.Items.Count-1)
            }
        }
    })
    $btnUp.Add_Click({
    if ($isRO) { return }
        $i=$listBox.SelectedIndex
        if ($i -gt 0) {
            $val=$listBox.Items[$i]
            $listBox.Items.RemoveAt($i)
            $listBox.Items.Insert($i-1,$val)
            $listBox.SelectedIndex=$i-1
        }
    })
    $btnDown.Add_Click({
    if ($isRO) { return }
        $i=$listBox.SelectedIndex
        if ($i -ge 0 -and $i -lt ($listBox.Items.Count-1)) {
            $val=$listBox.Items[$i]
            $listBox.Items.RemoveAt($i)
            $listBox.Items.Insert($i+1,$val)
            $listBox.SelectedIndex=$i+1
        }
    })
    $btnOK.Add_Click({
        if ($isRO) {
            $dlg.DialogResult=[System.Windows.Forms.DialogResult]::Cancel
            $dlg.Close(); return
        }
        $Question.ArrayItems.Clear()
        foreach ($it in $listBox.Items) {
            $trim = "$it".Trim()
            if ($trim.Length -gt 0) { [void]$Question.ArrayItems.Add($trim) }
        }
        $Question.Value=($Question.ArrayItems -join ';')
        if ($Question.PSObject.Properties.Name -contains 'IsPlaceholder') { $Question.IsPlaceholder = $false }
        Validate-Question $Question
        $dlg.DialogResult=[System.Windows.Forms.DialogResult]::OK
        $dlg.Close()
        Set-Dirty
        Push-UndoSnapshot
        Schedule-SectionRefresh
    })
    $btnCancel.Add_Click({
        $dlg.DialogResult=[System.Windows.Forms.DialogResult]::Cancel
        $dlg.Close()
    })
    [void]$dlg.ShowDialog($Global:AppState.MainForm)
}

# Propagate a value change to all other questions sharing the same ConfigurationCode
function Sync-LinkedQuestionsAfterChange {
    param(
        [Parameter(Mandatory)]$SourceQuestion,
        [Parameter(Mandatory)]$NewValue,
        [switch]$SkipSourceUpdate  # when caller already set SourceQuestion.Value
    )
    if (-not $SourceQuestion) { return }
    $configCode = $SourceQuestion.ConfigurationCode
    if ([string]::IsNullOrWhiteSpace($configCode)) { return }

    # Update global configuration store first (decoupled single source of truth)
    if ($Global:ConfigurationStore -and $Global:ConfigurationStore.ContainsKey($configCode)) {
        $entry = $Global:ConfigurationStore[$configCode]
        $entry.Value = $NewValue
    }

    # Gather all questions (sections + wizard subsections)
    $allQuestions = New-Object System.Collections.Generic.List[object]
    foreach ($sec in $Global:AppState.Sections) {
        foreach ($q in $sec.Collection) { $allQuestions.Add($q) }
        foreach ($wcode in $sec.WizardSectionCode) {
            $wiz = $Global:AppState.Sections | Where-Object Code -eq $wcode
            if ($wiz) { foreach ($qw in $wiz.Collection) { $allQuestions.Add($qw) } }
        }
    }

    # Filter same ConfigurationCode
    $linked = $allQuestions | Where-Object { $_.ConfigurationCode -eq $configCode }
    foreach ($q in $linked) {
        if ($q -ne $SourceQuestion) {
            $q.Value = $NewValue
            $q.IsPlaceholder = $false
            Validate-Question $q
            # Update bound control if exists
            $binding = $Global:AppState.ControlBindings["$($q.SectionCode)|$($q.Code)"]
            if ($binding -and $binding.Control -and -not $binding.Control.IsDisposed) {
                $ctrl = $binding.Control
                if ($ctrl -is [System.Windows.Forms.TextBox]) { $ctrl.Text = [string]$NewValue }
                elseif ($ctrl -is [System.Windows.Forms.ComboBox]) { if ($ctrl.Items.Contains($NewValue)) { $ctrl.SelectedItem=$NewValue } }
                elseif ($ctrl -is [System.Windows.Forms.Panel] -and $ctrl.Tag) {
                    if ($ctrl.Tag.Type -eq 'BooleanSwitch') { Set-BoolPanelVisual -Panel $ctrl -Value ([bool]$NewValue) }
                    elseif ($ctrl.Tag.Type -eq 'YesNoSwitch') {
                        # Repaint Yes/No panel manually
                        $yes=$null;$no=$null; foreach($c in $ctrl.Controls){ if($c -is [System.Windows.Forms.Label]){ if($c.Text -eq 'Yes'){ $yes=$c } elseif ($c.Text -eq 'No'){ $no=$c } } }
                        if ($yes -and $no) {
                            $activeColor = [System.Drawing.Color]::FromArgb(0,122,204)
                            $inactiveBack=[System.Drawing.Color]::White
                            $inactiveFore=[System.Drawing.Color]::FromArgb(0,122,204)
                            if ($NewValue -eq 'Yes') {
                                $yes.BackColor=$activeColor; $yes.ForeColor=[System.Drawing.Color]::White
                                $no.BackColor=$inactiveBack; $no.ForeColor=$inactiveFore
                            } else {
                                $no.BackColor=$activeColor; $no.ForeColor=[System.Drawing.Color]::White
                                $yes.BackColor=$inactiveBack; $yes.ForeColor=$inactiveFore
                            }
                        }
                    }
                }
                Mark-QuestionControl -Question $q -Control $ctrl
            }
        }
    }
    if (-not $SkipSourceUpdate) { Validate-Question $SourceQuestion }
    Schedule-SectionRefresh
}

# Factorisation du handler Execute utilisé par Build-QuestionControl (wizard) et Add-QuestionPanel (standard)
function Get-ExecuteButtonHandler {
    return {
        param($execSender,$execArgs)
        if ($Global:AppState.ReadOnly) {
            [System.Windows.Forms.MessageBox]::Show("Read-Only mode.","Read-Only","OK","Information")|Out-Null
            return
        }
        $meta = $execSender.Tag
        if (-not $meta) { return }
        $qq   = $meta.Question
        $res  = $meta.ResultLabel
        $upd  = $meta.UpdatesBox
        if (-not $qq -or -not $res) { return }
        $res.Text = "Result: Running..."
        try {
            $fn = $qq.ValidationHookFunction
            $result = $null
            if ($fn -and (Get-Command $fn -ErrorAction SilentlyContinue)) {
                $result = & $fn -Question $qq
            }
            if ($result -and $result -is [hashtable]) {
                $applied = Apply-ExecuteResult -ResultMap $result
                if ($applied.Count -gt 0) {
                    if ($upd) { $upd.Text = ($applied | ForEach-Object { "$($_.ConfigurationCode) = $($_.NewValue)" }) -join [Environment]::NewLine }
                    Schedule-SectionRefresh
                    $res.Text = "Result: Success - $($applied.Count) field(s) applied."
                    if ($execSender.Text -notmatch '\(Already executed\)$') { $execSender.Text += ' (Already executed)' }
                    if ($execSender.Parent -and -not $execSender.Parent.IsDisposed) { $execSender.Parent.BackColor = [System.Drawing.Color]::FromArgb(210,245,210) }
                } else {
                    $res.Text = "Result: Done (no applicable fields)."
                    if ($execSender.Text -notmatch '\(Already executed\)$') { $execSender.Text += ' (Already executed)' }
                    if ($execSender.Parent -and -not $execSender.Parent.IsDisposed) { $execSender.Parent.BackColor = [System.Drawing.Color]::FromArgb(210,245,210) }
                }
            } else {
                $res.Text = "Result: Completed (no output)."
                if ($execSender.Text -notmatch '\(Already executed\)$') { $execSender.Text += ' (Already executed)' }
                if ($execSender.Parent -and -not $execSender.Parent.IsDisposed) { $execSender.Parent.BackColor = [System.Drawing.Color]::FromArgb(210,245,210) }
            }
        } catch {
            $res.Text = "Result: Error - $($_.Exception.Message)"
        }
    }
}

# Rend et retourne un hashtable @{ Control=..; HeightDelta=.. } pour les types non Execute
function Render-QuestionValueControls {
    param(
        [Parameter(Mandatory)]$Question,
        [Parameter(Mandatory)][System.Windows.Forms.Panel]$ParentPanel,
        [Parameter(Mandatory)][int]$StartY,
        [switch]$Wizard
    )
    $q = $Question
    $y = $StartY
    $left = if ($Wizard) { 6 } else { 4 }
    $ctrl = $null
    $heightDelta = 0

    # Execute
    if ($q.ValueType -eq 'Execute') {
        $btnExec = New-Object System.Windows.Forms.Button
        $btnExec.Text = $q.Question
        $btnExec.Width = [Math]::Min(240, $ParentPanel.Width-20)
        $btnExec.Location = New-Object System.Drawing.Point($left,$y)
        $ParentPanel.Controls.Add($btnExec)
        $y += 42

        $resultPanel = New-Object System.Windows.Forms.Panel
        $resultPanel.Width = $ParentPanel.Width-8
        $resultPanel.Height=44
        $resultPanel.Location = New-Object System.Drawing.Point($left,$y)
        $lblResult = New-Object System.Windows.Forms.Label
        $lblResult.Text = "Result: Not Launched"
        $lblResult.AutoSize=$true
        $lblResult.Location='4,4'
        $resultPanel.Controls.Add($lblResult)
        $ParentPanel.Controls.Add($resultPanel)
        $y += 52

        $updatesPanel = New-Object System.Windows.Forms.Panel
        $updatesPanel.Width = $ParentPanel.Width-8
        $updatesPanel.Height=70
        $updatesPanel.Location = New-Object System.Drawing.Point($left,$y)
        $lblUpd = New-Object System.Windows.Forms.Label
        $lblUpd.Text = "Updated Fields:"
        $lblUpd.AutoSize=$true
        $lblUpd.Location='4,4'
        $updatesPanel.Controls.Add($lblUpd)
        $txtUpd = New-Object System.Windows.Forms.TextBox
        $txtUpd.Multiline=$true
        $txtUpd.ReadOnly=$true
        $txtUpd.ScrollBars='Vertical'
        $txtUpd.Width = $updatesPanel.Width-8
        $txtUpd.Height=40
        $txtUpd.Location='4,20'
        $updatesPanel.Controls.Add($txtUpd)
        $ParentPanel.Controls.Add($updatesPanel)
        $heightDelta = 170
        $btnExec.Tag = @{ Question=$q; ResultLabel=$lblResult; UpdatesBox=$txtUpd; Type='Execute' }
        $btnExec.Add_Click( (Get-ExecuteButtonHandler) )
        $ctrl=$btnExec
    }
    # Bool / Boolean
    elseif ($q.ValueType -in 'Bool','Boolean') {
        $boolPanel = New-Object System.Windows.Forms.Panel
        $boolPanel.Width = if ($Wizard) { 120 } else { 120 }
        $boolPanel.Height=24
        $boolPanel.Location = New-Object System.Drawing.Point($left, $y)
        $boolPanel.BorderStyle='FixedSingle'
        $boolPanel.Tag = @{ Type='BooleanSwitch'; Question=$q }
        $lblOn = New-Object System.Windows.Forms.Label; $lblOff=New-Object System.Windows.Forms.Label
        foreach($l in @($lblOn,$lblOff)) 
        { 
            $l.AutoSize=$false; 
            $l.TextAlign='MiddleCenter'; 
            $l.Font=New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold); 
            $l.Size=New-Object System.Drawing.Size(58,22); 
            $l.Cursor='Hand' 
        }
        $lblOn.Text='ON'; $lblOn.Location='0,0'; $lblOff.Text='OFF'; $lblOff.Location='60,0'
        $boolPanel.Controls.AddRange(@($lblOn,$lblOff))
        $cur=$false; 
        if ($null -ne $q.Value) { try { $cur=[System.Convert]::ToBoolean($q.Value) } catch {} }
        $q.Value=$cur; Set-BoolPanelVisual -Panel $boolPanel -Value $cur
        foreach($lbl in @($lblOn,$lblOff)) 
        { 
            $lbl.Add_Click(
                { 
                    param($src,$ea) 
                    if ($Global:AppState.ReadOnly){return}; 
                    $cont=$src.Parent; 
                    $qt=$cont.Tag.Question; 
                    $nv=($src.Text -eq 'ON'); 
                    if ($qt.Value -ne $nv)
                    { 
                        $qt.Value=$nv; 
                        Sync-LinkedQuestionsAfterChange -SourceQuestion $qt -NewValue $nv -SkipSourceUpdate; Validate-Question $qt; Set-Dirty; Mark-QuestionControl -Question $qt -Control $cont 
                    }; 
                    Set-BoolPanelVisual -Panel $cont -Value $nv 
                }
            )
        }
        $ParentPanel.Controls.Add($boolPanel); $ctrl=$boolPanel; $heightDelta=0
    }
    elseif ($q.ValueType -eq 'YesNo') {
        $ynPanel = New-Object System.Windows.Forms.Panel
        $ynPanel.Width=120; $ynPanel.Height=24; $ynPanel.Location=New-Object System.Drawing.Point($left,$y)
        $ynPanel.BorderStyle='FixedSingle'; 
        $ynPanel.Tag=@{ Type='YesNoSwitch'; Question=$q; IsWizard=$Wizard }
        $lblYes=New-Object System.Windows.Forms.Label; 
        $lblNo=New-Object System.Windows.Forms.Label
        foreach($l in @($lblYes,$lblNo))
        { 
            $l.AutoSize=$false; 
            $l.TextAlign='MiddleCenter'; 
            $l.Font=New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold); 
            $l.Size=New-Object System.Drawing.Size(58,22); 
            $l.Cursor='Hand' 
        }
        $lblYes.Text='Yes'; 
        $lblYes.Location='0,0'; 
        $lblNo.Text='No'; 
        $lblNo.Location='60,0'; 
        $ynPanel.Controls.AddRange(@($lblYes,$lblNo))

        $curYN = if ([string]::IsNullOrWhiteSpace([string]$q.Value)) { 'Yes' } else { [string]$q.Value }; 
        if ($curYN -notin @('Yes','No')) { $curYN='Yes' }; 
        $q.Value=$curYN

        $apply = { 
            param($panel,$val) 
            $yes=$null;$no=$null; 
            foreach($c in $panel.Controls)
            { 
                if($c -is [System.Windows.Forms.Label])
                { 
                    if($c.Text -eq 'Yes'){$yes=$c}
                    elseif($c.Text -eq 'No'){$no=$c} 
                } 
            }; 
            if (-not $yes -or -not $no){return}; 
            $ac=[System.Drawing.Color]::FromArgb(0,122,204); 
            $ib=[System.Drawing.Color]::White; 
            $if=[System.Drawing.Color]::FromArgb(0,122,204); 
            if($val -eq 'Yes')
            { 
                $yes.BackColor=$ac; $yes.ForeColor=[System.Drawing.Color]::White; $no.BackColor=$ib; $no.ForeColor=$if 
            } else { 
                $no.BackColor=$ac; $no.ForeColor=[System.Drawing.Color]::White; $yes.BackColor=$ib; $yes.ForeColor=$if 
            }
        }

        & $apply $ynPanel $curYN; $ynPanel.Tag.Apply=$apply
        foreach($lbl in @($lblYes,$lblNo))
        { 
            $lbl.Add_Click(
                { 
                    param($src,$ea) 
                    if ($Global:AppState.ReadOnly){return}; 
                    $p=$src.Parent; 
                    $qt=$p.Tag.Question; 
                    $nv=$src.Text; 
                    if ($qt.Value -ne $nv)
                    { 
                        $qt.Value=$nv; 
                        Sync-LinkedQuestionsAfterChange -SourceQuestion $qt -NewValue $nv -SkipSourceUpdate; 
                        Validate-Question $qt; 
                        Set-Dirty; 
                        Mark-QuestionControl -Question $qt -Control $p; 
                        if ($p.Tag -and $p.Tag.IsWizard) { Refresh-WizardVisibility } 
                    }; 
                    $ap=$p.Tag.Apply; 
                    if($ap){ & $ap $p $nv } 
                }
            )
        }
        $ParentPanel.Controls.Add($ynPanel); $ctrl=$ynPanel
    }
    elseif ($q.PossibleValues -and $q.PossibleValues.Count -gt 0) {
        $combo = New-Object System.Windows.Forms.ComboBox
        $combo.DropDownStyle='DropDownList'
        $combo.Items.AddRange($q.PossibleValues)
        if ($null -ne $q.Value -and $combo.Items.Contains($q.Value)) { $combo.SelectedItem=$q.Value }
        $combo.Location=New-Object System.Drawing.Point($left,$y)
        $combo.Width = if ($Wizard){ ($ParentPanel.Width-150) } else { $ParentPanel.Width - 140 }
        $combo.Tag=$q
        $combo.Add_SelectedIndexChanged(
            { 
                param($src,$ea) 
                $qq=$src.Tag; 
                Invoke-Safely -Context "question_combo:$($qq.Code)" -Code { 
                    $qq.Value=$src.SelectedItem; 
                    Sync-LinkedQuestionsAfterChange -SourceQuestion $qq -NewValue $qq.Value -SkipSourceUpdate; 
                    if ($qq.IsPlaceholder){ $qq.IsPlaceholder=$false }; 
                    Validate-Question $qq; 
                    Mark-QuestionControl -Question $qq -Control $src; 
                    Set-Dirty; Push-UndoSnapshot; 
                    if ($src.Parent.Tag -and $src.Parent.Tag.IsWizard) { Refresh-WizardVisibility } 
                } 
            })
        $ParentPanel.Controls.Add($combo); $ctrl=$combo
    }
    elseif ($q.IsComplex) {
        # Edition d'objets complexes (array ou map)
        $btnEdit   = New-Object System.Windows.Forms.Button -Property @{ Text='Edit Objects...'; Width=130; Location=(New-Object System.Drawing.Point($left,$y)); Tag=$q }
        $btnExport = New-Object System.Windows.Forms.Button -Property @{ Text='Export'; Width=70; Location=(New-Object System.Drawing.Point($left,($y+30))); Tag=$q }
        $btnImport = New-Object System.Windows.Forms.Button -Property @{ Text='Import'; Width=70; Location=(New-Object System.Drawing.Point(($left+136),($y+30))); Tag=$q }
        $ParentPanel.Controls.AddRange(@($btnEdit,$btnExport,$btnImport))
        $ctrl=$btnEdit; $heightDelta=60

        $btnEdit.Add_Click({
            param($src,$ea)
            $qLocal=$src.Tag
            if (-not $qLocal) { return }
            try {
                . (Join-Path $PSScriptRoot 'ObjectCollectionEditor.ps1')
                $updated = Show-ObjectCollectionEditor -Question $qLocal -Title "Complex Editor"
                if ($updated) {
                    Validate-Question $qLocal
                    Mark-QuestionControl -Question $qLocal -Control $src
                    Set-Dirty; Push-UndoSnapshot; Schedule-SectionRefresh
                }
            } catch {
                Write-ErrorLog -ErrorRecord $_ -Context 'complex_edit_button'
                Log-And-Telemetry -Action "complex_editor_error" -Message $_.Exception.Message -Data @{ code=$qLocal.Code }
            }
        })
        $btnExport.Add_Click({
            param($src,$ea)
            $qLocal=$src.Tag
            try {
                $val = $null
                if ($qLocal.ComplexKind -eq 'ObjectArray') {
                    $arr=@(); foreach ($it in $qLocal.ComplexItems) { $arr += $it }; $val = $arr
                } else {
                    $ht=[ordered]@{}; foreach ($k in $qLocal.ComplexMap.Keys) { $ht[$k]=$qLocal.ComplexMap[$k] }; $val = [pscustomobject]$ht
                }
                $ref = $val; Convert-AllNumbersAndBoolsToStrings ([ref]$ref)
                $json = ($ref | ConvertTo-Json -Depth 80)
                [Windows.Forms.Clipboard]::SetText($json)
                Log-And-Telemetry -Action "complex_export_quick" -Message "Exported" -Data @{ code=$qLocal.Code; length=$json.Length }
                [System.Windows.Forms.MessageBox]::Show("Exported JSON copied to clipboard.","Export","OK","Information")|Out-Null
            } catch {
                Write-ErrorLog -ErrorRecord $_ -Context 'complex_export_button'
            }
        })
        $btnImport.Add_Click({
            param($src,$ea)
            $qLocal=$src.Tag
            if ($Global:AppState.ReadOnly) {
                [System.Windows.Forms.MessageBox]::Show("Read-Only mode; switch to Write mode.","Read-Only","OK","Information")|Out-Null
                return
            }
            try {
                $raw=[Windows.Forms.Clipboard]::GetText()
                if (-not $raw) { [System.Windows.Forms.MessageBox]::Show("Clipboard empty.","Import","OK","Information")|Out-Null; return }
                $parsed = $raw | ConvertFrom-Json
                if ($qLocal.ComplexKind -eq 'ObjectArray') {
                    $new=@()
                    if ($parsed -is [System.Collections.IEnumerable] -and $parsed -isnot [string]) { foreach ($it in $parsed){ $new+=$it } }
                    elseif ($parsed -is [pscustomobject] -and $parsed.PSObject.Properties.Count -eq 1) {
                        foreach ($p in $parsed.PSObject.Properties) { if ($p.Value -is [System.Collections.IEnumerable] -and $p.Value -isnot [string]) { foreach ($it in $p.Value){ $new+=$it } } }
                    }
                    if ($new.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show("No array objects detected.","Import","OK","Warning")|Out-Null; return }
                    $qLocal.ComplexItems.Clear(); foreach ($it in $new) { $qLocal.ComplexItems.Add($it) | Out-Null }
                } else {
                    $map=[ordered]@{}
                    if ($parsed -is [pscustomobject]) { foreach ($p in $parsed.PSObject.Properties){ $map[$p.Name]=$p.Value } }
                    elseif ($parsed -is [hashtable]) { foreach ($k in $parsed.Keys){ $map[$k]=$parsed[$k] } }
                    else { [System.Windows.Forms.MessageBox]::Show("Not a map/object JSON.","Import","OK","Warning")|Out-Null; return }
                    $qLocal.ComplexMap.Clear(); foreach ($k in $map.Keys){ $qLocal.ComplexMap[$k]=$map[$k] }
                }
                Validate-Question $qLocal
                Mark-QuestionControl -Question $qLocal -Control $btnEdit
                Set-Dirty; Push-UndoSnapshot; Schedule-SectionRefresh
                Log-And-Telemetry -Action "complex_import_quick" -Message "Imported quick" -Data @{ code=$qLocal.Code }
                [System.Windows.Forms.MessageBox]::Show("Imported complex collection.","Import","OK","Information")|Out-Null
            } catch {
                Write-ErrorLog -ErrorRecord $_ -Context 'complex_import_button'
                Log-And-Telemetry -Action "complex_import_error" -Message $_.Exception.Message -Data @{ code=$qLocal.Code }
            }
        })
    }
    elseif ($q.ValueType -eq 'SecureString') {
        $txt = New-Object System.Windows.Forms.TextBox
        $txt.UseSystemPasswordChar=$true
        $txt.Text = if ($q.IsPlaceholder) { '' } else { [string]$q.Value }
        $txt.Width = if ($Wizard){ $ParentPanel.Width-150 } else { $ParentPanel.Width - 140 }
        $txt.Location=New-Object System.Drawing.Point($left,$y)
        $txt.Tag=$q
        $txt.Add_Enter(
            { 
                param($src,$ea) 
                if ($src.PSObject.Properties.Name -notcontains 'StartValue')
                { 
                    Add-Member -InputObject $src -NotePropertyName StartValue -NotePropertyValue $src.Text -Force 
                } else { $src.StartValue = $src.Text }
            })
        $txt.Add_Leave(
            { 
                param($src,$ea) 
                $q2=$src.Tag; 
                if (-not $q2){return}; 
                $start=$src.Text; 
                if ($src.PSObject.Properties.Name -contains 'StartValue'){ $start=$src.StartValue }; 
                $cur=$src.Text; 
                if ($q2.IsPlaceholder -and [string]::IsNullOrEmpty($cur)){return}; 
                if ($start -eq $cur){return}; 
                Invoke-Safely -Context "question_secure_leave:$($q2.Code)" -Code 
                { 
                    $q2.Value=$cur; 
                    $q2.IsPlaceholder=$false; 
                    Validate-Question $q2; 
                    Sync-LinkedQuestionsAfterChange -SourceQuestion $q2 -NewValue $q2.Value -SkipSourceUpdate; 
                    Mark-QuestionControl -Question $q2 -Control $src; 
                    Set-Dirty; 
                    Push-UndoSnapshot; 
                    if ($src.Parent.Tag -and $src.Parent.Tag.IsWizard) { Refresh-WizardVisibility } 
                }
            })
        $ParentPanel.Controls.Add($txt); $ctrl=$txt
    }
    elseif ($q.IsArray) {
        $listBox = New-Object System.Windows.Forms.ListBox
        $listBox.Width = if ($Wizard){ $ParentPanel.Width-180 } else { $ParentPanel.Width - 140 }
        $listBox.Height=70
        $listBox.Location=New-Object System.Drawing.Point($left,$y)
        foreach($v in $q.ArrayItems){ [void]$listBox.Items.Add($v) }
        $listBox.Tag=$q
        $ParentPanel.Controls.Add($listBox)
        $btnEdit = New-Object System.Windows.Forms.Button -Property @{ 
            Text='Edit...'; 
            Width=75; 
            Location=(New-Object System.Drawing.Point(($listBox.Location.X+$listBox.Width+8),$y)); 
            Tag=$q 
        }
        $btnEdit.Add_Click(
        { 
            param($src,$ea) 
            $q3=$src.Tag; 
            if ($Global:AppState.ReadOnly)
            { 
                [System.Windows.Forms.MessageBox]::Show("Read-Only mode; switch to Write mode.","Read-Only","OK","Information")|Out-Null; 
                return 
            }; 
            Invoke-Safely -Context "array_edit:$($q3.Code)" -Code 
            { 
                Open-ArrayEditor -Question $q3; 
                $listBox.Items.Clear(); 
                foreach($it in $q3.ArrayItems)
                { 
                    [void]$listBox.Items.Add($it) 
                }; 
                $q3.IsPlaceholder=$false; 
                Mark-QuestionControl -Question $q3 -Control $listBox; 
                Push-UndoSnapshot; 
                if ($listBox.Parent.Tag -and $listBox.Parent.Tag.IsWizard) { Refresh-WizardVisibility } 
            } 
        })
        $ParentPanel.Controls.Add($btnEdit)
        $ctrl=$listBox; $heightDelta = 80
    }
    else {
        $txt = New-Object System.Windows.Forms.TextBox
        $txt.Text = if ($q.IsPlaceholder) { '' } else { [string]$q.Value }
        $txt.Width = if ($Wizard){ $ParentPanel.Width-150 } else { $ParentPanel.Width - 140 }
        $txt.Location=New-Object System.Drawing.Point($left,$y)
        $txt.Tag=$q
        $txt.Add_Enter(
            { 
                param($src,$ea) 
                if ($src.PSObject.Properties.Name -notcontains 'StartValue')
                { 
                    Add-Member -InputObject $src -NotePropertyName StartValue -NotePropertyValue $src.Text -Force 
                } else { $src.StartValue=$src.Text } 
            })
        $txt.Add_Leave(
            { 
                param($src,$ea) 
                $q4=$src.Tag; 
                if (-not $q4){return}; 
                $start=$src.Text; 
                if ($src.PSObject.Properties.Name -contains 'StartValue'){ $start=$src.StartValue }; 
                $cur=$src.Text; 
                if ($q4.IsPlaceholder -and [string]::IsNullOrEmpty($cur)){return}; 
                if ($start -eq $cur){return}; 
                Invoke-Safely -Context "question_text_leave:$($q4.Code)" -Code { 
                    $q4.Value=$cur; 
                    $q4.IsPlaceholder=$false; 
                    Validate-Question $q4; 
                    Sync-LinkedQuestionsAfterChange -SourceQuestion $q4 -NewValue $q4.Value -SkipSourceUpdate; 
                    Mark-QuestionControl -Question $q4 -Control $src; 
                    Set-Dirty; 
                    Push-UndoSnapshot; 
                    if ($src.Parent.Tag -and $src.Parent.Tag.IsWizard) { Refresh-WizardVisibility } 
                } 
        })
        $ParentPanel.Controls.Add($txt); $ctrl=$txt
    }
    return @{ Control=$ctrl; HeightDelta=$heightDelta }
}