<#
Models.ps1 (Aggregator - UPDATED)

Now splits the model into two logical parts:
 - Models.Setup.ps1          (Setup / Enabled)
 - Models.Configuration.ps1  (Configuration / Disabled)

Build-SetupConfiguration continues to return the combined list for existing callers.
#>

. $PSScriptRoot\Models.Common.ps1
. $PSScriptRoot\Models.Setup.ps1
. $PSScriptRoot\Models.Configuration.ps1

function Build-SetupConfiguration {
    $setup  = Build-SetupModel
    $config = Build-ConfigurationModel
    $merged = [System.Collections.Generic.List[SetupSection]]::new()
    foreach ($s in $setup)  { $merged.Add($s) | Out-Null }
    foreach ($s in $config) { $merged.Add($s) | Out-Null }
    foreach ($sec in $merged) {
        foreach ($q in $sec.Collection) {
            if (-not $q.OriginalSetupStatus) { $q.OriginalSetupStatus = $q.SetupStatus }
        }
        foreach ($sub in $sec.WizardSectionCode) {
            foreach ($q in $sub.Collection) {
                if (-not $q.OriginalSetupStatus) { $q.OriginalSetupStatus = $q.SetupStatus }
            }
        }
    }
    return $merged
}