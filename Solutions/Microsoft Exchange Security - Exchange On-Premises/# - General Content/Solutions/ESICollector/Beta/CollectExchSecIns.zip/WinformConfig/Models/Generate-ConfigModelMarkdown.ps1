<#
.SYNOPSIS
Generates Markdown documentation (and optional per‑section files) from the Configuration Model (Models.ps1).

.DESCRIPTION
This script loads your existing configuration model (Build-SetupConfiguration in Models.ps1) and produces
human-readable Markdown that documents sections, (sub-)sections, questions, conditions, defaults,
possible values, regex constraints, value types, hidden flags, and configuration paths. It can also
include current values from a configuration JSON file for side‑by‑side comparison.

Multiple output styles are supported (Full / Quick / QuestionsOnly) plus optional splitting into
individual section markdown files. A Table of Contents (with anchor links) can be generated.

It also creates PowerShell code examples per question to assist in scripting manual configuration.

.PARAMETER ModelsPath
Path to Models.ps1 containing Build-SetupConfiguration. (Default: ../WinFormsMod/Models.ps1 relative to this script)

.PARAMETER OutputPath
Destination Markdown file (default: ./ConfigModel.Documentation.md in current directory)

.PARAMETER ConfigPath
Optional configuration JSON. When provided, a "CurrentValue" column and overrides in code samples are included.

.PARAMETER IncludeHidden
Include questions marked Hidden (default: omitted).

.PARAMETER TemplateType
One of: Full (default) | Quick | QuestionsOnly
 Full          : Tables + code blocks + detailed metadata.
 Quick         : Condensed tables only (minimal columns).
 QuestionsOnly : One code block (PowerShell) per question without tables.

.PARAMETER IncludeTOC
Include a Table of Contents.

.PARAMETER SplitSections
Create one markdown file per top-level section in a sibling folder <OutputPath>.sections/
(and still generate the main consolidated markdown).

.PARAMETER Overwrite
Allow overwriting an existing OutputPath (otherwise the script aborts if file exists).

.PARAMETER IncludeSubSections
Include sub-section headings (default: true). Use -NoIncludeSubSections to flatten.

.PARAMETER AddConfigAssignmentBlocks
Emits per-question PowerShell assignment blocks (default: Full & QuestionsOnly modes already do; can disable).

.PARAMETER ShowUnsetAs
String to use when a config value is absent (default: "<unset>").

.PARAMETER DateFormat
Timestamp format for header (default: "yyyy-MM-dd HH:mm:ss 'UTC'").

.PARAMETER ColumnSet
Custom column selection (comma list) overriding defaults for the chosen TemplateType.
Valid column keys: Index, Code, Question, Path, Default, CurrentValue, PossibleValues, Regex, Hidden, ValueType, Condition, Section, SubSection

.PARAMETER MaxValueLength
Max characters for in-table values; longer values are truncated with ellipsis (default 120).

.PARAMETER WrapWidth
Soft wrap width for descriptions in code comments (default 100, 0 = no wrap).

.EXAMPLE
.\Generate-ConfigModelMarkdown.ps1 -ModelsPath ..\WinFormsMod\Models.ps1 -OutputPath .\ConfigModel.md -IncludeTOC

.EXAMPLE
.\Generate-ConfigModelMarkdown.ps1 -ConfigPath ..\Config\CollectExchSecConfiguration.json -SplitSections -TemplateType Full

.EXAMPLE
.\Generate-ConfigModelMarkdown.ps1 -TemplateType QuestionsOnly -ColumnSet "Path,Default,CurrentValue"

.NOTES
Designed to be idempotent; regenerate after model updates.

#>

[CmdletBinding()]
param(
    [string]$ModelsPath       = (Join-Path $PSScriptRoot '..\WinFormsMod\Models.ps1'),
    [string]$OutputPath       = (Join-Path (Get-Location) 'ConfigModel.Documentation.md'),
    [string]$ConfigPath,
    [switch]$IncludeHidden,
    [ValidateSet('Full','Quick','QuestionsOnly')]
    [string]$TemplateType     = 'Full',
    [switch]$IncludeTOC,
    [switch]$SplitSections,
    [switch]$Overwrite,
    [switch]$AddConfigAssignmentBlocks = $true,
    [switch]$IncludeSubSections = $true,
    [string]$ShowUnsetAs = '<unset>',
    [string]$DateFormat = "yyyy-MM-dd HH:mm:ss 'UTC'",
    [string]$ColumnSet,
    [int]$MaxValueLength = 120,
    [int]$WrapWidth = 100
)

Set-StrictMode -Version Latest

function Fail($msg){ throw $msg }

if (-not (Test-Path -LiteralPath $ModelsPath)) { Fail "ModelsPath not found: $ModelsPath" }
if ((Test-Path -LiteralPath $OutputPath) -and -not $Overwrite) {
    Fail "OutputPath exists. Use -Overwrite to replace: $OutputPath"
}

# Load model
. $ModelsPath
if (-not (Get-Command Build-SetupConfiguration -ErrorAction SilentlyContinue)) {
    Fail "Build-SetupConfiguration not defined in Models file."
}
$Model = Build-SetupConfiguration
if (-not $Model) { Fail "Model returned no sections." }

# Load optional config JSON
$Config = $null
if ($ConfigPath) {
    if (-not (Test-Path -LiteralPath $ConfigPath)) { Fail "ConfigPath not found: $ConfigPath" }
    try {
        $raw = Get-Content -LiteralPath $ConfigPath -Raw
        $Config = $raw | ConvertFrom-Json -Depth 100
    } catch {
        Fail "Failed to parse configuration JSON: $($_.Exception.Message)"
    }
}

# Helper: Get config value by dotted path
function Get-ConfigValue {
    param([string]$Path)
    if (-not $Config) { return $null }
    $parts = $Path.Split('.')
    $cursor = $Config
    foreach ($p in $parts) {
        if ($cursor -isnot [psobject]) { return $null }
        if ($cursor.PSObject.Properties.Name -notcontains $p) { return $null }
        $cursor = $cursor.$p
    }
    return $cursor
}

function Trunc {
    param($v)
    if ($null -eq $v) { return '' }
    $s = [string]$v
    if ($MaxValueLength -gt 0 -and $s.Length -gt $MaxValueLength) {
        return ($s.Substring(0,$MaxValueLength) + '…')
    }
    return $s
}

function Wrap {
    param([string]$Text)
    if (-not $Text) { return '' }
    if ($WrapWidth -le 0) { return $Text }
    $out = New-Object System.Text.StringBuilder
    $line = ''
    foreach ($word in $Text -split '(\s+)') {
        if (($line + $word).Length -gt $WrapWidth) {
            [void]$out.AppendLine($line.TrimEnd())
            $line = $word
        } else {
            $line += $word
        }
    }
    if ($line) { [void]$out.AppendLine($line.TrimEnd()) }
    return $out.ToString().TrimEnd()
}

# Determine default columns per template
$defaultCols = switch ($TemplateType) {
    'Full' { @('Index','Code','Question','Path','Default','CurrentValue','PossibleValues','Regex','Hidden','ValueType','Condition') }
    'Quick' { @('Path','Question','Default','CurrentValue','PossibleValues') }
    'QuestionsOnly' { @('Path','Default','CurrentValue') }
}

if ($ColumnSet) {
    $cols = $ColumnSet.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
} else {
    $cols = $defaultCols
}

# Markdown escaping
function Esc {
    param([string]$s)
    if ($null -eq $s) { return '' }
    return ($s -replace '\|','\|')
}

# Build section folder if splitting
$sectionOutDir = $null
if ($SplitSections) {
    $sectionOutDir = "$OutputPath.sections"
    if (-not (Test-Path -LiteralPath $sectionOutDir)) {
        New-Item -ItemType Directory -Path $sectionOutDir | Out-Null
    }
}

$timeStamp = (Get-Date -AsUTC).ToString($DateFormat)
$md = New-Object System.Text.StringBuilder

# Header
[void]$md.AppendLine("# Configuration Model Documentation")
[void]$md.AppendLine()
[void]$md.AppendLine("> Generated: $timeStamp")
[void]$md.AppendLine("> Source Model: $([IO.Path]::GetFileName($ModelsPath))")
if ($ConfigPath) { [void]$md.AppendLine("> Compared Config: $([IO.Path]::GetFileName($ConfigPath))") }
[void]$md.AppendLine("> Template: `$TemplateType` ")
[void]$md.AppendLine()

if ($IncludeTOC) {
    [void]$md.AppendLine("## Table of Contents")
    foreach ($sec in ($Model | Sort-Object Index)) {
        $anchor = ($sec.Title -replace '[^A-Za-z0-9 ]','').ToLower() -replace ' ','-'
        [void]$md.AppendLine("- [{Esc $($sec.Title)}](#{ $anchor })")
        if ($IncludeSubSections) {
            foreach ($sub in ($sec.Section | Sort-Object Index)) {
                $subAnchor = ($sub.Title -replace '[^A-Za-z0-9 ]','').ToLower() -replace ' ','-'
                [void]$md.AppendLine("  - [$($sub.Title)](#${subAnchor})")
            }
        }
    }
    [void]$md.AppendLine()
}

# Per-section
foreach ($sec in ($Model | Sort-Object Index)) {

    $secAnchor = ($sec.Title -replace '[^A-Za-z0-9 ]','').ToLower() -replace ' ','-'
    [void]$md.AppendLine("## $($sec.Title)  ")
    [void]$md.AppendLine("Code: `$($sec.Code)`&nbsp; • Index: `$($sec.Index)`  ")
    if ($sec.Condition) { [void]$md.AppendLine("**Condition:** `$($sec.Condition)`  ") }
    if ($sec.Description) { [void]$md.AppendLine(); [void]$md.AppendLine("Esc $($sec.Description)"); [void]$md.AppendLine() }

    $sectionFileBuilder = $null
    if ($SplitSections) {
        $sectionFileBuilder = New-Object System.Text.StringBuilder
        [void]$sectionFileBuilder.AppendLine("## $($sec.Title)")
        if ($sec.Description) { [void]$sectionFileBuilder.AppendLine(); [void]$sectionFileBuilder.AppendLine($sec.Description); [void]$sectionFileBuilder.AppendLine() }
    }

    # gather questions (top + sub)
    $questions = @()
    $questions += $sec.Collection
    if ($IncludeSubSections) {
        foreach ($s2 in ($sec.Section | Sort-Object Index)) {
            # add sub-section heading if there are questions
            if ($s2.Collection.Count -gt 0) {
                $questions += $s2.Collection | ForEach-Object {
                    $_ | Add-Member -NotePropertyName _ParentSubSection -NotePropertyValue $s2 -Force
                    $_
                }
            }
        }
    }

    # filter hidden if needed
    if (-not $IncludeHidden) {
        $questions = $questions | Where-Object { -not $_.Hidden }
    }

    if ($TemplateType -ne 'QuestionsOnly') {
        # Table header
        [void]$md.Append('| ' + ($cols -join ' | ') + ' |')
        [void]$md.AppendLine()
        [void]$md.Append('| ' + ($cols | ForEach-Object { '---' }) -join ' | ' + ' |')
        [void]$md.AppendLine()

        if ($SplitSections) {
            [void]$sectionFileBuilder.Append('| ' + ($cols -join ' | ') + ' |')
            [void]$sectionFileBuilder.AppendLine()
            [void]$sectionFileBuilder.Append('| ' + ($cols | ForEach-Object { '---' }) -join ' | ' + ' |')
            [void]$sectionFileBuilder.AppendLine()
        }
    }

    $qIndex = 0
    foreach ($q in ($questions | Sort-Object Index)) {
        $qIndex++
        $currentVal = if ($q.ConfigurationCode) { Get-ConfigValue -Path $q.ConfigurationCode } else { $null }
        if ($currentVal -is [System.Collections.IEnumerable] -and $currentVal -isnot [string]) {
            $currentVal = ($currentVal | ForEach-Object { $_ }) -join ';'
        }
        if ($currentVal -eq $null -or $currentVal -eq '') { $currentVal = $ShowUnsetAs }

        $defaultVal = if ($q.Value) { $q.Value } else { $ShowUnsetAs }
        $possible = if ($q.PossibleValues -and $q.PossibleValues.Count -gt 0) { ($q.PossibleValues -join ', ') } else { '' }

        # Build row map
        $rowMap = @{
            Index        = $q.Index
            Code         = $q.Code
            Question     = Trunc $q.Question
            Path         = $q.ConfigurationCode
            Default      = Trunc $defaultVal
            CurrentValue = Trunc $currentVal
            PossibleValues = Trunc $possible
            Regex        = Trunc $q.Regex
            Hidden       = if ($q.Hidden){'Yes'} else {'No'}
            ValueType    = $q.ValueType
            Condition    = Trunc $q.Condition
            Section      = $sec.Code
            SubSection   = if ($q.PSObject.Properties.Name -contains '_ParentSubSection') { $q._ParentSubSection.Code } else { '' }
        }

        if ($TemplateType -ne 'QuestionsOnly') {
            $line = '| ' + ($cols | ForEach-Object { Esc ($rowMap[$_] ) }) -join ' | ' + ' |'
            [void]$md.AppendLine($line)
            if ($SplitSections) { [void]$sectionFileBuilder.AppendLine($line) }
        }

        if ($AddConfigAssignmentBlocks -and ($TemplateType -in @('Full','QuestionsOnly'))) {
            $descWrapped = Wrap $q.Description
            $codeBlock = New-Object System.Text.StringBuilder
            [void]$codeBlock.AppendLine()
            [void]$codeBlock.AppendLine('```powershell')
            [void]$codeBlock.AppendLine("# Section     : $($sec.Code)")
            if ($rowMap.SubSection) { [void]$codeBlock.AppendLine("# Sub-Section : $($rowMap.SubSection)") }
            [void]$codeBlock.AppendLine("# Question    : $($q.Question)")
            if ($q.ConfigurationCode) { [void]$codeBlock.AppendLine("# Path        : $($q.ConfigurationCode)") }
            if ($descWrapped) {
                foreach ($dl in ($descWrapped -split "`r?`n")) {
                    [void]$codeBlock.AppendLine("# Desc        : $dl")
                }
            }
            if ($possible) { [void]$codeBlock.AppendLine("# Possible    : $possible") }
            if ($q.Regex)  { [void]$codeBlock.AppendLine("# Regex       : $($q.Regex)") }
            if ($q.Condition) { [void]$codeBlock.AppendLine("# Condition   : $($q.Condition)") }
            [void]$codeBlock.AppendLine("# Default     : $defaultVal")
            [void]$codeBlock.AppendLine("# Current     : $currentVal")
            [void]$codeBlock.AppendLine("# Hidden      : $($rowMap.Hidden)")
            if ($q.ValueType) { [void]$codeBlock.AppendLine("# ValueType   : $($q.ValueType)") }
            if ($q.ConfigurationCode) {
                # Provide assignment skeleton
                $assignVal = if ($q.PossibleValues -and $q.PossibleValues.Count -gt 0) { $q.PossibleValues[0] } else { $defaultVal }
                if ($q.IsArray) {
                    $tmp34 = if ($defaultVal -and $defaultVal -ne $ShowUnsetAs) { '"' + ($defaultVal -split ';' | Where-Object { $_ }) -join '","' + '"' } else { '"<value1>","<value2>"' } 
                    [void]$codeBlock.AppendLine("$('$')config." + ($q.ConfigurationCode -replace '\.','.') + " = @(" + $tmp34  + ")")
                } else {
                    [void]$codeBlock.AppendLine("$('$')config." + ($q.ConfigurationCode -replace '\.','.') + " = `"${assignVal}`"")
                }
            } else {
                [void]$codeBlock.AppendLine("# (No configuration path mapped)")
            }
            [void]$codeBlock.AppendLine('```')
            [void]$md.AppendLine($codeBlock.ToString())
            if ($SplitSections) { [void]$sectionFileBuilder.AppendLine($codeBlock.ToString()) }
        }
    }

    [void]$md.AppendLine()
    if ($SplitSections) {
        $secFile = Join-Path $sectionOutDir ("Section_"+$sec.Code+".md")
        Set-Content -LiteralPath $secFile -Value $sectionFileBuilder.ToString() -Encoding UTF8
    }
}

# Footer
[void]$md.AppendLine()
[void]$md.AppendLine("---")
[void]$md.AppendLine("_End of generated documentation (Template: $TemplateType)_")

Set-Content -LiteralPath $OutputPath -Value $md.ToString() -Encoding UTF8

Write-Host "Markdown generated: $OutputPath"
if ($SplitSections) { Write-Host "Per-section files: $sectionOutDir" }