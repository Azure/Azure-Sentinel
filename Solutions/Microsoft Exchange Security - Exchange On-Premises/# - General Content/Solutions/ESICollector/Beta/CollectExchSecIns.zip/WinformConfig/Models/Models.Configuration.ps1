<#
Models.Configuration.ps1
UPDATED:
 - Renamed Add-DisabledQuestion -> Add-ConfigurationQuestion
 - Converted string booleans to real booleans
 - Added complex object questions:
     * Advanced.UDSLogProcessor     (ObjectArray)
     * AuditFunctionsFiles          (ObjectArray)
     * InstanceConfiguration        (ObjectMap) with nested objects (Default, IIS-IoCs, ExchangeOnlineMessageTracking, InstanceExample)
 - Added schemas for these complex object collections to drive the generic editor.
 - Value validation will be handled in Utilities / Validate-Question extended logic (Bool/Int/ObjectArray/ObjectMap).
#>

. $PSScriptRoot\Models.Common.ps1

function Add-ConfigurationQuestion {
    param(
        [SetupSection]$Section,
        [string]$Code,
        [int]$Index,
        [string]$ConfigurationCode,
        [string]$Question,
        [string]$Description,
        [object]$Value,
        [string[]]$PossibleValues,
        [string]$ValueType,
        [string]$Regex,
        [switch]$Hidden,
        [switch]$AsObjectArray,
        [switch]$AsObjectMap,
        [object]$Schema, 
        [string]$Condition,
        [String]$ValidationHookFunction
    )
    # Prevent duplicates
    foreach ($q in $Section.Collection) {
        if ($q.ConfigurationCode -and $q.ConfigurationCode -ieq $ConfigurationCode) { return }
    }
    $q = New-SetupQuestion -Code $Code -Index $Index -ConfigurationCode $ConfigurationCode `
        -Question $Question -Description $Description -Value $Value `
        -PossibleValues $PossibleValues -ValueType $ValueType -Regex $Regex -Hidden:$Hidden `
        -AsObjectArray:$AsObjectArray -AsObjectMap:$AsObjectMap -Schema $Schema -Condition $Condition -ValidationHookFunction $ValidationHookFunction
    $q.SetupStatus='Disabled'
    $q.OriginalSetupStatus='Disabled'
    $Section.Collection.Add($q) | Out-Null
}

function Build-ConfigurationModel {

    $cfgSections = [System.Collections.Generic.List[SetupSection]]::new()

    $iGlobal   = 1000
    $iAdvanced = 2000
    $iLog      = 3000
    $iInternet = 4000
    $iGraph    = 5000
    $iAuditF   = 6000
    $iAuditP   = 7000
    $iMisc     = 8000
    $iComplex  = 9000

    # ----- Global -----
    $globalSec = New-SetupSection -Code 'GlobalParameters' -Title 'Global Additional Parameters' -Index 50 -Description 'Additional global parameters.'
    Add-ConfigurationQuestion -Section $globalSec -Code 'ParallelTimeoutMinutes'     -Index ($iGlobal+1) -ConfigurationCode 'Global.ParallelTimeoutMinutes'        -Question 'Parallel timeout (minutes)' -Description 'Overall timeout (minutes).' -Value 5 -ValueType Int
    Add-ConfigurationQuestion -Section $globalSec -Code 'MaxParallelRunningJobs'      -Index ($iGlobal+2) -ConfigurationCode 'Global.MaxParallelRunningJobs'         -Question 'Max parallel running jobs' -Description 'Upper concurrency bound.' -Value 8 -ValueType Int
    Add-ConfigurationQuestion -Section $globalSec -Code 'GlobalParallelProcessing'    -Index ($iGlobal+3) -ConfigurationCode 'Global.GlobalParallelProcessing'       -Question 'Global parallel processing' -Description 'Activate parallel mechanisms.' -Value $true -PossibleValues @($true,$false) -ValueType Bool
    Add-ConfigurationQuestion -Section $globalSec -Code 'PerServerParallelProcessing' -Index ($iGlobal+4) -ConfigurationCode 'Global.PerServerParallelProcessing'    -Question 'Per-server parallel processing' -Description 'Parallel loops per server.' -Value $true -PossibleValues @($true,$false) -ValueType Bool
    Add-ConfigurationQuestion -Section $globalSec -Code 'DefaultDurationTracking'     -Index ($iGlobal+5) -ConfigurationCode 'Global.DefaultDurationTracking'        -Question 'Default duration tracking (days)' -Description 'Default lookback window.' -Value 30 -ValueType Int
    Add-ConfigurationQuestion -Section $globalSec -Code 'ESIProcessingType'           -Index ($iGlobal+6) -ConfigurationCode 'Global.ESIProcessingType'              -Question 'Processing Type (Online/On-Prem)' -Description 'Target environment string (placeholder).' -Value 'UNCONFIGUREDENTRYOnline' -PossibleValues @("On-Premises","Online")
    Add-ConfigurationQuestion -Section $globalSec -Code 'EnvironmentIdentification'   -Index ($iGlobal+7) -ConfigurationCode 'Global.EnvironmentIdentification'      -Question 'Environment Identification' -Description 'Identifier for environment.' -Value 'UNCONFIGUREDENTRYMyOwnEnvironment'
    $cfgSections.Add($globalSec) | Out-Null

    # ----- Advanced -----
    $advSec = New-SetupSection -Code 'AdvancedParameters' -Title 'Advanced Parameters' -Index 60 -Description 'Advanced behavior & performance.'
    Add-ConfigurationQuestion -Section $advSec -Code 'ParralelWaitRunning'              -Index ($iAdvanced+1)  -ConfigurationCode 'Advanced.ParralelWaitRunning'              -Question 'Parallel wait (s)' -Description 'Seconds to wait before timeout.' -Value 10 -ValueType Int
    Add-ConfigurationQuestion -Section $advSec -Code 'ParralelPingWaitRunning'          -Index ($iAdvanced+2)  -ConfigurationCode 'Advanced.ParralelPingWaitRunning'          -Question 'Parallel ping wait (s)' -Description 'Seconds waiting ping stage.' -Value 10 -ValueType Int
    Add-ConfigurationQuestion -Section $advSec -Code 'OnlyExplicitActivation'           -Index ($iAdvanced+3)  -ConfigurationCode 'Advanced.OnlyExplicitActivation'           -Question 'Only explicit activation' -Description 'Process only explicitly tagged functions.' -Value $false -PossibleValues @($true,$false) -ValueType Bool
    Add-ConfigurationQuestion -Section $advSec -Code 'ExchangeServerBinPath'            -Index ($iAdvanced+4)  -ConfigurationCode 'Advanced.ExchangeServerBinPath'            -Question 'Exchange Server BIN path' -Description 'Install path for Exchange binaries.' -Value 'c:\Program Files\Microsoft\Exchange Server\V15\bin'
    Add-ConfigurationQuestion -Section $advSec -Code 'BypassServerAvailabilityTest'     -Index ($iAdvanced+5)  -ConfigurationCode 'Advanced.BypassServerAvailabilityTest'     -Question 'Bypass server availability test' -Description 'Attempt collection even if unreachable.' -Value $false -PossibleValues @($true,$false) -ValueType Bool
    Add-ConfigurationQuestion -Section $advSec -Code 'ExplicitExchangeServerList'       -Index ($iAdvanced+6)  -ConfigurationCode 'Advanced.ExplicitExchangeServerList'       -Question 'Explicit Exchange server list' -Description 'Static semicolon server list.' -Value @() -ValueType Array
    Add-ConfigurationQuestion -Section $advSec -Code 'FunctionsListInline'              -Index ($iAdvanced+7)  -ConfigurationCode 'Advanced.FunctionsListInline'              -Question 'Functions list inline' -Description 'Read functions inline (retrocompat).' -Value $false -PossibleValues @($true,$false) -ValueType Bool
    Add-ConfigurationQuestion -Section $advSec -Code 'FunctionsListWithoutInternet'     -Index ($iAdvanced+8)  -ConfigurationCode 'Advanced.FunctionsListWithoutInternet'     -Question 'Functions list without internet' -Description 'Offline mode for functions.' -Value $false -PossibleValues @($true,$false) -ValueType Bool
    Add-ConfigurationQuestion -Section $advSec -Code 'Beta'                             -Index ($iAdvanced+9)  -ConfigurationCode 'Advanced.Beta'                             -Question 'Beta features' -Description 'Enable experimental functionality.' -Value $false -PossibleValues @($true,$false) -ValueType Bool
    Add-ConfigurationQuestion -Section $advSec -Code 'Useproxy'                         -Index ($iAdvanced+10) -ConfigurationCode 'Advanced.Useproxy'                         -Question 'Use proxy' -Description 'Enable outbound proxy use.' -Value $false -PossibleValues @($true,$false) -ValueType Bool
    Add-ConfigurationQuestion -Section $advSec -Code 'ProxyUrl'                         -Index ($iAdvanced+11) -ConfigurationCode 'Advanced.ProxyUrl'                         -Question 'Proxy URL' -Description 'Proxy endpoint.' -Value 'http://proxy.dom.net:8080'
    Add-ConfigurationQuestion -Section $advSec -Code 'MaximalSentinelPacketSizeMb'      -Index ($iAdvanced+12) -ConfigurationCode 'Advanced.MaximalSentinelPacketSizeMb'      -Question 'Max Sentinel packet size (MB)' -Description 'Maximum ingestion payload size.' -Value 32 -ValueType Int
    Add-ConfigurationQuestion -Section $advSec -Code 'PaginationErrorThreshold'         -Index ($iAdvanced+13) -ConfigurationCode 'Advanced.PaginationErrorThreshold'         -Question 'Pagination error threshold' -Description 'Abort after this many errors.' -Value 5 -ValueType Int
    Add-ConfigurationQuestion -Section $advSec -Code 'UpdateVersionCheckingDeactivated' -Index ($iAdvanced+14) -ConfigurationCode 'Advanced.UpdateVersionCheckingDeactivated' -Question 'Deactivate version checking' -Description 'Skip update/version check.' -Value $false -PossibleValues @($true,$false) -ValueType Bool
    Add-ConfigurationQuestion -Section $advSec -Code 'ExplicitESIDataPath'              -Index ($iAdvanced+15) -ConfigurationCode 'Advanced.ExplicitESIDataPath'              -Question 'Explicit ESI data path' -Description 'Override default data storage path.' -Value ''
    Add-ConfigurationQuestion -Section $advSec -Code 'DeactivateUDSLogs'                -Index ($iAdvanced+16) -ConfigurationCode 'Advanced.DeactivateUDSLogs'                -Question 'Deactivate UDS logs' -Description 'Suppress summary UDS logs.' -Value $false -PossibleValues @($true,$false) -ValueType Bool
    Add-ConfigurationQuestion -Section $advSec -Code 'LogVerboseActivated'              -Index ($iAdvanced+17) -ConfigurationCode 'Advanced.LogVerboseActivated'              -Question 'Verbose logging activated' -Description 'Enable verbose logging.' -Value $true -PossibleValues @($true,$false) -ValueType Bool

    # Complex: UDSLogProcessor (Array of objects)
    $udsDefault = @(
        [pscustomobject]@{ Activated = 'true';  StorageType='Output' },
        [pscustomobject]@{ Activated = 'false'; StorageType='File'; StoragePath='C:\ExchSecIns\data\Logs'; Prefix='ExchSecInsUDSLog'; LogStorageRetentionDays=30 },
        [pscustomobject]@{ Activated = 'false'; StorageType='AzureStorageAccount'; StorageAccountName='exchsecinslogs'; StorageBlobContainer='exchsecinslogs'; ConnexionType='ManagedIdentity'; Prefix='ExchSecInsUDSLog'; TenantId='UNCONFIGUREDENTRYWTenantID'; ApplicationID='UNCONFIGUREDENTRYWAppID'; CertificateThumbprint='UNCONFIGUREDENTRYWCertificateThumbprint' }
    )
    $udsSchema = @(
        @{ Name='Activated';                Type='Bool';   Required=$true;  Description='If true, this processor is active'; PossibleValues=@($true,$false) },
        @{ Name='StorageType';              Type='String'; Required=$true;  Description='Output | File | AzureStorageAccount'; PossibleValues=@('Output','File','AzureStorageAccount') },
        @{ Name='StoragePath';              Type='String'; Required=$true; Description='Path for File storage' ; Condition={ (($Entry['Activated'] -eq $true) -or ($Entry['Activated'] -eq 'true')) -and (($Entry['StorageType'] -eq 'File')) } },
        @{ Name='Prefix';                   Type='String'; Required=$false; Description='Prefix for file/blob naming'; Condition={ (($Entry['Activated'] -eq $true) -or ($Entry['Activated'] -eq 'true')) -and (($Entry['StorageType'] -ne 'Output')) } },
        @{ Name='LogStorageRetentionDays';  Type='Int';    Required=$false; Description='Retention days (File/Azure)'; Condition={ (($Entry['Activated'] -eq $true) -or ($Entry['Activated'] -eq 'true')) -and (($Entry['StorageType'] -ne 'Output'))  } },
        @{ Name='StorageAccountName';       Type='String'; Required=$true; Description='Azure Storage Account Name' ; Condition={ (($Entry['Activated'] -eq $true) -or ($Entry['Activated'] -eq 'true')) -and (($Entry['StorageType'] -eq 'AzureStorageAccount')) } },
        @{ Name='StorageBlobContainer';     Type='String'; Required=$true; Description='Azure Blob Container' ; Condition={ (($Entry['Activated'] -eq $true) -or ($Entry['Activated'] -eq 'true')) -and (($Entry['StorageType'] -eq 'AzureStorageAccount')) } },
        @{ Name='ConnexionType';            Type='String'; Required=$true; Description='ManagedIdentity | Certificate'; PossibleValues=@('ManagedIdentity','Certificate'); Condition={ (($Entry['Activated'] -eq $true) -or ($Entry['Activated'] -eq 'true')) -and (($Entry['StorageType'] -eq 'AzureStorageAccount')) } },
        @{ Name='TenantId';                 Type='String'; Required=$true; Description='Tenant Id for Azure storage'; Condition={ (($Entry['Activated'] -eq $true) -or ($Entry['Activated'] -eq 'true'))  -and (($Entry['StorageType'] -eq 'AzureStorageAccount')) } },
        @{ Name='ApplicationID';            Type='String'; Required=$true; Description='Application (Client) Id (Certificate mode)'; Condition={ (($Entry['Activated'] -eq $true) -or ($Entry['Activated'] -eq 'true')) -and (($Entry['ConnexionType'] -eq 'Certificate')) -and (($Entry['StorageType'] -eq 'AzureStorageAccount')) } },
        @{ Name='CertificateThumbprint';    Type='String'; Required=$false; Description='Cert thumbprint (Certificate mode)'; Condition={ (($Entry['Activated'] -eq $true) -or ($Entry['Activated'] -eq 'true')) -and (($Entry['ConnexionType'] -eq 'Certificate'))  -and (($Entry['StorageType'] -eq 'AzureStorageAccount')) } }
    )
    Add-ConfigurationQuestion -Section $advSec -Code 'UDSLogProcessor' -Index ($iAdvanced+18) -ConfigurationCode 'Advanced.UDSLogProcessor' `
        -Question 'UDS Log Processor (array of processors)' -Description 'Configure multiple log processors.' -Value $udsDefault -AsObjectArray -Schema $udsSchema

    $cfgSections.Add($advSec) | Out-Null

    # ----- Log Collection -----
    $logSec = New-SetupSection -Code 'LogCollectionParameters' -Title 'Log Collection Parameters' -Index 65 -Description 'Ingestion & output settings.'
    Add-ConfigurationQuestion -Section $logSec -Code 'ActivateLogUpdloadToSentinel' -Index ($iLog+1)  -ConfigurationCode 'LogCollection.ActivateLogUpdloadToSentinel' -Question 'Activate upload to Sentinel' -Description 'Enable API ingestion.' -Value $true -ValueType Bool -PossibleValues @($true,$false)
    Add-ConfigurationQuestion -Section $logSec -Code 'WorkspaceId'                  -Index ($iLog+4)  -ConfigurationCode 'LogCollection.WorkspaceId'                  -Question 'Workspace Id' -Description 'Workspace GUID' -Value 'UNCONFIGUREDENTRYWWorkspaceID' -Condition "Root[LogCollectionParameters].Collection[SentinelLogIngestionAPIActivated].Value -eq 'False'"
    Add-ConfigurationQuestion -Section $logSec -Code 'WorkspaceKey'                 -Index ($iLog+5)  -ConfigurationCode 'LogCollection.WorkspaceKey'                 -Question 'Workspace Key' -Description 'Shared key' -Value 'UNCONFIGUREDENTRYWKey' -Condition "Root[LogCollectionParameters].Collection[SentinelLogIngestionAPIActivated].Value -eq 'False'"
    Add-ConfigurationQuestion -Section $logSec -Code 'LogTypeName'                  -Index ($iLog+6)  -ConfigurationCode 'LogCollection.LogTypeName'                  -Question 'Log type (table) name' -Description 'Custom table name.' -Value 'ESIExchangeConfig' -Condition "Root[LogCollectionParameters].Collection[SentinelLogIngestionAPIActivated].Value -eq 'False'"
    Add-ConfigurationQuestion -Section $logSec -Code 'TogetherMode'                 -Index ($iLog+2)  -ConfigurationCode 'LogCollection.TogetherMode'                 -Question 'Together mode (file + API)' -Description 'Send to file and API.' -Value $false -ValueType Bool -PossibleValues @($true,$false) -Condition "Root[LogCollectionParameters].Collection[ActivateLogUpdloadToSentinel].Value -eq 'True'"
    Add-ConfigurationQuestion -Section $logSec -Code 'SentinelLogIngestionAPIActivated' -Index ($iLog+3) -ConfigurationCode 'LogCollection.SentinelLogIngestionAPIActivated' -Question 'Sentinel Log Ingestion API Activated' -Description 'Indicates Monitor ingestion API use.' -Value $true -ValueType Bool -PossibleValues @($true,$false)
    Add-ConfigurationQuestion -Section $logSec -Code 'DataCollectionEndpointURI'    -Index ($iLog+7)  -ConfigurationCode 'LogCollection.DataCollectionEndpointURI'   -Question 'Data Collection Endpoint URI' -Description 'Monitor ingestion endpoint.' -Value 'UNCONFIGUREDENTRYhttps://LogIngestionAPIURL.monitor.azure.com' -Condition "Root[LogCollectionParameters].Collection[ActivateLogUpdloadToSentinel].Value -eq 'True' -and Root[LogCollectionParameters].Collection[SentinelLogIngestionAPIActivated].Value -eq 'True'"
    Add-ConfigurationQuestion -Section $logSec -Code 'DCRImmutableId'               -Index ($iLog+8)  -ConfigurationCode 'LogCollection.DCRImmutableId'              -Question 'DCR Immutable Id' -Description 'Immutable DCR Id.' -Value 'UNCONFIGUREDENTRYWDCRImmutableId' -Condition "Root[LogCollectionParameters].Collection[ActivateLogUpdloadToSentinel].Value -eq 'True' -and Root[LogCollectionParameters].Collection[SentinelLogIngestionAPIActivated].Value -eq 'True'"
    Add-ConfigurationQuestion -Section $logSec -Code 'UseManagedIdentity'           -Index ($iLog+9)  -ConfigurationCode 'LogCollection.UseManagedIdentity'           -Question 'Use Managed Identity' -Description 'Use Managed Identity for authentication.' -Value $false -ValueType Bool -PossibleValues @($true,$false) -Condition "Root[LogCollectionParameters].Collection[ActivateLogUpdloadToSentinel].Value -eq 'True' -and Root[LogCollectionParameters].Collection[SentinelLogIngestionAPIActivated].Value -eq 'True'"
    Add-ConfigurationQuestion -Section $logSec -Code 'TargetLogTenantID'            -Index ($iLog+10)  -ConfigurationCode 'LogCollection.TargetLogTenantID'           -Question 'Target Log Tenant ID' -Description 'Tenant Id.' -Value 'UNCONFIGUREDENTRYWTenantID' -Condition "Root[LogCollectionParameters].Collection[ActivateLogUpdloadToSentinel].Value -eq 'True' -and Root[LogCollectionParameters].Collection[SentinelLogIngestionAPIActivated].Value -eq 'True'"
    Add-ConfigurationQuestion -Section $logSec -Code 'TargetLogAppID'               -Index ($iLog+11) -ConfigurationCode 'LogCollection.TargetLogAppID'              -Question 'Target Log App ID' -Description 'App (Client) Id.' -Value 'UNCONFIGUREDENTRYWAppID' -Condition "Root[LogCollectionParameters].Collection[ActivateLogUpdloadToSentinel].Value -eq 'True' -and Root[LogCollectionParameters].Collection[SentinelLogIngestionAPIActivated].Value -eq 'True' -and Root[LogCollectionParameters].Collection[UseManagedIdentity].Value -eq 'False'"
    Add-ConfigurationQuestion -Section $logSec -Code 'TargetLogAppSecretReference'  -Index ($iLog+12) -ConfigurationCode 'LogCollection.TargetLogAppSecretReference' -Question 'Target Log App Secret Reference' -Description 'Automation/KV secret ref.' -Value 'UNCONFIGUREDENTRYWAppSecretReference-AutomationVariableName' `
        -Condition "Root[LogCollectionParameters].Collection[ActivateLogUpdloadToSentinel].Value -eq 'True' -and Root[LogCollectionParameters].Collection[SentinelLogIngestionAPIActivated].Value -eq 'True' -and Root[LogCollectionParameters].Collection[UseManagedIdentity].Value -eq 'False'"
    Add-ConfigurationQuestion -Section $logSec -Code 'TargetLogCertificateThumbprint'  -Index ($iLog+13) -ConfigurationCode 'LogCollection.TargetLogCertificateThumbprint' -Question 'Target Log Certificate Thumbprint' -Description 'Thumbprint of existing Certificate in the server.' -Value 'UNCONFIGUREDENTRYWCertificateThumbprint' `
        -Condition "Root[LogCollectionParameters].Collection[ActivateLogUpdloadToSentinel].Value -eq 'True' -and Root[LogCollectionParameters].Collection[SentinelLogIngestionAPIActivated].Value -eq 'True' -and Root[LogCollectionParameters].Collection[UseManagedIdentity].Value -eq 'False'"
    Add-ConfigurationQuestion -Section $logSec -Code 'CSVOutputFile'                -Index ($iLog+14) -ConfigurationCode 'LogCollection.CSVOutputFile'               -Question 'CSV Output File Name' -Description 'Local CSV file name.' -Value 'ExchSecIns.csv' -Condition "Root[LogCollectionParameters].Collection[TogetherMode].Value -eq 'True' -or Root[LogCollectionParameters].Collection[ActivateLogUpdloadToSentinel].Value -eq 'False'"
    Add-ConfigurationQuestion -Section $logSec -Code 'ExportDomainsInformation'     -Index ($iLog+15) -ConfigurationCode 'LogCollection.ExportDomainsInformation'    -Question 'Export Domains Information' -Description 'Include domain info.' -Value $true -PossibleValues @($true,$false,'True','False') -ValueType Bool
    $cfgSections.Add($logSec) | Out-Null

    # ----- Internet Addon -----
    $internetSec = New-SetupSection -Code 'InternetAddonCollectionConfigurationParameters' -Title 'Internet Addon Collection Parameters' -Index 68 -Description 'External Add-on retrieval & GitHub settings.'
    Add-ConfigurationQuestion -Section $internetSec -Code 'UseGithubAPI'                 -Index ($iInternet+1) -ConfigurationCode 'InternetAddonCollectionConfiguration.UseGithubAPI' -Question 'Use GitHub API' -Description 'Use authenticated API.' -Value $false -ValueType Bool -PossibleValues @($true,$false)
    Add-ConfigurationQuestion -Section $internetSec -Code 'GithubRawUrlforOnPremises'    -Index ($iInternet+2) -ConfigurationCode 'InternetAddonCollectionConfiguration.GithubRawUrlforOnPremises' -Question 'Raw URL (On-Premises)' -Description 'Raw On-Prem add-ons url.' -Value 'https://raw.githubusercontent.com/Azure/Azure-Sentinel/refs/heads/master/Solutions/Microsoft%20Exchange%20Security%20-%20Exchange%20On-Premises/%23%20-%20General%20Content/Operations/ESICollector-Addons'
    Add-ConfigurationQuestion -Section $internetSec -Code 'GithubRawUrlforOnline'        -Index ($iInternet+3) -ConfigurationCode 'InternetAddonCollectionConfiguration.GithubRawUrlforOnline' -Question 'Raw URL (Online)' -Description 'Raw Online add-ons url.' -Value 'https://raw.githubusercontent.com/Azure/Azure-Sentinel/refs/heads/master/Solutions/Microsoft%20Exchange%20Security%20-%20Exchange%20Online/%23%20-%20General%20Content/Operations/ESICollector-Addons'
    Add-ConfigurationQuestion -Section $internetSec -Code 'GithubAPIToken'               -Index ($iInternet+4) -ConfigurationCode 'InternetAddonCollectionConfiguration.GithubAPIToken' -Question 'GitHub API Token' -Description 'PAT (secure).' -Value 'UNCONFIGUREDENTRYWToken' -ValueType 'SecureString' -Condition "Root[InternetAddonCollectionConfigurationParameters].Collection[UseGithubAPI].Value -eq 'true' -and Root[InternetAddonCollectionConfigurationParameters].Collection[GithubAPIConnectionType].Value -ne 'NoAuth'"
    Add-ConfigurationQuestion -Section $internetSec -Code 'GithubAPITokenVariableName'   -Index ($iInternet+5) -ConfigurationCode 'InternetAddonCollectionConfiguration.GithubAPITokenVariableName' -Question 'GitHub Token Variable Name' -Description 'Automation variable name.' -Value 'UNCONFIGUREDENTRYWTokenVariableName' -Condition "Root[InternetAddonCollectionConfigurationParameters].Collection[UseGithubAPI].Value -eq 'true' -and Root[InternetAddonCollectionConfigurationParameters].Collection[GithubAPIConnectionType].Value -ne 'NoAuth'"
    Add-ConfigurationQuestion -Section $internetSec -Code 'GithubAPITokenSecretReference' -Index ($iInternet+6) -ConfigurationCode 'InternetAddonCollectionConfiguration.GithubAPITokenSecretReference' -Question 'GitHub Token Secret Reference' -Description 'Secret ref name.' -Value 'UNCONFIGUREDENTRYWTokenSecretReference-AutomationVariableName' -Condition "Root[InternetAddonCollectionConfigurationParameters].Collection[UseGithubAPI].Value -eq 'true' -and Root[InternetAddonCollectionConfigurationParameters].Collection[GithubAPIConnectionType].Value -ne 'NoAuth'"
    Add-ConfigurationQuestion -Section $internetSec -Code 'GithubAPIConnectionType'      -Index ($iInternet+7) -ConfigurationCode 'InternetAddonCollectionConfiguration.GithubAPIConnectionType' -Question 'GitHub API Connection Type' -Description 'Auth mode.' -Value 'NoAuth' -PossibleValues @('NoAuth','PAT','Other') -Condition "Root[InternetAddonCollectionConfigurationParameters].Collection[UseGithubAPI].Value -eq 'true'"
    $cfgSections.Add($internetSec) | Out-Null

    # ----- Graph -----
    $graphSec = New-SetupSection -Code 'MGGraphAPIConnectionParameters' -Title 'MGGraph API Connection Parameters' -Index 70 -Description 'Microsoft Graph connectivity.'
    Add-ConfigurationQuestion -Section $graphSec -Code 'MGGraphAzureRMCertificate' -Index ($iGraph+1) -ConfigurationCode 'MGGraphAPIConnection.MGGraphAzureRMCertificate' -Question 'Graph Azure RM Certificate' -Description 'Thumbprint / cert reference.' -Value ''
    Add-ConfigurationQuestion -Section $graphSec -Code 'MGGraphAzureRMAppId'       -Index ($iGraph+2) -ConfigurationCode 'MGGraphAPIConnection.MGGraphAzureRMAppId'       -Question 'Graph Azure RM App Id' -Description 'Client Id.' -Value ''
    $cfgSections.Add($graphSec) | Out-Null

    # ----- InstanceConfiguration (Hashtable -> ObjectMap) -----
    $instanceSec = New-SetupSection -Code 'InstanceConfigurationParameters' -Title 'Instance Configuration' -Index 72 -Description 'Instances (map of objects).'
    $instanceValue = [pscustomobject]@{
        Default = [pscustomobject]@{ All='true'; Capabilities='OP|OL|MGGRAPH|ADINFOS' }
        'IIS-IoCs' = [pscustomobject]@{ All='true'; Category='IIS-IoCs'; Capabilities='IIS'; OutputName='ESIIISIoCs' }
        ExchangeOnlineMessageTracking = [pscustomobject]@{ All='true'; Category='OnlineMessageTracking'; Capabilities='OL'; OutputName='ExchangeOnlineMessageTracking' }
        InstanceExample = [pscustomobject]@{ SelectedAddons=@('Filename1','Filename2'); FileteredAddons=@('Filename1','Filename2') }
    }
    $instanceSchema = @(
        @{ Name='All';            Type='Bool';    Required=$false; Description='Activate all functions'; PossibleValues=@($true,$false,'true','false') },
        @{ Name='Category';       Type='String';  Required=$false; Description='Category tag' },
        @{ Name='Capabilities';   Type='String';  Required=$false; Description='Capability string' },
        @{ Name='OutputName';     Type='String';  Required=$false; Description='Output table/file name' },
        @{ Name='SelectedAddons'; Type='Array';   Required=$false; Description='Selected add-ons filenames' },
        @{ Name='FileteredAddons';Type='Array';   Required=$false; Description='Filtered (excluded) add-ons filenames' }
    )
    Add-ConfigurationQuestion -Section $instanceSec -Code 'InstanceConfiguration' -Index ($iComplex+1) -ConfigurationCode 'InstanceConfiguration' `
        -Question 'Instance Configuration Map' -Description 'Hashtable of named instances.' -Value $instanceValue -AsObjectMap -Schema $instanceSchema
    $cfgSections.Add($instanceSec) | Out-Null

    # ----- AuditFunctionsFiles (Array of objects) -----
    $auditFilesSec = New-SetupSection -Code 'AuditFunctionsFilesParameters' -Title 'AuditFunctionsFiles Parameters' -Index 75 -Description 'Audit function files ignore list.'
    $auditFilesValue = @(
        [pscustomobject]@{ Filename='FiletoIgnore'; Deactivated='false' }
    )
    $auditFilesSchema = @(
        @{ Name='Filename';    Type='String'; Required=$true;  Description='Filename to ignore' },
        @{ Name='Deactivated'; Type='Bool';   Required=$false; Description='Deactivate file'; PossibleValues=@($true,$false,'true','false') }
    )
    Add-ConfigurationQuestion -Section $auditFilesSec -Code 'AuditFunctionsFiles' -Index ($iAuditF+1) -ConfigurationCode 'AuditFunctionsFiles' `
        -Question 'Audit Functions Files array' -Description 'List of function-group files to deactivate.' -Value $auditFilesValue -AsObjectArray -Schema $auditFilesSchema
    $cfgSections.Add($auditFilesSec) | Out-Null

    # ----- AuditFunctionProtectedArea -----
    $auditProtSec = New-SetupSection -Code 'AuditFunctionProtectedAreaParameters' -Title 'AuditFunctionProtectedArea' -Index 80 -Description 'Protected / reserved.'
    Add-ConfigurationQuestion -Section $auditProtSec -Code 'ContentCheckSum' -Index ($iAuditP+1) -ConfigurationCode 'AuditFunctionProtectedArea.ContentCheckSum' -Question 'Content CheckSum' -Description 'Integrity placeholder.' -Value ''
    $cfgSections.Add($auditProtSec) | Out-Null

    # ----- Misc (AuditFunctions root array placeholder) -----
    $miscSec = New-SetupSection -Code 'MiscAdvancedParameters' -Title 'Miscellaneous Advanced Parameters' -Index 85 -Description 'Misc placeholders.'
    Add-ConfigurationQuestion -Section $miscSec -Code 'AuditFunctions' -Index ($iMisc+1) -ConfigurationCode 'AuditFunctions' -Question 'AuditFunctions array (legacy placeholder)' -Description 'Legacy root audit functions array.' -Value @() -ValueType Array -Hidden
    $cfgSections.Add($miscSec) | Out-Null

    return $cfgSections
}