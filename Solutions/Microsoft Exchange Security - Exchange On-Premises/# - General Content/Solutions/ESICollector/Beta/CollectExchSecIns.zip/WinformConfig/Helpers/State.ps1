<#
State.ps1
UPDATED:
 - Removed legacy grid arrays (UDSRows / InstanceRows) from active usage; kept placeholders for backward compatibility but marked deprecated.
 - Telemetry logging on initialization unchanged.
#>

param(
    [string]$InitialConfigPath,
    [int]$LogRetentionDays = 7
)

$Global:BaselineEffectiveConfig = $null

$Global:AppState = [ordered]@{
    Sections            = $null
    SectionLookup       = @{}
    QuestionsLookup     = @{}
    CurrentConfig       = $null
    ConfigPath          = $null
    Dirty               = $false
    ReadOnly            = $true
    UndoStack           = New-Object System.Collections.Stack
    RedoStack           = New-Object System.Collections.Stack
    UndoMax             = 30
    # Deprecated (legacy grid data – retained for backwards compatibility only)
    UDSRows             = New-Object System.Collections.ArrayList
    InstanceRows        = New-Object System.Collections.ArrayList
    MainForm            = $null
    CurrentEditorMode   = 'Sections'
    CurrentSectionCode  = $null
    ControlBindings     = @{}
    LogDirectory        = (Join-Path $PSScriptRoot 'logs')
    LogFile             = $null
    TelemetryFile       = $null
    ErrorLogFile        = $null
    SessionId           = [guid]::NewGuid().ToString()
    LastSnapshotHash    = $null
    LogRetentionDays    = $LogRetentionDays
    AdvancedBypassMandatory = $false
    AzureConnected      = $false
    GraphConnected      = $false
    AzureContextName    = "MESSetup"
    AzureTenant                  = $null
    AzureTenantDisplay           = $null
    AzureSubscriptions           = @()
    AzureSelectedSubscriptionId  = $null
    AzureSelectedSubscriptionName= $null
    ShowHiddenQuestions = $false
}

function Initialize-State {
    param([string]$ConfigPath)

    if (-not (Test-Path -LiteralPath $Global:AppState.LogDirectory)) {
        New-Item -ItemType Directory -Path $Global:AppState.LogDirectory | Out-Null
    }

    if ($Global:AppState.LogRetentionDays -gt 0) {
        try {
            $threshold = (Get-Date).AddDays(-[math]::Abs($Global:AppState.LogRetentionDays))
            Get-ChildItem -LiteralPath $Global:AppState.LogDirectory -File -ErrorAction SilentlyContinue |
                Where-Object { $_.LastWriteTime -lt $threshold } |
                ForEach-Object {
                    try { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop } catch {}
                }
        } catch {}
    }

    $timestamp = (Get-Date -Format 'yyyyMMdd_HHmmss')
    $Global:AppState.LogFile       = Join-Path $Global:AppState.LogDirectory "actions_$timestamp.log"
    $Global:AppState.TelemetryFile = Join-Path $Global:AppState.LogDirectory "telemetry_$timestamp.jsonl"
    $Global:AppState.ErrorLogFile  = Join-Path $Global:AppState.LogDirectory "errors_$timestamp.log"

    $Global:AppState.Sections = Build-SetupConfiguration
    foreach ($sec in $Global:AppState.Sections) {
        $Global:AppState.SectionLookup[$sec.Code] = $sec
        foreach ($q in $sec.Collection) {
            $q.SectionCode = $sec.Code
            $Global:AppState.QuestionsLookup["$($sec.Code)|$($q.Code)"] = $q
        }
        foreach ($sub in $sec.WizardSectionCode) {
            $Global:AppState.SectionLookup[$sub.Code] = $sub
            foreach ($s in $sub.Collection) {
                $s.SectionCode = $sub.Code
                $Global:AppState.QuestionsLookup["$($sec.Code).$($sub.Code)|$($s.Code)"] = $s
            }
        }
    }

    if ($ConfigPath -and (Test-Path -LiteralPath $ConfigPath)) {
        try {
            $json = Get-Content -LiteralPath $ConfigPath -Raw
            $Global:AppState.CurrentConfig = $json | ConvertFrom-Json -Depth 80
            $Global:AppState.ConfigPath = (Resolve-Path -LiteralPath $ConfigPath).Path
        } catch {
            $Global:AppState.CurrentConfig = [pscustomobject]@{}
        }
    } else {
        $Global:AppState.CurrentConfig = [pscustomobject]@{
            Global = [pscustomobject]@{}
            LogCollection = [pscustomobject]@{}
            Advanced = [pscustomobject]@{}
            InstanceConfiguration = [pscustomobject]@{}
        }
    }
}
Initialize-State -ConfigPath $InitialConfigPath