<#
Models.Setup.ps1
UPDATE (Wizard refactor + Execute question support):
 - Removed question-level wizard flag usage (unchanged from prior refactor).
 - Added section-level WizardSectionCode on subsections.
NEW (Execute support):
 - Added an "Execute" type question for the DCR subsection:
     * Code: DeployDCR
     * ValueType: Execute
     * ValidationHookFunction: DeployDCR
     * Condition: Only visible when "Create a DCR?" == 'Yes'
   This renders as a button in the UI (see UI.Sections.ps1 changes) which, when pressed,
   invokes the DeployDCR function (placeholder added in Utilities.ps1). Result & any returned
   key/value configuration updates are shown in dedicated panels below the button.
#>

. $PSScriptRoot\Models.Common.ps1

function Build-SetupModel {
    $SetupConfiguration = [System.Collections.Generic.List[SetupSection]]::new()

    $Basic = New-SetupSection -Code "Basic" -Title "Basic Information" -Index 1 `
        -Description "Setup the basic context for the configuration."
    $Basic.Collection.Add( (New-SetupQuestion -Code "SetupEnvironment" -Index 1 -ConfigurationCode "Global.ESIProcessingType" `
        -Question "What is the target of the configuration ?" `
        -Description "Exchange On-Premises or Exchange Online." `
        -PossibleValues @("On-Premises","Online")) )
    $Basic.Collection.Add( (New-SetupQuestion -Code "EnvironmentExecution" -Index 2 `
        -Question "Where will the script run ?" `
        -Description "Azure Automation or Server host." `
        -PossibleValues @("Azure Automation","Server") -Value "Azure Automation") )
    $Basic.Collection.Add( (New-SetupQuestion -Code "EnvironmentIdentification" -Index 3 -ConfigurationCode "Global.EnvironmentIdentification" `
        -Question "Environment identification string" `
        -Description "Used in Sentinel workbooks; '#ForestName#' auto-substituted on-prem." `
        -Value "#ForestName#" -ValidationHookFunction "Set-EnvironmentIdentification") )
    $Basic.Collection.Add( (New-SetupQuestion -Code "InstanceType" -Index 4 `
        -Question "Instance type (default vs IIS IoC) ?" `
        -Description "Def: Exchange configuration; IoC: IIS log artifacts." `
        -PossibleValues @("Def","IoC") -Value "Def") )
    $Basic.Collection.Add( (New-SetupQuestion -Code "MonitorAPICollection" -Index 5 `
        -Question "Which ingestion API?" `
        -Description "AzureMonitorAPI (recommended) or legacy LogAnaltyicsAPI." `
        -PossibleValues @("AzureMonitorAPI","LogAnaltyicsAPI") -Value "AzureMonitorAPI") )
    $SetupConfiguration.Add($Basic)

    $AzureAutomation = New-SetupSection -Code "AzureAutomationInformation" -Title "Azure Automation Information" -Index 2 `
        -Description "Parameters when using Azure Automation for storing logs." `
        -Condition "Root[Basic].Collection[EnvironmentExecution].Value -eq 'Azure Automation'"
    $AzureAutomation.Collection.Add( (New-SetupQuestion -Code "ExchangeCollectorManagedIdentityID" -Index 1 `
        -Question "Managed Identity ID" -Description "GUID of the managed identity.") )
    $AzureAutomation.Collection.Add( (New-SetupQuestion -Code "ExchangeCollectorTenantID" -Index 2 `
        -Question "Tenant ID" -Description "GUID of the tenant where the Automation is running.") )
    $AzureAutomation.Collection.Add( (New-SetupQuestion -Code "ApplyAutomationPermissionExchangeOnline" -Index 3 `
        -Question "Apply Automation Permission (Exchange Online)" `
        -Description "Apply Graph API and Exchange Online access to Managed Identity of the Automation" `
        -ValueType "Execute" `
        -ValidationHookFunction "ApplyExchangePermissionLogAnalytics") )
    $SetupConfiguration.Add($AzureAutomation)

    $LogAnalyticsAPIInformation = New-SetupSection -Code "LogAnalyticsAPIInformation" -Title "Log Analytics API Information" -Index 2 `
        -Description "Parameters when using legacy Log Analytics ingestion." `
        -Condition "Root[Basic].Collection[MonitorAPICollection].Value -eq 'LogAnaltyicsAPI'"
    $LogAnalyticsAPIInformation.Collection.Add( (New-SetupQuestion -Code "LogMonitorUsingAnalytics" -Index 1 -ConfigurationCode "LogCollection.SentinelLogIngestionAPIActivated" -Hidden `
        -Question "Internal flag (legacy)" -Value "false") )
    $LogAnalyticsAPIInformation.Collection.Add( (New-SetupQuestion -Code "WorkspaceId" -Index 2 -ConfigurationCode "LogCollection.WorkspaceId" `
        -Question "Log Analytics Workspace Id" -Description "GUID of workspace.") )
    $LogAnalyticsAPIInformation.Collection.Add( (New-SetupQuestion -Code "WorkspaceKey" -Index 3 -ConfigurationCode "LogCollection.WorkspaceKey" `
        -Question "Log Analytics Workspace Key" -Description "Shared key for ingestion.") )
    $SetupConfiguration.Add($LogAnalyticsAPIInformation)

    $AzureMonitorAPIInformation = New-SetupSection -Code "AzureMonitorAPIInformation" -Title "Azure Monitor API Information" -Index 3 `
        -Description "Parameters for Azure Monitor ingestion." `
        -Condition "Root[Basic].Collection[MonitorAPICollection].Value -eq 'AzureMonitorAPI'"
    $AzureMonitorAPIInformation.Collection.Add( (New-SetupQuestion -Code "TenantId" -Index 1 -ConfigurationCode "LogCollection.TargetLogTenantID" `
        -Question "Tenant Id" -Description "Tenant Id used for ingestion authentication." ) )
    $AzureMonitorAPIInformation.Collection.Add( (New-SetupQuestion -Code "EntraIDUseManagedIdentity" -Index 2 `
        -Question "Do you want to use a managed identity?" `
        -Description "If 'No', provide Entra ID App details." -ConfigurationCode "LogCollection.UseManagedIdentity" `
        -PossibleValues @("True","False") -Value "False" -ValueType 'Boolean') )
    # --- Subsections with Section-level WizardSectionCode ---

    $EntraIDApplicationInformation = New-SetupSection -Code "EntraIDApplicationInformation" -Title "Entra ID Application" -Index 1 `
        -Description "Application registration to push logs." `
        -Condition "Root[AzureMonitorAPIInformation].Collection[EntraIDUseManagedIdentity].Value -ne 'Yes'"
    $EntraIDApplicationInformation.Collection.Add( (New-SetupQuestion -Code "EntraIDApplicationCreation" -Index 1 `
        -Question "Create the Entra ID Application?" `
        -Description "If 'No', provide existing App details." `
        -PossibleValues @("Yes","No") -Value "No" -ValueType 'YesNo' -Hidden $true) )
    $EntraIDApplicationInformation.Collection.Add( (New-SetupQuestion -Code "ApplicationName" -Index 2 `
        -Question "New Application Name" `
        -Description "Used only if application creation is 'Yes'." -Value 'UNCONFIGUREDENTRY' `
        -Condition "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[EntraIDApplicationCreation].Value -eq 'Yes'") )
    $EntraIDApplicationInformation.Collection.Add( (New-SetupQuestion -Code "ApplicationId" -Index 4 `
        -Question "Existing Application (Client) ID" `
        -Description "App ID when not creating new app."  -Value 'UNCONFIGUREDENTRY' `
        -Condition "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[EntraIDApplicationCreation].Value -eq 'No'" `
        -ConfigurationCode "LogCollection.TargetLogAppID") )
    $EntraIDApplicationInformation.Collection.Add( (New-SetupQuestion -Code "ApplicationCertificate" -Index 5 `
        -Question "Certificate Thumbprint (existing app)" `
        -Description "40 hex characters certificate thumbprint." -Value 'UNCONFIGUREDENTRY' `
        -ConfigurationCode 'LogCollection.TargetLogCertificateThumbprint' `
        -ValidationHookFunction "Set-ApplicationCertificate" `
        -Condition "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[EntraIDApplicationCreation].Value -eq 'No'") )
    $EntraIDApplicationInformation.Collection.Add( (New-SetupQuestion -Code "ApplicationCertificateNew" -Index 6 `
        -Question "Certificate Path (new app)" `
        -Description "Enter the path of the Certificate that will be used when creating the Entra ID Application." -Value 'UNCONFIGUREDENTRY' `
        -ValidationHookFunction "Verify-Path" `
        -Condition "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[EntraIDApplicationCreation].Value -eq 'Yes'") )
    $EntraIDApplicationInformation.Collection.Add( (New-SetupQuestion -Code "CreateApplication" -Index 11 `
        -Question "Create Application" `
        -Description "Execute Creation of Entra ID Application and populate related fields." `
        -Condition "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[EntraIDApplicationCreation].Value -eq 'Yes'" `
        -ValueType "Execute" `
        -ValidationHookFunction "Create-EntraIDApplication") )

    $DCRInformation = New-SetupSection -Code "DCRInformation" -Title "Data Collection Rule" -Index 2 `
        -Description "DCR creation / linkage settings."
    $DCRInformation.Collection.Add( (New-SetupQuestion -Code "DCRCreation" -Index 1 `
        -Question "Create a DCR?" `
        -Description "If No, provide existing DCR details. If Yes, the DCR will be created in Azure" `
        -PossibleValues @("Yes","No") -Value "No" -ValueType 'YesNo' -Hidden $true) )
    $DCRInformation.Collection.Add( (New-SetupQuestion -Code "DCRPermission" -Index 2 `
        -Question "Assign application permissions to DCR?" `
        -Description "If Yes, the application will be granted Contributor role on the DCR resource. Else you need to apply permission manually" `
        -PossibleValues @("Yes","No") -Value "No" -ValueType 'YesNo' -Hidden $true) )
    $DCRInformation.Collection.Add( (New-SetupQuestion -Code "DCRName" -Index 3 `
        -Question "DCR Name (create)" -Value 'UNCONFIGUREDENTRY' `
        -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'Yes'") )
    $DCRInformation.Collection.Add( (New-SetupQuestion -Code "DCRResourceGroup" -Index 4 `
        -Question "DCR Resource Group" -Value 'UNCONFIGUREDENTRY' `
        -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'Yes'") )
    $DCRInformation.Collection.Add( (New-SetupQuestion -Code "DCRRegion" -Index 5 `
        -Question "DCR Region" -Value 'UNCONFIGUREDENTRY' `
        -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'Yes'") )
    $DCRInformation.Collection.Add( (New-SetupQuestion -Code "DCRNameForPermission" -Index 6 `
        -Question "Existing DCR Name (permission assignment)" -Value 'UNCONFIGUREDENTRY' `
        -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'No' -and Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRPermission].Value -eq 'Yes'") )
    $DCRInformation.Collection.Add( (New-SetupQuestion -Code "endpoint_uri" -Index 7 `
        -Question "DCR Ingestion Endpoint URI" -Value 'UNCONFIGUREDENTRY' `
        -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'No'" -ConfigurationCode 'LogCollection.DataCollectionEndpointURI' ))
    $DCRInformation.Collection.Add( (New-SetupQuestion -Code "dcrImmutableId" -Index 8 `
        -Question "DCR Immutable ID" -Value 'UNCONFIGUREDENTRY' `
        -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'No'" -ConfigurationCode 'LogCollection.DCRImmutableId' ))
    # NEW EXECUTE QUESTION (button)
    $DCRInformation.Collection.Add( (New-SetupQuestion -Code "DeployDCR" -Index 11 `
        -Question "Deploy DCR" `
        -Description "Execute deployment of the Data Collection Rule and populate related fields." `
        -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'Yes'" `
        -ValueType "Execute" `
        -ValidationHookFunction "DeployDCR") )
    $DCRInformation.Collection.Add( (New-SetupQuestion -Code "ApplyDCRPermission" -Index 13 `
        -Question "Apply DCR Permissions" `
        -Description "Execute application of permissions for the Data Collection Rule." `
        -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRPermission].Value -eq 'Yes'" `
        -ValueType "Execute" `
        -ValidationHookFunction "ApplyDCRPermission") )

    $AzureMonitorAPIInformation.WizardSectionCode.Add($EntraIDApplicationInformation)
    $AzureMonitorAPIInformation.WizardSectionCode.Add($DCRInformation)
    $SetupConfiguration.Add($AzureMonitorAPIInformation)

    $ExchangeOnPrem = New-SetupSection -Code "ExchangeOnPremisesInformation" -Title "Exchange On-Premises Information" -Index 4 `
        -Description "On-Premises Exchange related configuration." `
        -Condition "Root[Basic].Collection[SetupEnvironment].Value -eq 'On-Premises'"
    $ExchangeOnPrem.Collection.Add( (New-SetupQuestion -Code "ExchangeServerBinPath" -Index 1 -ConfigurationCode "Advanced.ExchangeServerBinPath" `
        -Question "Exchange BIN Path" -Description "Path to Exchange server bin directory." -Value "c:\Program Files\Microsoft\Exchange Server\V15\bin") )
    $ExchangeOnPrem.Collection.Add( (New-SetupQuestion -Code "ExchangeVersion" -Index 2 `
        -Question "Exchange Version" -Description "e.g., 2016/2019" -Value "2016") )
    $SetupConfiguration.Add($ExchangeOnPrem)

    $InstanceInfo = New-SetupSection -Code "InstanceInformation" -Title "Instance Information" -Index 5 `
        -Description "Multiple instances for varied scopes." `
        -Condition "Root[Basic].Collection[EnvironmentExecution].Value -eq 'Server'"
    $InstanceInfo.Collection.Add( (New-SetupQuestion -Code "InstanceType" -Index 1 `
        -Question "Instance Type" -Description "Default or IIS IoC." -PossibleValues @("Default","IIS IoC") -Value "Default") )
    $SetupConfiguration.Add($InstanceInfo)

    $ServerExecution = New-SetupSection -Code "ServerExecution" -Title "Server Execution" -Index 6 `
        -Description "Scheduled Task configuration (server mode)." `
        -Condition "Root[Basic].Collection[EnvironmentExecution].Value -eq 'Server'"
    $ServerExecution.Collection.Add( (New-SetupQuestion -Code "ScheduleTask" -Index 1 `
        -Question "Create Scheduled Task?" -PossibleValues @("Yes","No") -Value "Yes") )
    $ServerExecution.Collection.Add( (New-SetupQuestion -Code "ScheduleTaskName" -Index 2 `
        -Question "Scheduled Task Name" -Value "ESI - Exchange Security Configuration Collector" `
        -Condition "Root[ServerExecution].Collection[ScheduleTask].Value -eq 'Yes'") )
    $ServerExecution.Collection.Add( (New-SetupQuestion -Code "ScheduleTaskStartTime" -Index 3 `
        -Question "Scheduled Start Time (hh:mmAM/PM)" -Regex "^[0-9]{1,2}:[0-9]{1,2}(AM|PM)$" -Value "00:00" `
        -Condition "Root[ServerExecution].Collection[ScheduleTask].Value -eq 'Yes'") )
    $ServerExecution.Collection.Add( (New-SetupQuestion -Code "ScheduleTaskUser" -Index 4 `
        -Question "Service Account UPN" -Regex "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$" `
        -Condition "Root[ServerExecution].Collection[ScheduleTask].Value -eq 'Yes'") )
    $ServerExecution.Collection.Add( (New-SetupQuestion -Code "ScheduleTaskPassword" -Index 5 `
        -Question "Service Account Password" -ValueType "SecureString" `
        -Condition "Root[ServerExecution].Collection[ScheduleTask].Value -eq 'Yes'") )
    $ServerExecution.Collection.Add( (New-SetupQuestion -Code "CreateScheduledTask" -Index 13 `
        -Question "Create the Schedule Task" `
        -Description "Execute a script to create a scheduled task on the current server." `
        -Condition "Root[ServerExecution].Collection[ScheduleTask].Value -eq 'Yes'" `
        -ValueType "Execute" `
        -ValidationHookFunction "CreateScheduledTask") )
    $SetupConfiguration.Add($ServerExecution)

    foreach ($sec in $SetupConfiguration) {
        foreach ($q in $sec.Collection) {
            $q.SetupStatus='Enabled'; if (-not $q.OriginalSetupStatus) { $q.OriginalSetupStatus='Enabled' }
        }
        foreach ($sub in $sec.WizardSectionCode) {
            foreach ($q in $sub.Collection) {
                $q.SetupStatus='Enabled'; if (-not $q.OriginalSetupStatus) { $q.OriginalSetupStatus='Enabled' }
            }
        }
    }

    return $SetupConfiguration
}