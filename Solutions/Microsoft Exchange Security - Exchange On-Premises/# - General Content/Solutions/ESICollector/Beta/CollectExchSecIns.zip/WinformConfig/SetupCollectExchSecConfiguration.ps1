<#
Main (Updated)
Changes (current patch):
 - Added Read-Only / Write mode toggle on the left side of the status bar.
 - Default remains Read-Only (as already set in AppState).
 - Toggle button text & color reflect current mode (LightGray = Read-Only, LightGreen = Write).
 - Central Update-ReadOnlyUI function enforces mode across:
     * TextBoxes (ReadOnly property)
     * SecureTextBoxes (same)
     * ComboBoxes, ListBoxes (Enabled)
     * DataGridViews (ReadOnly property)
     * Buttons that perform mutating actions (Add / Remove / Restore / Edit... / Save / Save As / Raw Editor / Paste JSON etc.)
     * Corresponding menu items (Save / Save As / Raw Editor / Paste JSON)
 - Window title now includes mode (handled via Utilities.ps1 Update-WindowTitle patch).
 - Mode toggle calls Set-ReadOnlyMode which updates global flag, UI and window title.
#>

<#
Main (Updated)
Changes (current patch):
 - Added Read-Only / Write mode toggle on the left side of the status bar.
 - Default remains Read-Only (as already set in AppState).
 - Toggle button text & color reflect current mode (LightGray = Read-Only, LightGreen = Write).
 - Central Update-ReadOnlyUI function enforces mode across:
     * TextBoxes (ReadOnly property)
     * SecureTextBoxes (same)
     * ComboBoxes, ListBoxes (Enabled)
     * DataGridViews (ReadOnly property)
     * Buttons that perform mutating actions (Add / Remove / Restore / Edit... / Save / Save As / Raw Editor / Paste JSON etc.)
     * Corresponding menu items (Save / Save As / Raw Editor / Paste JSON)
 - Window title now includes mode (handled via Utilities.ps1 Update-WindowTitle patch).
 - Mode toggle calls Set-ReadOnlyMode which updates global flag, UI and window title.
 - (NEW PATCH) Read-Only UI now also disables Wizard buttons (Tag.Type='Wizard').
#>

param(
  [string]$ConfigPath = (Join-Path $PSScriptRoot '..\Config\CollectExchSecConfiguration.json'),
  [int]$LogRetentionDays = 7
)


Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic

$Global:ConfigurationStore = $null

. (Join-Path $PSScriptRoot 'Models\Models.ps1')
. (Join-Path $PSScriptRoot 'Helpers\State.ps1') -InitialConfigPath $ConfigPath -LogRetentionDays $LogRetentionDays
. (Join-Path $PSScriptRoot 'Helpers\Logging.ps1')
. (Join-Path $PSScriptRoot 'Helpers\Utilities.ps1')
. (Join-Path $PSScriptRoot 'Helpers\RawJsonEditor.ps1')
. (Join-Path $PSScriptRoot 'Helpers\Utilities.ObjectComplex.ps1')
. (Join-Path $PSScriptRoot 'Helpers\Utilities.Serialization.ps1')
. (Join-Path $PSScriptRoot 'Helpers\ObjectCollectionEditor.ps1')
#. (Join-Path $PSScriptRoot 'Helpers\UI.Sections.ps1') -SectionsFlow $null -RightHost $null   # loaded for functions


$Global:BaselineEffectiveConfig = $null
$Global:cachefile = $null
$Global:cacheFileContent = $null
$Global:AppState.Sections = Build-SetupConfiguration
$Global:AppState.SectionLookup=@{}
$Global:AppState.QuestionsLookup=@{}
foreach ($sec in $Global:AppState.Sections) {
    $Global:AppState.SectionLookup[$sec.Code]=$sec
    foreach ($q in $sec.Collection) { $q.SectionCode=$sec.Code; $Global:AppState.QuestionsLookup["$($sec.Code)|$($q.Code)"]=$q }
    foreach ($sub in $sec.WizardSectionCode) {
        $Global:AppState.SectionLookup[$sub.Code]=$sub
        foreach ($q in $sub.Collection) { $q.SectionCode=$sub.Code; $Global:AppState.QuestionsLookup["$($sub.Code)|$($q.Code)"]=$q }
    }
}

$Global:AppState.SetupFilter = 'Initial Setup'

$MainForm = New-Object System.Windows.Forms.Form
$MainForm.Width=1600; $MainForm.Height=920
$MainForm.StartPosition='CenterScreen'
$MainForm.Text="CollectExchSec Config Editor"
$Global:AppState.MainForm = $MainForm
$MainForm.KeyPreview = $true

# Runtime flag to force display of initially hidden questions
if (-not ($Global:AppState.PSObject.Properties.Name -contains 'ShowHiddenQuestions')) {
    $Global:AppState.ShowHiddenQuestions = $false
}

# Keyboard shortcut: Ctrl+Shift+D => toggle display of hidden questions
$MainForm.Add_KeyDown({
    param($src,$ea)
    if ($ea.Control -and $ea.Shift -and $ea.KeyCode -eq [System.Windows.Forms.Keys]::D) {
        $Global:AppState.ShowHiddenQuestions = -not $Global:AppState.ShowHiddenQuestions
        try {
            Build-SectionButtons -Container $sectionsFlow
            if ($Global:AppState.CurrentSectionCode) { Render-Section -SectionCode $Global:AppState.CurrentSectionCode }
            Log-And-Telemetry -Action 'toggle_hidden' -Message 'Toggle hidden questions' -Data @{ show=$Global:AppState.ShowHiddenQuestions }
        } catch {
            Write-Host "Toggle hidden error: $($_.Exception.Message)" -ForegroundColor Red
        }
        $ea.Handled = $true; $ea.SuppressKeyPress = $true
    }
})

$menu = New-Object System.Windows.Forms.MenuStrip
$menu.Dock = [System.Windows.Forms.DockStyle]::Top

$fileMenu = New-Object System.Windows.Forms.ToolStripMenuItem("File")
$fileOpen = New-Object System.Windows.Forms.ToolStripMenuItem("Open")
$fileSave = New-Object System.Windows.Forms.ToolStripMenuItem("Save")
$fileSaveAs = New-Object System.Windows.Forms.ToolStripMenuItem("Save As")
$fileMenu.DropDownItems.Add($fileOpen)
$fileMenu.DropDownItems.Add($fileSave)
$fileMenu.DropDownItems.Add($fileSaveAs)

$jsonMenu = New-Object System.Windows.Forms.ToolStripMenuItem("JSON")
$jsonRaw = New-Object System.Windows.Forms.ToolStripMenuItem("Raw Editor")
$jsonPaste = New-Object System.Windows.Forms.ToolStripMenuItem("Paste JSON")
$jsonCopy = New-Object System.Windows.Forms.ToolStripMenuItem("Copy JSON")
$jsonMenu.DropDownItems.Add($jsonRaw)
$jsonMenu.DropDownItems.Add($jsonPaste)
$jsonMenu.DropDownItems.Add($jsonCopy)

$toolsMenu = New-Object System.Windows.Forms.ToolStripMenuItem("Tools")
$toolsDiff = New-Object System.Windows.Forms.ToolStripMenuItem("Diff Summary")
$toolsReset = New-Object System.Windows.Forms.ToolStripMenuItem("Reset ConfigurationCode...")
$toolsResetAll = New-Object System.Windows.Forms.ToolStripMenuItem("Reset All Changes")
$toolsMenu.DropDownItems.Add($toolsDiff)
$toolsMenu.DropDownItems.Add($toolsReset)
$toolsMenu.DropDownItems.Add($toolsResetAll)

$configMetaMenu = New-Object System.Windows.Forms.ToolStripMenuItem("Configuration Metadata")

$helpMenu = New-Object System.Windows.Forms.ToolStripMenuItem("Help")

# NEW Azure menu
$azureMenu = New-Object System.Windows.Forms.ToolStripMenuItem("Azure")
$azureConnect = New-Object System.Windows.Forms.ToolStripMenuItem("Connect to Azure")
$azureMenu.DropDownItems.Add($azureConnect)

$menu.Items.Add($fileMenu)
$menu.Items.Add($jsonMenu)
$menu.Items.Add($toolsMenu)
$menu.Items.Add($configMetaMenu)
$menu.Items.Add($azureMenu)
$menu.Items.Add($helpMenu)

$setupModePanel = New-Object System.Windows.Forms.Panel
$setupModePanel.Width  = 170
$setupModePanel.Height = 24
$setupModePanel.Margin = '0,0,0,0'
$setupModePanel.BackColor = [System.Drawing.Color]::Transparent
$setupModePanel.BorderStyle = 'FixedSingle'

$lblInitial = New-Object System.Windows.Forms.Label
$lblInitial.Text = 'Initial Setup'
$lblInitial.AutoSize = $false
$lblInitial.TextAlign = 'MiddleCenter'
$lblInitial.Font = New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold)
$lblInitial.Location = '0,0'
$lblInitial.Size = New-Object System.Drawing.Size(85,22)
$lblInitial.Cursor = 'Hand'

$lblConfig = New-Object System.Windows.Forms.Label
$lblConfig.Text = 'Configuration'
$lblConfig.AutoSize = $false
$lblConfig.TextAlign = 'MiddleCenter'
$lblConfig.Font = New-Object System.Drawing.Font('Segoe UI',8,[System.Drawing.FontStyle]::Bold)
$lblConfig.Location = '85,0'
$lblConfig.Size = New-Object System.Drawing.Size(83,22)
$lblConfig.Cursor = 'Hand'

$setupModePanel.Controls.AddRange(@($lblInitial,$lblConfig))

function Update-SetupModeVisual {
    param([string]$mode)
    $activeColor = [System.Drawing.Color]::FromArgb(0,122,204)  # Azure-esque blue
    $inactiveBack = [System.Drawing.Color]::White
    $inactiveFore = [System.Drawing.Color]::FromArgb(0,122,204)
    if ($mode -eq 'Initial Setup') {
        $lblInitial.BackColor = $activeColor; $lblInitial.ForeColor = [System.Drawing.Color]::White
        $lblConfig.BackColor  = $inactiveBack; $lblConfig.ForeColor  = $inactiveFore
    } else {
        $lblConfig.BackColor  = $activeColor; $lblConfig.ForeColor  = [System.Drawing.Color]::White
        $lblInitial.BackColor = $inactiveBack; $lblInitial.ForeColor = $inactiveFore
    }
}
Update-SetupModeVisual -mode $Global:AppState.SetupFilter

foreach ($lbl in @($lblInitial,$lblConfig)) {
    $lbl.Add_Click({
        if ($Global:AppState.SetupFilter -eq 'Initial Setup') { $Global:AppState.SetupFilter = 'Configuration' } else { $Global:AppState.SetupFilter = 'Initial Setup' }
        Update-SetupModeVisual -mode $Global:AppState.SetupFilter
        Build-SectionButtons -Container $sectionsFlow
        if ($Global:AppState.CurrentSectionCode) { Render-Section -SectionCode $Global:AppState.CurrentSectionCode }
        Update-MandatoryIndicators
        Update-ReadOnlyUI -SkipTelemetry
        Log-And-Telemetry -Action 'filter_change' -Message 'Setup filter toggled' -Data @{ filter=$Global:AppState.SetupFilter; readOnly=$Global:AppState.ReadOnly }
    })
}


function Center-SetupModePanel {
    if (-not $setupModePanel -or $setupModePanel.IsDisposed) { return }
    # Vertical alignment (a bit of padding from top)
    $setupModePanel.Top = 2
    # Horizontal center relative to the client width of the menu
    $centerX = [int](($menu.ClientSize.Width - $setupModePanel.Width) / 2)
    if ($centerX -lt 0) { $centerX = 0 }
    $setupModePanel.Left = $centerX
    $setupModePanel.BringToFront()
}
$menu.Add_Resize({ Center-SetupModePanel })
$MainForm.Add_Resize({ Center-SetupModePanel })

# Azure status label (top-right)
$Global:AzureStatusLabel = New-Object System.Windows.Forms.Label
$Global:AzureStatusLabel.AutoSize = $true
$Global:AzureStatusLabel.Font = New-Object System.Drawing.Font("Segoe UI",9,[System.Drawing.FontStyle]::Bold)
$Global:AzureStatusLabel.Text = "Azure: Disconnected"
$Global:AzureStatusLabel.ForeColor = [System.Drawing.Color]::Red
# Place after Load (we will anchor to top-right)

$Global:AzureStatusLabel.BringToFront()
$Global:AzureStatusLabel.Anchor='Top,Right'
$Global:AzureStatusLabel.Location = New-Object System.Drawing.Point(($MainForm.ClientSize.Width - 160), 6)

# Handler for Azure Connect
$azureConnect.Add_Click({
    try {
        if (-not (Get-Command Show-AzureConnectDialog -ErrorAction SilentlyContinue)) {
            [System.Windows.Forms.MessageBox]::Show("Azure connection utilities not loaded.","Error","OK","Error")|Out-Null
            return
        }
        Show-AzureConnectDialog
        Update-AzureStatusIndicator
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Azure connection failed: $($_.Exception.Message)","Azure Error","OK","Error")|Out-Null
    }
})

# --- Add handler for Configuration Metadata ---

$configMetaMenu.Add_Click({
    $eff = Build-EffectiveConfig
    if (-not $eff -or -not ($eff.PSObject.Properties.Name -contains 'SolutionMetadata')) {
        [System.Windows.Forms.MessageBox]::Show("No SolutionMetadata section found in current configuration.","Metadata","OK","Information")|Out-Null
        return
    }

    $meta    = $eff.SolutionMetadata
    $verInfo = $meta.VersionInformation

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Configuration Metadata"
    $dlg.Width = 920
    $dlg.Height = 620
    $dlg.StartPosition='CenterParent'
    $dlg.Font = New-Object System.Drawing.Font("Segoe UI",9)

    # Container: top info panel + content panel
    $top    = New-Object System.Windows.Forms.Panel
    $content= New-Object System.Windows.Forms.Panel

    $top.Dock     = 'Top'
    $top.Height   = 78
    $content.Dock = 'Fill'

    $dlg.Controls.Add($content)
    $dlg.Controls.Add($top)

    # Top labels
    $lblVersion = New-Object System.Windows.Forms.Label
    $lblVersion.AutoSize = $true
    $lblVersion.Location = New-Object System.Drawing.Point(12,12)
    $lblVersion.Text = "JSON Version : " + ([string]$meta.JsonVersion)

    $lblDate = New-Object System.Windows.Forms.Label
    $lblDate.AutoSize = $true
    $lblDate.Location = New-Object System.Drawing.Point(12,36)
    $lblDate.Text = "Update Date : " + ([string]$meta.JsonUpdateDate)

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text='Close'
    $btnClose.Width=100
    $btnClose.Location = New-Object System.Drawing.Point(800,12)
    $btnClose.Add_Click({ $dlg.Close() })

    $top.Controls.AddRange(@($lblVersion,$lblDate,$btnClose))

    # Split container inside content panel
    $split = New-Object System.Windows.Forms.SplitContainer
    $split.Parent = $content
    $split.Dock = 'Fill'
    # Give a reasonable left pane width (26 was too narrow & caused perceived overlay)
    $split.SplitterDistance = 260

    # Left list
    $lst = New-Object System.Windows.Forms.ListBox
    $lst.Dock='Fill'
    $lst.Font = New-Object System.Drawing.Font("Consolas",10)
    $split.Panel1.Controls.Add($lst)

    # Right details
    $rt = New-Object System.Windows.Forms.RichTextBox
    $rt.Dock='Fill'
    $rt.ReadOnly=$true
    $rt.WordWrap=$false
    $rt.Font = New-Object System.Drawing.Font("Consolas",10)
    $split.Panel2.Controls.Add($rt)

    # Prepare version list
    $versions = @()
    if ($verInfo) {
        foreach ($p in $verInfo.PSObject.Properties) { $versions += $p.Name }
    }
    $versions = $versions | Sort-Object {
        try { [Version]$_ } catch { [Version]"0.0.0.0" }
    } -Descending
    foreach ($v in $versions) { [void]$lst.Items.Add($v) }

    function Show-VersionDetails {
        param($ver,$metaObj,$box)
        if (-not $ver) { return }
        $box.Clear()
        $entry = $metaObj.VersionInformation.$ver
        if (-not $entry) {
            $box.Text = "No details for version $ver"
            return
        }
        $box.SelectionFont = New-Object System.Drawing.Font("Consolas",11,[System.Drawing.FontStyle]::Bold)
        $box.AppendText("Version $ver`r`n")
        $box.SelectionFont = New-Object System.Drawing.Font("Consolas",10,[System.Drawing.FontStyle]::Regular)
        $box.AppendText("".PadRight(60,'-') + "`r`n")

        if ($entry.PSObject.Properties.Name -contains 'Tracking') {
            $trk = $entry.Tracking
            if ($trk -is [System.Collections.IEnumerable] -and $trk -isnot [string]) {
                $box.SelectionFont = New-Object System.Drawing.Font("Consolas",10,[System.Drawing.FontStyle]::Bold)
                $box.AppendText("Tracking:`r`n")
                $box.SelectionFont = New-Object System.Drawing.Font("Consolas",10)
                foreach ($line in $trk) { $box.AppendText(" - $line`r`n") }
                $box.AppendText("`r`n")
            }
        }

        if ($entry.PSObject.Properties.Name -contains 'MigrationMessageFromLastVersion') {
            $mig = $entry.MigrationMessageFromLastVersion
            $box.SelectionFont = New-Object System.Drawing.Font("Consolas",10,[System.Drawing.FontStyle]::Bold)
            $box.AppendText("MigrationMessageFromLastVersion:`r`n")
            $box.SelectionFont = New-Object System.Drawing.Font("Consolas",10)
            if ($mig -is [System.Collections.IEnumerable] -and $mig -isnot [string]) {
                foreach ($line in $mig) { $box.AppendText(" - $line`r`n") }
            } elseif ($mig) {
                $box.AppendText(" - $mig`r`n")
            }
            $box.AppendText("`r`n")
        }
        $box.AppendText("Done.`r`n")
        $box.SelectionStart = 0
        $box.ScrollToCaret()
    }

    $lst.Add_SelectedIndexChanged({
        if ($lst.SelectedItem) {
            Show-VersionDetails -ver $lst.SelectedItem -metaObj $meta -box $rt
        }
    })

    if ($lst.Items.Count -gt 0) { $lst.SelectedIndex = 0 }

    [void]$dlg.ShowDialog($Global:AppState.MainForm)
})

# --- END PATCH ---

# (LOAD Sections UI)
$split = New-Object System.Windows.Forms.SplitContainer
$split.Dock='Fill'
$split.SplitterDistance=24


$MainForm.Controls.Add($split)

$MainForm.Controls.Add($setupModePanel)
$MainForm.Controls.Add($Global:AzureStatusLabel)
$MainForm.Controls.Add($menu)
Center-SetupModePanel

$leftPanel = New-Object System.Windows.Forms.Panel
$leftPanel.Dock='Fill'
$split.Panel1.Controls.Add($leftPanel)

$lblSections = New-Object System.Windows.Forms.Label
$lblSections.Text="Sections"
$lblSections.Font= New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
$lblSections.AutoSize=$true
$lblSections.Location=(New-Object System.Drawing.Point(6,6))
$leftPanel.Controls.Add($lblSections)

$sectionsFlow = New-Object System.Windows.Forms.FlowLayoutPanel
$sectionsFlow.Location=(New-Object System.Drawing.Point(6,34))
$sectionsFlow.Anchor='Top,Bottom,Left,Right'
$sectionsFlow.Width= ($split.SplitterDistance - 12)
$sectionsFlow.Height= $leftPanel.Height - 40
$sectionsFlow.AutoScroll=$true
$leftPanel.Controls.Add($sectionsFlow)

$rightPanel = New-Object System.Windows.Forms.Panel
$rightPanel.Dock='Fill'
$rightPanel.AutoScroll=$true
$split.Panel2.Controls.Add($rightPanel)

# ----- Read-Only / Write toggle + status bar (unchanged base) -----
$statusBar = New-Object System.Windows.Forms.StatusStrip
$tsReadOnlyToggle = New-Object System.Windows.Forms.ToolStripButton
$tsReadOnlyToggle.Text = "Mode: Read-Only"
$tsReadOnlyToggle.DisplayStyle = 'Text'
$tsReadOnlyToggle.BackColor = [System.Drawing.Color]::LightGray
$statusBar.Items.Add($tsReadOnlyToggle)

$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusLabel.Text="Ready."
$statusLabel.Spring = $true
$script:statusMandatory = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusMandatory.Text="Mandatory missing: 0"
$statusMandatory.ForeColor=[System.Drawing.Color]::DarkGreen
$statusMandatory.IsLink = $true
$statusMandatory.Font = New-Object System.Drawing.Font($statusMandatory.Font, [System.Drawing.FontStyle]::Bold)
$statusBar.Items.Add($statusLabel)
$statusBar.Items.Add($statusMandatory)
$MainForm.Controls.Add($statusBar)
$Global:MandatoryStatusLabel=$statusMandatory

$Global:MandatoryPlaceholder = 'UNCONFIGUREDENTRY'

function Get-AllChildControls {
    param(
        [System.Windows.Forms.Control]$Parent
    )
    $all = New-Object System.Collections.Generic.List[System.Windows.Forms.Control]
    if (-not $Parent) { return $all }
    $stack = New-Object System.Collections.Stack
    $stack.Push($Parent)
    while ($stack.Count -gt 0) {
        $p = $stack.Pop()
        foreach ($c in $p.Controls) {
            $all.Add($c) | Out-Null
            if ($c.Controls.Count -gt 0) { $stack.Push($c) }
        }
    }
    return $all
}

function Update-ReadOnlyUI {
    param([switch]$SkipTelemetry)

    if (-not $Global:AppState) { return }
    $ro = [bool]$Global:AppState.ReadOnly

    foreach ($kv in $Global:AppState.ControlBindings.GetEnumerator()) {
        $meta = $kv.Value
        if (-not $meta) { continue }
        $ctrl = $meta.Control
        if (-not $ctrl -or $ctrl.IsDisposed) { continue }

        if ($ctrl -is [System.Windows.Forms.TextBox]) {
            $ctrl.ReadOnly = $ro
        } elseif ($ctrl -is [System.Windows.Forms.ComboBox]) {
            if ($ctrl.Name -eq 'SetupModeFilter' -or $ctrl.Tag -eq 'ReadOnlySafe') {
                $ctrl.Enabled = $true
            } else {
                $ctrl.Enabled = -not $ro
            }
        } elseif ($ctrl -is [System.Windows.Forms.ListBox]) {
            $ctrl.Enabled = -not $ro
        }

        if ($meta.Restore -and -not $meta.Restore.IsDisposed) {
            $meta.Restore.Enabled = -not $ro
        }
        if ($meta.Wizard -and -not $meta.Wizard.IsDisposed) {
            $meta.Wizard.Enabled = -not $ro
        }
    }

    foreach ($c in (Get-AllChildControls -Parent $Global:AppState.MainForm)) {
        if ($c -is [System.Windows.Forms.DataGridView]) {
            $c.ReadOnly = $ro
        } elseif ($c -is [System.Windows.Forms.Button]) {
            $isWizard = ($c.Tag -is [hashtable] -and $c.Tag.Type -eq 'Wizard')
            $mutating = @(
                'Add','Remove','Restore Row','Restore','Edit Addons...','Edit...',
                'Apply Changes','Paste from Clipboard','Accept and Save','Accept and Save As',
                'OK','Apply','Save','Save As','Wizard...'
            )
            if ($isWizard -or $mutating -contains $c.Text) {
                $c.Enabled = -not $ro
            }
        } elseif ($c -is [System.Windows.Forms.ComboBox]) {
            if ($c.Name -eq 'SetupModeFilter' -or $c.Tag -eq 'ReadOnlySafe') {
                $c.Enabled = $true
            }
        }
    }

    foreach ($itm in $menu.Items) {
        if ($itm -is [System.Windows.Forms.ToolStripMenuItem]) {
            foreach ($sub in $itm.DropDownItems) {
                if (-not $sub) { continue }
                if ($sub.Text -in @('Save','Save As')) {
                    $sub.Enabled = -not $ro
                }
            }
        }
    }

    if ($tsReadOnlyToggle) {
        if ($ro) {
            $tsReadOnlyToggle.Text = "Mode: Read-Only"
            $tsReadOnlyToggle.BackColor = [System.Drawing.Color]::LightGray
        } else {
            $tsReadOnlyToggle.Text = "Mode: Write"
            $tsReadOnlyToggle.BackColor = [System.Drawing.Color]::LightGreen
        }
    }

    if (-not $SkipTelemetry) {
        Log-And-Telemetry -Action "readonly_ui_update" -Message "Applied ReadOnly state" -Data @{ readOnly=$ro }
    }
}

function Set-ReadOnlyMode {
    param([bool]$ReadOnly)
    $Global:AppState.ReadOnly = $ReadOnly
    Update-ReadOnlyUI
    Update-WindowTitle
}

$tsReadOnlyToggle.Add_Click({
    Set-ReadOnlyMode -ReadOnly (-not $Global:AppState.ReadOnly)
})

$MainForm.Add_Shown({ Update-ReadOnlyUI })

 # (Removed combo box handler; toggle button now manages mode changes)

# (At the end of the existing initial render sequence, AFTER Render-Section is called:)
# Ensure read-only is enforced for newly created controls
Update-ReadOnlyUI -SkipTelemetry

# ---------- End Read-Only Support ----------

function Show-MandatoryMissingWindow {

    if (-not (Get-Command Get-UnconfiguredState -ErrorAction SilentlyContinue)) {
        [System.Windows.Forms.MessageBox]::Show("Mandatory state function not available.","Error","OK","Error") | Out-Null
        return
    }

    $state = Get-UnconfiguredState
    if (-not $state -or $state.Total -le 0) {
        [System.Windows.Forms.MessageBox]::Show("No mandatory missing values detected.","Info","OK","Information") | Out-Null
        return
    }

    # Collect question-based mandatory items (already filtered to enabled sections by Get-UnconfiguredState)
    $items = New-Object System.Collections.ArrayList
    foreach ($qKey in $state.QuestionMap.Keys) {
        if ($Global:AppState.QuestionsLookup.ContainsKey($qKey)) {
            $q = $Global:AppState.QuestionsLookup[$qKey]
            $cur = if ($q.IsArray) { ($q.ArrayItems -join ';') } else { $q.Value }
            [void]$items.Add([pscustomobject]@{
                Type          = 'Question'
                SectionCode   = $q.SectionCode
                QuestionCode  = $q.Code
                QuestionPath  = $q.ConfigurationCode
                QuestionText  = $q.Question
                CurrentValue  = $cur
                NewValue      = ''
                IsArray       = $q.IsArray
                GridRowIndex  = $null
                GridProperty  = $null
            })
        }
    }
    
    if ($items.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("No mandatory missing values in enabled sections.","Info","OK","Information") | Out-Null
        return
    }

    # Build dialog
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Mandatory Missing Values"
    $dlg.Width = 1100
    $dlg.Height = 600
    $dlg.StartPosition='CenterParent'
    $dlg.Font = New-Object System.Drawing.Font("Segoe UI",9)

    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.AutoSize = $true
    $lblInfo.Text = "Edit 'NewValue' cells. Leave blank to skip. Double-click a Question row to navigate to its section."
    $lblInfo.Location = New-Object System.Drawing.Point(10,10)
    $dlg.Controls.Add($lblInfo)

    $grid = New-Object System.Windows.Forms.DataGridView
    $grid.Location = New-Object System.Drawing.Point(10,36)
    $grid.Width = 1060
    $grid.Height = 470
    $grid.Anchor = 'Top,Left,Right,Bottom'
    $grid.AllowUserToAddRows = $false
    $grid.AllowUserToDeleteRows = $false
    $grid.RowHeadersVisible = $false
    $grid.SelectionMode = 'FullRowSelect'
    $grid.AutoSizeColumnsMode='Fill'
    $grid.EditMode='EditOnEnter'

    $binding = New-Object System.Windows.Forms.BindingSource
    $binding.DataSource = $items
    $grid.DataSource = $binding
    $dlg.Controls.Add($grid)

    # Make only NewValue column editable
    foreach ($col in $grid.Columns) {
        if ($col.Name -ne 'NewValue') {
            $col.ReadOnly = $true
        } else {
            $col.ReadOnly = $false
        }
    }

    $btnApply = New-Object System.Windows.Forms.Button
    $btnApply.Text = "Apply Changes"
    $btnApply.Width = 140
    $btnApply.Location = New-Object System.Drawing.Point(10,520)

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = "Close"
    $btnClose.Width = 100
    $btnClose.Location = New-Object System.Drawing.Point(160,520)

    $dlg.Controls.AddRange(@($btnApply,$btnClose))

    # Navigate to section on double-click for regular questions
    $grid.Add_CellDoubleClick({
        param($s,$e)
        if ($e.RowIndex -lt 0) { return }
        $rowObj = $grid.Rows[$e.RowIndex].DataBoundItem
        if ($rowObj.Type -eq 'Question') {
            $secCode = $rowObj.SectionCode
            if ($Global:AppState.SectionLookup.ContainsKey($secCode)) {
                $Global:AppState.CurrentSectionCode = $secCode
                if (Get-Command Render-Section -ErrorAction SilentlyContinue) {
                    Render-Section -SectionCode $secCode
                }
                $dlg.Activate()
            }
        }
    })

    $btnApply.Add_Click({
        if ($Global:AppState.ReadOnly) {
            [System.Windows.Forms.MessageBox]::Show("Cannot apply while in Read-Only mode. Switch to Write mode.","Read-Only","OK","Information")|Out-Null
            return
        }
        $changes = 0
        foreach ($it in $items) {
            if ([string]::IsNullOrWhiteSpace($it.NewValue)) { continue }
            switch ($it.Type) {
                'Question' {
                    if ($Global:AppState.QuestionsLookup.ContainsKey("$($it.SectionCode)|$($it.QuestionCode)")) {
                        $q = $Global:AppState.QuestionsLookup["$($it.SectionCode)|$($it.QuestionCode)"]
                        if ($q.IsArray) {
                            $q.ArrayItems.Clear()
                            ($it.NewValue -split ';' | Where-Object {$_}) | ForEach-Object { [void]$q.ArrayItems.Add($_) }
                            $q.Value = ($q.ArrayItems -join ';')
                        } else {
                            $q.Value = $it.NewValue
                        }
                        Validate-Question $q
                        $changes++
                    }
                }
            }
        }

        if ($changes -gt 0) {
            Set-Dirty
            if ($Global:AppState.CurrentSectionCode -and (Get-Command Render-Section -ErrorAction SilentlyContinue)) {
                Render-Section -SectionCode $Global:AppState.CurrentSectionCode
            }
            if (Get-Command Update-MandatoryIndicators -ErrorAction SilentlyContinue) {
                Update-MandatoryIndicators
            }
            [System.Windows.Forms.MessageBox]::Show("$changes value(s) updated.","Updated","OK","Information") | Out-Null
            $dlg.Close()
        } else {
            [System.Windows.Forms.MessageBox]::Show("No changes provided (NewValue column empty).","Info","OK","Information") | Out-Null
        }
    })

    $btnClose.Add_Click({ $dlg.Close() })

    [void]$dlg.ShowDialog($Global:AppState.MainForm)
}

# ----- Mandatory Placeholder Logic -----
function Test-ValueNeedsConfig {
    param($v)
    if ($null -eq $v) { return $false }
    if ($v -is [string]) {
        return ($v.ToUpper().Contains('UNCONFIGUREDENTRY'.ToUpper()))
    }
    if ($v -is [System.Collections.IEnumerable] -and $v -isnot [string]) {
        foreach ($i in $v) {
            if (Test-ValueNeedsConfig -v $i) { return $true }
        }
        return $false
    }
    if ($v -is [pscustomobject]) {
        foreach ($p in $v.PSObject.Properties) {
            if (Test-ValueNeedsConfig -v $p.Value) { return $true }
        }
        return $false
    }
    if ($v -is [System.Collections.IDictionary]) {
        foreach ($k in $v.Keys) {
            if (Test-ValueNeedsConfig -v $v[$k]) { return $true }
        }
        return $false
    }
    return $false
}

 # (Second duplicate handler removed; toggle covers functionality)
 
 function Get-UnconfiguredState {
    $state = [ordered]@{
        Total       = 0
        Sections    = @{}
        QuestionMap = @{}
        Grids = @{
            UDS = 0
            Instance = 0
        }
    }
    $needle = $Global:MandatoryPlaceholder
    foreach ($sec in $Global:AppState.Sections) {
        $sectionEnabled = (Evaluate-Condition -Condition $sec.Condition)
        if (-not $sectionEnabled) { continue }
        foreach ($q in $sec.Collection) {
            $needs = $false

            if ([string]::IsNullOrEmpty($q.ConfigurationCode)) {
                continue;
            }

            if ($q.IsArray) {
                foreach ($ai in $q.ArrayItems) {
                    if ([string]$ai -like "*$needle*") { $needs = $true; break }
                }
            } else {
                if ([string]$q.Value -like "*$needle*") { $needs = $true }
            }
            if ($needs) {
                $show = (-not $q.Hidden)
                if ($show) { $show = Evaluate-Condition -Condition $q.Condition }
                if ($show) {
                    if (-not $state.Sections.ContainsKey($sec.Code)) { $state.Sections[$sec.Code] = 0 }
                    $state.Sections[$sec.Code]++
                    $state.Total++
                    $state.QuestionMap["$($sec.Code)|$($q.Code)"] = $true
                }
            }
        }
        foreach ($sub in $sec.WizardSectionCode) {
            $subEnabled = (Evaluate-Condition -Condition $sub.Condition)
            if (-not $subEnabled) { continue }
            foreach ($q in $sub.Collection) {
                $needs = $false

                if ([string]::IsNullOrEmpty($q.ConfigurationCode)) {
                    continue;
                }

                if ($q.IsArray) {
                    foreach ($ai in $q.ArrayItems) {
                        if ([string]$ai -like "*$needle*") { $needs = $true; break }
                    }
                } else {
                    if ([string]$q.Value -like "*$needle*") { $needs = $true }
                }
                if ($needs) {
                    $show = (-not $q.Hidden)
                    if ($show) { $show = Evaluate-Condition -Condition $q.Condition }
                    if ($show) {
                        if (-not $state.Sections.ContainsKey($sub.Code)) { $state.Sections[$sub.Code] = 0 }
                        $state.Sections[$sub.Code]++
                        $state.Total++
                        $state.QuestionMap["$($sub.Code)|$($q.Code)"] = $true
                    }
                }
            }
        }
    }

    return $state
}

if ($statusMandatory -and ($statusMandatory -is [System.Windows.Forms.ToolStripStatusLabel])) {
    if (-not $statusMandatory.Tag -or -not ($statusMandatory.Tag -is [hashtable])) {
        $statusMandatory.Tag = @{}
    }
    if (-not $statusMandatory.Tag.ContainsKey('MandatoryClickAttached')) {
        $statusMandatory.Add_Click({ Show-MandatoryMissingWindow })
        $statusMandatory.Tag.MandatoryClickAttached = $true
    }
}

function Update-MandatoryIndicators {
    try {
        $s = Get-UnconfiguredState
        $Global:AppState.UnconfiguredState = $s
        if ($Global:MandatoryStatusLabel -and -not $Global:MandatoryStatusLabel.IsDisposed) {
            $Global:MandatoryStatusLabel.Text = "Mandatory missing: " + $s.Total
            $Global:MandatoryStatusLabel.ForeColor = if ($s.Total -gt 0) { [System.Drawing.Color]::Red } else { [System.Drawing.Color]::DarkGreen }
        }
        foreach ($ctrl in $sectionsFlow.Controls) {
            if ($ctrl -is [System.Windows.Forms.Button]) {
                $code=$ctrl.Tag
                $hasMissing = ($code -and $s.Sections.ContainsKey($code) -and $s.Sections[$code] -gt 0)
                if ($ctrl.Enabled -and $hasMissing) {
                    $ctrl.BackColor=[System.Drawing.Color]::Red
                    $ctrl.ForeColor=[System.Drawing.Color]::White
                } else {
                    if ($ctrl.BackColor -eq [System.Drawing.Color]::Red) {
                        $ctrl.BackColor=[System.Drawing.Color]::FromArgb(240,240,240)
                        $ctrl.ForeColor=[System.Drawing.Color]::Black
                    }
                }
            }
        }
    } catch {}
}

function Get-UnconfiguredCount { (Get-UnconfiguredState).Total }

$MandatoryTimer = New-Object System.Windows.Forms.Timer
$MandatoryTimer.Interval=1200
$MandatoryTimer.Add_Tick({ Update-MandatoryIndicators })
$MandatoryTimer.Start()

. (Join-Path $PSScriptRoot 'Helpers\UI.Sections.ps1') -SectionsFlow $sectionsFlow -RightHost $rightPanel

Rehydrate-All
Build-SectionButtons -Container $sectionsFlow
$Global:AppState.CurrentSectionCode = ($Global:AppState.Sections | Sort-Object Index | Select-Object -First 1).Code
Render-Section -SectionCode $Global:AppState.CurrentSectionCode
Push-UndoSnapshot
Update-WindowTitle
Update-ReadOnlyUI
Update-MandatoryIndicators

if (-not $Global:BaselineEffectiveConfig) {
    $Global:BaselineEffectiveConfig = (
        (Build-EffectiveConfig | ConvertTo-Json -Depth 80) | ConvertFrom-Json -Depth 80
    )
}

Log-And-Telemetry -Action "start" -Message "App started with SetupFilter=Initial Setup"

<# $setupModeCombo.Add_SelectedIndexChanged({
    param($sender,$e)
    $Global:AppState.SetupFilter = $sender.SelectedItem
    Build-SectionButtons -Container $sectionsFlow
    if ($Global:AppState.CurrentSectionCode) { Render-Section -SectionCode $Global:AppState.CurrentSectionCode }
    Update-MandatoryIndicators
    Update-ReadOnlyUI -SkipTelemetry
    Log-And-Telemetry -Action "filter_change" -Message "Setup filter changed" -Data @{ filter=$Global:AppState.SetupFilter; readOnly=$Global:AppState.ReadOnly }
}) #>

function Generate-DiffSummary {
    $changed = Generate-ChangedSettingsObject
    $lines=@()
    # Build lookup of originals (from store or question originals)
    $origLookup = @{}
    if ($Global:ConfigurationStore) {
        foreach ($kv in $Global:ConfigurationStore.GetEnumerator()) { $origLookup[$kv.Key] = $kv.Value.OriginalValue }
    }
    foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
        $q=$kv.Value
        if ($q.ConfigurationCode -and -not $origLookup.ContainsKey($q.ConfigurationCode)) { $origLookup[$q.ConfigurationCode] = $q.OriginalValue }
    }
    foreach ($k in $changed.Questions.Keys) {
        $newVal = $changed.Questions[$k]
        $oldVal = $origLookup[$k]
        $oldText = if ($oldVal -is [array]) { ($oldVal | ConvertTo-Json -Compress) } elseif ($oldVal -is [psobject]) { ($oldVal | ConvertTo-Json -Compress) } else { $oldVal }
        $newText = if ($newVal -is [array]) { ($newVal | ConvertTo-Json -Compress) } elseif ($newVal -is [psobject]) { ($newVal | ConvertTo-Json -Compress) } else { $newVal }
        $lines += "Changed: $k : $oldText => $newText"
    }
    foreach ($row in $changed.UDSLogProcessor) { $lines += "Changed: UDSLogProcessor: $($row | ConvertTo-Json -Compress)" }
    foreach ($k in $changed.InstanceConfiguration.Keys) {
        $lines += "Changed: InstanceConfiguration $k = $($changed.InstanceConfiguration[$k] | ConvertTo-Json -Compress)"
    }
    if (-not $lines) { $lines=@("No changes detected.") }
    $lines -join "`r`n"
}

# Reset all questions for a given ConfigurationCode (and store value)
function Reset-ConfigurationCodeValue {
    param([Parameter(Mandatory)][string]$ConfigurationCode)
    if ($Global:AppState.ReadOnly) {
        [System.Windows.Forms.MessageBox]::Show("Read-Only mode.","Read-Only","OK","Information")|Out-Null; return
    }
    if ([string]::IsNullOrWhiteSpace($ConfigurationCode)) { return }
    $orig = $null
    if ($Global:ConfigurationStore -and $Global:ConfigurationStore.ContainsKey($ConfigurationCode)) {
        $entry = $Global:ConfigurationStore[$ConfigurationCode]
        $orig = $entry.OriginalValue
        $entry.Value = $entry.OriginalValue
    }
    # Update all questions sharing the code
    $updatedCtr = 0
    foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
        $q=$kv.Value
        if ($q.ConfigurationCode -ne $ConfigurationCode) { continue }
        $q.Value = $q.OriginalValue
        Validate-Question $q
        $binding = $Global:AppState.ControlBindings["$($q.SectionCode)|$($q.Code)"]
        if ($binding -and $binding.Control -and -not $binding.Control.IsDisposed) {
            $ctrl = $binding.Control
            if ($ctrl -is [System.Windows.Forms.TextBox]) { $ctrl.Text = [string]$q.Value }
            elseif ($ctrl -is [System.Windows.Forms.ComboBox]) { if ($ctrl.Items.Contains($q.Value)) { $ctrl.SelectedItem=$q.Value } }
            elseif ($ctrl -is [System.Windows.Forms.Panel] -and $ctrl.Tag) {
                if ($ctrl.Tag.Type -eq 'BooleanSwitch') { Set-BoolPanelVisual -Panel $ctrl -Value ([bool]$q.Value) }
                elseif ($ctrl.Tag.Type -eq 'YesNoSwitch') {
                    $yes=$null;$no=$null; foreach($c in $ctrl.Controls){ if($c -is [System.Windows.Forms.Label]){ if($c.Text -eq 'Yes'){ $yes=$c } elseif($c.Text -eq 'No'){ $no=$c } } }
                    if ($yes -and $no) {
                        $activeColor=[System.Drawing.Color]::FromArgb(0,122,204)
                        $inactiveBack=[System.Drawing.Color]::White
                        $inactiveFore=[System.Drawing.Color]::FromArgb(0,122,204)
                        if ($q.Value -eq 'Yes') { $yes.BackColor=$activeColor; $yes.ForeColor=[System.Drawing.Color]::White; $no.BackColor=$inactiveBack; $no.ForeColor=$inactiveFore }
                        else { $no.BackColor=$activeColor; $no.ForeColor=[System.Drawing.Color]::White; $yes.BackColor=$inactiveBack; $yes.ForeColor=$inactiveFore }
                    }
                }
            }
            Mark-QuestionControl -Question $q -Control $ctrl
        }
        $updatedCtr++
    }
    Schedule-SectionRefresh
    Set-Dirty
    Log-And-Telemetry -Action "reset_config_code" -Message "Reset $ConfigurationCode" -Data @{ count=$updatedCtr }
    [System.Windows.Forms.MessageBox]::Show("Reset applied to $updatedCtr linked question(s).","Reset","OK","Information")|Out-Null
}

# Reset every changed configuration value back to its original (store + questions)
function Reset-AllConfigurationChanges {
    if ($Global:AppState.ReadOnly) {
        [System.Windows.Forms.MessageBox]::Show("Read-Only mode.","Read-Only","OK","Information")|Out-Null; return
    }
    $confirm = [System.Windows.Forms.MessageBox]::Show("Reset ALL modified values back to their original state?","Confirm Reset All","YesNo","Warning")
    if ($confirm -ne 'Yes') { return }
    $codesReset = 0
    $questionsReset = 0
    # First restore store entries
    if ($Global:ConfigurationStore) {
        foreach ($kv in $Global:ConfigurationStore.GetEnumerator()) {
            $entry = $kv.Value
            if ($entry -and ($entry.Value -ne $entry.OriginalValue)) {
                $entry.Value = $entry.OriginalValue
                $codesReset++
            }
        }
    }
    # Restore each question Value & complex/array items
    foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
        $q = $kv.Value
        $changed = $false
        $props = $q.PSObject.Properties.Name
        if ($q.IsComplex) {
            if ($q.ComplexKind -eq 'ObjectArray') {
                if ($props -contains 'ComplexItemsOriginal' -and $q.ComplexItemsOriginal) {
                    $q.ComplexItems = New-Object System.Collections.ArrayList
                    foreach ($it in $q.ComplexItemsOriginal) { [void]$q.ComplexItems.Add($it) }
                }
            } elseif ($q.ComplexKind -eq 'ObjectMap') {
                if ($props -contains 'ComplexMapOriginal' -and $q.ComplexMapOriginal) {
                    $q.ComplexMap = [ordered]@{}
                    foreach ($k in $q.ComplexMapOriginal.Keys) { $q.ComplexMap[$k] = $q.ComplexMapOriginal[$k] }
                }
            }
            # Complex original diff not yet granular; treat as changed if any config code entry changed (already counted via store)
        } elseif ($q.IsArray) {
            if ($props -contains 'ArrayItemsOriginal' -and $q.ArrayItemsOriginal) {
                $q.ArrayItems = New-Object System.Collections.ArrayList
                foreach ($it in $q.ArrayItemsOriginal) { [void]$q.ArrayItems.Add($it) }
            } else {
                # Fallback: derive from OriginalValue if present
                if ($q.OriginalValue -is [array]) { $items = @($q.OriginalValue) }
                elseif ([string]::IsNullOrWhiteSpace($q.OriginalValue)) { $items = @() }
                else { $items = "$($q.OriginalValue)".Split(';') }
                $q.ArrayItems = New-Object System.Collections.ArrayList
                foreach ($it in $items) { [void]$q.ArrayItems.Add($it) }
            }
            $prev = $q.Value
            $q.Value = ($q.ArrayItems -join ';')
            if ($q.Value -ne $prev) { $changed = $true }
        } else {
            if ($q.Value -ne $q.OriginalValue) { $q.Value = $q.OriginalValue; $changed = $true }
        }
        if ($changed) { $questionsReset++ }
        Validate-Question $q
        # Update bound UI control
        $binding = $Global:AppState.ControlBindings["$($q.SectionCode)|$($q.Code)"]
        if ($binding -and $binding.Control -and -not $binding.Control.IsDisposed) {
            $ctrl = $binding.Control
            if ($ctrl -is [System.Windows.Forms.TextBox]) { $ctrl.Text = [string]$q.Value }
            elseif ($ctrl -is [System.Windows.Forms.ComboBox]) { if ($ctrl.Items.Contains($q.Value)) { $ctrl.SelectedItem = $q.Value } }
            elseif ($ctrl -is [System.Windows.Forms.Panel] -and $ctrl.Tag) {
                if ($ctrl.Tag.Type -eq 'BooleanSwitch') { Set-BoolPanelVisual -Panel $ctrl -Value ([bool]$q.Value) }
                elseif ($ctrl.Tag.Type -eq 'YesNoSwitch') {
                    $yes=$null;$no=$null; foreach($c in $ctrl.Controls){ if($c -is [System.Windows.Forms.Label]){ if($c.Text -eq 'Yes'){ $yes=$c } elseif ($c.Text -eq 'No'){ $no=$c } } }
                    if ($yes -and $no) {
                        $activeColor=[System.Drawing.Color]::FromArgb(0,122,204)
                        $inactiveBack=[System.Drawing.Color]::White
                        $inactiveFore=[System.Drawing.Color]::FromArgb(0,122,204)
                        if ($q.Value -eq 'Yes') { $yes.BackColor=$activeColor; $yes.ForeColor=[System.Drawing.Color]::White; $no.BackColor=$inactiveBack; $no.ForeColor=$inactiveFore }
                        else { $no.BackColor=$activeColor; $no.ForeColor=[System.Drawing.Color]::White; $yes.BackColor=$inactiveBack; $yes.ForeColor=$inactiveFore }
                    }
                }
            }
            Mark-QuestionControl -Question $q -Control $ctrl
        }
    }
    Schedule-SectionRefresh
    Set-Dirty -Clear
    $Global:BaselineEffectiveConfig = Build-EffectiveConfig
    Log-And-Telemetry -Action "reset_all" -Message "Reset all changes" -Data @{ codes=$codesReset; questions=$questionsReset }
    [System.Windows.Forms.MessageBox]::Show("Reset complete. Codes reset: $codesReset; Questions updated: $questionsReset","Reset All","OK","Information")|Out-Null
}

$toolsResetAll.Add_Click({ Reset-AllConfigurationChanges })

function Save-ConfigFile {
    param($path)
    if ($Global:AppState.ReadOnly) {
        [System.Windows.Forms.MessageBox]::Show("Cannot save while in Read-Only mode. Switch to Write mode first.","Read-Only","OK","Information")|Out-Null
        return
    }
    $missing = Get-UnconfiguredCount
    if ($missing -gt 0) {
        [System.Windows.Forms.MessageBox]::Show("$missing mandatory value(s) still contain 'UNCONFIGUREDENTRY'. Please fill them before saving.","Mandatory Values Missing",'OK','Warning') | Out-Null
        return
    }
    try {
        $cfg = Get-ConfigStringifiedClone
    $json = ($cfg | ConvertTo-Json -Depth 80)
        Set-Content -Path $path -Value $json -Encoding UTF8
        $Global:AppState.ConfigPath = $path
        Set-Dirty -Clear
        Update-WindowTitle
        Update-MandatoryIndicators
        Log-And-Telemetry -Action "save_config" -Message "Configuration saved" -Data @{ path=$path }
        [System.Windows.Forms.MessageBox]::Show("Configuration saved to $path.","Saved",'OK','Information')
    } catch {
        Write-ErrorLog -ErrorRecord $_ -Context 'Save-ConfigFile'
        Log-And-Telemetry -Action "save_config_error" -Message $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show("Save failed: $($_.Exception.Message)","Error",'OK','Error')
    }
}


# Copy JSON (stringified)
$jsonCopy.Add_Click({
    try {
        $cfg = Get-ConfigStringifiedClone
    $json = ($cfg | ConvertTo-Json -Depth 80)
        [Windows.Forms.Clipboard]::SetText($json)
        Log-And-Telemetry -Action "copy_json" -Message "Copied JSON" -Data @{ length=$json.Length }
        [Windows.Forms.MessageBox]::Show("JSON (stringified) copied to clipboard.","Copied",'OK','Information')
    } catch {
        Write-ErrorLog -ErrorRecord $_ -Context 'CopyJSON'
    }
})

# Paste JSON (accept numeric/bool as strings; convert on rehydrate)
$jsonPaste.Add_Click({
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text="Paste JSON Configuration"
    $dlg.Width=840; $dlg.Height=600
    $dlg.StartPosition='CenterParent'
    $tb = New-Object System.Windows.Forms.TextBox -Property @{
        Multiline=$true; ScrollBars='Both'; Font=(New-Object System.Drawing.Font("Consolas",10));
        Width=800; Height=480; Location=(New-Object System.Drawing.Point(12,12))
    }
    $btnPaste = New-Object System.Windows.Forms.Button -Property @{ Text='Paste from Clipboard'; Width=160; Location=(New-Object System.Drawing.Point(12,510)) }
    $btnApply = New-Object System.Windows.Forms.Button -Property @{ Text='Apply'; Width=120; Location=(New-Object System.Drawing.Point(180,510)) }
    $btnCancel= New-Object System.Windows.Forms.Button -Property @{ Text='Cancel'; Width=120; Location=(New-Object System.Drawing.Point(308,510)) }
    $dlg.Controls.AddRange(@($tb,$btnPaste,$btnApply,$btnCancel))
    $btnPaste.Add_Click({ $tb.Text=[Windows.Forms.Clipboard]::GetText() })
    $btnApply.Add_Click({
        try {
            $parsed = $tb.Text | ConvertFrom-Json -Depth 80
                
            # Validation & éventuelle migration vers dernière version
            $migrated = Invoke-ConfigValidationAndUpgrade -IncomingConfig $parsed -SourceLabel 'Paste'
            if ($migrated -eq $null) { return } # user cancelled
            $Global:AppState.CurrentConfig = $migrated

            Rehydrate-All
            Build-SectionButtons -Container $sectionsFlow
            if ($Global:AppState.CurrentSectionCode) { Render-Section -SectionCode $Global:AppState.CurrentSectionCode }
            Set-Dirty
            Update-MandatoryIndicators
            Log-And-Telemetry -Action "paste_json" -Message "Applied pasted JSON"
            $dlg.Close()
            [Windows.Forms.MessageBox]::Show("Configuration updated.","Success",'OK','Information')
        } catch {
            Write-ErrorLog -ErrorRecord $_ -Context 'PasteJSON'
            [Windows.Forms.MessageBox]::Show("Invalid JSON: $_",'Error','OK','Error')
        }
    })
    $btnCancel.Add_Click({ $dlg.Close() })
    [void]$dlg.ShowDialog($MainForm)
})

if (-not ($jsonRaw.Tag -is [hashtable])) { $jsonRaw.Tag = @{} }
if (-not $jsonRaw.Tag.ContainsKey('RawHandlerAttached')) {
    $jsonRaw.Add_Click({
        # Always build / refresh baseline once
        if (-not $Global:BaselineEffectiveConfig) {
            $initial = Build-EffectiveConfig
            if (-not $initial) { $initial = @{} }
            $Global:BaselineEffectiveConfig = (
                ($initial | ConvertTo-Json -Depth 80) | ConvertFrom-Json -Depth 80
            )
        }
        $currentObject = Build-EffectiveConfig
        if (-not $currentObject) { $currentObject = @{} }

        $readOnlyView = [bool]$Global:AppState.ReadOnly
        $edited = Show-RawJsonEditor -CurrentObject $currentObject -BaselineObject $Global:BaselineEffectiveConfig -ReadOnly:$readOnlyView

        # In Read-Only mode we never get an edited object back (viewer only)
        if ($readOnlyView) {
            return
        }

        if ($edited) {
            $rawStr = ($edited | ConvertTo-Json -Depth 80)
            if ($rawStr.ToUpper().Contains('UNCONFIGUREDENTRY')) {
                [Windows.Forms.MessageBox]::Show("Edited JSON still contains 'UNCONFIGUREDENTRY'. Please fill all mandatory values.","Mandatory Values Missing",'OK','Warning') | Out-Null
            }
            $Global:AppState.CurrentConfig = $edited
            Rehydrate-All
            Build-SectionButtons -Container $sectionsFlow
            if ($Global:AppState.CurrentSectionCode) { Render-Section -SectionCode $Global:AppState.CurrentSectionCode }
            Set-Dirty
            Update-MandatoryIndicators
            Log-And-Telemetry -Action "raw_json_applied" -Message "Raw JSON editor applied changes"
            [Windows.Forms.MessageBox]::Show("Configuration updated from Raw JSON editor.","Success",'OK','Information')
        }
    })
    $jsonRaw.Tag.RawHandlerAttached = $true
}

$toolsDiff.Add_Click({
    $diff = Generate-DiffSummary
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text="Diff Summary"
    $dlg.Width=760; $dlg.Height=540
    $dlg.StartPosition='CenterParent'
    $tb = New-Object System.Windows.Forms.TextBox -Property @{
        Multiline=$true; ReadOnly=$true; ScrollBars='Both';
        Font=(New-Object System.Drawing.Font("Consolas",10));
        Width=720; Height=440; Location=(New-Object System.Drawing.Point(12,12));
        Text=$diff
    }
    $btnOk = New-Object System.Windows.Forms.Button -Property @{ Text='OK'; Width=120; Location=(New-Object System.Drawing.Point(12,464)) }
    $btnOk.Add_Click({ $dlg.Close() })
    $dlg.Controls.AddRange(@($tb,$btnOk))
    [void]$dlg.ShowDialog($MainForm)
})

$toolsReset.Add_Click({
    if ($Global:AppState.ReadOnly) {
        [System.Windows.Forms.MessageBox]::Show("Read-Only mode.","Read-Only","OK","Information")|Out-Null; return
    }
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text="Reset ConfigurationCode"
    $dlg.Width=500; $dlg.Height=190; $dlg.StartPosition='CenterParent'
    $lbl = New-Object System.Windows.Forms.Label -Property @{ Text='Enter ConfigurationCode path to reset:'; AutoSize=$true; Location=(New-Object System.Drawing.Point(12,14)) }
    $txt = New-Object System.Windows.Forms.TextBox -Property @{ Width=460; Location=(New-Object System.Drawing.Point(12,40)) }
    $btn = New-Object System.Windows.Forms.Button -Property @{ Text='Reset'; Width=120; Location=(New-Object System.Drawing.Point(12,80)) }
    $btnClose = New-Object System.Windows.Forms.Button -Property @{ Text='Close'; Width=120; Location=(New-Object System.Drawing.Point(152,80)) }
    $btnClose.Add_Click({ $dlg.Close() })
    $btn.Add_Click({
        param($s,$e)
        $code = $txt.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($code)) { return }
        if ($Global:ConfigurationStore -and -not $Global:ConfigurationStore.ContainsKey($code)) {
            [System.Windows.Forms.MessageBox]::Show("Code not found in current configuration store.","Not Found","OK","Warning")|Out-Null; return
        }
        Reset-ConfigurationCodeValue -ConfigurationCode $code
    })
    $dlg.Controls.AddRange(@($lbl,$txt,$btn,$btnClose))
    [void]$dlg.ShowDialog($MainForm)
})

$fileOpen.Add_Click({
    if ($Global:AppState.ReadOnly -eq $false) {
        # Opening is allowed in both modes, but we keep write mode; no change required.
        # (If you want to force Read-Only after open, uncomment next line)
        # Set-ReadOnlyMode -ReadOnly $true
    }
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*"
    $ofd.Title  = "Open Configuration JSON"
    if ($Global:AppState.ConfigPath -and (Test-Path -LiteralPath $Global:AppState.ConfigPath)) {
        $ofd.InitialDirectory = [System.IO.Path]::GetDirectoryName($Global:AppState.ConfigPath)
        try { $ofd.FileName = [System.IO.Path]::GetFileName($Global:AppState.ConfigPath) } catch {}
    }
    if ($ofd.ShowDialog() -ne 'OK') { return }

    try {
        $raw = Get-Content -LiteralPath $ofd.FileName -Raw -ErrorAction Stop
        $parsed = $raw | ConvertFrom-Json -Depth 100
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Failed to load JSON:`r`n$($_.Exception.Message)","Open Error",'OK','Error') | Out-Null
        return
    }

    $migrated = Invoke-ConfigValidationAndUpgrade -IncomingConfig $parsed -SourceLabel "OpenFile:$($ofd.FileName)"
    if ($migrated -eq $null) { return }
    $Global:AppState.CurrentConfig = $migrated
    $Global:AppState.ConfigPath    = (Resolve-Path -LiteralPath $ofd.FileName).Path

    Rehydrate-All
    Build-SectionButtons -Container $sectionsFlow
    if ($Global:AppState.CurrentSectionCode) {
        Render-Section -SectionCode $Global:AppState.CurrentSectionCode
    }

    $Global:BaselineEffectiveConfig = (
        (Build-EffectiveConfig | ConvertTo-Json -Depth 80) | ConvertFrom-Json -Depth 80
    )

    Set-Dirty -Clear
    Update-WindowTitle
    if (Get-Command Update-MandatoryIndicators -ErrorAction SilentlyContinue) {
        Update-MandatoryIndicators
    }
    Update-ReadOnlyUI
    Log-And-Telemetry -Action "open_config" -Message "Opened configuration file" -Data @{ path=$Global:AppState.ConfigPath }
    [System.Windows.Forms.MessageBox]::Show("Configuration loaded: $($Global:AppState.ConfigPath)","Opened",'OK','Information') | Out-Null
})

$fileSave.Add_Click({
    if ($Global:AppState.ReadOnly) {
        [System.Windows.Forms.MessageBox]::Show("Switch to Write mode to save.","Read-Only",'OK','Information')|Out-Null
        return
    }
    $missing = Get-UnconfiguredCount
    if ($missing -gt 0) {
        $msg = "$missing mandatory value(s) still contain 'UNCONFIGUREDENTRY'." +
            "`r`n`r`nSaving now will produce an incomplete/invalid configuration." +
            "`r`nIt may fail at runtime. Do you want to save anyway?"
        $resp = [System.Windows.Forms.MessageBox]::Show($msg,'Mandatory Values Missing',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($resp -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        if (Get-Command Log-And-Telemetry -ErrorAction SilentlyContinue) {
            Log-And-Telemetry -Action "save_bypass_mandatory" -Message "User chose to bypass mandatory check" -Data @{ missing=$missing; path=$Global:AppState.ConfigPath }
        }
    }
    $diff = Generate-DiffSummary
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text="Diff Before Save"
    $dlg.Width=760; $dlg.Height=540
    $dlg.StartPosition='CenterParent'
    $tb = New-Object System.Windows.Forms.TextBox -Property @{
        Multiline=$true; ReadOnly=$true; ScrollBars='Both';
        Font=(New-Object System.Drawing.Font("Consolas",10));
        Width=720; Height=440; Location=(New-Object System.Drawing.Point(12,12));
        Text=$diff
    }
    $btnOk = New-Object System.Windows.Forms.Button -Property @{ Text='Accept and Save'; Width=160; Location=(New-Object System.Drawing.Point(12,464)) }
    $btnCancel = New-Object System.Windows.Forms.Button -Property @{ Text='Cancel'; Width=120; Location=(New-Object System.Drawing.Point(190,464)) }
    $btnOk.Add_Click({ $dlg.Close(); Save-ConfigFile $Global:AppState.ConfigPath })
    $btnCancel.Add_Click({ $dlg.Close() })
    $dlg.Controls.AddRange(@($tb,$btnOk,$btnCancel))
    [void]$dlg.ShowDialog($MainForm)
})

$fileSaveAs.Add_Click({
    if ($Global:AppState.ReadOnly) {
        [System.Windows.Forms.MessageBox]::Show("Switch to Write mode to save.","Read-Only",'OK','Information')|Out-Null
        return
    }
    $missing = Get-UnconfiguredCount
    if ($missing -gt 0) {
        $msg = "$missing mandatory value(s) still contain 'UNCONFIGUREDENTRY'." +
            "`r`n`r`nSaving now will produce an incomplete/invalid configuration." +
            "`r`nIt may fail at runtime. Do you want to continue with Save As?"
        $resp = [System.Windows.Forms.MessageBox]::Show($msg,'Mandatory Values Missing',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($resp -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        if (Get-Command Log-And-Telemetry -ErrorAction SilentlyContinue) {
            Log-And-Telemetry -Action "saveas_bypass_mandatory" -Message "User chose to bypass mandatory check (Save As)" -Data @{ missing=$missing }
        }
    }
    $sfd = New-Object System.Windows.Forms.SaveFileDialog
    $sfd.Filter="JSON files (*.json)|*.json|All files (*.*)|*.*"
    $sfd.Title="Save Configuration As"
    $sfd.FileName = [System.IO.Path]::GetFileName($Global:AppState.ConfigPath)
    if ($sfd.ShowDialog() -eq "OK") {
        $diff = Generate-DiffSummary
        $dlg = New-Object System.Windows.Forms.Form
        $dlg.Text="Diff Before Save As"
        $dlg.Width=760; $dlg.Height=540
        $dlg.StartPosition='CenterParent'
        $tb = New-Object System.Windows.Forms.TextBox -Property @{
            Multiline=$true; ReadOnly=$true; ScrollBars='Both';
            Font=(New-Object System.Drawing.Font("Consolas",10));
            Width=720; Height=440; Location=(New-Object System.Drawing.Point(12,12));
            Text=$diff
        }
        $btnOk = New-Object System.Windows.Forms.Button -Property @{ Text='Accept and Save As'; Width=160; Location=(New-Object System.Drawing.Point(12,464)) }
        $btnCancel = New-Object System.Windows.Forms.Button -Property @{ Text='Cancel'; Width=120; Location=(New-Object System.Drawing.Point(190,464)) }
        $btnOk.Add_Click({ $dlg.Close(); Save-ConfigFile $sfd.FileName })
        $btnCancel.Add_Click({ $dlg.Close() })
        $dlg.Controls.AddRange(@($tb,$btnOk,$btnCancel))
        [void]$dlg.ShowDialog($MainForm)
    }
})

#region Config Version & Schema Validation / Upgrade
if (-not (Get-Variable -Name ConfigParameterVersion -Scope Global -ErrorAction SilentlyContinue)) {
    try {
        $maybe = Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'Models') -Filter 'Models.Common.ps1' -ErrorAction Stop | Select-Object -First 1
        if ($maybe) { . $maybe.FullName }
    } catch {}
}

function Get-LatestReferenceConfig {
    param([switch]$Beta)

    $channel = if ($Beta) { 'beta' } else { 'prod' }
    $localcacheFile = "CollectExchSecConfiguration.$channel.latest.json"
    $Global:cacheFileContent = $null
    if ($Global:cacheFile -eq $localcacheFile -and $Global:cacheFileContent) {
        try { return ($Global:cacheFileContent | ConvertFrom-Json -Depth 100) } catch {}
    }

    $rawUrl = 'https://github.com/Azure/Azure-Sentinel/raw/refs/heads/master/Solutions/Microsoft%20Exchange%20Security%20-%20Exchange%20Online/%23%20-%20General%20Content/Solutions/ESICollector/CollectExchSecIns.zip'
    if ($Beta)
    {
        $rawUrl = 'https://github.com/Azure/Azure-Sentinel/raw/refs/heads/master/Solutions/Microsoft%20Exchange%20Security%20-%20Exchange%20Online/%23%20-%20General%20Content/Solutions/ESICollector/Beta/CollectExchSecIns.zip'
    }

    $Global:cachefile = $localcacheFile
    $Global:cacheFileContent = $null
    
    try {
        $tmp = Invoke-WebRequest -UseBasicParsing -Uri $rawUrl -TimeoutSec 20
        if ($tmp.Content) 
        { 
            # Extract JSON from ZIP content
            $zipStream = New-Object IO.MemoryStream(,$tmp.Content)
            $zip = New-Object IO.Compression.ZipArchive($zipStream)
            $entry = $zip.Entries | Where-Object { $_.Name -ieq 'CollectExchSecConfiguration.json' } | Select-Object -First 1
            if ($entry) {
                $reader = $entry.Open()
                $sr = New-Object IO.StreamReader($reader)
                $jsonContent = $sr.ReadToEnd()
                $sr.Close()
                $reader.Close()
                $zip.Dispose()
                $zipStream.Close()
                $result = $jsonContent | ConvertFrom-Json -Depth 100
                $Global:cacheFileContent = $jsonContent
                return $result
            }
        }
    } catch {}
    return $null
}

function Test-ConfigVersionMismatch { param($Config) try { return ($Config.SolutionMetadata.VersionInformation.PSObject.Properties.Name | Sort-Object -Descending | Select-Object -First 1) -ne $Global:ConfigParameterVersion } catch { return $true } }

function Show-ConfigUpgradeReview { param($Original,$Proposed,[string]$Title='Configuration Upgrade Review') $edited = Show-RawJsonEditor -CurrentObject $Proposed -BaselineObject $Original -ReadOnly:$false; return $edited }

function Invoke-ConfigValidationAndUpgrade {
    param($IncomingConfig,[string]$SourceLabel)
    if (-not $IncomingConfig) { return $IncomingConfig }
    $needsVersion = Test-ConfigVersionMismatch -Config $IncomingConfig
    $schemaOk = ($IncomingConfig.PSObject.Properties.Name -contains 'SolutionMetadata' -and $IncomingConfig.PSObject.Properties.Name -contains 'Global')
    if (-not $needsVersion -and $schemaOk) { return $IncomingConfig }
    $msg = "Configuration is outdated or schema incomplete. Source: $SourceLabel`nAttempt auto-upgrade?"
    $res = [System.Windows.Forms.MessageBox]::Show($msg,'Upgrade Required',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
    if ($res -ne [System.Windows.Forms.DialogResult]::Yes) { return $null }
    # Ask user for reference source
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text='Select Reference Source'; $dlg.Width=420; $dlg.Height=200; $dlg.StartPosition='CenterParent'
    $rbProd = New-Object System.Windows.Forms.RadioButton -Property @{ Text='Latest (Production)'; Checked=$true; Location=(New-Object System.Drawing.Point(12,12)); AutoSize=$true }
    $rbBeta = New-Object System.Windows.Forms.RadioButton -Property @{ Text='Latest (Beta)'; Location=(New-Object System.Drawing.Point(12,40)); AutoSize=$true }
    $rbLocal= New-Object System.Windows.Forms.RadioButton -Property @{ Text='Select Local Reference File'; Location=(New-Object System.Drawing.Point(12,68)); AutoSize=$true }
    $btnOk = New-Object System.Windows.Forms.Button -Property @{ Text='OK'; Width=100; Location=(New-Object System.Drawing.Point(12,110)) }
    $btnCancel = New-Object System.Windows.Forms.Button -Property @{ Text='Cancel'; Width=100; Location=(New-Object System.Drawing.Point(120,110)) }
    $dlg.Controls.AddRange(@($rbProd,$rbBeta,$rbLocal,$btnOk,$btnCancel))
    $btnOk.Add_Click({
        $sel = if ($rbProd.Checked) { 'prod' } elseif ($rbBeta.Checked) { 'beta' } elseif ($rbLocal.Checked) { 'local' } else { $null }
        if (-not $dlg.Tag -or -not ($dlg.Tag -is [hashtable])) { $dlg.Tag = @{} }
        $dlg.Tag.Selection = $sel
        if ($sel -eq 'local') {
            $ofd = New-Object System.Windows.Forms.OpenFileDialog
            $ofd.Filter='JSON files (*.json)|*.json|All files (*.*)|*.*'; $ofd.Title='Select Local Reference Configuration'
            if ($ofd.ShowDialog() -eq 'OK') {
                try { $dlg.Tag.LocalRef = (Get-Content -LiteralPath $ofd.FileName -Raw | ConvertFrom-Json -Depth 100) } catch { $dlg.Tag.LocalRef = $null }
            } else {
                $dlg.Tag.Selection = $null
            }
        }
        $dlg.Close()
    })
    $btnCancel.Add_Click({ $dlg.Tag = @{ Selection=$null }; $dlg.Close() })
    [void]$dlg.ShowDialog($MainForm)

    if (-not $dlg.Tag -or -not ($dlg.Tag -is [hashtable]) -or -not $dlg.Tag.Selection) { return $null }
    $selection = $dlg.Tag.Selection
    $latest = $null
    if ($selection -eq 'local') {
        $latest = $dlg.Tag.LocalRef
    } else {
        $latest = Get-LatestReferenceConfig -Beta:($selection -eq 'beta')
    }
    if (-not $latest) {
        [System.Windows.Forms.MessageBox]::Show('Failed to obtain reference configuration.','Reference Error','OK','Error')|Out-Null
        return $null
    }
    # --- Deprecated top-level fields handling ---
    $deprecated = @()
    try {
        if ($IncomingConfig -is [psobject] -and $latest -is [psobject]) {
            $incomingKeys = $IncomingConfig.PSObject.Properties.Name
            $refKeys = $latest.PSObject.Properties.Name
            $deprecated += $incomingKeys | Where-Object { $refKeys -notcontains $_ }
        }
    } catch {}
    if ($null -ne $deprecated -and $deprecated.Count -gt 0) {
        $dlgDep = New-Object System.Windows.Forms.Form
        $dlgDep.Text='Deprecated Fields'; $dlgDep.Width=460; $dlgDep.Height=420; $dlgDep.StartPosition='CenterParent'
        $lbl = New-Object System.Windows.Forms.Label -Property @{ Text='Select deprecated top-level fields to remove:'; AutoSize=$true; Location=(New-Object System.Drawing.Point(12,12)) }
        $clb = New-Object System.Windows.Forms.CheckedListBox -Property @{ Location=(New-Object System.Drawing.Point(12,40)); Width=420; Height=300; CheckOnClick=$true }
        foreach($k in $deprecated){ [void]$clb.Items.Add($k,$true) }
        $btnRemove = New-Object System.Windows.Forms.Button -Property @{ Text='Remove Selected'; Width=130; Location=(New-Object System.Drawing.Point(12,350)) }
        $btnKeep = New-Object System.Windows.Forms.Button -Property @{ Text='Keep All'; Width=100; Location=(New-Object System.Drawing.Point(160,350)) }
        $btnCancel = New-Object System.Windows.Forms.Button -Property @{ Text='Cancel'; Width=100; Location=(New-Object System.Drawing.Point(270,350)) }
        $dlgDep.Controls.AddRange(@($lbl,$clb,$btnRemove,$btnKeep,$btnCancel))
        $dlgDep.Tag=@{ Action=''; Remove=@() }
        $btnRemove.Add_Click({ $sel=@(); foreach($i in $clb.CheckedItems){ $sel+=$i }; $dlgDep.Tag.Action='remove'; $dlgDep.Tag.Remove=$sel; $dlgDep.Close() })
        $btnKeep.Add_Click({ $dlgDep.Tag.Action='keep'; $dlgDep.Close() })
        $btnCancel.Add_Click({ $dlgDep.Tag.Action='cancel'; $dlgDep.Close() })
        [void]$dlgDep.ShowDialog($MainForm)
        if ($dlgDep.Tag.Action -eq 'cancel') { return $null }
        if ($dlgDep.Tag.Action -eq 'remove' -and $dlgDep.Tag.Remove.Count -gt 0 -and $IncomingConfig -is [psobject]) {
            foreach($rk in $dlgDep.Tag.Remove){ try { $prop=$IncomingConfig.PSObject.Properties[$rk]; if($prop){ $IncomingConfig.PSObject.Properties.Remove($rk)|Out-Null } } catch {} }
        }
    }

    $merged = RJ_MergeConfig -Reference $latest -Existing $IncomingConfig -ForceRefSolutionMetadata
    $review = Show-ConfigUpgradeReview -Original $IncomingConfig -Proposed $merged -Title 'Configuration Upgrade Review'
    if (-not $review) { return $null }
    return $review
}

function RJ_MergeConfig {
    param(
        $Reference,
        $Existing,
        [switch]$ForceRefSolutionMetadata
    )
    if ($Reference -is [System.Collections.IEnumerable] -and $Reference -isnot [string] -and $Existing -is [System.Collections.IEnumerable] -and $Existing -isnot [string]) { return $Existing }
    if ($Reference -is [psobject] -and $Existing -is [psobject]) {
        $out = [ordered]@{}
        foreach ($p in $Reference.PSObject.Properties) {
            if ($ForceRefSolutionMetadata -and $p.Name -eq 'SolutionMetadata') { $out[$p.Name] = $p.Value; continue }
            if ($Existing.PSObject.Properties.Name -contains $p.Name) {
                $out[$p.Name] = RJ_MergeConfig -Reference $p.Value -Existing $Existing.($p.Name) -ForceRefSolutionMetadata:$ForceRefSolutionMetadata
            } else { $out[$p.Name] = $p.Value }
        }
        foreach ($p in $Existing.PSObject.Properties) 
        { 
            if (-not $out.Contains($p.Name)) { $out[$p.Name] = $p.Value } 
        }

        return ([pscustomobject]$out)
    }
    if ($null -ne $Existing -and $Existing -ne '') { return $Existing }
    return $Reference
}
#endregion Config Version & Schema Validation / Upgrade

$MainForm.Add_Shown({ Update-MandatoryIndicators; Update-ReadOnlyUI })
$MainForm.Add_Shown({ if (Get-Command Update-AzureStatusIndicator -ErrorAction SilentlyContinue) { Update-AzureStatusIndicator } })

[void]$MainForm.ShowDialog()