<#
Utilities.Serialization.ps1
NEW:
 - Convert-AllNumbersAndBoolsToStrings: deep transform (mutates) object graph; booleans -> 'true'/'false' (lowercase), integers -> string.
 - Get-ConfigStringifiedClone: returns a clone of current effective config with transformation applied.
Logging:
 - Logs action start/end & summary.
#>

if (-not (Get-Command Log-And-Telemetry -ErrorAction SilentlyContinue)) {
    function Log-And-Telemetry { param([string]$Action,[string]$Message,[hashtable]$Data=@{}) Write-Host "LOG: $Action $Message" }
}
if (-not (Get-Command Write-ErrorLog -ErrorAction SilentlyContinue)) {
    function Write-ErrorLog { param($ErrorRecord,[string]$Context) Write-Warning "$Context : $($ErrorRecord.Exception.Message)" }
}

function Convert-AllNumbersAndBoolsToStrings {
    param([ref]$Obj)
    if ($null -eq $Obj.Value) { return }
    $t = $Obj.Value.GetType().FullName
    switch ($Obj.Value) {
        { $_ -is [bool] } {
            $Obj.Value = if ($Obj.Value) { 'true' } else { 'false' }; return
        }
        { $_ -is [byte] -or $_ -is [sbyte] -or $_ -is [int16] -or $_ -is [uint16] -or $_ -is [int32] -or $_ -is [uint32] -or $_ -is [int64] -or $_ -is [uint64] -or $_ -is [single] -or $_ -is [double] -or $_ -is [decimal] } {
            $Obj.Value = "$($Obj.Value)"; return
        }
        { $_ -is [string] } { return }
    }
    # Arrays / lists
    if ($Obj.Value -is [System.Collections.IEnumerable] -and $Obj.Value -isnot [string]) {
        # PSCustomObject?
        if ($Obj.Value -is [pscustomobject]) {
            foreach ($p in $Obj.Value.PSObject.Properties) {
                $tmp = $p.Value
                Convert-AllNumbersAndBoolsToStrings ([ref]$tmp)
                $Obj.Value | Add-Member -NotePropertyName $p.Name -NotePropertyValue $tmp -Force
            }
            return
        }
        # Hashtable / IDictionary
        if ($Obj.Value -is [System.Collections.IDictionary]) {
            foreach ($k in @($Obj.Value.Keys)) {
                $tmp = $Obj.Value[$k]
                Convert-AllNumbersAndBoolsToStrings ([ref]$tmp)
                $Obj.Value[$k] = $tmp
            }
            return
        }
        # Generic collection / array
        $new = New-Object System.Collections.ArrayList
        foreach ($el in $Obj.Value) {
            $tmp=$el
            Convert-AllNumbersAndBoolsToStrings ([ref]$tmp)
            [void]$new.Add($tmp)
        }
        $Obj.Value = @($new)
        return
    }
}

function Get-ConfigStringifiedClone {
    try {
        Log-And-Telemetry -Action "stringify_start" -Message "Starting stringify clone"
        $eff = Build-EffectiveConfig
    $clone = (($eff | ConvertTo-Json -Depth 80) | ConvertFrom-Json)
        $ref = $clone
        Convert-AllNumbersAndBoolsToStrings ([ref]$ref)
        Log-And-Telemetry -Action "stringify_done" -Message "Stringify clone complete"
        return $ref
    } catch {
        Write-ErrorLog -ErrorRecord $_ -Context 'Get-ConfigStringifiedClone'
        Log-And-Telemetry -Action "stringify_error" -Message $_.Exception.Message
        throw
    }
}