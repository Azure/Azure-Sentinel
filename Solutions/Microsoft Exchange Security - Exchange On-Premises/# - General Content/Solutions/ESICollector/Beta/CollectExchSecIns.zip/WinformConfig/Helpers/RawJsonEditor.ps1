<#
RawJsonEditor.ps1
UNIFIED PATCH:
 - Fix persistent overlap of the toolbar (bar) over the TreeView.
 - Re‑introduce the Read‑Only (-ReadOnly) mode from earlier patch.
 - Ensure only ONE layout implementation is used (remove older RawJsonEditor.ps1 versions).
 - Uses a dedicated container panel ($treeHost) inside the Tree tab:
      $treeHost (Dock=Fill)
        ├─ $bar  (Dock=Top, Height=44)
        ├─ $tree (Dock=Fill)
        └─ $edit (absolute positioned inline editor; added AFTER tree so it renders on top)
 - Docking order is enforced explicitly with SuspendLayout/ResumeLayout to avoid race / DPI anomalies.
 - Added $treeHost.PerformLayout() after initial build & after each rebuild to guarantee layout refresh.
 - Added BringToFront on $bar after adding all children (some hosts with custom themes reversed z-order).
 - Inline editor SetBounds uses tree.DisplayRectangle.Top to ensure correct vertical offset if any border/padding changes.
 - ReadOnly mode:
      * Disables editing / context menu / raw JSON editing & undo/redo.
      * Still allows expand / collapse / search (search live filters).
 - Function signature:
      Show-RawJsonEditor -CurrentObject <psobject> -BaselineObject <psobject> [-ReadOnly]
 - Returns:
      * Edited psobject (Write mode & Apply)
      * $null in ReadOnly mode or when cancelled.
Make sure SetupCollectExchSecConfiguration.ps1 calls this version (optionally passing -ReadOnly based on app state).
#>

#region Helpers (unchanged core helpers)

function RJ_NewClone {
    param($Obj)
    if ($null -eq $Obj) { return @{} }
    try { return (($Obj | ConvertTo-Json -Depth 60) | ConvertFrom-Json -Depth 60) } catch { return $Obj }
}
function RJ_GetNoteProps {
    param($Obj)
    if ($Obj -is [pscustomobject]) {
        return $Obj.PSObject.Properties |
            Where-Object MemberType -eq NoteProperty |
            Select-Object -ExpandProperty Name
    }
    if ($Obj -is [System.Collections.IDictionary]) { return @($Obj.Keys) }
    return @()
}
function RJ_BuildPathMap {
    param($Object,[string]$Base='')
    $map=@{}
    if ($null -eq $Object) { return $map }
    if ($Object -is [System.Collections.IEnumerable] -and
        $Object -isnot [string] -and
        $Object -isnot [System.Collections.IDictionary] -and
        $Object -isnot [pscustomobject]) {
        $i=0
        foreach($x in $Object){
            $child = if ($Base) { "$Base`[$i`]" } else { "`[$i`]" }
            (RJ_BuildPathMap -Object $x -Base $child).GetEnumerator() | ForEach-Object { $map[$_.Key]=$_.Value }
            $i++
        }
        return $map
    }
    if ($Object -is [System.Collections.IDictionary]) {
        foreach ($k in $Object.Keys){
            $child = if ($Base) { "$Base.$k" } else { "$k" }
            (RJ_BuildPathMap -Object $Object[$k] -Base $child).GetEnumerator() | ForEach-Object { $map[$_.Key]=$_.Value }
        }
        return $map
    }
    if ($Object -is [pscustomobject]) {
        foreach ($k in (RJ_GetNoteProps $Object)){
            $val=$Object.$k
            $child= if ($Base) { "$Base.$k" } else { "$k" }
            (RJ_BuildPathMap -Object $val -Base $child).GetEnumerator() | ForEach-Object { $map[$_.Key]=$_.Value }
        }
        return $map
    }
    $map[$Base]=$Object
    return $map
}
function RJ_GetByPath {
    param($Object,[string]$Path)
    if (-not $Path) { return $Object }
    $segments=@()
    $regex=[regex]'\[[0-9]+\]|[^.\[\]]+'
    foreach($m in $regex.Matches($Path)){ $segments+=$m.Value }
    $cur=$Object
    foreach($seg in $segments){
        if ($seg -match '^\[[0-9]+\]$'){
            $i=[int]($seg.Trim('[',']'))
            if ($cur -is [System.Collections.IList]) {
                if ($i -ge $cur.Count) { return $null }
                $cur=$cur[$i]
            } else { return $null }
        } else {
            if ($cur -is [System.Collections.IDictionary]) {
                if (-not $cur.Contains($seg)) { return $null }
                $cur=$cur[$seg]
            } elseif ($cur -is [pscustomobject]) {
                if (-not $cur.PSObject.Properties.Match($seg)) { return $null }
                $cur=$cur.$seg
            } else { return $null }
        }
    }
    return $cur
}
function RJ_SetByPath {
    param($Object,[string]$Path,$Value)
    if (-not $Path) { return }
    $segments=@()
    $regex=[regex]'\[[0-9]+\]|[^.\[\]]+'
    foreach($m in $regex.Matches($Path)){ $segments+=$m.Value }
    $cursor=$Object
    $last=$segments.Count-1
    for($i=0;$i -lt $last;$i++){
        $seg=$segments[$i]
        if ($seg -match '^\[[0-9]+\]$'){
            $idx=[int]($seg.Trim('[',']'))
            if ($cursor -is [System.Collections.IList]) {
                if ($idx -ge $cursor.Count) { return }
                $cursor=$cursor[$idx]
            } else { return }
        } else {
            if ($cursor -is [System.Collections.IDictionary]) {
                if (-not $cursor.Contains($seg)) { return }
                $cursor=$cursor[$seg]
            } elseif ($cursor -is [pscustomobject]) {
                if (-not $cursor.PSObject.Properties.Match($seg)) { return }
                $cursor=$cursor.$seg
            } else { return }
        }
    }
    $leaf=$segments[-1]
    if ($leaf -match '^\[[0-9]+\]$'){
        $idx=[int]($leaf.Trim('[',']'))
        if ($cursor -is [System.Collections.IList] -and $idx -lt $cursor.Count){ $cursor[$idx]=$Value }
    } else {
        if ($cursor -is [System.Collections.IDictionary]) {
            if ($cursor.Contains($leaf)) { $cursor[$leaf]=$Value }
        } elseif ($cursor -is [pscustomobject]) {
            if ($cursor.PSObject.Properties.Match($leaf)){
                $cursor | Add-Member -NotePropertyName $leaf -NotePropertyValue $Value -Force
            }
        }
    }
}
function RJ_Infer {
    param([string]$Raw)
    if ($null -eq $Raw) { return $null }
    if ($Raw -eq 'null') { return $null }
    if ($Raw -match '^(?i:true|false)$'){ return [bool]::Parse($Raw.ToLower()) }
    if ($Raw -match '^-?\d+$'){ try { return [int]$Raw } catch {} }
    if ($Raw -match '^-?\d+\.\d+$'){ try { return [double]$Raw } catch {} }
    return $Raw
}
function RJ_NormFilter { param([string]$t) if ([string]::IsNullOrEmpty($t)){''} else { try { $t.ToLower() } catch { '' } } }

#endregion Helpers

#region Tree builder

function RJ_AddNodes {
    param(
        [System.Windows.Forms.TreeNode]$Parent,
        $Object,
        [string]$BasePath,
        [hashtable]$BaseMap,
    [hashtable]$CurMap,
    [hashtable]$DiffClassMap,
        [string]$Filter
    )
    if (-not $Parent){ return $false }
    $Filter = RJ_NormFilter $Filter
    $isLeaf=$false
    $kids=@()

    try {
        if ($null -eq $Object){
            $isLeaf=$true
        } elseif ($Object -is [System.Collections.IEnumerable] -and
                  $Object -isnot [string] -and
                  $Object -isnot [System.Collections.IDictionary] -and
                  $Object -isnot [pscustomobject]) {
            $i=0
            foreach($item in $Object){
                $child= if ($BasePath) { "$BasePath`[$i`]" } else { "`[$i`]" }
                $n = New-Object System.Windows.Forms.TreeNode -Property @{ Text="[${i}]" }
                $n.Tag=@{ Path=$child; IsLeaf=$false; IsArrayElement=$true; Index=$i }
                if (RJ_AddNodes -Parent $n -Object $item -BasePath $child -BaseMap $BaseMap -CurMap $CurMap -Filter $Filter) { $kids+=$n }
                $i++
            }
        } elseif ($Object -is [System.Collections.IDictionary]) {
            $keys=@($Object.Keys | Sort-Object)
            if ($keys -contains 'SolutionMetadata'){
                $keys = @('SolutionMetadata') + ($keys | Where-Object { $_ -ne 'SolutionMetadata' })
            }
            foreach($k in $keys){
                $child= if ($BasePath){ "$BasePath.$k" } else { "$k" }
                $n = New-Object System.Windows.Forms.TreeNode -Property @{ Text=$k }
                $n.Tag=@{ Path=$child; IsLeaf=$false }
                if (RJ_AddNodes -Parent $n -Object $Object[$k] -BasePath $child -BaseMap $BaseMap -CurMap $CurMap -Filter $Filter) { $kids+=$n }
            }
        } elseif ($Object -is [pscustomobject]) {
            $props=(RJ_GetNoteProps $Object | Sort-Object)
            if ($props -contains 'SolutionMetadata'){
                $props = @('SolutionMetadata') + ($props | Where-Object { $_ -ne 'SolutionMetadata' })
            }
            foreach($k in $props){
                $val=$Object.$k
                $child= if ($BasePath){ "$BasePath.$k" } else { "$k" }
                $n = New-Object System.Windows.Forms.TreeNode -Property @{ Text=$k }
                $n.Tag=@{ Path=$child; IsLeaf=$false }
                if (RJ_AddNodes -Parent $n -Object $val -BasePath $child -BaseMap $BaseMap -CurMap $CurMap -Filter $Filter) { $kids+=$n }
            }
        } else {
            $isLeaf=$true
        }

        $changed=$false
        $class=$null
        if ($BasePath) {
            if ($DiffClassMap -and $DiffClassMap.ContainsKey($BasePath)) { $class = $DiffClassMap[$BasePath] }
            if (-not $class -and $BaseMap.ContainsKey($BasePath) -and $CurMap.ContainsKey($BasePath)) {
                if ("$($BaseMap[$BasePath])" -ne "$($CurMap[$BasePath])") { $changed=$true }
            }
        }
        if (-not $changed -and $kids.Count -gt 0){ foreach($k in $kids){ if ($k.BackColor -ne [System.Drawing.Color]::Empty){ $changed=$true; break } } }
        switch($class){
            'Added'            { $Parent.BackColor=[System.Drawing.Color]::LightGreen }
            'Removed'          { $Parent.BackColor=[System.Drawing.Color]::LightCoral }
            'ModifiedValue'    { $Parent.BackColor=[System.Drawing.Color]::Khaki }
            'ModifiedStructure'{ $Parent.BackColor=[System.Drawing.Color]::LightBlue }
            default { if ($changed) { $Parent.BackColor=[System.Drawing.Color]::Khaki } }
        }

        if ($isLeaf){
            $disp = if ($null -eq $Object) { 'null' } else { $Object }
            $keyLabel=$Parent.Text
            if ($disp -is [string]){
                $Parent.Text="$keyLabel : `"$disp`""
            } else {
                $Parent.Text="$keyLabel : $disp"
            }
            $Parent.Tag=@{ Path=$BasePath; IsLeaf=$true; RawKey=$keyLabel }
        } else {
            foreach($n in $kids){ [void]$Parent.Nodes.Add($n) }
        }

    if ($script:HideUnchanged -and -not $class -and -not $changed) { return $false }
    if (-not $Filter){ return $true }
        $textLower = RJ_NormFilter $Parent.Text
        $baseLower = RJ_NormFilter $BasePath
        $match = ($textLower.Contains($Filter) -or ($baseLower -and $baseLower.Contains($Filter)))
        return ($match -or ($kids.Count -gt 0))
    } catch {
        return $false
    }
}

#endregion Tree builder

#region Undo helper
function RJ_PushUndo {
    param([ref]$Undo,[ref]$Redo,$Working)
    try {
        $Undo.Value.Push( (RJ_NewClone $Working) )
        $Redo.Value.Clear()
    } catch {}
}
#endregion Undo helper

#region Main UI

function Show-RawJsonEditor {
    param(
        $CurrentObject,
        $BaselineObject,
        [switch]$ReadOnly,
        [string]$Title,
        [switch]$DiffMode
    )

    if ($null -eq $CurrentObject)  { $CurrentObject=@{} }
    if ($null -eq $BaselineObject) { $BaselineObject=@{} }

    # Reset per-invocation state to prevent leaking from previous calls
    $script:HideUnchanged = $false
    $script:diffText = New-Object System.Text.StringBuilder

    $Working  = RJ_NewClone $CurrentObject
    $Baseline = RJ_NewClone $BaselineObject

    $undo = New-Object System.Collections.Stack
    $redo = New-Object System.Collections.Stack
    RJ_PushUndo -Undo ([ref]$undo) -Redo ([ref]$redo) -Working $Working

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = if ($Title) { $Title } elseif ($ReadOnly) { 'Raw JSON Viewer (Read-Only)' } else { 'Raw JSON Editor' }
    $dlg.Width=1150; $dlg.Height=800
    $dlg.StartPosition='CenterParent'
    $dlg.KeyPreview=$true

    # Buttons bottom

    $bottomPanel = New-Object System.Windows.Forms.Panel
    $bottomPanel.Dock = 'Bottom'
    $bottomPanel.Height = 50
    $dlg.Controls.Add($bottomPanel)

    $textContent = if ($ReadOnly) { 'Close' } else { 'Apply' }
    $btnApply = New-Object System.Windows.Forms.Button -Property @{
        Text = $textContent
        Width=120; Location=(New-Object System.Drawing.Point(12,8))
    }
    $btnCancel= $null
    if (-not $ReadOnly) {
        $btnCancel = New-Object System.Windows.Forms.Button -Property @{ Text='Cancel'; Width=120; Location=(New-Object System.Drawing.Point(140,8)) }
        $bottomPanel.Controls.Add($btnCancel)
    }
    $bottomPanel.Controls.Add($btnApply)

    $tabs = New-Object System.Windows.Forms.TabControl
    $tabs.Dock='Fill'
    $dlg.Controls.Add($tabs)

    $tpTree = New-Object System.Windows.Forms.TabPage -Property @{ Text='Tree' }
    $tpRaw  = New-Object System.Windows.Forms.TabPage -Property @{ Text='Raw' }
    $tpDiff = New-Object System.Windows.Forms.TabPage -Property @{ Text='Diff' }
    $tabs.TabPages.AddRange(@($tpTree,$tpRaw,$tpDiff))

    # ---- Tree Host (prevents overlap) ----
    $treeHost = New-Object System.Windows.Forms.Panel
    $treeHost.Dock='Fill'
    $tpTree.Controls.Add($treeHost)

    # Toolbar
    $bar = New-Object System.Windows.Forms.Panel -Property @{ Dock='Top'; Height=44 }
    $btnExpand   = New-Object System.Windows.Forms.Button -Property @{ Text='Expand';   Width=80; Location=(New-Object System.Drawing.Point(6,8)) }
    $btnCollapse = New-Object System.Windows.Forms.Button -Property @{ Text='Collapse'; Width=80; Location=(New-Object System.Drawing.Point(92,8)) }
    $btnUndo     = New-Object System.Windows.Forms.Button -Property @{ Text='Undo';     Width=60; Location=(New-Object System.Drawing.Point(178,8)) }
    $btnRedo     = New-Object System.Windows.Forms.Button -Property @{ Text='Redo';     Width=60; Location=(New-Object System.Drawing.Point(242,8)) }
    $lblChg      = New-Object System.Windows.Forms.Label  -Property @{ Text='Add=LightGreen  Rem=LightCoral  Val=Khaki  Struct=LightBlue'; AutoSize=$true; Location=(New-Object System.Drawing.Point(310,12)) }
    $chkHideTree = New-Object System.Windows.Forms.CheckBox -Property @{ Text='Δ only'; AutoSize=$true; Location=(New-Object System.Drawing.Point(720,12)) }
    $txtSearch   = New-Object System.Windows.Forms.TextBox -Property @{ Width=240; Location=(New-Object System.Drawing.Point(450,10)) }
    $btnClear    = New-Object System.Windows.Forms.Button -Property @{ Text='Clear'; Width=55; Location=(New-Object System.Drawing.Point(694,8)) }
    $bar.Controls.AddRange(@($btnExpand,$btnCollapse,$btnUndo,$btnRedo,$lblChg,$txtSearch,$btnClear,$chkHideTree))
    

    # Tree
    $tree = New-Object System.Windows.Forms.TreeView -Property @{
        Dock='Fill'; HideSelection=$false; Font=(New-Object System.Drawing.Font('Consolas',10))
    }
    $treeHost.Controls.Add($tree)
    $treeHost.Controls.Add($bar)

    # Inline editor textbox (added after tree so it renders above it)
    $edit = New-Object System.Windows.Forms.TextBox -Property @{
        Visible=$false; Font=(New-Object System.Drawing.Font('Consolas',10)); BorderStyle='FixedSingle'
    }
    if (-not $ReadOnly) { $treeHost.Controls.Add($edit) }


    # Raw tab
    $textContent = if ($ReadOnly) { 'Read-Only view of JSON.' } else { 'Edit JSON below; valid changes sync to tree.' }
    $rawInfo = New-Object System.Windows.Forms.Label -Property @{ Text= $textContent; AutoSize=$true; Location=(New-Object System.Drawing.Point(8,10)) }
    $chkHideRaw = New-Object System.Windows.Forms.CheckBox -Property @{ Text='Δ only'; AutoSize=$true; Location=(New-Object System.Drawing.Point(300,8)) }
    $lblRawLegend = New-Object System.Windows.Forms.Label -Property @{ Text='Add=LightGreen  Rem=LightCoral  Val=Khaki  Struct=LightBlue  …=omission'; AutoSize=$true; Location=(New-Object System.Drawing.Point(370,10)) }
    $panelRawTop = New-Object System.Windows.Forms.Panel -Property @{ Dock='Top'; Height=34 }
    $panelRawTop.Controls.AddRange(@($rawInfo,$chkHideRaw,$lblRawLegend))

    $rtb = New-Object System.Windows.Forms.RichTextBox -Property @{
        Dock='Fill'; Font=(New-Object System.Drawing.Font('Consolas',10)); WordWrap=$false; ScrollBars='Both'; ReadOnly=$ReadOnly
    }
    $tpRaw.Controls.Add($rtb)
    $tpRaw.Controls.Add($panelRawTop)

    # JSON syntax highlight helpers
    function RJ_HighlightJsonTokens {
        param(
            [System.Windows.Forms.RichTextBox]$Box,
            [switch]$NoReset,
            [switch]$OnlyUnchangedDiff
        )
        if (-not $Box) { return }
        try {
            $text = $Box.Text
            if (-not $text) { return }
            $selStart = $Box.SelectionStart; $selLen = $Box.SelectionLength
            if (-not $NoReset) {
                $Box.SelectionStart = 0; $Box.SelectionLength = $Box.TextLength
                $Box.SelectionColor = [System.Drawing.Color]::Black
            }
            $patterns = @(
                @{ Pattern='"([^"\\]|\\.)*"(?=\s*:)' ; Color=[System.Drawing.Color]::Blue },          # property names
                @{ Pattern='(?<=:\s*)"([^"\\]|\\.)*"' ; Color=[System.Drawing.Color]::Brown },        # string values
                @{ Pattern='(?<![A-Za-z0-9_\-])[-]?(?:0|[1-9]\d*)(?:\.\d+)?(?!(?:[A-Za-z0-9_]))' ; Color=[System.Drawing.Color]::DarkCyan }, # numbers
                @{ Pattern='\b(true|false|null)\b' ; Color=[System.Drawing.Color]::Purple }               # booleans/null
            )
            foreach($pat in $patterns){
                $rg = New-Object System.Text.RegularExpressions.Regex($pat.Pattern,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
                foreach($m in $rg.Matches($text)){
                    $idx = $m.Index; $len = $m.Length
                    if ($OnlyUnchangedDiff) {
                        # Determine start of line
                        $lineStart = $text.LastIndexOf("`n", [Math]::Max(0,$idx-1))
                        if ($lineStart -lt 0) { $lineStart = 0 } else { $lineStart++ }
                        if ($text.Length -le $lineStart + 1) { continue }
                        $prefix = $text.Substring($lineStart, [Math]::Min(2, $text.Length - $lineStart))
                        if ($prefix -ne '  ') { continue } # Only highlight unchanged lines (start with two spaces)
                    }
                    $Box.SelectionStart = $idx
                    $Box.SelectionLength = $len
                    $Box.SelectionColor = $pat.Color
                }
            }
            # Restore selection
            $Box.SelectionStart = $selStart
            $Box.SelectionLength = $selLen
        } catch {}
    }

    # Diff tab (read-only visual diff baseline vs working)
    $diffInfo = New-Object System.Windows.Forms.Label -Property @{ Text='Baseline vs Current (contextual line diff)'; AutoSize=$true; Location=(New-Object System.Drawing.Point(8,8)) }
    $diffBox = New-Object System.Windows.Forms.RichTextBox -Property @{ Dock='Fill'; Font=(New-Object System.Drawing.Font('Consolas',10)); ReadOnly=$true; WordWrap=$false; HideSelection=$false }
    $panelDiffTop = New-Object System.Windows.Forms.Panel -Property @{ Dock='Top'; Height=30 }
    $btnDiffCopy = New-Object System.Windows.Forms.Button -Property @{ Text='Copy'; Width=60; Location=(New-Object System.Drawing.Point(300,4)) }
    $btnDiffExport = New-Object System.Windows.Forms.Button -Property @{ Text='Export'; Width=70; Location=(New-Object System.Drawing.Point(366,4)) }
    # Légende des marqueurs (+ ajouté, - supprimé, lignes modifiées affichées en paire -/+ ; deux espaces = inchangé ; SolutionMetadata ignoré ; ordre des propriétés normalisé)
    $lblDiffLegend = New-Object System.Windows.Forms.Label -Property @{ 
        AutoSize = $true;
        Location = (New-Object System.Drawing.Point(450,8));
        Text = '+ ajouté   - supprimé   (ligne modifiée = bloc - / +)   "  " inchangé   (SolutionMetadata ignoré, ordre des propriétés ignoré)'
    }
    $panelDiffTop.Controls.AddRange(@($diffInfo,$btnDiffCopy,$btnDiffExport,$lblDiffLegend))
    $tpDiff.Controls.Add($diffBox)
    $tpDiff.Controls.Add($panelDiffTop)

    # Canonicalisation: tri récursif des clés d'objet pour rendre le diff tolérant aux réordonnancements.
    # On exclut explicitement la racine / les sous-arbres 'SolutionMetadata' du diff (ignoré).
    function RJ_ToCanonical {
        param($Obj)
        if ($null -eq $Obj) { return $null }
        # Tableau / énumération (conserve l'ordre des éléments)
        if ($Obj -is [System.Collections.IEnumerable] -and $Obj -isnot [string] -and $Obj -isnot [System.Collections.IDictionary] -and $Obj -isnot [pscustomobject]) {
            $tmp = @()
            foreach($it in $Obj){ $tmp += ,(RJ_ToCanonical $it) }
            return $tmp
        }
        # Dictionnaire
        if ($Obj -is [System.Collections.IDictionary]) {
            $ordered = [ordered]@{}
            $keys = @($Obj.Keys | Where-Object { $_ -ne 'SolutionMetadata' } | Sort-Object)
            foreach($k in $keys){ $ordered[$k] = RJ_ToCanonical $Obj[$k] }
            return $ordered
        }
        # PSCustomObject
        if ($Obj -is [pscustomobject]) {
            $ordered = [ordered]@{}
            $props = @( (RJ_GetNoteProps $Obj) | Where-Object { $_ -ne 'SolutionMetadata' } | Sort-Object )
            foreach($p in $props){ $ordered[$p] = RJ_ToCanonical $Obj.$p }
            return $ordered
        }
        return $Obj
    }

    function Update-DiffTab {
        try {
            # 1. Canonicaliser (ordre des clés) et exclure SolutionMetadata
            $canonBase = RJ_ToCanonical $Baseline
            $canonWork = RJ_ToCanonical $Working

            # 2. Construire des maps chemin->valeur (réutilise logique existante)
            $mapBase = RJ_BuildPathMap -Object $canonBase
            $mapWork = RJ_BuildPathMap -Object $canonWork

            # 3. Union des chemins (ignorer racine vide et ceux contenant SolutionMetadata)
            $allPaths = New-Object System.Collections.Generic.HashSet[string]
            foreach($k in $mapBase.Keys){ if ($k -and $k -notmatch '^SolutionMetadata(\.|$)' -and $k -notmatch '\bSolutionMetadata\b'){ [void]$allPaths.Add($k) } }
            foreach($k in $mapWork.Keys){ if ($k -and $k -notmatch '^SolutionMetadata(\.|$)' -and $k -notmatch '\bSolutionMetadata\b'){ [void]$allPaths.Add($k) } }

            # 4. Tri des chemins pour stabilité (prof->alpha)
            $sorted = $allPaths | Sort-Object { $_.Split('.').Length }, { $_ }

            # Helpers format valeur sur une ligne
            function RJ_FormatValue([object]$v){
                if ($null -eq $v) { return 'null' }
                if ($v -is [string]) { return '"' + ($v -replace '"','\"') + '"' }
                if ($v -is [System.ValueType]) { return $v.ToString() }
                # Utiliser une profondeur élevée pour éviter troncature d'objets imbriqués
                # (ConvertTo-Json tronque dès que Depth insuffisant -> ...)
                try {
                    $json = $v | ConvertTo-Json -Depth 60 -Compress
                    return ($json -replace "`r|`n", ' ')
                } catch { return $v.ToString() }
            }

            $added=0; $removed=0; $modified=0; $unchanged=0
            $builder = New-Object System.Text.StringBuilder

            foreach($p in $sorted){
                $hasB = $mapBase.ContainsKey($p)
                $hasW = $mapWork.ContainsKey($p)
                if ($hasB -and $hasW){
                    $vb = $mapBase[$p]; $vw = $mapWork[$p]
                    $sb = RJ_FormatValue $vb
                    $sw = RJ_FormatValue $vw
                    if ($sb -eq $sw){
                        $unchanged++
                    } else {
                        $modified++
                        [void]$builder.AppendLine("`n- $p : $sb")
                        [void]$builder.AppendLine("`n+ $p : $sw")
                    }
                } elseif ($hasB -and -not $hasW){
                    $removed++
                    $sb = RJ_FormatValue $mapBase[$p]
                    [void]$builder.AppendLine("`n- $p : $sb")
                } elseif (-not $hasB -and $hasW){
                    $added++
                    $sw = RJ_FormatValue $mapWork[$p]
                    [void]$builder.AppendLine("`n+ $p : $sw")
                }
            }

            $summary = "Summary: modified=$modified, added=$added, removed=$removed, unchanged=$unchanged (property-level diff; order & SolutionMetadata ignorés)"
            $full = "$summary`r`n`r`n" + $builder.ToString()
            $diffBox.Clear(); $diffBox.Text = $full
            if (-not $script:diffText) { $script:diffText = New-Object System.Text.StringBuilder }
            $script:diffText.Clear() | Out-Null
            [void]$script:diffText.Append($full)
            Colorize-DiffContent
        } catch {}
    }

    function Colorize-DiffContent {
        try {
            $text = $diffBox.Text
            if (-not $text) { return }
            $lines = $text -split "`r?`n"
            $offset=0
            foreach($line in $lines){
                $len = $line.Length
                if ($len -gt 0) {
                    $prefix = if ($line.Length -ge 2) { $line.Substring(0,2) } else { $line }
                    $baseColor = [System.Drawing.Color]::Gray
                    if ($prefix.StartsWith('+')) { $baseColor = [System.Drawing.Color]::Green }
                    elseif ($prefix.StartsWith('-')) { $baseColor = [System.Drawing.Color]::Red }
                    elseif ($prefix -eq '  ') { $baseColor = [System.Drawing.Color]::Gray }
                    # Color prefix (first 2 chars if diff marker, else maybe two spaces)
                    $markLen = [Math]::Min(2,$len)
                    $diffBox.SelectionStart = $offset
                    $diffBox.SelectionLength = $markLen
                    $diffBox.SelectionColor = $baseColor
                    # Token highlight remainder (skip summary header line which starts with 'Summary:')
                    if ($line -notmatch '^Summary:') {
                        $startTokens = $offset + $markLen
                        $segmentLen = $len - $markLen
                        if ($segmentLen -gt 0) {
                            RJ_ColorizeJsonSegment -Box $diffBox -Start $startTokens -Length $segmentLen
                        }
                    } else {
                        $diffBox.SelectionStart = $offset
                        $diffBox.SelectionLength = $len
                        $diffBox.SelectionColor = [System.Drawing.Color]::DarkBlue
                        $diffBox.SelectionFont = New-Object System.Drawing.Font($diffBox.Font, [System.Drawing.FontStyle]::Bold)
                    }
                }
                $offset += $len + 2 # \r\n
            }
            $diffBox.SelectionStart = 0; $diffBox.SelectionLength = 0
        } catch {}
    }

    function RJ_ColorizeJsonSegment {
        param([System.Windows.Forms.RichTextBox]$Box,[int]$Start,[int]$Length)
        try {
            if ($Length -le 0) { return }
            $segment = $Box.Text.Substring($Start,$Length)
            $patterns = @(
                @{ Pattern='"([^"\\]|\\.)*"(?=\s*:)' ; Color=[System.Drawing.Color]::Blue },
                @{ Pattern='(?<=:\s*)"([^"\\]|\\.)*"' ; Color=[System.Drawing.Color]::Brown },
                @{ Pattern='(?<![A-Za-z0-9_\-])[-]?(?:0|[1-9]\d*)(?:\.\d+)?(?!(?:[A-Za-z0-9_]))' ; Color=[System.Drawing.Color]::DarkCyan },
                @{ Pattern='\b(true|false|null)\b' ; Color=[System.Drawing.Color]::Purple }
            )
            foreach($pat in $patterns){
                $rg = New-Object System.Text.RegularExpressions.Regex($pat.Pattern,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
                foreach($m in $rg.Matches($segment)){
                    $Box.SelectionStart = $Start + $m.Index
                    $Box.SelectionLength = $m.Length
                    $Box.SelectionColor = $pat.Color
                }
            }
        } catch {}
    }

    $btnDiffCopy.Add_Click({ try { if ($script:diffText) { [Windows.Forms.Clipboard]::SetText($script:diffText.ToString()) } } catch {} })
    $btnDiffExport.Add_Click({
        try {
            $sfd = New-Object System.Windows.Forms.SaveFileDialog -Property @{ Filter='Diff files (*.diff)|*.diff|Text files (*.txt)|*.txt|All files (*.*)|*.*'; Title='Export Diff Report'; FileName='config_migration.diff' }
            if ($sfd.ShowDialog() -eq 'OK') { [IO.File]::WriteAllText($sfd.FileName, ($script:diffText.ToString())) }
        } catch {}
    })

    # Timers
    $rawTimer    = New-Object System.Windows.Forms.Timer -Property @{ Interval=600 }
    $searchTimer = New-Object System.Windows.Forms.Timer -Property @{ Interval=300 }
    $pendingRaw=$false; $pendingSearch=$false

    function RefreshUndoRedo {
        if ($ReadOnly) {
            $btnUndo.Enabled=$false; $btnRedo.Enabled=$false
        } else {
            $btnUndo.Enabled=($undo.Count -gt 1); $btnRedo.Enabled=($redo.Count -gt 0)
        }
    }

    # Capture / restore expansion
    function CaptureExpanded {
        $h = New-Object System.Collections.Generic.HashSet[string]
        foreach($r in $tree.Nodes){
            function Walk($n){
                if ($n -and $n.IsExpanded -and $n.Tag -and ($n.Tag -is [hashtable]) -and $n.Tag.ContainsKey('Path')) {
                    [void]$h.Add($n.Tag['Path'])
                }
                foreach($c in $n.Nodes){ Walk $c }
            }
            Walk $r
        }
        return $h
    }
    function RestoreExpanded($set){
        if (-not $set) { return }
        foreach($r in $tree.Nodes){
            function Walk($n,$s){
                if (-not $n) { return }
                $p=$null
                if ($n.Tag -is [hashtable] -and $n.Tag.ContainsKey('Path')) { $p=$n.Tag['Path'] }
                if ($p -and $s.Contains($p)) { $n.Expand() }
                foreach($c in $n.Nodes){ Walk $c $s }
            }
            Walk $r $set
        }
    }
    function FindNode($path){
        if (-not $path) { return $null }
        foreach($r in $tree.Nodes){
            function Walk($n,$p){
                if (-not $n) { return $null }
                $p2=$null
                if ($n.Tag -is [hashtable] -and $n.Tag.ContainsKey('Path')) { $p2=$n.Tag['Path'] }
                if ($p2 -eq $p){ return $n }
                foreach($c in $n.Nodes){
                    $f=Walk $c $p
                    if ($f){ return $f }
                }
                return $null
            }
            $f=Walk $r $path
            if ($f){ return $f }
        }
        return $null
    }

    function RebuildTree([string]$Filter=''){
        $Filter = RJ_NormFilter $Filter
        $exp=CaptureExpanded
        $sel = if ($tree.SelectedNode -and $tree.SelectedNode.Tag -is [hashtable] -and $tree.SelectedNode.Tag.ContainsKey('Path')) {
            $tree.SelectedNode.Tag['Path']
        } else { $null }

        $tree.BeginUpdate()
        $tree.Nodes.Clear()
        $baseMap = RJ_BuildPathMap -Object $Baseline
        $curMap  = RJ_BuildPathMap -Object $Working
        # Classification fine
        $script:PathDiffMap = @{}
        $script:AddedKeySet          = New-Object System.Collections.Generic.HashSet[string]
        $script:RemovedKeySet        = New-Object System.Collections.Generic.HashSet[string]
        $script:ModifiedValueKeySet  = New-Object System.Collections.Generic.HashSet[string]
        $script:StructureKeySet      = New-Object System.Collections.Generic.HashSet[string]
        foreach($p in $curMap.Keys){
            if (-not $p) { continue }
            if ($p -match '^SolutionMetadata(\.|$)' -or $p -match '\bSolutionMetadata\b') { continue }
            if (-not $baseMap.ContainsKey($p)) {
                $script:PathDiffMap[$p]='Added'
                $seg=($p.Split('.')[-1] -replace '\[[0-9]+\]',''); [void]$script:AddedKeySet.Add($seg)
            } elseif ("$($baseMap[$p])" -ne "$($curMap[$p])") {
                $script:PathDiffMap[$p]='ModifiedValue'
                $seg=($p.Split('.')[-1] -replace '\[[0-9]+\]',''); [void]$script:ModifiedValueKeySet.Add($seg)
            }
        }
        foreach($p in $baseMap.Keys){
            if (-not $p) { continue }
            if ($p -match '^SolutionMetadata(\.|$)' -or $p -match '\bSolutionMetadata\b') { continue }
            if (-not $curMap.ContainsKey($p)) {
                $script:PathDiffMap[$p]='Removed'
                $seg=($p.Split('.')[-1] -replace '\[[0-9]+\]',''); [void]$script:RemovedKeySet.Add($seg)
            }
        }
        foreach($p in @($script:PathDiffMap.Keys)){
            $parts=$p -split '\.'
            for($i=0;$i -lt $parts.Length-1;$i++){
                $anc=($parts[0..$i] -join '.')
                if (-not $anc) { continue }
                if (-not $script:PathDiffMap.ContainsKey($anc)) { $script:PathDiffMap[$anc]='ModifiedStructure'; $seg=($anc.Split('.')[-1] -replace '\[[0-9]+\]',''); [void]$script:StructureKeySet.Add($seg) }
            }
        }
        $root = New-Object System.Windows.Forms.TreeNode -Property @{ Text='ROOT'; Tag=@{ Path=''; IsLeaf=$false } }
        [void]$tree.Nodes.Add($root)
        RJ_AddNodes -Parent $root -Object $Working -BasePath '' -BaseMap $baseMap -CurMap $curMap -DiffClassMap $script:PathDiffMap -Filter $Filter | Out-Null
        $root.Expand()
        RestoreExpanded $exp
        if ($sel){
            $n=FindNode $sel
            if ($n){ $tree.SelectedNode=$n }
        }
        $tree.EndUpdate()
        $treeHost.PerformLayout()
        Update-DiffTab
    }

    function ColorizeRawDiff {
        try {
            if (-not $script:PathDiffMap) { return }
            $lines = $rtb.Lines
            if (-not $lines) { return }
            # Pré-calcul des offsets pour performance
            $offsets = New-Object int[] ($lines.Count)
            $acc=0
            for($i=0;$i -lt $lines.Count;$i++){ $offsets[$i]=$acc; $acc += ($lines[$i].Length + 2) }
            for($i=0;$i -lt $lines.Count;$i++){
                $line=$lines[$i]
                if ($line -notmatch '^\s*"([^"\\]|\\.)+"\s*:'){ continue }
                $m=[regex]::Match($line,'^\s*"(([^"\\]|\\.)+)"\s*:')
                if (-not $m.Success){ continue }
                $key=$m.Groups[1].Value
                $cls=$null
                if ($script:AddedKeySet.Contains($key)) { $cls='Added' }
                elseif ($script:RemovedKeySet.Contains($key)) { $cls='Removed' }
                elseif ($script:ModifiedValueKeySet.Contains($key)) { $cls='ModifiedValue' }
                elseif ($script:StructureKeySet.Contains($key)) { $cls='ModifiedStructure' }
                if (-not $cls) { continue }
                $rtb.SelectionStart = $offsets[$i]
                $rtb.SelectionLength = $line.Length
                switch($cls){
                    'Added'            { $rtb.SelectionBackColor = [System.Drawing.Color]::PaleGreen }
                    'Removed'          { $rtb.SelectionBackColor = [System.Drawing.Color]::LightCoral }
                    'ModifiedValue'    { $rtb.SelectionBackColor = [System.Drawing.Color]::Khaki }
                    'ModifiedStructure'{ $rtb.SelectionBackColor = [System.Drawing.Color]::LightBlue }
                }
                $rtb.SelectionLength=0
            }
        } catch {}
    }

    function BuildRawJsonText { try { return ($Working | ConvertTo-Json -Depth 60) } catch { return '{}' } }
    function BuildRawDeltaView {
        try {
            $full = BuildRawJsonText
            $lines = $full -split "`n"
            $sb = New-Object System.Text.StringBuilder
            $omitted=0
            for($i=0;$i -lt $lines.Count;$i++){
                $l=$lines[$i]
                $emit=$false
                if ($l -match '^\s*"(([^"\\]|\\.)+)"\s*:'){
                    $k=[regex]::Match($l,'^\s*"(([^"\\]|\\.)+)"\s*:').Groups[1].Value
                    if ($script:AddedKeySet.Contains($k) -or $script:RemovedKeySet.Contains($k) -or $script:ModifiedValueKeySet.Contains($k) -or $script:StructureKeySet.Contains($k)) { $emit=$true }
                }
                if ($emit){
                    if ($omitted -gt 0){ [void]$sb.AppendLine("  ... ($omitted lignes omises)"); $omitted=0 }
                    [void]$sb.AppendLine($l)
                } else { $omitted++ }
            }
            if ($omitted -gt 0){ [void]$sb.AppendLine("  ... ($omitted lignes omises)") }
            return $sb.ToString()
        } catch { return BuildRawJsonText }
    }
    function UpdateRaw {
        try {
            if ($chkHideRaw -and $chkHideRaw.Checked) { $rtb.Text = BuildRawDeltaView } else { $rtb.Text = BuildRawJsonText }
            RJ_HighlightJsonTokens -Box $rtb
            ColorizeRawDiff
            Update-DiffTab
        } catch {}
    }

    # Initial build
    $script:HideUnchanged = $false
    RebuildTree
    UpdateRaw
    RefreshUndoRedo

    if ($chkHideTree) { $chkHideTree.Add_CheckedChanged({ $script:HideUnchanged = $chkHideTree.Checked; RebuildTree -Filter $txtSearch.Text }) }
    if ($chkHideRaw)  { $chkHideRaw.Add_CheckedChanged({ UpdateRaw }) }

    # Editing (only if not ReadOnly)
    if (-not $ReadOnly) {
        $Script:editingNode=$null; $Script:original=''

        function BeginEdit($n){
            if (-not $n -or -not $n.Tag -or -not ($n.Tag -is [hashtable]) -or -not $n.Tag.IsLeaf){ return }
            $text=$n.Text
            $colon=$text.IndexOf(':')
            if ($colon -lt 0){ return }
            $key=$text.Substring(0,$colon).Trim()
            $val=$text.Substring($colon+1).Trim()
            if ($val.StartsWith('"') -and $val.EndsWith('"')){ $val=$val.Trim('"') }
            $b=$n.Bounds

            $x = [int]($b.X + [Math]::Min([double]$b.Width, (($key.Length + 2) * 7))+10)
            # Use DisplayRectangle.Top in case of internal padding
            $y = [int]($b.Y + $tree.DisplayRectangle.Top+44)
            $w = [int]([Math]::Max(120, (($val.Length + 4) * 7)))
            $h = [int]($b.Height + 4)
            $edit.SetBounds($x,$y,$w,$h)

            $edit.Text=$val
            $Script:original=$val
            $Script:editingNode=$n
            $edit.Visible=$true
            $edit.BringToFront()
            $edit.SelectAll()
            $edit.Focus()
        }
        function CommitEdit {
            if (-not $Script:editingNode){ return }
            $new=$edit.Text
            if ($new -ne $Script:original){
                $p=$Script:editingNode.Tag['Path']
                $val=RJ_Infer $new
                RJ_SetByPath -Object $Working -Path $p -Value $val
                RJ_PushUndo -Undo ([ref]$undo) -Redo ([ref]$redo) -Working $Working
                RebuildTree -Filter $txtSearch.Text
                UpdateRaw
                RefreshUndoRedo
            }
            $edit.Visible=$false
            $Script:editingNode=$null
        }
        function CancelEdit { $edit.Visible=$false; $Script:editingNode=$null }

        $tree.Add_NodeMouseDoubleClick({ param($s,$e) if ($edit.Visible){ CommitEdit }; BeginEdit $e.Node })
        $tree.Add_KeyDown({
            param($s,$e)
            switch ($e.KeyCode){
                'F2'    { if ($edit.Visible){ CommitEdit } else { BeginEdit $tree.SelectedNode } }
                'Enter' { if ($edit.Visible){ CommitEdit; $e.Handled=$true } }
                'Escape'{ if ($edit.Visible){ CancelEdit; $e.Handled=$true } }
            }
        })
        $edit.Add_KeyDown({
            param($s,$e)
            switch($e.KeyCode){
                'Enter'  { CommitEdit; $e.Handled=$true }
                'Escape' { CancelEdit; $e.Handled=$true }
            }
        })
        $edit.Add_LostFocus({ if ($edit.Visible){ CommitEdit } })

        # Context menu for arrays
        $ctx = New-Object System.Windows.Forms.ContextMenuStrip
        $miAdd = New-Object System.Windows.Forms.ToolStripMenuItem -Property @{ Text='Add Element' }
        $miDel = New-Object System.Windows.Forms.ToolStripMenuItem -Property @{ Text='Remove Element' }
        $ctx.Items.AddRange(@($miAdd,$miDel))
        $tree.Add_NodeMouseClick({
            param($s,$e)
            if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Right){
                $tree.SelectedNode=$e.Node
                $meta=$e.Node.Tag
                if ($meta -is [hashtable]){
                    $obj=RJ_GetByPath -Object $Working -Path $meta['Path']
                    $isParent = ($obj -is [System.Collections.IEnumerable] -and $obj -isnot [string] -and $meta['IsLeaf'] -eq $false)
                    $isElem   = ($meta['IsArrayElement'] -eq $true -and $meta['IsLeaf'] -eq $true)
                    $miAdd.Visible=$isParent
                    $miDel.Visible=$isElem
                    if ($miAdd.Visible -or $miDel.Visible){ $ctx.Show($tree,$e.Location) }
                }
            }
        })
        $miAdd.Add_Click({
            $n=$tree.SelectedNode
            if (-not $n -or -not ($n.Tag -is [hashtable])){ return }
            $path=$n.Tag['Path']
            $arr=RJ_GetByPath -Object $Working -Path $path
            if ($null -eq $arr) { return }
            if ($arr.GetType().IsArray){
                $tmp=[System.Collections.ArrayList]@($arr); $tmp.Add($null)|Out-Null
                RJ_SetByPath -Object $Working -Path $path -Value ($tmp.ToArray())
            } elseif ($arr -is [System.Collections.IList]) {
                if ($arr.IsReadOnly){
                    $tmp=[System.Collections.ArrayList]@($arr); $tmp.Add($null)|Out-Null
                    RJ_SetByPath -Object $Working -Path $path -Value ($tmp.ToArray())
                } else {
                    $arr.Add($null)|Out-Null
                }
            } else { return }
            RJ_PushUndo -Undo ([ref]$undo) -Redo ([ref]$redo) -Working $Working
            RebuildTree -Filter $txtSearch.Text
            UpdateRaw
            RefreshUndoRedo
        })
        $miDel.Add_Click({
            $n=$tree.SelectedNode
            if (-not $n -or -not ($n.Tag -is [hashtable])){ return }
            $path=$n.Tag['Path']
            if ($path -notmatch '\[[0-9]+\]$'){ return }
            $parent=$path -replace '\[[0-9]+\]$',''
            $arr=RJ_GetByPath -Object $Working -Path $parent
            if ($null -eq $arr){ return }
            $idx=[int]($path.Substring($path.LastIndexOf('[')+1) -replace '\]','')
            if ($arr.GetType().IsArray){
                $tmp=[System.Collections.ArrayList]@($arr)
                if ($idx -lt $tmp.Count){ $tmp.RemoveAt($idx) }
                RJ_SetByPath -Object $Working -Path $parent -Value ($tmp.ToArray())
            } elseif ($arr -is [System.Collections.IList]) {
                if (-not $arr.IsReadOnly -and $idx -lt $arr.Count){ $arr.RemoveAt($idx) }
                else {
                    $tmp=[System.Collections.ArrayList]@($arr)
                    if ($idx -lt $tmp.Count){ $tmp.RemoveAt($idx) }
                    RJ_SetByPath -Object $Working -Path $parent -Value ($tmp.ToArray())
                }
            }
            RJ_PushUndo -Undo ([ref]$undo) -Redo ([ref]$redo) -Working $Working
            RebuildTree -Filter $txtSearch.Text
            UpdateRaw
            RefreshUndoRedo
        })

        # Search (debounced)
        $txtSearch.Add_TextChanged({ $pendingSearch=$true })
        $btnClear.Add_Click({ $txtSearch.Text=''; RebuildTree })
        $searchTimer.Add_Tick({
            if ($pendingSearch){
                $pendingSearch=$false
                RebuildTree -Filter $txtSearch.Text
            }
        })
        $searchTimer.Start()

        # Raw editing sync
        $rtb.Add_TextChanged({ $pendingRaw=$true })
        $rawTimer.Add_Tick({
            if ($pendingRaw){
                $pendingRaw=$false
                try {
                    $parsed=$rtb.Text | ConvertFrom-Json -Depth 60
                    if ($parsed){
                        RJ_PushUndo -Undo ([ref]$undo) -Redo ([ref]$redo) -Working $Working
                        $Working=$parsed
                        RebuildTree -Filter $txtSearch.Text
                        RefreshUndoRedo
                    }
                } catch {}
            }
        })
        $rawTimer.Start()

        # Undo/Redo
        $btnUndo.Add_Click({
            if ($undo.Count -gt 1){
                $redo.Push($undo.Pop())
                $Working = RJ_NewClone ($undo.Peek())
                RebuildTree -Filter $txtSearch.Text
                UpdateRaw
                RefreshUndoRedo
            }
        })
        $btnRedo.Add_Click({
            if ($redo.Count -gt 0){
                $state=$redo.Pop()
                $undo.Push((RJ_NewClone $state))
                $Working = RJ_NewClone $state
                RebuildTree -Filter $txtSearch.Text
                UpdateRaw
                RefreshUndoRedo
            }
        })
        $btnExpand.Add_Click({ $tree.BeginUpdate(); $tree.ExpandAll(); $tree.EndUpdate() })
        $btnCollapse.Add_Click({ $tree.BeginUpdate(); $tree.CollapseAll(); if ($tree.Nodes.Count -gt 0){ $tree.Nodes[0].Expand() }; $tree.EndUpdate() })

        $dlg.Add_KeyDown({
            param($s,$e)
            if ($e.Control -and $e.KeyCode -eq 'Z'){ $btnUndo.PerformClick(); $e.Handled=$true }
            elseif ($e.Control -and $e.KeyCode -eq 'Y'){ $btnRedo.PerformClick(); $e.Handled=$true }
        })
    }
    else {
        # Read-Only specifics
        $btnUndo.Enabled=$false
        $btnRedo.Enabled=$false
        $tree.Add_NodeMouseDoubleClick({}) # no-op
        $btnExpand.Add_Click({ $tree.BeginUpdate(); $tree.ExpandAll(); $tree.EndUpdate() })
        $btnCollapse.Add_Click({ $tree.BeginUpdate(); $tree.CollapseAll(); if ($tree.Nodes.Count -gt 0){ $tree.Nodes[0].Expand() }; $tree.EndUpdate() })
        $txtSearch.Add_TextChanged({ RebuildTree -Filter $txtSearch.Text })
        $btnClear.Add_Click({ $txtSearch.Text=''; RebuildTree })
    }

    if (-not $ReadOnly) {
        #$dlg.AcceptButton=$btnApply
        #$dlg.CancelButton=$btnCancel
        $btnApply.Add_Click({
            try {
                $final=$rtb.Text | ConvertFrom-Json -Depth 60
                if (-not $final){ $final=@{} }
                $dlg.Tag=$final
                $dlg.DialogResult=[System.Windows.Forms.DialogResult]::OK
                $dlg.Close()
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Invalid JSON: $_",'Error','OK','Error') | Out-Null
            }
        })
        $btnCancel.Add_Click({ $dlg.Close() })
    } else {
        $btnApply.Add_Click({ $dlg.Close() })
    }

    [void]$dlg.ShowDialog($Global:AppState.MainForm)

    $rawTimer.Stop(); $searchTimer.Stop()
    if ($ReadOnly) { return $null }
    return $dlg.Tag
}

#endregion Main