<#
Utilities.ObjectComplex.ps1
NEW: Helper functions for complex object questions (ObjectArray / ObjectMap).
 - Validation
 - Round-trip conversion in Build-EffectiveConfig
These are separated to keep Utilities.ps1 lean.
#>

function Convert-ComplexQuestionToConfigValue {
    param([SetupQuestion]$Question)
    if (-not $Question.IsComplex) { return $Question.Value }
    switch ($Question.ComplexKind) {
        'ObjectArray' {
            # Items are PSCustomObjects / hashtables
            $out = @()
            foreach ($item in $Question.ComplexItems) {
                if ($item -is [pscustomobject] -or $item -is [hashtable]) { $out += $item }
            }
            return $out
        }
        'ObjectMap' {
            $ht = [ordered]@{}
            foreach ($k in $Question.ComplexMap.Keys) {
                $ht[$k] = $Question.ComplexMap[$k]
            }
            return ([pscustomobject]$ht)
        }
        default { return $Question.Value }
    }
}

function Validate-ComplexItem {
    param(
        [hashtable]$SchemaEntry,
        [hashtable]$Item
    )
    if (-not $SchemaEntry) { return $true }
    $name = $SchemaEntry.Name
    if ($SchemaEntry.Required -and (-not $Item.ContainsKey($name) -or ($null -eq $Item[$name]) -or ($Item[$name] -eq ''))) {
        return $false
    }
    if ($Item.ContainsKey($name) -and $SchemaEntry.Type) {
        $val = $Item[$name]
        switch ($SchemaEntry.Type) {
            'Bool' {
                if ($val -isnot [bool]) {
                    if ($val -is [string] -and $val -match '^(?i:true|false)$') {
                        $Item[$name] = [bool]::Parse($val.ToLower())
                    } else { return $false }
                }
            }
            'Int' {
                if ($val -isnot [int]) {
                    if ($val -is [string] -and $val -match '^-?\d+$') {
                        try { $Item[$name] = [int]$val } catch { return $false }
                    } else { return $false }
                }
            }
            'Array' {
                if ($val -is [string]) {
                    $Item[$name] = @($val -split ';' | Where-Object { $_ })
                }
            }
        }
    }
    return $true
}

function Validate-ComplexQuestion {
    param([SetupQuestion]$Question)
    if (-not $Question.IsComplex) { return }
    $Question.IsValid = $true
    if ($Question.ComplexSchema.Count -gt 0) {
        # Build lookup by name
        $schemaLookup = @{}
        foreach ($s in $Question.ComplexSchema) {
            if ($s.Name) { $schemaLookup[$s.Name] = $s }
        }
        switch ($Question.ComplexKind) {
            'ObjectArray' {
                foreach ($raw in $Question.ComplexItems) {
                    $hash = @{}
                    if ($raw -is [pscustomobject]) {
                        foreach ($p in $raw.PSObject.Properties) { $hash[$p.Name] = $p.Value }
                    } elseif ($raw -is [hashtable]) {
                        foreach ($k in $raw.Keys) { $hash[$k] = $raw[$k] }
                    }
                    foreach ($k in $schemaLookup.Keys) {
                        $ok = Validate-ComplexItem -SchemaEntry $schemaLookup[$k] -Item $hash
                        if (-not $ok) { $Question.IsValid=$false; $Question.ValidationMessage="Invalid object entry for property '$k'."; return }
                    }
                }
            }
            'ObjectMap' {
                foreach ($mapKey in $Question.ComplexMap.Keys) {
                    $obj = $Question.ComplexMap[$mapKey]
                    $hash = @{}
                    if ($obj -is [pscustomobject]) {
                        foreach ($p in $obj.PSObject.Properties) { $hash[$p.Name] = $p.Value }
                    } elseif ($obj -is [hashtable]) {
                        foreach ($k in $obj.Keys) { $hash[$k] = $obj[$k] }
                    }
                    foreach ($k in $schemaLookup.Keys) {
                        # Only validate keys that exist (flexible map)
                        if ($hash.ContainsKey($k)) {
                            $ok = Validate-ComplexItem -SchemaEntry $schemaLookup[$k] -Item $hash
                            if (-not $ok) { $Question.IsValid=$false; $Question.ValidationMessage="Invalid instance '$mapKey' property '$k'."; return }
                        }
                    }
                }
            }
        }
    }
}