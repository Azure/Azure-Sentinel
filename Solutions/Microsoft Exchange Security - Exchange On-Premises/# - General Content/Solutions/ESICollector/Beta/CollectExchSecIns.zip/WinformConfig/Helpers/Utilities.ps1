<#
Utilities.ps1
ADD:
 - Global Azure connection state helpers (Connect / (optional) Graph connect) + UI dialog trigger support.
 - New functions:
      Initialize-AzureState
      Show-AzureConnectDialog
      Invoke-AzureConnection
      Update-AzureStatusIndicator (lightweight; real label lives in main form script)
 - Enhanced DeployDCR implementation:
      * Validates Azure connection (errors out if not connected).
      * Reads required questions (DCRName, DCRResourceGroup, DCRRegion) from current model.
      * Prompts (GUI) for Endpoint URI if needed (when creating a new DCR).
      * Generates ImmutableId if creating new DCR and none provided.
      * Uses Az.Monitor cmdlets (Get-AzDataCollectionRule / New-AzDataCollectionRule).
      * Returns hashtable to update hidden configuration questions:
          LogCollection.DCRImmutableId
          LogCollection.DataCollectionEndpointURI
      * Graceful error handling (message box + result panel shows error).
 - NOTE: Requires Az.Accounts and Az.Monitor modules available in the host.
#>


. (Join-Path $PSScriptRoot 'Utilities.ObjectComplex.ps1')
. (Join-Path $PSScriptRoot 'Utilities.Serialization.ps1')

function DeployDCR {
    param([SetupQuestion]$Question)

    # Ensure Azure connection
    if (-not $Global:AppState.AzureConnected) {
        [System.Windows.Forms.MessageBox]::Show("Azure is not connected. Please use 'Azure -> Connect to Azure' first.","Azure Not Connected","OK","Warning")|Out-Null
        throw "Azure not connected."
    }

    if (-not $Global:AppState.AzureSelectedSubscriptionId) {
        [System.Windows.Forms.MessageBox]::Show("No subscription selected. Connect and choose a subscription first.","Subscription Missing","OK","Warning")|Out-Null
        throw "No subscription selected."
    }

    foreach ($m in @('Az.Accounts','Az.Monitor','Az.Resources')) {
        if (-not (Get-Module -ListAvailable -Name $m)) {
            try { Import-Module $m -ErrorAction Stop } catch { throw "Required module '$m' not available." }
        }
    }

    # Ensure context
    try {
        Set-AzureSubscriptionContext -SubscriptionId $Global:AppState.AzureSelectedSubscriptionId
    } catch {
        throw "Failed to set subscription context before DCR operations: $($_.Exception.Message)"
    }

    # Helper to get question value by code inside DCRInformation subsection
    function _GetValue {
        param($QCode)
        foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
            if ($kv.Key -match 'DCRInformation\|' -and $kv.Key -like "*|$QCode") {
                $q=$kv.Value
                if ($q.IsArray) { return ($q.ArrayItems -join ';') }
                return $q.Value
            }
        }
        return $null
    }

    $createMode = ($(_GetValue -QCode 'DCRCreation') -eq 'Yes')
    if (-not $createMode) {
        return $null  # Nothing to do when not in create mode
    }

    $name   = _GetValue -QCode 'DCRName'
    $rg     = _GetValue -QCode 'DCRResourceGroup'
    $region = _GetValue -QCode 'DCRRegion'

    if (-not $name -or -not $rg -or -not $region) {
        throw "Missing required DCR fields (Name, Resource Group, Region)."
    }

    # Try to get existing DCR
    $existing = $null
    try {
        $existing = Get-AzDataCollectionRule -Name $name -ResourceGroupName $rg -ErrorAction Stop
    } catch {
        $existing = $null
    }

    $endpointUri = $null
    $immutableId = $null

    if ($existing) {
        $endpointUri = $existing.DataCollectionEndpoint
        if (-not $endpointUri -and $null -ne $existing.Properties) {
            $endpointUri = $existing.Properties.DataCollectionEndpointId
        }
        $immutableId = $existing.ImmutableId
    } else {
        # Prompt for Endpoint URI (simple dialog)
        $endpointUri = ""
        $dlg = New-Object System.Windows.Forms.Form
        $dlg.Text="DCR Endpoint URI"
        $dlg.Width=560; $dlg.Height=200
        $dlg.StartPosition='CenterParent'
        $lbl = New-Object System.Windows.Forms.Label -Property @{
            Text="Enter Data Collection Endpoint URI (e.g. https://<id>.<region>.ingest.monitor.azure.com):"
            AutoSize=$false; Width=520; Height=40; Location='10,10'
        }
        $tb = New-Object System.Windows.Forms.TextBox -Property @{ Width=520; Location='10,60' }
        $btnOK = New-Object System.Windows.Forms.Button -Property @{ Text='OK'; Width=100; Location='10,100' }
        $btnCancel = New-Object System.Windows.Forms.Button -Property @{ Text='Cancel'; Width=100; Location='120,100' }
        $dlg.Controls.AddRange(@($lbl,$tb,$btnOK,$btnCancel))
        $dlg.Tag = @{ Accepted = $false }
        $btnOK.Add_Click({ if ([string]::IsNullOrWhiteSpace($tb.Text)) { [System.Windows.Forms.MessageBox]::Show("Endpoint URI required.","Validation","OK","Warning")|Out-Null } else { $dlg.Tag.Accepted=$true; $dlg.Close() } })
        $btnCancel.Add_Click({ $dlg.Tag.Accepted=$false; $dlg.Close() })
        [void]$dlg.ShowDialog($Global:AppState.MainForm)
        if (-not $dlg.Tag.Accepted) { throw "Endpoint URI entry canceled by user." }
        $endpointUri = $tb.Text.Trim()

        $immutableId = ([guid]::NewGuid()).Guid

        try {
            # Create DCR (simplified creation)
            $newParams = @{
                Name              = $name
                ResourceGroupName = $rg
                Location          = $region
                ImmutableId       = $immutableId
                DataCollectionEndpointId = $endpointUri
            }

            # Some Az versions use -Region, others -Location; attempt fallback
            try {
                $createdDcr = New-AzDataCollectionRule @newParams -ErrorAction Stop
            } catch {
                $originalError = $_.Exception.Message
                $newParams.Remove('Location') | Out-Null
                $newParams['Region']=$region
                try {
                    $createdDcr = New-AzDataCollectionRule @newParams -ErrorAction Stop
                } catch {
                    throw "Failed to create DCR (tried both -Location and -Region): $originalError | $($_.Exception.Message)"
                }
            }

            # created successfully
            $existing = $createdDcr
        } catch {
            throw "Failed to create DCR: $($_.Exception.Message)"
        }
    }

    if ($existing) {
        if (-not $endpointUri) {
            $endpointUri = $existing.DataCollectionEndpoint
            if (-not $endpointUri -and $null -ne $existing.Properties) {
                $endpointUri = $existing.Properties.DataCollectionEndpointId
            }
        }
        if (-not $immutableId) {
            $immutableId = $existing.ImmutableId
        }
    }

    if (-not $endpointUri -or -not $immutableId) {
        throw "Could not resolve DCR endpoint or immutable ID."
    }

    return @{
        'LogCollection.DCRImmutableId'          = $immutableId
        'LogCollection.DataCollectionEndpointURI' = $endpointUri
    }
}

# ---------------- Azure Connection Support ----------------

function Initialize-AzureState {
    if (-not $Global:AppState.AzureConnected) {
        $Global:AppState.AzureConnected = $false
        $Global:AppState.GraphConnected = $false
        $Global:AppState.AzureContextName = "MESSetup"
        $Global:AppState.AzureTenant                  = $null
        $Global:AppState.AzureTenantDisplay           = $null
        $Global:AppState.AzureSubscriptions           = @()
        $Global:AppState.AzureSelectedSubscriptionId  = $null
        $Global:AppState.AzureSelectedSubscriptionName= $null
    }
}

function Invoke-AzureLogin {
    param(
        [string]$Tenant,
        [switch]$ConnectGraph
    )
    Initialize-AzureState
    try {
        Import-Module Az.Accounts -ErrorAction Stop
    } catch {
        throw "Az.Accounts module missing. Install Az PowerShell modules (Install-Module Az)."
    }

    if (Get-AzContext -Name "MESSetup") {
        Select-AzContext -Name "MESSetup" | Out-Null
    }

    # Build connect parameters (no console Read-Host)
    $connectParams = @{
        ContextName = $Global:AppState.AzureContextName
        ErrorAction = 'Stop'
    }
    if ($Tenant) { $connectParams.Tenant = $Tenant }

    $defaultSubscriptionForLogin = Get-AzConfig -DefaultSubscriptionForLogin
    Update-AzConfig -DefaultSubscriptionForLogin ''

    try {
        $ctx = Connect-AzAccount @connectParams -Force:$True
        $Global:AppState.AzureConnected = $true
        $Global:AppState.AzureTenant    = $ctx.Context.Tenant.Id
        $Global:AppState.AzureTenantDisplay = $ctx.Context.Tenant.Id
        Update-AzConfig -DefaultSubscriptionForLogin $defaultSubscriptionForLogin
    } catch {
        $Global:AppState.AzureConnected = $false
        Update-AzConfig -DefaultSubscriptionForLogin $defaultSubscriptionForLogin
        throw "Azure interactive login failed: $($_.Exception.Message)"
    }

    # Retrieve subscriptions
    try {
        Import-Module Az.Resources -ErrorAction SilentlyContinue | Out-Null
        $subs = Get-AzSubscription -ErrorAction Stop | Sort-Object Name
        $Global:AppState.AzureSubscriptions = $subs
    } catch {
        $Global:AppState.AzureSubscriptions = @()
        throw "Failed to list subscriptions: $($_.Exception.Message)"
    }

    if ($ConnectGraph) {
        try {
            if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
                Import-Module Microsoft.Graph -ErrorAction Stop
            } else {
                Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
            }
            $activeCtx = Get-AzContext -Name $Global:AppState.AzureContextName -ErrorAction Stop
            $token = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate(
                $activeCtx.Account,
                $activeCtx.Environment,
                $activeCtx.Tenant.Id.ToString(),
                $null,
                [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never,
                $null,
                "https://graph.microsoft.com"
            )
            Connect-MgGraph -AccessToken $token.AccessToken | Out-Null
            $Global:AppState.GraphConnected = $true
        } catch {
            $Global:AppState.GraphConnected = $false
            throw "Graph connection failed: $($_.Exception.Message)"
        }
    }
}

# ---------- Set Subscription Context ----------
function Set-AzureSubscriptionContext {
    param(
        [string]$SubscriptionId
    )
    if (-not $Global:AppState.AzureConnected) {
        throw "Not connected to Azure."
    }
    if (-not $SubscriptionId) {
        throw "Subscription Id is empty."
    }
    try {
        $ctx = Set-AzContext -Subscription $SubscriptionId -Name $Global:AppState.AzureContextName -Force:$True -ErrorAction Stop
        $Global:AppState.AzureSelectedSubscriptionId   = $ctx.Subscription.Id
        $Global:AppState.AzureSelectedSubscriptionName = $ctx.Subscription.Name
    } catch {
        throw "Failed to set subscription context: $($_.Exception.Message)"
    }
}

# ---------- GUI: Connect to Azure ----------
function Show-AzureConnectDialog {
    Initialize-AzureState

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "Connect to Azure"
    $dlg.Width=640; $dlg.Height=500
    $dlg.StartPosition='CenterParent'
    $dlg.Font = New-Object System.Drawing.Font("Segoe UI",9)

    $lblTenant = New-Object System.Windows.Forms.Label -Property @{
        Text = "Tenant (Domain or Tenant ID - leave blank for default account picker):"
        AutoSize = $false; Width=600; Height=32; Location='12,12'
    }
    $tenantDisplay = if ($null -ne $Global:AppState.AzureTenantDisplay) { $Global:AppState.AzureTenantDisplay } else { '' }
    $tbTenant = New-Object System.Windows.Forms.TextBox -Property @{ Width=600; Location='12,44'; Text=$tenantDisplay }

    $chkGraph = New-Object System.Windows.Forms.CheckBox -Property @{
        Text = "Also connect to Microsoft Graph"
        Width=300; Location='12,78'; Checked=$Global:AppState.GraphConnected
    }

    $btnLogin = New-Object System.Windows.Forms.Button -Property @{
        Text='Login / Refresh Subscriptions'; Width=220; Location='12,110'
    }

    $lblSubs = New-Object System.Windows.Forms.Label -Property @{
        Text="Available Subscriptions (select default):"
        AutoSize=$false; Width=600; Height=22; Location='12,150'
    }

    $comboSubs = New-Object System.Windows.Forms.ComboBox -Property @{
        Location='12,174'; Width=600; DropDownStyle='DropDownList'
    }

    $btnSetSub = New-Object System.Windows.Forms.Button -Property @{
        Text='Set Subscription & Close'; Width=200; Location='12,214'; Enabled=$false
    }

    $lblStatus = New-Object System.Windows.Forms.Label -Property @{
        AutoSize=$false; Width=600; Height=120; Location='12,252'; ForeColor=[System.Drawing.Color]::FromArgb(60,60,60)
        Text="Status:`r`nAzure Connected = $($Global:AppState.AzureConnected); Graph Connected = $($Global:AppState.GraphConnected)"
    }

    $btnClose = New-Object System.Windows.Forms.Button -Property @{
        Text='Close'; Width=120; Location='12,390'
    }

    $dlg.Controls.AddRange(@($lblTenant,$tbTenant,$chkGraph,$btnLogin,$lblSubs,$comboSubs,$btnSetSub,$lblStatus,$btnClose))

    function Refresh-SubscriptionsCombo {
        $comboSubs.Items.Clear()
        foreach ($s in $Global:AppState.AzureSubscriptions) {
            $display = "$($s.Name)  [$($s.Id)]"
            [void]$comboSubs.Items.Add($display)
            if ($Global:AppState.AzureSelectedSubscriptionId -and $s.Id -eq $Global:AppState.AzureSelectedSubscriptionId) {
                $comboSubs.SelectedItem = $display
            }
        }
        $btnSetSub.Enabled = ($comboSubs.Items.Count -gt 0)
    }

    $btnLogin.Add_Click({
        $btnLogin.Enabled = $false
        $btnSetSub.Enabled = $false
        $lblStatus.ForeColor=[System.Drawing.Color]::DarkOrange
        $lblStatus.Text="Status: Connecting..."
        $dlg.Refresh()
        try {
            Invoke-AzureLogin -Tenant $tbTenant.Text.Trim() -ConnectGraph:($chkGraph.Checked)
            $lblStatus.ForeColor=[System.Drawing.Color]::Green
            $tenantShown = $Global:AppState.AzureTenant
            if ($Global:AppState.AzureSubscriptions -is [System.Collections.ArrayList]) {
                $subCount = $Global:AppState.AzureSubscriptions.Count
            }
            elseif (-not $Global:AppState.AzureSubscriptions) {
                $subCount = 0
            }
            else {
                $subCount = 1
            }
            $lblStatus.Text = "Status:`r`nConnected to tenant $tenantShown`r`nSubscriptions found: $subCount`r`nGraph Connected: $($Global:AppState.GraphConnected)"
            Refresh-SubscriptionsCombo
            Update-AzureStatusIndicator
        } catch {
            $Global:AppState.AzureSubscriptions=@()
            $lblStatus.ForeColor=[System.Drawing.Color]::Red
            $lblStatus.Text = "Error: $($_.Exception.Message)"
        } finally {
            $btnLogin.Enabled = $true
        }
    })

    $btnSetSub.Add_Click({
        if ($comboSubs.SelectedItem) {
            # Parse subscription Id from selection
            $sel = [string]$comboSubs.SelectedItem
            if ($sel -match '\[([0-9a-fA-F\-]{36})\]') {
                $subId = $Matches[1]
                try {
                    Set-AzureSubscriptionContext -SubscriptionId $subId
                    $lblStatus.ForeColor=[System.Drawing.Color]::Green
                    $lblStatus.Text += "`r`nSubscription set: $($Global:AppState.AzureSelectedSubscriptionName)"
                    Update-AzureStatusIndicator
                    $dlg.Close()
                } catch {
                    [System.Windows.Forms.MessageBox]::Show("Failed to set subscription: $($_.Exception.Message)","Subscription Error","OK","Error")|Out-Null
                }
            }
        }
    })

    $comboSubs.Add_SelectedIndexChanged({
        if ($comboSubs.SelectedItem) { $btnSetSub.Enabled = $true }
    })

    $btnClose.Add_Click({ $dlg.Close() })

    [void]$dlg.ShowDialog($Global:AppState.MainForm)
}

# ---------- Status Indicator ----------
function Update-AzureStatusIndicator {
    Initialize-AzureState
    if (-not $Global:AzureStatusLabel -or $Global:AzureStatusLabel.IsDisposed) { return }
    if ($Global:AppState.AzureConnected) {
        $subInfo = ""
        if ($Global:AppState.AzureSelectedSubscriptionName) {
            $subInfo = " ($($Global:AppState.AzureSelectedSubscriptionName))"
        }
        $Global:AzureStatusLabel.Text = "Azure: Connected$subInfo"
        $Global:AzureStatusLabel.ForeColor = [System.Drawing.Color]::Green
    } else {
        $Global:AzureStatusLabel.Text = "Azure: Disconnected"
        $Global:AzureStatusLabel.ForeColor = [System.Drawing.Color]::Red
    }

    $Global:AzureStatusLabel.Location = New-Object System.Drawing.Point(($MainForm.ClientSize.Width - ($Global:AzureStatusLabel.Text.Length*8)), 6)
}

# Ensure initial state set
Initialize-AzureState


function Get-QuestionValue {
    param($SectionCode,$QuestionCode)
    $key="$SectionCode|$QuestionCode"
    if ($Global:AppState.QuestionsLookup.ContainsKey($key)) {
        $q = $Global:AppState.QuestionsLookup[$key]
        if ($q.IsArray) { return ($q.ArrayItems -join ';') }
        return $q.Value
    }
    return ""
}

function Evaluate-Condition {
    param([string]$Condition)
    if ([string]::IsNullOrWhiteSpace($Condition)) { return $true }
    $pattern = 'Root\[(?<Sec>[^\]]+)\](\.(Collection|Section)\[(?<Sub>[^\]]+)\])?\.(Collection|Section)\[(?<Q>[^\]]+)\]\.Value'
    $expr = [System.Text.RegularExpressions.Regex]::Replace($Condition,$pattern,{
        param($m)
        $sec=$m.Groups['Sec'].Value
        $sub=$m.Groups['Sub'].Value
        $qcode=$m.Groups['Q'].Value
        if ($sub) { $sec="$sub" }
        $val = Get-QuestionValue -SectionCode $sec -QuestionCode $qcode
        return ('"'+($val -replace '"','\"')+'"')
    })
    try { return [bool](Invoke-Expression $expr) } catch { return $false }
}

function Validate-Question {
    param($Question)
    if ($Question.IsComplex) {
        # Complex validation handled elsewhere (Validate-ComplexQuestion in Utilities.ObjectComplex.ps1)
        return
    }
    if ($Question.ValueType -eq 'Execute') {
        # Always valid; Execute button has no intrinsic value
        $Question.IsValid=$true
        $Question.ValidationMessage=$null
        return
    }
    $Question.IsValid=$true
    $Question.ValidationMessage=$null
    $val = if ($Question.IsArray) { ($Question.ArrayItems -join ';') } else { $Question.Value }
    if ($Question.Regex -and $val) {
        try {
            if (-not ($val -match $Question.Regex)) {
                $Question.IsValid=$false
                $Question.ValidationMessage="Regex mismatch: $($Question.Regex)"
            }
        } catch {
            $Question.IsValid=$false
            $Question.ValidationMessage="Invalid regex pattern: $($Question.Regex) - $($_.Exception.Message)"
            if (Get-Command Write-ErrorLog -ErrorAction SilentlyContinue) {
                Write-ErrorLog -ErrorRecord $_ -Context "Validate-Question:Regex:$($Question.Code)"
            }
        }
    }
    if ($Question.IsValid -and $Question.ValidationHookFunction) {
        switch ($Question.ValidationHookFunction) {
            'Set-EnvironmentIdentification' {
                if ($val -and $val.Length -gt 64) {
                    $Question.IsValid=$false
                    $Question.ValidationMessage="Too long (max 64)."
                }
            }
            'Set-ApplicationCertificate' {
                if ($val -and ($val -notmatch '^[A-Fa-f0-9]{40}$')) {
                    $Question.IsValid=$false
                    $Question.ValidationMessage="Thumbprint must be 40 hex chars."
                }
            }
            'Verify-Path' {
                if ($val -and -not (Test-Path $val)) {
                    $Question.IsValid=$false
                    $Question.ValidationMessage="Path does not exist."
                }
            }
            default {
                # Do not fail validation on unknown hook function; just log if logging function exists
                if (Get-Command $Question.ValidationHookFunction -ErrorAction SilentlyContinue) {
                    & $Question.ValidationHookFunction -Question $Question -Value $val
                }
                else {
                    # Action when all if and elseif conditions are false
                    Write-ErrorLog -ErrorRecord $_ -Context 'UnknownValidationHook'
                }
            }
        }
    }
}


function Ensure-Config {
    if (-not $Global:AppState.CurrentConfig) {
        $Global:AppState.CurrentConfig = [pscustomobject]@{
            Global = [pscustomobject]@{}
            LogCollection = [pscustomobject]@{}
            Advanced = [pscustomobject]@{}
            InstanceConfiguration = [pscustomobject]@{}
        }
    }
}

function Get-ConfigValuePath {
    param($Path)
    Ensure-Config
    $parts=$Path.Split('.')
    $cursor=$Global:AppState.CurrentConfig
    foreach ($p in $parts) {
        if ($cursor -isnot [psobject]) { return $null }
        if ($cursor.PSObject.Properties.Name -notcontains $p) { return $null }
        $cursor = $cursor.$p
    }
    return $cursor
}

function Set-ConfigValuePath {
    param($Path,$Value,$Target)
    $parts=$Path.Split('.')
    if ($parts.Count -gt 20) {
        throw "ConfigurationCode path depth exceeds maximum (20 levels): $Path"
    }
    $cursor=$Target
    for ($i=0;$i -lt $parts.Count;$i++) {
        $p=$parts[$i]
        $leaf=($i -eq $parts.Count-1)
        if ($leaf) {
            Add-Member -InputObject $cursor -NotePropertyName $p -NotePropertyValue $Value -Force
        } else {
            if ($cursor.PSObject.Properties.Name -notcontains $p -or $null -eq $cursor.$p) {
                $cursor | Add-Member -NotePropertyName $p -NotePropertyValue ([pscustomobject]@{}) -Force
            }
            $cursor = $cursor.$p
        }
    }
}

function New-ShallowOrderedCopy {
    param($Source)
    $copy = [ordered]@{}
    if ($null -eq $Source) { return $copy }
    if ($Source -is [System.Collections.IDictionary]) {
        foreach ($k in $Source.Keys) {
            if ($k -eq 'Original') { continue }
            $copy[$k] = $Source[$k]
        }
    } elseif ($Source -is [psobject]) {
        foreach ($p in $Source.PSObject.Properties) {
            if ($p.Name -eq 'Original') { continue }
            $copy[$p.Name] = $p.Value
        }
    }
    return $copy
}

function New-RowSnapshot {
    param($RowObject)
    return (New-ShallowOrderedCopy -Source $RowObject)
}

function Rehydrate-Question {
    param($q)
    if (-not $q.ConfigurationCode) {
        $q.OriginalValue = $q.Value
        return
    }
    $v = Get-ConfigValuePath -Path $q.ConfigurationCode

    if ($q.IsComplex) {
        # Reset structures
        if ($q.ComplexKind -eq 'ObjectArray') {
            $q.ComplexItems.Clear()
            if ($v -is [System.Collections.IEnumerable] -and $v -isnot [string]) {
                foreach ($item in $v) {
                    if ($item -is [psobject] -or $item -is [hashtable]) { $q.ComplexItems.Add($item) | Out-Null }
                }
            }
        } elseif ($q.ComplexKind -eq 'ObjectMap') {
            $q.ComplexMap.Clear()
            if ($v -is [psobject]) {
                foreach ($p in $v.PSObject.Properties) { $q.ComplexMap[$p.Name] = $p.Value }
            } elseif ($v -is [hashtable]) {
                foreach ($k in $v.Keys) { $q.ComplexMap[$k] = $v[$k] }
            }
        }
        $q.OriginalValue = $null
        Validate-Question $q
        return
    }

    if ($q.IsArray) {
        $q.ArrayItems.Clear()
        if ($v -is [System.Collections.IEnumerable] -and $v -isnot [string]) {
            foreach ($i in $v) { [void]$q.ArrayItems.Add("$i") }
            $q.Value = ($q.ArrayItems -join ';')
        } elseif ($v -is [string]) {
            ($v -split ';') | Where-Object { $_ } | ForEach-Object { [void]$q.ArrayItems.Add($_) }
            $q.Value = ($q.ArrayItems -join ';')
        }
    } else {
        if ($q.ValueType -eq 'Bool' -and $v -is [string] -and $v -match '^(?i:true|false)$') {
            $q.Value = [bool]::Parse($v.ToLower())
        } elseif ($q.ValueType -eq 'Int' -and $v -is [string] -and $v -match '^-?\d+$') {
            $q.Value = [int]$v
        } else {
            if ($null -ne $v) { $q.Value = $v }
        }
    }
    $q.OriginalValue = $q.Value
    $q.IsPlaceholder = ($q.Value -is [string] -and $q.Value -like '*UNCONFIGUREDENTRY*')
    Validate-Question $q
}

function Rehydrate-Grids {
    $Global:AppState.UDSRows.Clear()
    if ($Global:AppState.CurrentConfig.Advanced -and $Global:AppState.CurrentConfig.Advanced.UDSLogProcessor) {
        foreach ($r in $Global:AppState.CurrentConfig.Advanced.UDSLogProcessor) {
            $row=[ordered]@{}
            foreach ($prop in 'Activated','StorageType','StoragePath','Prefix','LogStorageRetentionDays','StorageAccountName','StorageBlobContainer','ConnexionType','TenantId','ApplicationID','CertificateThumbprint') {
                $row[$prop] = if ($r.PSObject.Properties.Name -contains $prop) { [string]$r.$prop } else { "" }
            }
            $row.Original = New-RowSnapshot -RowObject $row
            [void]$Global:AppState.UDSRows.Add([pscustomobject]$row)
        }
    }
    $Global:AppState.InstanceRows.Clear()
    if ($Global:AppState.CurrentConfig.InstanceConfiguration) {
        foreach ($p in $Global:AppState.CurrentConfig.InstanceConfiguration.PSObject.Properties) {
            $val=$p.Value
            $row=[ordered]@{
                InstanceName=$p.Name
                All="";Category="";Capabilities="";OutputName=""
                SelectedAddons="";FileteredAddons=""
            }
            foreach ($sp in $val.PSObject.Properties) {
                switch ($sp.Name) {
                    'All' { $row.All=[string]$sp.Value }
                    'Category' { $row.Category=[string]$sp.Value }
                    'Capabilities' { $row.Capabilities=[string]$sp.Value }
                    'OutputName' { $row.OutputName=[string]$sp.Value }
                    'SelectedAddons' { $row.SelectedAddons = ($sp.Value -join ';') }
                    'FileteredAddons' { $row.FileteredAddons = ($sp.Value -join ';') }
                }
            }
            $row.Original = New-RowSnapshot -RowObject $row
            [void]$Global:AppState.InstanceRows.Add([pscustomobject]$row)
        }
    }
}

function Rehydrate-All {
    Ensure-Config
    foreach ($sec in $Global:AppState.Sections) {
        foreach ($q in $sec.Collection) { Rehydrate-Question $q }
        foreach ($sub in $sec.WizardSectionCode) {
            foreach ($q in $sub.Collection) { Rehydrate-Question $q }
        }
    }
    Rehydrate-Grids
    Set-Dirty -Clear
    Clear-UndoRedo
    Push-UndoSnapshot
    Log-And-Telemetry -Action "rehydrate" -Message "Configuration rehydrated" -Data @{ path=$Global:AppState.ConfigPath }
}

function Build-EffectiveConfig {
    Ensure-Config
    $clone = ($Global:AppState.CurrentConfig | ConvertTo-Json -Depth 80) | ConvertFrom-Json
    # Prefer consolidated ConfigurationStore if available
    $written = New-Object System.Collections.Generic.HashSet[string]
    if ($Global:ConfigurationStore) {
        foreach ($entry in $Global:ConfigurationStore.GetEnumerator()) {
            $code = $entry.Key
            $valObj = $entry.Value
            $val = $valObj.Value
            Set-ConfigValuePath -Path $code -Value $val -Target $clone
            [void]$written.Add($code)
        }
    }
    # Handle complex / array questions (not flattened in store) & any codes not yet written
    foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
        $q = $kv.Value
        if (-not $q.ConfigurationCode) { continue }
        if ($written.Contains($q.ConfigurationCode)) {
            # For complex kinds still need to override with structured shapes
            if (-not ($q.IsComplex -or $q.IsArray)) { continue }
        }
        $valueToWrite = $null
        if ($q.IsComplex) {
            if ($q.ComplexKind -eq 'ObjectArray') {
                $arr=@(); foreach ($it in $q.ComplexItems) { $arr += $it }; $valueToWrite=$arr
            } elseif ($q.ComplexKind -eq 'ObjectMap') {
                $ht=[ordered]@{}; foreach ($k in $q.ComplexMap.Keys) { $ht[$k]=$q.ComplexMap[$k] }; $valueToWrite=[pscustomobject]$ht
            }
        } elseif ($q.IsArray) {
            $valueToWrite = @($q.ArrayItems)
        } elseif ($q.ValueType -eq 'Execute') {
            continue
        } else {
            $valueToWrite = $q.Value
        }
        Set-ConfigValuePath -Path $q.ConfigurationCode -Value $valueToWrite -Target $clone
    }
    return $clone
}

# Retrieve current effective value of a configuration code (from store or by resolving path)
function Get-ConfigurationValue {
    param([Parameter(Mandatory)][string]$Code)
    if ([string]::IsNullOrWhiteSpace($Code)) { return $null }
    if ($Global:ConfigurationStore -and $Global:ConfigurationStore.ContainsKey($Code)) {
        return $Global:ConfigurationStore[$Code].Value
    }
    # Fallback: build effective config (light) and traverse
    $eff = Build-EffectiveConfig
    $segments = $Code -split '\.'
    $cursor = $eff
    foreach ($seg in $segments) {
        if ($null -eq $cursor) { return $null }
        if ($cursor -is [System.Collections.IDictionary]) { if ($cursor.Contains($seg)) { $cursor = $cursor[$seg] } else { return $null } }
        elseif ($cursor.PSObject -and $cursor.PSObject.Properties[$seg]) { $cursor = $cursor.PSObject.Properties[$seg].Value }
        else { return $null }
    }
    return $cursor
}

function ScanComplexQuestionForPlaceholders {
    param($Question,[string]$Placeholder='UNCONFIGUREDENTRY')
    if (-not $Question.IsComplex) { return $false }
    if ($Question.ComplexKind -eq 'ObjectArray') {
        foreach ($it in $Question.ComplexItems) {
            foreach ($p in $it.PSObject.Properties) {
                $v=$p.Value
                if ($v -is [string] -and $v -like "*$Placeholder*") { return $true }
                if ($v -is [System.Collections.IEnumerable] -and $v -isnot [string]) {
                    foreach ($x in $v) {
                        if ($x -is [string] -and $x -like "*$Placeholder*") { return $true }
                    }
                }
            }
        }
    } else {
        foreach ($k in $Question.ComplexMap.Keys) {
            $obj=$Question.ComplexMap[$k]
            foreach ($p in $obj.PSObject.Properties) {
                $v=$p.Value
                if ($v -is [string] -and $v -like "*$Placeholder*") { return $true }
                if ($v -is [System.Collections.IEnumerable] -and $v -isnot [string]) {
                    foreach ($x in $v) {
                        if ($x -is [string] -and $x -like "*$Placeholder*") { return $true }
                    }
                }
            }
        }
    }
    return $false
}

function Normalize-DiffValue {
    param($Value)
    if ($null -eq $Value) { return '' }
    # Scalar
    if ($Value -is [string]) { return ($Value.Trim()) }
    if ($Value -is [bool]) { return ($Value.ToString().ToLower()) }
    if ($Value -is [int] -or $Value -is [long] -or $Value -is [double] -or $Value -is [decimal]) { return ("$Value") }
    # Array / enumerable (exclude string already handled)
    if ($Value -is [System.Collections.IEnumerable] -and $Value -isnot [string]) {
        # Distinguish hashtable / object vs pure collection
        if ($Value -is [hashtable]) {
            $ordered = [ordered]@{}
            foreach ($k in ($Value.Keys | Sort-Object)) { $ordered[$k] = Normalize-DiffValue $Value[$k] }
            return $ordered
        }
        elseif ($Value -is [pscustomobject]) {
            $ordered = [ordered]@{}
            foreach ($p in ($Value.PSObject.Properties.Name | Sort-Object)) { $ordered[$p] = Normalize-DiffValue ($Value.PSObject.Properties[$p].Value) }
            return $ordered
        } else {
            $arr=@()
            foreach ($el in $Value) { $arr += (Normalize-DiffValue $el) }
            return $arr
        }
    }
    return ($Value.ToString())
}

function Test-DeepEqual {
    param($A,$B)
    if ($null -eq $A -and $null -eq $B) { return $true }
    if ($null -eq $A -or $null -eq $B) { return $false }
    $normA = Normalize-DiffValue $A
    $normB = Normalize-DiffValue $B
    try {
        $jsonA = ($normA | ConvertTo-Json -Depth 80 -Compress)
        $jsonB = ($normB | ConvertTo-Json -Depth 80 -Compress)
        return ($jsonA -eq $jsonB)
    } catch {
        return ($normA -eq $normB)
    }
}

function Get-ComplexCurrentOriginal {
    param($Question)
    if (-not $Question.IsComplex) { return @{} }
    if ($Question.ComplexKind -eq 'ObjectArray') {
        $cur = @()
        foreach ($it in $Question.ComplexItems) { $cur += $it }
        $orig = @()
        if ($Question.PSObject.Properties.Name -contains 'ComplexItemsOriginal') {
            foreach ($it in $Question.ComplexItemsOriginal) { $orig += $it }
        } else { foreach ($it in $Question.ComplexItems) { $orig += $it } }
        return @{ Current=$cur; Original=$orig }
    } else {
        $curMap = [ordered]@{}
        foreach ($k in $Question.ComplexMap.Keys) { $curMap[$k] = $Question.ComplexMap[$k] }
        $origMap = [ordered]@{}
        if ($Question.PSObject.Properties.Name -contains 'ComplexMapOriginal') {
            foreach ($k in $Question.ComplexMapOriginal.Keys) { $origMap[$k] = $Question.ComplexMapOriginal[$k] }
        } else { foreach ($k in $Question.ComplexMap.Keys) { $origMap[$k] = $Question.ComplexMap[$k] } }
        return @{ Current=[pscustomobject]$curMap; Original=[pscustomobject]$origMap }
    }
}

function Generate-ChangedSettingsObject {
    $changed = [ordered]@{
        Questions = [ordered]@{}
        UDSLogProcessor = @()
        InstanceConfiguration = [ordered]@{}
    }
    $processedCodes = New-Object System.Collections.Generic.HashSet[string]
    if ($Global:ConfigurationStore) {
        foreach ($entry in $Global:ConfigurationStore.GetEnumerator()) {
            $code = $entry.Key
            $valObj = $entry.Value
            $cur = $valObj.Value
            $orig = $valObj.OriginalValue
            if (-not (Test-DeepEqual $cur $orig)) { $changed.Questions[$code] = $cur }
            [void]$processedCodes.Add($code)
        }
    }
    foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
        $q=$kv.Value
        if ($q.ValueType -eq 'Execute') { continue }
        if ([string]::IsNullOrEmpty($q.ConfigurationCode)) { continue }
        # Skip primitives already handled via store
        if ($processedCodes.Contains($q.ConfigurationCode) -and -not ($q.IsComplex -or $q.IsArray)) { continue }

        if ($q.IsArray) {
            $current = @(); foreach ($it in $q.ArrayItems) { $current += $it }
            $original = @()
            if ($q.PSObject.Properties.Name -contains 'ArrayItemsOriginal') { foreach ($it in $q.ArrayItemsOriginal) { $original += $it } } else { $original = @($current) }
            if (-not (Test-DeepEqual $current $original)) { $changed.Questions[$q.ConfigurationCode] = $current }
            continue
        }
        if ($q.IsComplex) {
            $cmp = Get-ComplexCurrentOriginal -Question $q
            if (-not (Test-DeepEqual $cmp.Current $cmp.Original)) { $changed.Questions[$q.ConfigurationCode] = $cmp.Current }
            continue
        }
        # Primitive fallback (question not in store)
        $curVal = $q.Value
        $origVal = $q.OriginalValue
        if (-not (Test-DeepEqual $curVal $origVal)) { $changed.Questions[$q.ConfigurationCode] = $curVal }
    }
    foreach ($r in $Global:AppState.UDSRows) {
        $rowChanged=$false
        foreach ($p in $r.PSObject.Properties) {
            if ($p.Name -eq 'Original') { continue }
            if (-not (Test-DeepEqual $p.Value $r.Original[$p.Name])) { $rowChanged=$true; break }
        }
        if ($rowChanged) {
            $changed.UDSLogProcessor += [pscustomobject]@{
                Activated=$r.Activated
                StorageType=$r.StorageType
                StoragePath=$r.StoragePath
                Prefix=$r.Prefix
                LogStorageRetentionDays=$r.LogStorageRetentionDays
                StorageAccountName=$r.StorageAccountName
                StorageBlobContainer=$r.StorageBlobContainer
                ConnexionType=$r.ConnexionType
                TenantId=$r.TenantId
                ApplicationID=$r.ApplicationID
                CertificateThumbprint=$r.CertificateThumbprint
            }
        }
    }
    foreach ($r in $Global:AppState.InstanceRows) {
        $rowChanged=$false
        foreach ($p in $r.PSObject.Properties) {
            if ($p.Name -eq 'Original') { continue }
            if (-not (Test-DeepEqual $p.Value $r.Original[$p.Name])) { $rowChanged=$true; break }
        }
        if ($rowChanged -and $r.InstanceName) {
            $changed.InstanceConfiguration[$r.InstanceName] = [pscustomobject]@{
                All=$r.All
                Category=$r.Category
                Capabilities=$r.Capabilities
                OutputName=$r.OutputName
                SelectedAddons= ($r.SelectedAddons -split ';' | Where-Object {$_})
                FileteredAddons= ($r.FileteredAddons -split ';' | Where-Object {$_})
            }
        }
    }
    return $changed
}

function Set-Dirty {
    param([switch]$Clear)
    if ($Clear) { $Global:AppState.Dirty=$false } else { $Global:AppState.Dirty=$true }
    Update-WindowTitle
}

function Update-WindowTitle {
    if ($Global:AppState.MainForm -and -not $Global:AppState.MainForm.IsDisposed) {
        $star = if ($Global:AppState.Dirty) { '*' } else { '' }
        $file = if ($Global:AppState.ConfigPath) { [IO.Path]::GetFileName($Global:AppState.ConfigPath) } else { '(No File)' }
        $mode = if ($Global:AppState.ReadOnly) { 'RO' } else { 'Write' }
        $hiddenTag = if ($Global:AppState.ShowHiddenQuestions) { ' [Hidden Shown]' } else { '' }
        $Global:AppState.MainForm.Text = "$star CollectExchSec Config Editor - $file (Filter: $($Global:AppState.SetupFilter)) (Mode: $mode)$hiddenTag"
    }
}

function Clear-UndoRedo {
    $Global:AppState.UndoStack.Clear()
    $Global:AppState.RedoStack.Clear()
}

function Capture-State {
    $payload=[ordered]@{
        Questions=@{}
        UDS=@()
        Instance=@()
    }
    foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
        $q=$kv.Value
        if ($q.ValueType -eq 'Execute') { continue }
        $payload.Questions[$kv.Key] = @{
            V = if ($q.IsArray) { ($q.ArrayItems -join ';') } else { $q.Value }
            O = $q.OriginalValue
            A = $q.IsArray
        }
    }
    foreach ($r in $Global:AppState.UDSRows) {
        $payload.UDS += @{
            Activated=$r.Activated;StorageType=$r.StorageType;StoragePath=$r.StoragePath;Prefix=$r.Prefix;
            LogStorageRetentionDays=$r.LogStorageRetentionDays;StorageAccountName=$r.StorageAccountName;
            StorageBlobContainer=$r.StorageBlobContainer;ConnexionType=$r.ConnexionType;TenantId=$r.TenantId;
            ApplicationID=$r.ApplicationID;CertificateThumbprint=$r.CertificateThumbprint;Original=$r.Original
        }
    }
    foreach ($r in $Global:AppState.InstanceRows) {
        $payload.Instance += @{
            InstanceName=$r.InstanceName;All=$r.All;Category=$r.Category;Capabilities=$r.Capabilities;OutputName=$r.OutputName;
            SelectedAddons=$r.SelectedAddons;FileteredAddons=$r.FileteredAddons;Original=$r.Original
        }
    }
    return ($payload | ConvertTo-Json -Depth 40)
}

function Restore-State {
    param([string]$Json)
    try {
        $data = $Json | ConvertFrom-Json
    } catch { return }
    if (-not $data) { return }
    foreach ($kv in $data.Questions.PSObject.Properties) {
        if ($Global:AppState.QuestionsLookup.ContainsKey($kv.Name)) {
            $entry=$kv.Value
            $q=$Global:AppState.QuestionsLookup[$kv.Name]
            if ($q.ValueType -eq 'Execute') { continue }
            $q.IsArray=$entry.A
            if ($q.IsArray) {
                $q.ArrayItems.Clear()
                ($entry.V -split ';' | Where-Object {$_}) | ForEach-Object {[void]$q.ArrayItems.Add($_)}
                $q.Value=($q.ArrayItems -join ';')
            } else {
                $q.Value=$entry.V
            }
            $q.OriginalValue=$entry.O
            Validate-Question $q
        }
    }
    $Global:AppState.UDSRows.Clear()
    foreach ($r in $data.UDS) {
        $row=[ordered]@{
            Activated=$r.Activated;StorageType=$r.StorageType;StoragePath=$r.StoragePath;Prefix=$r.Prefix;
            LogStorageRetentionDays=$r.LogStorageRetentionDays;StorageAccountName=$r.StorageAccountName;
            StorageBlobContainer=$r.StorageBlobContainer;ConnexionType=$r.ConnexionType;TenantId=$r.TenantId;
            ApplicationID=$r.ApplicationID;CertificateThumbprint=$r.CertificateThumbprint
        }
        $row.Original = New-RowSnapshot -RowObject $row
        [void]$Global:AppState.UDSRows.Add([pscustomobject]$row)
    }
    $Global:AppState.InstanceRows.Clear()
    foreach ($r in $data.Instance) {
        $row=[ordered]@{
            InstanceName=$r.InstanceName;All=$r.All;Category=$r.Category;Capabilities=$r.Capabilities;OutputName=$r.OutputName;
            SelectedAddons=$r.SelectedAddons;FileteredAddons=$r.FileteredAddons

        }
        $row.Original = New-RowSnapshot -RowObject $row
        [void]$Global:AppState.InstanceRows.Add([pscustomobject]$row)
    }
    Set-Dirty
}

function Push-UndoSnapshot {
    $state = Capture-State
    $Global:AppState.UndoStack.Push($state)
    $Global:AppState.RedoStack.Clear()
}

function Do-Undo {
    if ($Global:AppState.UndoStack.Count -lt 2) { return }
    $current = $Global:AppState.UndoStack.Pop()
    $Global:AppState.RedoStack.Push($current)
    $previous = $Global:AppState.UndoStack.Peek()
    Restore-State -Json $previous
    Set-Dirty
    Log-And-Telemetry -Action "undo" -Message "Undo applied"
}

function Do-Redo {
    if ($Global:AppState.RedoStack.Count -eq 0) { return }
    $next = $Global:AppState.RedoStack.Pop()
    $Global:AppState.UndoStack.Push($next)
    Restore-State -Json $next
    Set-Dirty
    Log-And-Telemetry -Action "redo" -Message "Redo applied"
}

# ---------------- Execute Question Support ----------------

function Apply-ExecuteResult {
    param(
        [hashtable]$ResultMap
    )
    if (-not $ResultMap) { return @() }
    $applied = @()
    foreach ($k in $ResultMap.Keys) {
        $val = $ResultMap[$k]
        $targetQ = $null
        foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
            if ($kv.Value.ConfigurationCode -and ($kv.Value.ConfigurationCode -ieq $k)) {
                $targetQ = $kv.Value
                break
            }
        }
        if ($targetQ) {
            if ($targetQ.IsArray -and $val -is [System.Collections.IEnumerable] -and $val -isnot [string]) {
                $targetQ.ArrayItems.Clear()
                foreach ($i in $val) { [void]$targetQ.ArrayItems.Add([string]$i) }
                $targetQ.Value = ($targetQ.ArrayItems -join ';')
            } else {
                $targetQ.Value = $val
            }
            Validate-Question $targetQ
            $applied += [pscustomobject]@{ ConfigurationCode=$k; NewValue=$val }
        }
    }
    if ($applied.Count -gt 0) {
        Set-Dirty
        Push-UndoSnapshot
    }
    return $applied
}

function Create-EntraIDApplication {
    param(
        [SetupQuestion]$Question
    )
    <#
        Crée (ou valide) une application Entra ID (Azure AD) pour un scénario Certificate.
        Flux:
          1. Vérifie connexion Azure + Graph (Invoke-AzureLogin avec -ConnectGraph si dispo).
          2. Lit les questions nécessaires:
                - Application Display Name (ConfigurationCode peut être p.ex. 'LogCollection.TargetLogAppID' sibling ou spécifique)
                - (Optionnel) Certificate Path / Thumbprint (si on veut charger un certificat local pour clé publique)
          3. Cherche application existante par DisplayName; sinon la crée.
          4. Crée le Service Principal si absent.
          5. Si un certificat (fichier .cer / .pem) fourni: attache comme KeyCredential (Usage=Verify).
          6. Retourne un hashtable des ConfigurationCode -> valeur (ex: ApplicationID, CertificateThumbprint si applicable).
        NOTE: Cette implémentation suppose que les codes de configuration suivants existent dans le modèle:
              - 'LogCollection.TargetLogAppID' (Application (client) Id)
              - 'LogCollection.TargetLogAppSecretReference' ou un champ pour le certificat (facultatif)
        Si absents, aucun retour ne sera appliqué.
    #>
    try {
        if (-not $Global:AppState.AzureConnected) {
            [System.Windows.Forms.MessageBox]::Show("Azure not connected. Use Azure -> Connect.","Azure","OK","Warning") | Out-Null
            return $null
        }
        # Tentative de charger modules requis
        foreach ($m in 'Az.Accounts','Microsoft.Graph.Applications','Microsoft.Graph.Authentication') {
            if (-not (Get-Module -ListAvailable -Name $m)) { continue }
            Import-Module $m -ErrorAction SilentlyContinue | Out-Null
        }
        # Détermination du DisplayName depuis la question 'ApplicationName' (code de question, pas ConfigurationCode)
        $displayName = 'ExchSecIns-App-' + ([guid]::NewGuid().ToString().Substring(0,8))
        foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
            # Key format: <Section>|<QuestionCode>
            if ($kv.Key -match '\|ApplicationName$') {
                $q=$kv.Value
                if ($q.Value -and $q.Value -notmatch 'UNCONFIGUREDENTRY') { $displayName=$q.Value; break }
            }
        }

        # Récupération du chemin certificat via la question 'ApplicationCertificateNew'
        $certPath = $null
        foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
            if ($kv.Key -match '\|ApplicationCertificateNew$') {
                $q=$kv.Value
                if ($q.Value -and $q.Value -notmatch 'UNCONFIGUREDENTRY' -and (Test-Path $q.Value)) { $certPath=$q.Value }
                break
            }
        }
        # Vérifie si application existe déjà
        $existing = $null
        try {
            if (Get-Command Get-MgApplication -ErrorAction SilentlyContinue) {
                $existing = Get-MgApplication -Filter "DisplayName eq '$displayName'" -ErrorAction Stop
            }
        } catch { $existing = $null }
        if (-not $existing) {
            if (Get-Command New-MgApplication -ErrorAction SilentlyContinue) {
                $existing = New-MgApplication -DisplayName $displayName -ErrorAction Stop
            } else {
                throw 'Microsoft Graph Applications module not loaded; cannot create application.'
            }
        }
        $appId = $existing.AppId
        # Service Principal
        $sp = $null
        try {
            if (Get-Command Get-MgServicePrincipal -ErrorAction SilentlyContinue) {
                $sp = Get-MgServicePrincipal -Filter "AppId eq '$appId'" -ErrorAction Stop
            }
        } catch { $sp=$null }
        if (-not $sp) {
            if (Get-Command New-MgServicePrincipal -ErrorAction SilentlyContinue) {
                $sp = New-MgServicePrincipal -AppId $appId -ErrorAction Stop
            }
        }
        $thumbprint = $null
        if ($certPath) {
            try {
                $bytes = [System.IO.File]::ReadAllBytes($certPath)
                $base64 = [Convert]::ToBase64String($bytes)
                $x509 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($bytes)
                $thumbprint = $x509.Thumbprint
                $keyCred = @{
                    Type = 'AsymmetricX509Cert'
                    Usage = 'Verify'
                    Key = $base64
                    DisplayName = $displayName
                }
                if (Get-Command Update-MgApplication -ErrorAction SilentlyContinue) {
                    Update-MgApplication -ApplicationId $existing.Id -KeyCredentials @($keyCred) -ErrorAction Stop | Out-Null
                }
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Failed to attach certificate: $($_.Exception.Message)","Certificate","OK","Warning") | Out-Null
            }
        }
        $result = @{}
        # Map vers ConfigurationCodes si présents
        $result['LogCollection.TargetLogAppID'] = $appId
        if ($thumbprint) { $result['LogCollection.TargetLogCertificateThumbprint'] = $thumbprint }
        Log-And-Telemetry -Action 'create_entraid_app' -Message 'Application created/validated' -Data @{ appId=$appId; displayName=$displayName; certAttached=([bool]$thumbprint) }
        return $result
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Create EntraID Application failed: $($_.Exception.Message)","Error","OK","Error") | Out-Null
        Log-And-Telemetry -Action 'create_entraid_app_error' -Message $_.Exception.Message
        return $null
    }
}

function ApplyExchangePermissionLogAnalytics {
    param(
        [SetupQuestion]$Question
    )
    <#
        Applique les permissions (AppRole assignments) nécessaires pour la collecte Exchange / Log Analytics.
        Inspiré de ExchangeOnlinePermSetup.ps1 :
          - Rôles Microsoft Graph: user.read.all, group.read.all, AuditLog.Read.All
          - Rôle Exchange Online (AppRoleId fixe dc50a0fb-09a3-484d-be87-e023b12c6440)
        Flux:
          1. Vérifie connexion Azure déjà établie (sinon avertit) – mais permet quand même d’essayer Graph direct.
          2. Assure modules Microsoft.Graph chargés (Authentication + Applications + Directory + ServicePrincipal).
          3. Connect-MgGraph (scopes: AppRoleAssignment.ReadWrite.All, Application.Read.All) si pas connecté.
          4. Détermine l’ObjectId du Principal cible (Managed Identity / App) :
               - Cherche une question dont le ConfigurationCode contient 'ManagedIdentityObjectId' ou 'TargetLogAppObjectId'.
               - Sinon InputBox pour saisie manuelle.
          5. Récupère SP Microsoft Graph et Exchange, filtre les AppRoles nécessaires.
          6. Pour chaque AppRole, crée une attribution (ignore si déjà existante).
          7. Retourne un hashtable (peut être consommé par Apply-ExecuteResult) marquant l’application des permissions.
        Retour: @{ 'LogCollection.ExchangePermissionsApplied' = '<timestamp>' }
    #>
    try {
        # --- Modules Graph ---
        foreach ($m in 'Microsoft.Graph.Authentication','Microsoft.Graph.Applications','Microsoft.Graph.DirectoryObjects','Microsoft.Graph.ServicePrincipal') {
            if (-not (Get-Module -Name $m -ListAvailable)) { continue }
            Import-Module $m -ErrorAction SilentlyContinue | Out-Null
        }
        if (-not (Get-Command Connect-MgGraph -ErrorAction SilentlyContinue)) {
            [System.Windows.Forms.MessageBox]::Show('Microsoft Graph PowerShell SDK not installed. Install module Microsoft.Graph.','Graph Module Missing','OK','Warning') | Out-Null
            return $null
        }
        # Test connexion Graph (rudimentaire):
        $graphConnected = $false
        $mgContext = $null
        try { $mgContext = Get-MgContext; $graphConnected = $true } catch { $graphConnected = $false }

        # Récupérer tenant attendu depuis la configuration (ExchangeCollectorTenantID)
        $expectedTenant = $null
        foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
            $q=$kv.Value
            if ($q.ConfigurationCode -and $q.ConfigurationCode -match 'ExchangeCollectorTenantID') {
                if ($q.Value -and $q.Value -notmatch 'UNCONFIGUREDENTRY') { $expectedTenant = $q.Value.Trim(); break }
            }
        }
        # Fallback si stocké dans ConfigurationStore
        if (-not $expectedTenant -and $Global:ConfigurationStore -and $Global:ConfigurationStore.ContainsKey('ExchangeCollectorTenantID')) {
            $expectedTenant = $Global:ConfigurationStore['ExchangeCollectorTenantID'].Value
        }

        if (-not $graphConnected) {
            $scopes = 'AppRoleAssignment.ReadWrite.All','Application.Read.All'
            try {
                if ($expectedTenant) { Connect-MgGraph -TenantId $expectedTenant -Scopes $scopes | Out-Null }
                else { Connect-MgGraph -Scopes $scopes | Out-Null }
                $mgContext = Get-MgContext
                $graphConnected = $true
            } catch {
                [System.Windows.Forms.MessageBox]::Show("Graph connection failed: $($_.Exception.Message)","Graph","OK","Error") | Out-Null
                return $null
            }
        }

        if ($expectedTenant -and $graphConnected) {
            $ctxTenant = $mgContext.TenantId
            if ($ctxTenant -and ($ctxTenant -ine $expectedTenant)) {
                [System.Windows.Forms.MessageBox]::Show("Connected Graph tenant ($ctxTenant) differs from expected ExchangeCollectorTenantID ($expectedTenant). Aborting.","Tenant Mismatch","OK","Error") | Out-Null
                return $null
            }
        }

        # --- Résolution du target principal ---
        $targetObjectId = $null
        # Chercher d'abord ExchangeCollectorManagedIdentityID
        foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
            $q = $kv.Value
            if (-not $q.ConfigurationCode) { continue }
            if ($q.ConfigurationCode -match 'ExchangeCollectorManagedIdentityID') {
                if ($q.Value -and $q.Value -notmatch 'UNCONFIGUREDENTRY') { $targetObjectId = $q.Value.Trim(); break }
            }
        }
        # Sinon chercher un SP App ObjectId générique
        if (-not $targetObjectId) {
            foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
                $q = $kv.Value
                if (-not $q.ConfigurationCode) { continue }
                if ($q.ConfigurationCode -match 'ManagedIdentityObjectId|TargetLogAppObjectId') {
                    if ($q.Value -and $q.Value -notmatch 'UNCONFIGUREDENTRY') { $targetObjectId = $q.Value.Trim(); break }
                }
            }
        }
        # Fallback sur InputBox
        if (-not $targetObjectId) {
            try { $targetObjectId = [Microsoft.VisualBasic.Interaction]::InputBox('Enter Service Principal ObjectId to assign roles:','Exchange Permissions','') } catch {}
        }
        if ([string]::IsNullOrWhiteSpace($targetObjectId)) {
            [System.Windows.Forms.MessageBox]::Show('No target Service Principal ObjectId provided. Aborting.','Missing Target','OK','Warning') | Out-Null
            return $null
        }

        # Validate target SP exists
        $targetSp = $null
        try { $targetSp = Get-MgServicePrincipal -ServicePrincipalId $targetObjectId -ErrorAction Stop } catch {}
        if (-not $targetSp) {
            [System.Windows.Forms.MessageBox]::Show("Target Service Principal not found: $targetObjectId","Invalid Target","OK","Error") | Out-Null
            return $null
        }

        $graphAppId    = '00000003-0000-0000-c000-000000000000'
        $exchangeAppId = '00000002-0000-0ff1-ce00-000000000000'
        $exchangeRoleId = [guid]'dc50a0fb-09a3-484d-be87-e023b12c6440'

        $graphSp = $null
        $exchSp  = $null
        try { $graphSp = Get-MgServicePrincipal -Filter "appId eq '$graphAppId'" -ErrorAction Stop } catch {}
        try { $exchSp  = Get-MgServicePrincipal -Filter "appId eq '$exchangeAppId'" -ErrorAction Stop } catch {}
        if (-not $graphSp -or -not $exchSp) {
            [System.Windows.Forms.MessageBox]::Show('Failed to resolve Graph or Exchange Service Principals.','Lookup Error','OK','Error') | Out-Null
            return $null
        }

        $graphRoles = @()
        foreach ($r in $graphSp.AppRoles) {
            if (-not $r.Value) { continue }
            if ($r.Value -match '^(?i)user.read.all$' -or $r.Value -match 'group.read.all' -or $r.Value -match 'AuditLog.Read.All') {
                $graphRoles += $r
            }
        }
        if ($graphRoles.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show('No matching Graph roles found (user/group/audit).','Roles Missing','OK','Warning') | Out-Null
        }

        $assigned = 0
        function _AssignRole([guid]$roleId,[string]$resourceId) {

            try {
                New-MgServicePrincipalAppRoleAssignment -ServicePrincipalId $targetObjectId -PrincipalId $targetObjectId -ResourceId $resourceId -AppRoleId $roleId -ErrorAction Stop | Out-Null
                $script:assigned++
            } catch {
                # Ignore conflicts (already assigned)
                if ($_.Exception.Message -notmatch 'existing|conflict') { Write-Verbose $_.Exception.Message }
            }
        }

        foreach ($r in $graphRoles) { _AssignRole -roleId $r.Id -resourceId $graphSp.Id }
        _AssignRole -roleId $exchangeRoleId -resourceId $exchSp.Id

        Log-And-Telemetry -Action 'exchange_permissions' -Message 'Roles applied' -Data @{ target=$targetObjectId; assigned=$assigned }
        [System.Windows.Forms.MessageBox]::Show("Exchange/Graph permissions applied (new assignments: $assigned).","Permissions","OK","Information") | Out-Null

        return @{ 'LogCollection.ExchangePermissionsApplied' = (Get-Date).ToString('s') }
    } catch {
        Log-And-Telemetry -Action 'exchange_permissions_error' -Message $_.Exception.Message
        [System.Windows.Forms.MessageBox]::Show("Failed applying Exchange permissions: $($_.Exception.Message)","Error","OK","Error") | Out-Null
        return @{
            'Error' = "Failed applying Exchange permissions: $($_.Exception.Message)"
        }
    }
}

function ApplyDCRPermission {
    param([SetupQuestion]$Question)

    # Pattern identique Execute: valider connexion Azure
    if (-not $Global:AppState.AzureConnected) {
        [System.Windows.Forms.MessageBox]::Show("Azure n'est pas connecté. Utilisez 'Azure -> Connect to Azure' d'abord.","Azure Non Connecté","OK","Warning")|Out-Null
        throw "Azure not connected."
    }
    if (-not $Global:AppState.AzureSelectedSubscriptionId) {
        [System.Windows.Forms.MessageBox]::Show("Aucun abonnement sélectionné.","Abonnement manquant","OK","Warning")|Out-Null
        throw "No subscription selected."
    }

    foreach ($m in @('Az.Accounts','Az.Resources','Az.Monitor','Az.Authorization')) {
        if (-not (Get-Module -ListAvailable -Name $m)) {
            try { Import-Module $m -ErrorAction Stop } catch { throw "Module requis '$m' absent." }
        }
    }

    try { Set-AzureSubscriptionContext -SubscriptionId $Global:AppState.AzureSelectedSubscriptionId } catch { throw "Impossible de définir le contexte abonnement: $($_.Exception.Message)" }

    # Helpers locaux pour récupérer des valeurs de questions de la sous-section DCRInformation et EntraIDApplicationInformation
    function _GetQValue {
        param($SectionMatch,$QCode)
        foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
            if ($kv.Key -match $SectionMatch -and $kv.Key -like "*|$QCode") { return $kv.Value.Value }
        }
        return $null
    }

    $createMode = (_GetQValue -SectionMatch 'DCRInformation\|' -QCode 'DCRCreation') -eq 'Yes'
    $permWanted = (_GetQValue -SectionMatch 'DCRInformation\|' -QCode 'DCRPermission') -eq 'Yes'
    if (-not $permWanted) { return $null }

    # Nom du DCR selon mode
    if ($createMode) { $dcrName = _GetQValue -SectionMatch 'DCRInformation\|' -QCode 'DCRName' }
    else { $dcrName = _GetQValue -SectionMatch 'DCRInformation\|' -QCode 'DCRNameForPermission' }

    $dcrRg   = _GetQValue -SectionMatch 'DCRInformation\|' -QCode 'DCRResourceGroup'
    if (-not $dcrRg -and -not $createMode) { # si pas création on ne l'a peut-être pas saisi -> demander
        $dcrRg = [System.Windows.Forms.Interaction]::InputBox("Resource Group du DCR","DCR Resource Group","")
    }

    if (-not $dcrName -or -not $dcrRg) { throw "Nom ou Resource Group du DCR manquant." }

    # Récupérer l'ID Applicatif cible
    $appId = _GetQValue -SectionMatch 'EntraIDApplicationInformation\|' -QCode 'ApplicationId'
    if (-not $appId) { $appId = (Get-Variable -Name Global -ValueOnly).AppState.ConfigurationValues['LogCollection.TargetLogAppID'] }
    if (-not $appId) { throw "Impossible de déterminer LogCollection.TargetLogAppID (Application / Managed Identity)." }

    # Résoudre l'objet principal (Service Principal ou Managed Identity) via AppId
    $sp = $null
    try {
        $sp = Get-AzADServicePrincipal -ApplicationId $appId -ErrorAction Stop
    } catch {
        # Peut être un principal géré? Essayer par DisplayName si format GUID absent
        if ($appId -match '^[0-9a-fA-F-]{36}$') { throw "Service principal introuvable pour AppId $appId" }
        try { $sp = Get-AzADServicePrincipal -DisplayName $appId -ErrorAction Stop } catch { throw "Service principal / identité managée introuvable ($appId)." }
    }
    $principalId = $sp.Id

    # Rôle Monitoring Metrics Publisher (GUID fixe)
    $roleName = 'Monitoring Metrics Publisher'
    $roleDef = Get-AzRoleDefinition -Name $roleName -ErrorAction SilentlyContinue
    if (-not $roleDef) { throw "Role '$roleName' introuvable dans l'abonnement." }

    # Résoudre l'ID du DCR
    $dcr = $null
    try { $dcr = Get-AzDataCollectionRule -Name $dcrName -ResourceGroupName $dcrRg -ErrorAction Stop } catch { throw "DCR '$dcrName' introuvable dans RG '$dcrRg'." }
    $dcrId = $dcr.Id

    # Vérifier si rôle déjà assigné
    $existingAssign = Get-AzRoleAssignment -ObjectId $principalId -Scope $dcrId -ErrorAction SilentlyContinue | Where-Object { $_.RoleDefinitionName -eq $roleName }
    if (-not $existingAssign) {
        try {
            New-AzRoleAssignment -ObjectId $principalId -RoleDefinitionName $roleName -Scope $dcrId -ErrorAction Stop | Out-Null
        } catch {
            throw "Echec d'assignation du rôle '$roleName' sur DCR: $($_.Exception.Message)"
        }
    }

    return @{'LogCollection.DCRPermissionApplied' = (Get-Date).ToString('s') }
}

function CreateScheduledTask {
    param([SetupQuestion]$Question)

    <#
        Crée une tâche planifiée Windows basée sur les questions de la section ServerExecution :
          - ScheduleTaskStartTime (hh:mmAM/PM)
          - ScheduleTaskUser (UPN)
          - ScheduleTaskPassword (SecureString)
          - ScheduleTaskName (Nom de la tâche) (optionnel / défaut si absent)
        Utilise CollectExchSecIns.ps1 comme script (ajoute -InstanceName si != Default).
        Retourne un hashtable (optionnel) vide car aucune ConfigurationCode à mettre à jour.
        Erreurs: lève une exception pour que l'UI affiche le message (pattern DeployDCR).
    #>

    # Verify OS (Windows required for scheduled tasks)
    if ($PSVersionTable.PSEdition -eq 'Core' -and -not $IsWindows) { throw "Scheduled Task only supported on Windows." }

    # Récupération valeurs via QuestionsLookup (pattern interne)
    function _GetServerValue {
        param($QCode)
        foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
            if ($kv.Key -match 'ServerExecution\|' -and $kv.Key -like "*|$QCode") { return $kv.Value }
        }
        return $null
    }

    $qTime   = _GetServerValue -QCode 'ScheduleTaskStartTime'
    $qUser   = _GetServerValue -QCode 'ScheduleTaskUser'
    $qPass   = _GetServerValue -QCode 'ScheduleTaskPassword'
    $qName   = _GetServerValue -QCode 'ScheduleTaskName'

    $startTime = if ($null -ne $qTime) { $qTime.Value } else { $null }
    $user      = if ($null -ne $qUser) { $qUser.Value } else { $null }
    $name      = if ($qName -and $qName.Value) { $qName.Value } else { 'ESI - Exchange Security Configuration Collector' }

    if (-not $startTime -or -not $user -or -not $qPass) { throw "Missing required ServerExecution fields (time, user, password)." }

    # Gestion SecureString: le champ stocke un SecureString ou un texte ?
    $securePass = $null
    if ($qPass.Value -is [System.Security.SecureString]) { $securePass = $qPass.Value }
    elseif ($qPass.ValueType -eq 'SecureString' -and $qPass.Value) {
        # Si la sérialisation a transformé en texte, tenter conversion (non idéal). On rejette.
        throw "Password value not stored as SecureString. Re-enter it before creating the task." 
    } else {
        throw "ScheduleTaskPassword not provided as SecureString."
    }

    # InstanceName (optionnel) depuis InstanceInformation section (question InstanceType ? ou Provided InstanceName?)
    # On regarde si une question avec code ScheduleTaskName contient un suffixe ou si un InstanceName existe ailleurs.
    $instanceName = 'Default'
    foreach ($kv in $Global:AppState.QuestionsLookup.GetEnumerator()) {
        if ($kv.Key -match 'InstanceInformation\|InstanceType$') { if ($kv.Value.Value) { $instanceName = $kv.Value.Value } }
    }

    # Localisation du script CollectExchSecIns.ps1 (supposé même dossier que binaire principal)
    $scriptDir = Split-Path -Parent $PSCommandPath
    # Si $PSCommandPath pointe sur Utilities.ps1, on remonte d'un niveau au répertoire parent pour trouver CollectExchSecIns.ps1
    $baseDir = Split-Path -Parent $scriptDir
    $collectorScript = Join-Path $baseDir 'CollectExchSecIns.ps1'
    if (-not (Test-Path $collectorScript)) {
        # Fallback: chercher dans racine ExchSecIns
        $candidate = Join-Path (Split-Path -Parent $baseDir) 'CollectExchSecIns.ps1'
        if (Test-Path $candidate) { $collectorScript = $candidate }
    }
    if (-not (Test-Path $collectorScript)) { throw "CollectExchSecIns.ps1 not found (searched at $collectorScript)." }

    # Transformer heure hh:mmAM/PM en TimeSpan pour New-ScheduledTaskTrigger
    if ($startTime -notmatch '^[0-9]{1,2}:[0-9]{1,2}(AM|PM)$') { throw "Start time format invalid ($startTime)." }
    try { $triggerTime = [datetime]::ParseExact($startTime,'h:mmtt',[System.Globalization.CultureInfo]::InvariantCulture) } catch { throw "Failed to parse start time $startTime." }
    $hour   = $triggerTime.Hour
    $minute = $triggerTime.Minute

    # Convert SecureString -> plaintext (temporary, zeroed after use)
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePass)
    $plainPwd = $null
    try {
        $plainPwd = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }

    # Build script arguments
    $execScript = "`"$collectorScript`""
    if ($instanceName -and $instanceName -ne 'Default') { $execScript += " -InstanceName '$instanceName'" }

    try {
        $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $execScript -ErrorAction Stop
        $trigger = New-ScheduledTaskTrigger -Daily -At ([datetime]::Today.AddHours($hour).AddMinutes($minute).TimeOfDay) -ErrorAction Stop
        $settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 23) -MultipleInstances IgnoreNew -RestartCount 5 -RestartInterval (New-TimeSpan -Hours 1)

        Register-ScheduledTask -TaskName $name -Trigger $trigger -User $user -Password $plainPwd -Action $action -Settings $settings -ErrorAction Stop | Out-Null
    } catch {
        throw "Failed to register scheduled task: $($_.Exception.Message)"
    } finally {
        # Zero the plaintext password from memory
        if ($plainPwd) { $plainPwd = [string]::new([char]0, $plainPwd.Length); $plainPwd = $null }
    }

    # Pas de codes config à mettre à jour: retourner null ou un dictionnaire vide
    return @{}
}