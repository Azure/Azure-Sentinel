<#
.SYNOPSIS
    Forwarder Pickup Processor - Process JSON files from pickup folder and inject to Microsoft Sentinel
.DESCRIPTION
    This script processes JSON files from a pickup directory and injects them into Microsoft Sentinel.
    It supports both Log Analytics API (classic) and Log Ingestion API (DCR-based).
    Files are processed, archived, and error handling ensures reliable data ingestion.
.PARAMETER ConfigurationFile
    Path to the JSON configuration file
.PARAMETER PickupFolder
    Path to the folder containing files to process (overrides config)
.PARAMETER ArchiveFolder
    Path to archive processed files (overrides config)
.PARAMETER ErrorFolder
    Path to move files that failed processing (overrides config)
.PARAMETER MaxFilesPerRun
    Maximum number of files to process in one execution (default: 0 = unlimited)
.PARAMETER DeleteAfterProcessing
    If specified, files are deleted instead of archived after successful processing
.EXAMPLE
    .\ForwarderPickupProcessor.ps1 -ConfigurationFile ".\Config\ForwarderConfig.json"
.EXAMPLE
    .\ForwarderPickupProcessor.ps1 -PickupFolder "C:\ESI\Pickup" -ArchiveFolder "C:\ESI\Archive"
.NOTES
    Author: Nicolas Lepagnez (nilepagn@microsoft.com)
    Version: 1.0.0
    Compatible with CollectExchSecIns.ps1 v8.0+
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$false)]
    [string]$ConfigurationFile = ".\Config\ForwarderPickupConfig.json",
    
    [Parameter(Mandatory=$false)]
    [string]$PickupFolder,
    
    [Parameter(Mandatory=$false)]
    [string]$ArchiveFolder,
    
    [Parameter(Mandatory=$false)]
    [string]$ErrorFolder,
    
    [Parameter(Mandatory=$false)]
    [int]$MaxFilesPerRun = 0,
    
    [Parameter(Mandatory=$false)]
    [switch]$DeleteAfterProcessing,

    [Parameter(Mandatory=$false)]
    [switch]$UseProxy,

    [Parameter(Mandatory=$false)]
    [string]$ProxyUrl
)

#region Script Variables
$Script:Version = "1.0.0"
$Script:ProcessedFiles = 0
$Script:FailedFiles = 0
$Script:TotalBytesProcessed = 0
$Script:StartTime = Get-Date
$Script:LogFile = $null
$Script:Config = $null
$Script:SentinelLogIngestionToken = $null
$Script:AlreadyAzSentinelConnected = $false
#endregion

#region Logging Functions
function Write-ForwarderLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Message,
        
        [Parameter(Mandatory=$false)]
        [ValidateSet("Info","Warning","Error","Success")]
        [string]$Level = "Info"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    
    # Console output with colors
    switch($Level) {
        "Info"    { Write-Host $logMessage -ForegroundColor Cyan }
        "Warning" { Write-Warning $logMessage }
        "Error"   { Write-Host $logMessage -ForegroundColor Red }
        "Success" { Write-Host $logMessage -ForegroundColor Green }
    }
    
    # File logging
    if ($Script:LogFile -and (Test-Path (Split-Path $Script:LogFile))) {
        Add-Content -Path $Script:LogFile -Value $logMessage -ErrorAction SilentlyContinue
    }
}
#endregion

#region Configuration Management
function Get-ForwarderConfiguration {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$ConfigPath
    )
    
    Write-ForwarderLog "Loading configuration from: $ConfigPath"
    
    if (-not (Test-Path $ConfigPath)) {
        Write-ForwarderLog "Configuration file not found. Creating default configuration." -Level Warning
        
        # Create default configuration
        $defaultConfig = @{
            PickupFolder = "C:\ESI\ForwarderPickup"
            ArchiveFolder = "C:\ESI\Archive"
            ErrorFolder = "C:\ESI\Error"
            LogFolder = "C:\ESI\Logs"
            DeleteAfterProcessing = $false
            MaxFilesPerRun = 0
            FilePattern = "*.json"
            SentinelConnection = @{
                UseManagedIdentity = $false
                UseLogIngestionAPI = $true
                WorkspaceId = ""
                WorkspaceKey = ""
                DataCollectionEndpointURI = ""
                DCRImmutableId = ""
                TenantID = ""
                ApplicationId = ""
                CertificateThumbprint = ""
                DefaultLogType = "ESIExchangeConfig"
                MaxSegmentSizeMb = 31.9
            }
            Proxy = @{
                UseProxy = $false
                ProxyUrl = ""
            }
        }
        
        $configDir = Split-Path $ConfigPath
        if (-not (Test-Path $configDir)) {
            New-Item -ItemType Directory -Path $configDir -Force | Out-Null
        }
        
        $defaultConfig | ConvertTo-Json -Depth 10 | Set-Content -Path $ConfigPath -Encoding UTF8
        Write-ForwarderLog "Default configuration created at: $ConfigPath" -Level Success
        
        return $defaultConfig
    }
    
    try {
        $config = Get-Content -Path $ConfigPath -Raw | ConvertFrom-Json
        Write-ForwarderLog "Configuration loaded successfully" -Level Success
        return $config
    }
    catch {
        Write-ForwarderLog "Failed to load configuration: $($_.Exception.Message)" -Level Error
        throw
    }
}

function Initialize-Folders {
    [CmdletBinding()]
    param()
    
    $folders = @(
        $Script:Config.PickupFolder,
        $Script:Config.ArchiveFolder,
        $Script:Config.ErrorFolder,
        $Script:Config.LogFolder
    )
    
    foreach ($folder in $folders) {
        if (-not (Test-Path $folder)) {
            Write-ForwarderLog "Creating folder: $folder"
            try {
                New-Item -ItemType Directory -Path $folder -Force | Out-Null
                Write-ForwarderLog "Folder created successfully: $folder" -Level Success
            }
            catch {
                Write-ForwarderLog "Failed to create folder $folder : $($_.Exception.Message)" -Level Error
                throw
            }
        }
    }
}
#endregion

#region Sentinel Connection
function Connect-SentinelLogIngestionAPI {
    [CmdletBinding()]
    param()
    
    if ($Script:AlreadyAzSentinelConnected) {
        Write-ForwarderLog "Already connected to Azure for Sentinel ingestion"
        return
    }
    
    Write-ForwarderLog "Connecting to Azure for Sentinel Log Ingestion API..."
    
    try {
        # Disable context autosave
        Disable-AzContextAutosave -Scope Process | Out-Null
        
        if ($Script:Config.SentinelConnection.UseManagedIdentity) {
            Write-ForwarderLog "Using Managed Identity for authentication"
            $AzureContext = (Connect-AzAccount -Identity -ContextName "SentinelIngestion").context
        }
        else {
            if ([string]::IsNullOrEmpty($Script:Config.SentinelConnection.CertificateThumbprint)) {
                Write-ForwarderLog "Using Interactive authentication"
                $AzureContext = (Connect-AzAccount -ContextName "SentinelIngestion").context
            }
            else {
                Write-ForwarderLog "Using Service Principal with Certificate"
                $AzureContext = (Connect-AzAccount `
                    -ContextName "SentinelIngestion" `
                    -CertificateThumbprint $Script:Config.SentinelConnection.CertificateThumbprint `
                    -Tenant $Script:Config.SentinelConnection.TenantID `
                    -ApplicationId $Script:Config.SentinelConnection.ApplicationId).context
            }
        }
        
        $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.Contexts["SentinelIngestion"]
        $Script:SentinelLogIngestionToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate(
            $context.Account, 
            $context.Environment, 
            $context.Tenant.Id.ToString(), 
            $null, 
            [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, 
            $null, 
            "https://monitor.azure.com"
        )
        
        $Script:AlreadyAzSentinelConnected = $true
        Write-ForwarderLog "Successfully connected to Azure" -Level Success
    }
    catch {
        Write-ForwarderLog "Failed to connect to Azure: $($_.Exception.Message)" -Level Error
        throw
    }
}

function Build-LogAnalyticsSignature {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$CustomerId,
        
        [Parameter(Mandatory=$true)]
        [string]$SharedKey,
        
        [Parameter(Mandatory=$true)]
        [string]$Date,
        
        [Parameter(Mandatory=$true)]
        [int]$ContentLength,
        
        [Parameter(Mandatory=$true)]
        [string]$Method,
        
        [Parameter(Mandatory=$true)]
        [string]$ContentType,
        
        [Parameter(Mandatory=$true)]
        [string]$Resource
    )
    
    $xHeaders = "x-ms-date:" + $Date
    $stringToHash = $Method + "`n" + $ContentLength + "`n" + $ContentType + "`n" + $xHeaders + "`n" + $Resource
    
    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes = [Convert]::FromBase64String($SharedKey)
    
    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $CustomerId, $encodedHash
    
    return $authorization
}
#endregion

#region Data Injection
function Send-ToLogAnalytics {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$CustomerId,
        
        [Parameter(Mandatory=$true)]
        [string]$SharedKey,
        
        [Parameter(Mandatory=$true)]
        [byte[]]$Body,
        
        [Parameter(Mandatory=$true)]
        [string]$LogType
    )
    
    $method = "POST"
    $contentType = "application/json"
    $resource = "/api/logs"
    $rfc1123date = [DateTime]::UtcNow.ToString("r")
    $contentLength = $Body.Length
    
    $signature = Build-LogAnalyticsSignature `
        -CustomerId $CustomerId `
        -SharedKey $SharedKey `
        -Date $rfc1123date `
        -ContentLength $contentLength `
        -Method $method `
        -ContentType $contentType `
        -Resource $resource
    
    $uri = "https://" + $CustomerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"
    
    $headers = @{
        "Authorization" = $signature
        "Log-Type" = $LogType
        "x-ms-date" = $rfc1123date
        "time-generated-field" = [DateTime]::UtcNow
    }
    
    Write-ForwarderLog "Sending $([Math]::Round($Body.Length/1KB, 2)) KB to Log Analytics (Table: $LogType)"
    
    try {
        if ($Script:Config.Proxy.UseProxy -and -not [string]::IsNullOrEmpty($Script:Config.Proxy.ProxyUrl)) {
            $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $Body -UseBasicParsing -Proxy $Script:Config.Proxy.ProxyUrl
        }
        else {
            $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $Body -UseBasicParsing
        }
        
        if ($response.StatusCode -eq 200) {
            Write-ForwarderLog "Data successfully uploaded to Log Analytics" -Level Success
            return $true
        }
        else {
            Write-ForwarderLog "Server returned status code: $($response.StatusCode)" -Level Error
            return $false
        }
    }
    catch {
        Write-ForwarderLog "Failed to send data to Log Analytics: $($_.Exception.Message)" -Level Error
        return $false
    }
}

function Send-ToLogIngestionAPI {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Body,
        
        [Parameter(Mandatory=$true)]
        [string]$StreamName
    )
    
    if ($null -eq $Script:SentinelLogIngestionToken) {
        Connect-SentinelLogIngestionAPI
    }

    # if StreamName doesn't begin with 'Custom-', add it
    if (-not $StreamName.StartsWith("Custom-")) {
        $StreamName = "Custom-$StreamName"
    }
    
    $method = "POST"
    $DceUri = $Script:Config.SentinelConnection.DataCollectionEndpointURI
    $DCRImmutableID = $Script:Config.SentinelConnection.DCRImmutableId
    $bearerToken = $Script:SentinelLogIngestionToken.AccessToken
    
    $uri = "$DceUri/dataCollectionRules/$DCRImmutableID/streams/$StreamName`?api-version=2023-01-01"
    
    $headers = @{
        "Authorization" = "Bearer $bearerToken"
        "Content-Type" = "application/json"
    }
    
    Write-ForwarderLog "Sending $([Math]::Round($Body.Length/1KB, 2)) KB to Log Ingestion API (Stream: $StreamName)"
    
    try {
        if ($Script:Config.Proxy.UseProxy -and -not [string]::IsNullOrEmpty($Script:Config.Proxy.ProxyUrl)) {
            $response = Invoke-WebRequest -Uri $uri -Method $method -Headers $headers -Body $Body -UseBasicParsing -Proxy $Script:Config.Proxy.ProxyUrl
        }
        else {
            $response = Invoke-WebRequest -Uri $uri -Method $method -Headers $headers -Body $Body -UseBasicParsing
        }
        
        if ($response.StatusCode -eq 204) {
            Write-ForwarderLog "Data successfully uploaded to Log Ingestion API" -Level Success
            return $true
        }
        else {
            Write-ForwarderLog "Server returned status code: $($response.StatusCode)" -Level Error
            return $false
        }
    }
    catch {
        Write-ForwarderLog "Failed to send data to Log Ingestion API: $($_.Exception.Message)" -Level Error
        return $false
    }
}

function Send-SentinelSegment {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [array]$SegmentData,

        [Parameter(Mandatory=$true)]
        [string]$LogType,

        [Parameter(Mandatory=$true)]
        [double]$MaxSize,

        [Parameter(Mandatory=$false)]
        [string]$SegmentLabel = "segment"
    )

    $segmentJson = $SegmentData | ConvertTo-Json -Compress -Depth 10
    $segmentLength = [System.Text.Encoding]::UTF8.GetBytes($segmentJson).Length

    if ($segmentLength -gt $MaxSize) {
        if ($SegmentData.Count -lt 2) {
            Write-ForwarderLog "$SegmentLabel is larger than max size ($([Math]::Round($segmentLength/1MB, 2)) MB > $([Math]::Round($MaxSize/1MB, 2)) MB) and cannot be split further" -Level Error
            return $false
        }

        Write-ForwarderLog "$SegmentLabel is larger than max size ($([Math]::Round($segmentLength/1MB, 2)) MB). Retrying in 2 parts" -Level Warning

        $mid = [math]::Floor($SegmentData.Count / 2)

        if ($mid -lt 1) {
            Write-ForwarderLog "Unable to split $SegmentLabel into 2 valid parts" -Level Error
            return $false
        }

        $firstHalf = @($SegmentData[0..($mid - 1)])
        $secondHalf = @($SegmentData[$mid..($SegmentData.Count - 1)])

        $firstResult = Send-SentinelSegment -SegmentData $firstHalf -LogType $LogType -MaxSize $MaxSize -SegmentLabel "$SegmentLabel part 1/2"
        $secondResult = Send-SentinelSegment -SegmentData $secondHalf -LogType $LogType -MaxSize $MaxSize -SegmentLabel "$SegmentLabel part 2/2"

        return ($firstResult -and $secondResult)
    }

    Write-ForwarderLog "Sending $SegmentLabel ($([Math]::Round($segmentLength/1MB, 2)) MB)"

    if ($Script:Config.SentinelConnection.UseLogIngestionAPI) {
        return (Send-ToLogIngestionAPI -Body $segmentJson -StreamName $LogType)
    }
    else {
        $segmentBytes = [System.Text.Encoding]::UTF8.GetBytes($segmentJson)
        return (Send-ToLogAnalytics `
            -CustomerId $Script:Config.SentinelConnection.WorkspaceId `
            -SharedKey $Script:Config.SentinelConnection.WorkspaceKey `
            -Body $segmentBytes `
            -LogType $LogType)
    }
}

function Send-DataToSentinel {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [array]$Data,
        
        [Parameter(Mandatory=$true)]
        [string]$LogType
    )
    
    try {
        $jsonData = $Data | ConvertTo-Json -Compress -Depth 10
        $dataLength = [System.Text.Encoding]::UTF8.GetBytes($jsonData).Length
        $maxSize = $Script:Config.SentinelConnection.MaxSegmentSizeMb * 1024 * 1024
        
        # Check if we need to segment the data
        $segmentCount = [math]::Ceiling($dataLength / $maxSize)
        
        if ($segmentCount -le 1) {
            # Single segment
            Write-ForwarderLog "Sending data in 1 segment ($([Math]::Round($dataLength/1MB, 2)) MB)"

            $result = Send-SentinelSegment -SegmentData $Data -LogType $LogType -MaxSize $maxSize -SegmentLabel "segment 1/1"

            return $result
        }
        else {
            # Multiple segments
            Write-ForwarderLog "Data size ($([Math]::Round($dataLength/1MB, 2)) MB) exceeds limit. Splitting into $segmentCount segments"
            
            $itemsPerSegment = [math]::Floor($Data.Count / $segmentCount)
            $currentIndex = 0
            $allSucceeded = $true
            
            for ($i = 0; $i -lt $segmentCount; $i++) {
                $endIndex = [math]::Min($currentIndex + $itemsPerSegment, $Data.Count)
                
                if ($i -eq ($segmentCount - 1)) {
                    $endIndex = $Data.Count
                }
                
                $segment = $Data[$currentIndex..($endIndex - 1)]
                
                Write-ForwarderLog "Sending segment $($i + 1)/$segmentCount (items $currentIndex to $($endIndex - 1))"

                $result = Send-SentinelSegment -SegmentData $segment -LogType $LogType -MaxSize $maxSize -SegmentLabel "segment $($i + 1)/$segmentCount"
                
                if (-not $result) {
                    $allSucceeded = $false
                    Write-ForwarderLog "Failed to send segment $($i + 1)" -Level Error
                }
                
                $currentIndex = $endIndex
            }
            
            return $allSucceeded
        }
    }
    catch {
        Write-ForwarderLog "Error preparing data for Sentinel: $($_.Exception.Message)" -Level Error
        return $false
    }
}
#endregion

#region File Processing
function Get-LogTypeFromFileName {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$FileName
    )
    
    # Extract log type from filename
    # Expected format: LogType-*.json or LogType.json
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($FileName)
    
    # Remove timestamp suffix if present (format: -YYYY-MM-DD-HH-mm-ss)
    $logType = $baseName -replace '-\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-\d{2}$', ''
    
    # Remove GUID suffix if present
    $logType = $logType -replace '-[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$', ''
    
    # Remove page indicators
    $logType = $logType -replace '-Page_\d+.*$', ''
    
    if ([string]::IsNullOrWhiteSpace($logType)) {
        $logType = $Script:Config.SentinelConnection.DefaultLogType
    }
    
    return $logType
}

function Process-PickupFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [System.IO.FileInfo]$File
    )
    
    Write-ForwarderLog "Processing file: $($File.Name)"
    
    try {
        # Read file content
        $content = Get-Content -Path $File.FullName -Raw -Encoding UTF8
        $data = $content | ConvertFrom-Json
        
        # Ensure data is an array
        if ($data -isnot [array]) {
            $data = @($data)
        }
        
        Write-ForwarderLog "File contains $($data.Count) records"
        
        # Extract log type from filename
        $logType = Get-LogTypeFromFileName -FileName $File.Name
        Write-ForwarderLog "Target log type: $logType"
        
        # Send to Sentinel
        $success = Send-DataToSentinel -Data $data -LogType $logType
        
        if ($success) {
            Write-ForwarderLog "Successfully processed file: $($File.Name)" -Level Success
            
            # Archive or delete
            if ($Script:Config.DeleteAfterProcessing) {
                Write-ForwarderLog "Deleting processed file..."
                Remove-Item -Path $File.FullName -Force
            }
            else {
                $archivePath = Join-Path -Path $Script:Config.ArchiveFolder -ChildPath $File.Name
                
                # Handle duplicate names
                if (Test-Path $archivePath) {
                    $timestamp = Get-Date -Format "yyyyMMddHHmmss"
                    $archivePath = Join-Path -Path $Script:Config.ArchiveFolder -ChildPath "$($File.BaseName)_$timestamp$($File.Extension)"
                }
                
                Write-ForwarderLog "Archiving to: $archivePath"
                Move-Item -Path $File.FullName -Destination $archivePath -Force
            }
            
            $Script:ProcessedFiles++
            $Script:TotalBytesProcessed += $File.Length
            
            return $true
        }
        else {
            Write-ForwarderLog "Failed to process file: $($File.Name)" -Level Error
            
            # Move to error folder
            $errorPath = Join-Path -Path $Script:Config.ErrorFolder -ChildPath $File.Name
            
            if (Test-Path $errorPath) {
                $timestamp = Get-Date -Format "yyyyMMddHHmmss"
                $errorPath = Join-Path -Path $Script:Config.ErrorFolder -ChildPath "$($File.BaseName)_$timestamp$($File.Extension)"
            }
            
            Write-ForwarderLog "Moving to error folder: $errorPath" -Level Warning
            Move-Item -Path $File.FullName -Destination $errorPath -Force
            
            $Script:FailedFiles++
            
            return $false
        }
    }
    catch {
        Write-ForwarderLog "Error processing file $($File.Name): $($_.Exception.Message)" -Level Error
        
        # Move to error folder
        try {
            $errorPath = Join-Path -Path $Script:Config.ErrorFolder -ChildPath $File.Name
            
            if (Test-Path $errorPath) {
                $timestamp = Get-Date -Format "yyyyMMddHHmmss"
                $errorPath = Join-Path -Path $Script:Config.ErrorFolder -ChildPath "$($File.BaseName)_error_$timestamp$($File.Extension)"
            }
            
            Move-Item -Path $File.FullName -Destination $errorPath -Force -ErrorAction Stop
            Write-ForwarderLog "Moved failed file to error folder" -Level Warning
        }
        catch {
            Write-ForwarderLog "Could not move file to error folder: $($_.Exception.Message)" -Level Error
        }
        
        $Script:FailedFiles++
        
        return $false
    }
}
#endregion

#region Main Execution
function Start-ForwarderProcessing {
    [CmdletBinding()]
    param()
    
    Write-ForwarderLog "=== Forwarder Pickup Processor v$($Script:Version) ===" -Level Success
    Write-ForwarderLog "Started at: $($Script:StartTime.ToString('yyyy-MM-dd HH:mm:ss'))"
    
    # Load configuration
    $Script:Config = Get-ForwarderConfiguration -ConfigPath $ConfigurationFile
    
    # Override config with command-line parameters
    if ($PickupFolder) { $Script:Config.PickupFolder = $PickupFolder }
    if ($ArchiveFolder) { $Script:Config.ArchiveFolder = $ArchiveFolder }
    if ($ErrorFolder) { $Script:Config.ErrorFolder = $ErrorFolder }
    if ($MaxFilesPerRun -gt 0) { $Script:Config.MaxFilesPerRun = $MaxFilesPerRun }
    if ($DeleteAfterProcessing) { $Script:Config.DeleteAfterProcessing = $true }
    if ($UseProxy) { $Script:Config.Proxy.UseProxy = $true }
    if ($ProxyUrl) { $Script:Config.Proxy.ProxyUrl = $ProxyUrl }
    
    # Initialize logging
    $logFileName = "ForwarderProcessor_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
    $Script:LogFile = Join-Path -Path $Script:Config.LogFolder -ChildPath $logFileName
    
    # Initialize folders
    Initialize-Folders
    
    Write-ForwarderLog "Pickup Folder: $($Script:Config.PickupFolder)"
    Write-ForwarderLog "Archive Folder: $($Script:Config.ArchiveFolder)"
    Write-ForwarderLog "Error Folder: $($Script:Config.ErrorFolder)"
    Write-ForwarderLog "Log File: $($Script:LogFile)"
    
    # Get files to process
    $files = Get-ChildItem -Path $Script:Config.PickupFolder -Filter $Script:Config.FilePattern -File | Sort-Object LastWriteTime
    
    Write-ForwarderLog "Found $($files.Count) file(s) to process"
    
    if ($files.Count -eq 0) {
        Write-ForwarderLog "No files to process. Exiting." -Level Info
        return
    }
    
    # Limit files if specified
    if ($Script:Config.MaxFilesPerRun -gt 0 -and $files.Count -gt $Script:Config.MaxFilesPerRun) {
        Write-ForwarderLog "Limiting to $($Script:Config.MaxFilesPerRun) files per configuration" -Level Warning
        $files = $files | Select-Object -First $Script:Config.MaxFilesPerRun
    }
    
    # Connect to Azure if using Log Ingestion API
    if ($Script:Config.SentinelConnection.UseLogIngestionAPI) {
        Connect-SentinelLogIngestionAPI
    }
    
    # Process each file
    foreach ($file in $files) {
        Process-PickupFile -File $file
    }
    
    # Summary
    $endTime = Get-Date
    $duration = $endTime - $Script:StartTime
    
    Write-ForwarderLog "=== Processing Summary ===" -Level Success
    Write-ForwarderLog "Total files processed: $($Script:ProcessedFiles)"
    Write-ForwarderLog "Failed files: $($Script:FailedFiles)"
    Write-ForwarderLog "Total data processed: $([Math]::Round($Script:TotalBytesProcessed/1MB, 2)) MB"
    Write-ForwarderLog "Duration: $($duration.ToString('hh\:mm\:ss'))"
    Write-ForwarderLog "Completed at: $($endTime.ToString('yyyy-MM-dd HH:mm:ss'))"
    
    if ($Script:FailedFiles -gt 0) {
        Write-ForwarderLog "Some files failed processing. Check error folder: $($Script:Config.ErrorFolder)" -Level Warning
    }
}

# Force TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Start processing
try {
    Start-ForwarderProcessing
}
catch {
    Write-ForwarderLog "Critical error: $($_.Exception.Message)" -Level Error
    Write-ForwarderLog "Stack trace: $($_.ScriptStackTrace)" -Level Error
    exit 1
}
#endregion
