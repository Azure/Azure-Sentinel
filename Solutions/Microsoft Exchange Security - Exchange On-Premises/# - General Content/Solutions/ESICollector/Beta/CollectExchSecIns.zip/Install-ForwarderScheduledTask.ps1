<#
.SYNOPSIS
    Scheduled task installation script for ForwarderPickupProcessor
.DESCRIPTION
    This script creates and configures a Windows scheduled task to automatically
    execute ForwarderPickupProcessor at regular intervals.
.PARAMETER TaskName
    Name of the scheduled task (default: "ESI Forwarder Processor")
.PARAMETER ScriptPath
    Full path to ForwarderPickupProcessor.ps1
.PARAMETER IntervalMinutes
    Execution interval in minutes (default: 15)
.PARAMETER ServiceAccount
    Service account to use (e.g., "DOMAIN\ServiceAccount")
.PARAMETER UseSystemAccount
    Use SYSTEM account (for Managed Identity on Azure VM)
.EXAMPLE
    .\Install-ForwarderScheduledTask.ps1 -IntervalMinutes 10
.EXAMPLE
    .\Install-ForwarderScheduledTask.ps1 -ServiceAccount "CONTOSO\svc-esi" -IntervalMinutes 15
.EXAMPLE
    .\Install-ForwarderScheduledTask.ps1 -UseSystemAccount
.NOTES
    Author: Nicolas Lepagnez (nilepagn@microsoft.com)
    Version: 1.0.0
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$false)]
    [string]$TaskName = "ESI Forwarder Processor",
    
    [Parameter(Mandatory=$false)]
    [string]$ScriptPath = "C:\ESI\Scripts\ForwarderPickupProcessor.ps1",
    
    [Parameter(Mandatory=$false)]
    [int]$IntervalMinutes = 15,
    
    [Parameter(Mandatory=$false)]
    [string]$ServiceAccount,
    
    [Parameter(Mandatory=$false)]
    [switch]$UseSystemAccount,

    [Parameter(Mandatory=$false)]
    [string]$ConfigPath = "C:\ESI\Scripts\Config\ForwarderPickupConfig.json"
)

# Check administrator privileges
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$isAdmin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "This script requires administrator privileges." -ForegroundColor Red
    Write-Host "Please run PowerShell as administrator." -ForegroundColor Yellow
    exit 1
}

Write-Host "=== ESI Forwarder Scheduled Task Installation ===" -ForegroundColor Cyan
Write-Host ""

# Check that script exists
if (-not (Test-Path $ScriptPath)) {
    Write-Host "ERROR: Script does not exist at location: $ScriptPath" -ForegroundColor Red
    Write-Host "Please verify the path or use the -ScriptPath parameter" -ForegroundColor Yellow
    exit 1
}

Write-Host "✓ Script found: $ScriptPath" -ForegroundColor Green

# Check configuration
if (-not (Test-Path $ConfigPath)) {
    Write-Host "WARNING: Configuration file not found: $ConfigPath" -ForegroundColor Yellow
    $createConfig = Read-Host "Do you want to create a default configuration? (Y/N)"
    
    if ($createConfig -eq "Y" -or $createConfig -eq "y") {
        $configDir = Split-Path $ConfigPath
        if (-not (Test-Path $configDir)) {
            New-Item -ItemType Directory -Path $configDir -Force | Out-Null
        }
        
        # Create minimal configuration
        $defaultConfig = @{
            PickupFolder = "C:\ESI\ForwarderPickup"
            ArchiveFolder = "C:\ESI\Archive"
            ErrorFolder = "C:\ESI\Error"
            LogFolder = "C:\ESI\Logs"
            DeleteAfterProcessing = $false
            MaxFilesPerRun = 0
            FilePattern = "*.json"
            SentinelConnection = @{
                UseManagedIdentity = $UseSystemAccount.IsPresent
                UseLogIngestionAPI = $true
                DataCollectionEndpointURI = "https://your-dce.ingest.monitor.azure.com"
                DCRImmutableId = "dcr-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                TenantID = ""
                ApplicationId = ""
                CertificateThumbprint = ""
                DefaultLogType = "ESIExchangeConfig"
                MaxSegmentSizeMb = 0.9
            }
            Proxy = @{
                UseProxy = $false
                ProxyUrl = ""
            }
        }
        
        $defaultConfig | ConvertTo-Json -Depth 10 | Set-Content -Path $ConfigPath -Encoding UTF8
        Write-Host "✓ Configuration created: $ConfigPath" -ForegroundColor Green
        Write-Host "⚠ IMPORTANT: You must edit this configuration before using the forwarder!" -ForegroundColor Yellow
    }
}
else {
    Write-Host "✓ Configuration found: $ConfigPath" -ForegroundColor Green
}

# Remove existing task if it exists
$existingTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existingTask) {
    Write-Host ""
    Write-Host "A task with this name already exists." -ForegroundColor Yellow
    $overwrite = Read-Host "Do you want to replace it? (Y/N)"
    
    if ($overwrite -eq "Y" -or $overwrite -eq "y") {
        Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
        Write-Host "✓ Existing task removed" -ForegroundColor Green
    }
    else {
        Write-Host "Installation cancelled." -ForegroundColor Yellow
        exit 0
    }
}

Write-Host ""
Write-Host "Configuring scheduled task..." -ForegroundColor Cyan

# Create action
$psExePath = (Get-Command powershell.exe).Source
$arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$ScriptPath`" -ConfigurationFile `"$ConfigPath`""

$action = New-ScheduledTaskAction `
    -Execute $psExePath `
    -Argument $arguments

Write-Host "✓ Action created" -ForegroundColor Green

# Create trigger (infinite repetition every X minutes)
$trigger = New-ScheduledTaskTrigger `
    -Once `
    -At (Get-Date).AddMinutes(1) `
    -RepetitionInterval (New-TimeSpan -Minutes $IntervalMinutes) `
    -RepetitionDuration ([TimeSpan]::MaxValue)

Write-Host "✓ Trigger created (interval: $IntervalMinutes minutes)" -ForegroundColor Green

# Create principal (execution account)
if ($UseSystemAccount) {
    $principal = New-ScheduledTaskPrincipal `
        -UserId "SYSTEM" `
        -LogonType ServiceAccount `
        -RunLevel Highest
    Write-Host "✓ Execution account: SYSTEM" -ForegroundColor Green
}
elseif ($ServiceAccount) {
    Write-Host ""
    Write-Host "Authentication required for account: $ServiceAccount" -ForegroundColor Yellow
    $credential = Get-Credential -UserName $ServiceAccount -Message "Enter service account password"
    
    $principal = New-ScheduledTaskPrincipal `
        -UserId $ServiceAccount `
        -LogonType Password `
        -RunLevel Highest
    
    Write-Host "✓ Execution account: $ServiceAccount" -ForegroundColor Green
}
else {
    Write-Host ""
    Write-Host "No account specified. Using current account." -ForegroundColor Yellow
    $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    Write-Host "Account: $currentUser" -ForegroundColor Cyan
    
    $usePassword = Read-Host "Do you want to store the password? (Y/N - N will require interactive login)"
    
    if ($usePassword -eq "Y" -or $usePassword -eq "y") {
        $credential = Get-Credential -UserName $currentUser -Message "Enter your password"
        $principal = New-ScheduledTaskPrincipal `
            -UserId $currentUser `
            -LogonType Password `
            -RunLevel Highest
    }
    else {
        $principal = New-ScheduledTaskPrincipal `
            -UserId $currentUser `
            -LogonType Interactive `
            -RunLevel Highest
        Write-Host "⚠ Task will only run when you are logged in" -ForegroundColor Yellow
    }
}

# Create settings
$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable `
    -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit (New-TimeSpan -Hours 1)

Write-Host "✓ Settings configured" -ForegroundColor Green

# Register task
Write-Host ""
Write-Host "Registering scheduled task..." -ForegroundColor Cyan

try {
    if ($ServiceAccount -or ($usePassword -eq "Y" -or $usePassword -eq "y")) {
        $task = Register-ScheduledTask `
            -TaskName $TaskName `
            -Action $action `
            -Trigger $trigger `
            -Principal $principal `
            -Settings $settings `
            -Description "Processes JSON files from Pickup folder and sends them to Microsoft Sentinel every $IntervalMinutes minutes" `
            -User $credential.UserName `
            -Password $credential.GetNetworkCredential().Password
    }
    else {
        $task = Register-ScheduledTask `
            -TaskName $TaskName `
            -Action $action `
            -Trigger $trigger `
            -Principal $principal `
            -Settings $settings `
            -Description "Processes JSON files from Pickup folder and sends them to Microsoft Sentinel every $IntervalMinutes minutes"
    }
    
    Write-Host ""
    Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host "✓ Scheduled task created successfully!" -ForegroundColor Green
    Write-Host "═══════════════════════════════════════════════════════" -ForegroundColor Green
    Write-Host ""
    Write-Host "Task details:" -ForegroundColor Cyan
    Write-Host "  Name: $TaskName"
    Write-Host "  Interval: Every $IntervalMinutes minutes"
    Write-Host "  Script: $ScriptPath"
    Write-Host "  Configuration: $ConfigPath"
    Write-Host ""
    
    # Show next executions
    $taskInfo = Get-ScheduledTaskInfo -TaskName $TaskName
    Write-Host "Next execution: $($taskInfo.NextRunTime)" -ForegroundColor Yellow
    Write-Host ""
    
    # Offer to start immediately
    $startNow = Read-Host "Do you want to start the task immediately to test? (Y/N)"
    if ($startNow -eq "Y" -or $startNow -eq "y") {
        Write-Host ""
        Write-Host "Starting task..." -ForegroundColor Cyan
        Start-ScheduledTask -TaskName $TaskName
        Start-Sleep -Seconds 2
        
        $taskInfo = Get-ScheduledTaskInfo -TaskName $TaskName
        Write-Host "Status: $($taskInfo.LastTaskResult)" -ForegroundColor Green
        Write-Host ""
        Write-Host "Check logs in: $((Get-Content $ConfigPath | ConvertFrom-Json).LogFolder)" -ForegroundColor Yellow
    }
    
    Write-Host ""
    Write-Host "To manage the task:" -ForegroundColor Cyan
    Write-Host "  - Open Task Scheduler: taskschd.msc"
    Write-Host "  - Or use PowerShell:"
    Write-Host "    Get-ScheduledTask -TaskName '$TaskName'"
    Write-Host "    Start-ScheduledTask -TaskName '$TaskName'"
    Write-Host "    Stop-ScheduledTask -TaskName '$TaskName'"
    Write-Host "    Disable-ScheduledTask -TaskName '$TaskName'"
    Write-Host "    Unregister-ScheduledTask -TaskName '$TaskName'"
    Write-Host ""
}
catch {
    Write-Host ""
    Write-Host "ERROR creating task:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Additional details:" -ForegroundColor Yellow
    Write-Host $_.Exception.GetType().FullName
    exit 1
}
