<#
Disclaimer:
This sample script is not supported under any Microsoft standard support program or service.
The sample script is provided AS IS without warranty of any kind. Microsoft further disclaims
all implied warranties including, without limitation, any implied warranties of merchantability
or of fitness for a particular purpose. The entire risk arising out of the use or performance of
the sample scripts and documentation remains with you. In no event shall Microsoft, its authors,
or anyone else involved in the creation, production, or delivery of the scripts be liable for any
damages whatsoever (including, without limitation, damages for loss of business profits, business
interruption, loss of business information, or other pecuniary loss) arising out of the use of or
inability to use the sample scripts or documentation, even if Microsoft has been advised of the
possibility of such damages
#>
<#
.Synopsis
    This script generates a csv file of the Exchange Configuration for Exchange Security Insight project.
.DESCRIPTION
    This script has to be scheduled to generate a CSV file of the Exchange configuration that will be imported into Sentinel by ALA Agent.
    Multiple Exchange Cmdlets are used to extract information.

.EXAMPLE
.INPUTS
    .\CollectExchSecIns.ps1
        
.OUTPUTS
    Ingestion in Azure Sentinel
.NOTES
    Developed by ksangui@microsoft.com and Nicolas Lepagnez (nilepagn@microsoft.com)

        Version : 0.5 BETA - NOT RELEASED - nilepagn
        - Create Azure Monitor API things to Setup (DCR, Tables, Application, etc)
    
#>

Param(
    [Switch] $LoadFromConfiguration,
    [string] $ConfigurationFile = ".\Config\CollectExchSecConfiguration.json",
    [int] $ClearFilesOlderThan = 30
)

#region Log and file Management
function Write-LogMessage {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]
        $Message,
        [Parameter(Mandatory=$false)]
        [string]
        $Category="General",
        [Parameter(Mandatory=$false)]
        [ValidateSet("Info","Warning","Error","Verbose")]
        [string]
        $Level="Info",
        [switch] $NoOutput
    )
    $line = "$(Get-Date -f 'yyyy/MM/dd HH:mm:ss')`t$Level`t$Category`t$Message"
    Set-Variable -Name UDSLogs  -Value "$UDSLogs`n$line" -Scope Script
    if($NoOutput -or $Global:DeactivateWriteOutput){
        if ($script:FASTVerboseLevel) { Write-Verbose $line }
        else{
            Write-Host $line
        }
    }else{
        Write-Output $line
    }
    switch ($Level) {
        "Verbose" {
            if ($script:FASTVerboseLevel) { Write-Verbose "[VERBOSE] $Category :`t$Message" }
        }
        "Info" {
            Write-Information "[INFO] $Category :`t$Message"
        }
        "Warning" {
            Write-Warning "$Category :`t$Message"
        }
        "Error" {
            Write-Error "$Category :`t$Message"
        }
        Default {}
    }    
}

function Set-ESIContent{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true) ]
        [string]
        $Content,
        [Parameter(Mandatory=$true)]
        [string]
        $Path
    )

    if ($PSVersionTable.PSVersion.Major -ge 7)
    {
        # PowerShell 7 and higher
        $Content | Set-Content -Path $Path -NoNewline -Encoding utf8NoBOM
    }
    else
    {
        # Powershell 5.1
        $Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding $False
        #[System.IO.File]::WriteAllLines($Path, $Content, $Utf8NoBomEncoding) Prefer WriteAllText as it doesn't add newline at the end of the file
        [System.IO.File]::WriteAllText($Path, $Content, $Utf8NoBomEncoding)
    }
}

function Get-UDSLogs
{
    [CmdletBinding()]
    param()

    return $Script:UDSLogs
}

function Invoke-UDSLogProcessor
{
    $LogProcessorOutput = "`n`n**** UDS Log Processor ****"
    if ($script:DeactivateUDSLogs)
    {
        $LogProcessorOutput += "`nLogs deactivated"
    }
    else {
        if ($script:UDSLogControl)
        {
            $LogProcessorOutput += "`nUDS Log Control activated"
            if ($null -eq $Script:UDSLogProcessor -or $Script:UDSLogProcessor.Count -eq 0)
            {
                $LogProcessorOutput += "`nNo processor defined"
            }
            else {
                $LogProcessorOutput += "`n$($Script:UDSLogProcessor.Count) UDS Processor(s) defined"
            }
        }
        else {
            $LogProcessorOutput += "`nUDS Log Control deactivated"

            $OutputProcessor = @{
                LogStorageType = "Output"
            }

            $LogProcessorOutput += "`nAdd Output processor"

            $Script:UDSLogProcessor = @($OutputProcessor)
        }

        foreach($ProcessorEntry in $Script:UDSLogProcessor)
        {
            
            try {
                $LogProcessorOutput += "`nInvoke processor $($ProcessorEntry.LogStorageType)"
                switch($ProcessorEntry.LogStorageType)
                {
                    "Output"
                    {
                        $LogProcessorOutput += "`n**************** LOGS **********************"
                        $LogProcessorOutput += Get-UDSLogs
                        $LogProcessorOutput += "`n**************** END LOGS **********************`n"
                    }
                    "File"
                    {
                        if ($Global:isRunbook)
                        {
                            $LogProcessorOutput += "`nUDS File processor not available in Runbook"
                        }
                        else {
                            if ([System.IO.Path]::IsPathRooted($ProcessorEntry.LogStoragePath))
                            {
                                $UDSLogPath = $ProcessorEntry.LogStoragePath
                            }
                            else
                            {
                                $UDSLogPath = $Script:scriptFolder + "\" + $ProcessorEntry.LogStoragePath
                            }
                            
                            if (-not (Test-Path $UDSLogPath))
                            {
                                $LogProcessorOutput += "`nCreate folder $UDSLogPath"
                                New-Item -ItemType Directory -Path $UDSLogPath
                            }

                            CleanFiles -ScriptLogPath $UDSLogPath -ClearFilesOlderThan $ProcessorEntry.LogStorageRetentionDays

                            # Generate Filename using Prefix, ScriptInstanceID and Date
                            $UDSLogFileName = "$($ProcessorEntry.Prefix)-$($Script:ScriptInstanceID)-$(Get-Date -f 'yyyyMMdd').log"

                            $LogProcessorOutput += "`nWrite logs to $UDSLogPath\$UDSLogFileName"
                            $UDSLogs | Out-File -FilePath "$UDSLogPath\$UDSLogFileName"
                        }
                    }
                    "AzureStorageAccount"
                    {
                        $ExecutionImpossible = $false
                        if (-not (Get-Module -Name Az.Storage -ListAvailable))
                        {
                            $LogProcessorOutput += "`nUDS Azure Storage Account module not available"
                            $ExecutionImpossible = $true
                        }
                        elseif (-not (Get-Command -Name Connect-AzAccount -Module Az.Accounts -ErrorAction SilentlyContinue))
                        {
                            $LogProcessorOutput += "`nUDS Azure Storage Account module not available"
                            $ExecutionImpossible = $true
                        }

                        if (-not $Global:isRunbook)
                        {
                            if ($ProcessorEntry.ConnectionType -like "ManagedIdentity")
                            {
                                $LogProcessorOutput += "`nUDS Azure Storage Account Managed Identity not available"
                                $ExecutionImpossible = $true
                            }
                        }
                        
                        if (-not $ExecutionImpossible)
                        {                            
                            try
                            {
                                switch ($ProcessorEntry.ConnexionType) {
                                    "ManagedIdentity" { 
                                        # BEGIN: Authenticate with Managed Identity
                                        $ResultAccount = Connect-AzAccount -Identity -Tenant $ProcessorEntry.TenantID
                                        # END: Authenticate with Managed Identity
                                    }
                                    "Certificate" { 
                                        # BEGIN: Authenticate with Certificate
                                        $ResultAccount = Connect-AzAccount -CertificateThumbprint $ProcessorEntry.CertificateThumbprint -ApplicationId $ProcessorEntry.ApplicationID -Tenant $ProcessorEntry.TenantId -ServicePrincipal
                                        # END: Authenticate with Certificate
                                    }
                                    Default 
                                    {   
                                        $LogProcessorOutput += "`nNAuthentication type $($ProcessorEntry.ConnexionType) not implemented yet"
                                        Throw "nAuthentication type $($ProcessorEntry.ConnexionType) not implemented yet"
                                    }
                                }

                                if ($null -eq $ResultAccount)
                                {
                                    Throw "Impossible to authenticate to Azure Storage Account"
                                }
                                else {
                                    $LogProcessorOutput += "`nUDS Azure Storage Account processor authenticated"
                                }

                                
                                # BEGIN: Create a new blob client
                                $context = New-AzStorageContext -StorageAccountName $ProcessorEntry.StorageAccountName -UseConnectedAccount
                                # END: Create a new blob client

                                # BEGIN: Create a new container if it doesn't exist
                                $container = Get-AzStorageContainer -Context $context -Name $ProcessorEntry.StorageBlobContainer
                                if ($null -eq $container) {
                                    $container = New-AzStorageContainer -Name $ProcessorEntry.StorageBlobContainer -Context $context
                                }
                                # END: Create a new container if it doesn't exist

                                # BEGIN: Create a new blob and upload the logs
                                if ($null -ne $ProcessorEntry.Prefix)
                                {
                                    $blobName = "$($ProcessorEntry.Prefix)-$($Script:ScriptInstanceID)-$(Get-Date -f 'yyyyMMdd').log"
                                }
                                else
                                {
                                    $blobName = "$($Script:ScriptInstanceID)-$(Get-Date -f 'yyyyMMdd').log"
                                }

                                $Filename = "$($env:TEMP)\$blobName"
                                Set-ESIContent -Path $Filename -Content (Get-UDSLogs)
                                Set-AzStorageBlobContent -File $Filename -Container $container.Name -Blob $blobName -Context $context
                                
                                Remove-Item $Filename -ErrorAction SilentlyContinue
                                
                                $LogProcessorOutput += "`nUDS Logs written to Azure Storage Account: $($ProcessorEntry.StorageAccountName) - Container: $($ProcessorEntry.StorageBlobContainer) - Blob: $blobName"
                            }
                            catch {
                                $LogProcessorOutput += "`nError during UDS Azure Storage Account processor"
                                $LogProcessorOutput += "`n$($_.Exception.Message) - $($_.Exception.ItemName) - $($_.Exception.InvocationInfo.PositionMessage) - $($_.Exception.InvocationInfo.ScriptLineNumber) - $($_.Exception.InvocationInfo.OffsetInLine) - $($_.Exception.InvocationInfo.Line)"
                                Write-Warning "Error during UDS Azure Storage Account processor"
                                Write-Warning "$($_.Exception.Message) - $($_.Exception.ItemName) - $($_.Exception.InvocationInfo.PositionMessage) - $($_.Exception.InvocationInfo.ScriptLineNumber) - $($_.Exception.InvocationInfo.OffsetInLine) - $($_.Exception.InvocationInfo.Line)"
                            }
                        }
                        else {
                            $LogProcessorOutput += "`nUDS Azure Storage Account processor not executed, missing PS Module or bad context"
                        }
                    }
                    Default
                    {
                        $LogProcessorOutput += "`nUnknown processor type"
                    }
                }
            }
            catch {
                $LogProcessorOutput += "`nError during processor $($ProcessorEntry.LogStorageType)"
                $LogProcessorOutput += "`n$($_.Exception.Message)"
                Write-Warning "Error during UDS processor $($ProcessorEntry.LogStorageType)"
                Write-Warning "$($_.Exception.Message)"
            }
            
        }
    }

    $LogProcessorOutput += "`n**** END UDS Log Processor ****"

    return $LogProcessorOutput
}

function CleanFiles
{
    Param(
        $ClearFilesOlderThan,
        $ScriptLogPath,
        $outputpath = $null
    )

    $DirectoryList = @()
    $DirectoryList += $ScriptLogPath
    if ($null -ne $outputpath) { $DirectoryList += (Split-Path $outputpath) }

    Write-LogMessage "`t ..Cleaning Report and log files older than $ClearFilesOlderThan days."
    $MaxDate = (Get-Date).AddDays($ClearFilesOlderThan*-1)

    $OtherOldFiles = @()
    $FileList = @()
    if ($DirectoryList.count -gt 0)
    {
        foreach ($dir in $DirectoryList)
        {
            if (Test-Path $dir)
            {
                $OtherPathObj = Get-Item -Path $dir
                $OtherFiles = $OtherPathObj.GetFiles()
                $OtherOldFiles = $OtherFiles | Where-Object {$_.LastWriteTime -le $MaxDate}
                Write-LogMessage ("`t`t There is "+ $OtherFiles.Count + " existing files in $dir with "+ $OtherOldFiles.Count +" files older than $MaxDate.")
            }
            elseif (Test-Path ($scriptFolder + "\" + $dir))
            {
                $OtherPathObj = Get-Item -Path $dir
                $OtherFiles = $OtherPathObj.GetFiles()
                $OtherOldFiles = $OtherFiles | Where-Object {$_.LastWriteTime -le $MaxDate}
                Write-LogMessage ("`t`t There is "+ $OtherFiles.Count + " existing files in $dir with "+ $OtherOldFiles.Count +" files older than $MaxDate.")
            }
            $FileList += $OtherOldFiles
        }
    }

    $NbRemove = 0
    foreach ($File in $FileList)
    {
        Remove-Item $File.FullName
        $NbRemove += 1
        Write-LogMessage ("`t`t`t File "+ $File.Name + " Removed.")
    }
    
    Write-LogMessage ("`t`t $NbRemove Files Removed for cleaning process.")
}

#endregion Log and file Management

#region Azure Action

function Connect-SetupAzure
{
    Param (
        [switch] $isForSave,
        [switch] $MGGraph
    )
    Write-LogMessage -Message ("Trying Connection to Azure ...")

    $PromptMessage = "Do you want to connect to Azure to get the configuration ?"
    if (-not $isForSave) 
    {
        $PromptMessage += "`nIf you choose 'No', the configuration will be read from the configuration file but not verified."
        $PromptMessage += "`nIf you choose 'No', but ask for Azure object creation during script, you will be prompted again."
    }
    else {
        $PromptMessage += "`nIf you choose 'No', the configuration have to create Azure objects before saving the configuration."
    }

    $PromptResult = $null
    while ($PromptResult -ne "Yes" -and $PromptResult -ne "No")
    {
        $PromptResult = Read-Host -Prompt $PromptMessage
        if ($PromptResult -ne "Yes" -and $PromptResult -ne "No")
        {
            Write-LogMessage -Message "Please choose 'Yes' or 'No'"
        }
    }

    if ($PromptResult -eq "No")
    {
        Write-LogMessage -Message "Azure Connection refused"
        $AzureContext = $null

        if ($isForSave)
        {
            Write-LogMessage -Message "Azure Connection refused for saving configuration"
            Write-LogMessage -Message "Please connect to Azure to create the Azure objects"
            Write-LogMessage -Message "The configuration will be saved after the Azure objects creation"
            $Script:AzConnectionForSaveRefused = $true
        }
        else {
            Write-LogMessage -Message "Azure Connection refused for reading configuration"
            Write-LogMessage -Message "The configuration will be read from the configuration file but not verified"
            $Script:AzConnectionForReadRefused = $true
        }
        return
    }

    # Ask for connecting to Azure or not for configuration reading
    if (-not $Global:AlreadyAzConnected)
    {
        Write-LogMessage -Message "Connect to Azure RM"
        Write-LogMessage -Message "Az Connect with Interactive Logon"
        $Script:MESAzureContext = (Connect-AzAccount -ContextName "MESSetup").context

        $Global:AlreadyAzConnected = $true
    }
    else {$Script:MESAzureContext = Get-AzContext -Name "MESSetup"}

    Select-AzContext -Name "MESSetup"
    Write-LogMessage -Message "Azure Connection established"

    if ($MGGraph -and -not $global:MESSetupMGGraphConnected)
    {
        $context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.Contexts["MESSetup"]

        $ModuleGraphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com")

        Connect-MgGraph -AccessToken $ModuleGraphToken.AccessToken
        $global:MESSetupMGGraphConnected = $true
    }
}

function Create-EntraIDLogMonitorApplication
{
    Param(
        [string] $ApplicationName,
        [string] $CertificatePath
    )

    Connect-SetupAzure -IsForSave -MGGraph

    $Result = @{
        "ApplicationId" = $null
        "ObjectId" = $null
    }

    Write-LogMessage -Message ""
    Write-LogMessage -Message "Validating Azure App [ $($ApplicationName) ]"
    $AppCheck = Get-MgApplication -Filter "DisplayName eq '$ApplicationName'" -ErrorAction Stop
    If ($null -eq $AppCheck)
    {
        Write-LogMessage -Message  ""
        Write-LogMessage -Message  "Creating Azure App [ $($ApplicationName) ]"
        $AzureApp = New-MgApplication -DisplayName $ApplicationName
    }

    Write-LogMessage -Message  ""
    Write-LogMessage -Message  "Validating Azure Service Principal on App [ $($ApplicationName) ]"
    $AppInfo  = Get-MgApplication -Filter "DisplayName eq '$ApplicationName'"

    $Result['ApplicationId']    = $AppInfo.AppId
    $Result['ObjectId'] = $AppInfo.Id

    $ServicePrincipalCheck = Get-MgServicePrincipal -Filter "AppId eq '$($Result['ApplicationId']))'"
    If ($null -eq $ServicePrincipalCheck)
    {
        Write-LogMessage -Message  ""
        Write-LogMessage -Message  "Creating Azure Service Principal on App [ $($ApplicationName) ]"
        $ServicePrincipal = New-MgServicePrincipal -AppId $Result['ApplicationId']
    }

    $certContent = [System.IO.File]::ReadAllBytes($CertificatePath)
    $base64Cert = [System.Convert]::ToBase64String($certContent)
    $keyCredential = @{
        Type = "AsymmetricX509Cert"
        Usage = "Verify"
        Key = $base64Cert
        DisplayName = $ApplicationName
    }
    Update-MgApplication -ApplicationId $appId -KeyCredentials @($keyCredential)
}

function Create-DCRForInjestion
{
    Param(
        [string] $DCRName,
        [string] $ResourceGroup,
        [string] $Region,
        [string] $EndpointUri,
        [string] $ImmutableId
    )

    Connect-SetupAzure -IsForSave -MGGraph

    $Result = @{
        "DCRId" = $null
        "ImmutableId" = $null
    }

    Write-LogMessage -Message ""
    Write-LogMessage -Message "Validating DCR [ $($DCRName) ]"
    $DCRCheck = Get-AzDataCollectionRule -Name $DCRName -ResourceGroupName $ResourceGroup -ErrorAction Stop
    If ($null -eq $DCRCheck)
    {
        Write-LogMessage -Message  ""
        Write-LogMessage -Message  "Creating DCR [ $($DCRName) ]"
        $DCR = New-AzDataCollectionRule -Name $DCRName -ResourceGroupName $ResourceGroup -Region $Region -ImmutableId $ImmutableId -EndpointUri $EndpointUri
    }

    $Result['DCRId'] = $DCR.Id
    $Result['ImmutableId'] = $DCR.ImmutableId
}

#endregion Azure Action

#region Prompt Configuration

function New-SetupQuestion
{
    Param(
        [string] $Code,
        [int] $Index,
        [string] $Question,
        [string] $Description,
        [string[]] $PossibleValues,
        [string] $Value = "",
        [string] $Condition = "",
        [string] $regex = "",
        [string] $ValueType = "String",
        [string] $ConfigurationCode = $null,
        [switch] $Hidden,
        [switch] $ReadOnly,
        [string] $ReadOnlyReason = "By Design",
        [switch] $LoadedFromConfiguration = $false,
        [string] $LoadHookFunction = $null,
        [string] $SaveHookFunction = $null,
        [string] $ValidationHookFunction = $null
    )


    $QuestionStructure = @{
        "Code" = $Code
        "Index" = $Index
        "Question" = $Question
        "Description" = $Description
        "PossibleValues" = $PossibleValues
        "Value" = $Value
        "Condition" = $Condition
        "regex" = $regex
        "ValueType" = $ValueType
        "ConfigurationCode" = $ConfigurationCode
        "Hidden" = $Hidden
        "ReadOnly" = $ReadOnly
        "ReadOnlyReason" = $ReadOnlyReason
        "LoadedFromConfiguration" = $LoadedFromConfiguration
        "ToSave" = $false
        "LoadHookFunction" = $LoadHookFunction
        "SaveHookFunction" = $SaveHookFunction
        "ValidationHookFunction" = $ValidationHookFunction
    }

    $TheObject = New-Object PSObject -Property $QuestionStructure
    return $TheObject
}

function New-SetupSection
{
    Param(
        [string] $Title,
        [int] $Index,
        [string] $Description,
        [string] $Condition,
        [string] $Code

    )

    $SectionStructure = @{
        "Title" = $Title
        "Index" = $Index
        "Description" = $Description
        "Condition" = $Condition
        "Collection" = @()
        "Code" = $Code
        "Section" = @()
    }

    $TheObject = New-Object PSObject -Property $SectionStructure
    return $TheObject
}

function New-SetupInformationStructure
{
    $SetupConfiguration = @()

    #region Basic Information

    $Basic = New-SetupSection -Code "Basic" -Title "Basic Information" -Index 1 `
        -Description "This section is used to setup the basic information for the configuration."
    
    $Basic.Collection += New-SetupQuestion -Code "SetupEnvironment" -Index 1 -ConfigurationCode "Global.ESIProcessingType" `
        -Question "What is the target of the configuration ?"  `
        -Description "This configuration is used to setup the Collector Script for Exchange Security Insight. The Script could be used to collect data from Exchange Servers (On-Premises) or Exchange Online Environment (Online)."  `
        -PossibleValues @("On-Premises", "Online")

    $Basic.Collection += New-SetupQuestion -Code "EnvironmentExecution" -Index 2 `
        -Question "What is the environment where the script will be executed ?"  `
        -Description "For Exchange Online Collection, the Script could be executed in an Azure Automation or from a Server."  `
        -PossibleValues @("Azure Automation", "Server") `
        -Value "Azure Automation"

    $Basic.Collection += New-SetupQuestion -Code "EnvironmentIdentification" -Index 3 -ConfigurationCode "Global.EnvironmentIdentification" `
        -Question "Specific name to identify the environment on Microsoft Sentinel Workbooks and Analytics Rules."  `
        -Description "You can leave it by default and the forest name will be used if you are On-Premises." `
        -Value "#ForestName#" -ValidationHookFunction "Set-EnvironmentIdentification"

    $Basic.Collection += New-SetupQuestion -Code "InstanceType" -Index 4 `
        -Question "Do you want to process default analysis or the IIS IoC analysis ?"  `
        -Description "The default analysis is used to collect data from Exchange Servers. The IIS IoC analysis is used to collect data from IIS Logs."  `
        -PossibleValues @("Def", "IoC") `
        -Value "Def"

    $Basic.Collection += New-SetupQuestion -Code "MonitorAPICollection" -Index 5 `
        -Question "What method has to used as API to ingest data into Azure Monitor ?"  `
        -Description "By Default the script will use the Azure Monitor API to ingest data into Azure Monitor. The other method is to use the oldest Log Analytics API that will be deprecated in 2025. We recommand to used the Azure Monitor API."  `
        -PossibleValues @("AzureMonitorAPI", "LogAnaltyicsAPI") `
        -Value "AzureMonitorAPI"

    $SetupConfiguration += $Basic

    #endregion Basic Information

    #region Log Analytics API Information

    $LogAnalyticsAPIInformation = New-SetupSection -Code "LogAnalyticsAPIInformation" -Title "Log Analytics API Information" -Index 2 `
        -Description "This section is used to setup the Log Analytics API Information." `
        -Condition "Root[Basic].Collection[MonitorAPICollection].Value -eq 'LogAnaltyicsAPI'"

    $LogAnalyticsAPIInformation.Collection += New-SetupQuestion -Code "LogMonitorUsingAnalytics" -Index 1 -ConfigurationCode "LogCollection.SentinelLogIngestionAPIActivated" -Hidden `
        -Question "Is Monitor API used ?" -Value "false"

    $LogAnalyticsAPIInformation.Collection += New-SetupQuestion -Code "WorkspaceId" -Index 1 -ConfigurationCode "LogCollection.WorkspaceId" `
        -Question "What is the Log Analytics Workspace Id used ?"  `
        -Description "The Log Analytics Workspace Id is used to ingest data into Log Analytics."

    $LogAnalyticsAPIInformation.Collection += New-SetupQuestion -Code "WorkspaceKey" -Index 2 -ConfigurationCode "LogCollection.WorkspaceKey" `
        -Question "What is the Log Analytics Workspace Key used ?"  `
        -Description "The Log Analytics Workspace Key is used to ingest data into Log Analytics."

    $SetupConfiguration += $LogAnalyticsAPIInformation

    #endregion Log Analytics API Information

    #region Azure Monitor API Information

    $AzureMonitorAPIInformation = New-SetupSection -Code "AzureMonitorAPIInformation" -Title "Azure Monitor API Information" -Index 3 `
        -Description "This section is used to setup the Azure Monitor API Information." `
        -Condition "Root[Basic].Collection[MonitorAPICollection].Value -eq 'AzureMonitorAPI'"

    $LogAnalyticsAPIInformation.Collection += New-SetupQuestion -Code "LogMonitorUsingAnalytics" -Index 1 -ConfigurationCode "LogCollection.SentinelLogIngestionAPIActivated" -Hidden `
        -Question "Is Monitor API used ?" -Value "true"

    $AzureMonitorAPIInformation.Collection += New-SetupQuestion -Code "TenantId" -Index 1 -ConfigurationCode "LogCollection.TargetLogTenantID" `
        -Question "What is the Tenant Id used to ingest data into Azure Monitor ?"  `
        -Description "The Tenant Id is used to authenticate the script to ingest data into Azure Monitor."

    #region Entra ID Application Information
        $EntraIDApplicationInformation = New-SetupSection -Code "EntraIDApplicationInformation" -Title "Entra ID Application for Azure Monitor API Information" -Index 1 `
            -Description "This section is used to setup the Entra ID Application part of Azure Monitor API Information."

        $EntraIDApplicationInformation.Collection += New-SetupQuestion -Code "EntraIDApplicationCreation" -Index 1 `
            -Question "Do you want to create the Entra ID Application for Ingestion ?"  `
            -Description "If you don't have an Entra ID Application, you can create one to ingest data into Azure Monitor with this script if you have the good permissions."  `
            -PossibleValues @("Yes", "No") `
            -Value "Yes"

        $EntraIDApplicationInformation.Collection += New-SetupQuestion -Code "ApplicationName" -Index 2 `
            -Question "What is the Application Name to create for ingesting data into Azure Monitor ?"  `
            -Description "The Application Name is visible in the Application blade on Entra ID."  `
            -Condition "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[EntraIDApplicationCreation].Value -eq 'Yes'"

        $EntraIDApplicationInformation.Collection += New-SetupQuestion -Code "ApplicationId" -Index 3 -ConfigurationCode "LogCollection.TargetLogAppID" `
            -Question "What is the Application Id used to ingest data into Azure Monitor ?"  `
            -Description "The Application Id is used to authenticate the script to ingest data into Azure Monitor."  `
            -Condition "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[EntraIDApplicationCreation].Value -eq 'No'"

        $EntraIDApplicationInformation.Collection += New-SetupQuestion -Code "ApplicationCertificate" -Index 4 `
            -Question "What is the Application Certificate Thumbprint used to ingest data into Azure Monitor ?"  `
            -Description "We choose force authentication with Certificate instead of Key for better security."  `
            -Condition "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[EntraIDApplicationCreation].Value -eq 'No'" `
            -ValidationHookFunction "Set-ApplicationCertificate"

        $EntraIDApplicationInformation.Collection += New-SetupQuestion -Code "ApplicationCertificateNew" -Index 5 `
            -Question "What is the Application Certificate Thumbprint used to ingest data into Azure Monitor ?"  `
            -Description "We choose force authentication with Certificate instead of Key for better security. You have to fill manually the certificate into the application after creation"  `
            -Condition "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[EntraIDApplicationCreation].Value -eq 'Yes'" `
            -ValidationHookFunction "Set-ApplicationCertificate"

        $EntraIDApplicationInformation.Collection += New-SetupQuestion -Code "ApplicationCertificateForConfiguration" -Index 5 -ConfigurationCode "LogCollection.TargetLogAppSecretReference" -Hidden `
            -Question "What is the Application Certificate Thumbprint used to ingest data into Azure Monitor ?"  `
            -Value "UNCONFIGUREDENTRY"

        $AzureMonitorAPIInformation.Section += $EntraIDApplicationInformation
    #endregion Entra ID Application Information

    #region DCR Information
        $DCRInformation = New-SetupSection -Code "DCRInformation" -Title "Data Collection Rule and Table for Azure Monitor API Information" -Index 2 `
            -Description "This section is used to setup the DCR and Table part of Azure Monitor API Information."

        $DCRInformation.Collection += New-SetupQuestion -Code "DCRCreation" -Index 1 `
            -Question "Do you want to create the DCR for Ingestion ?"  `
            -Description "If you already have the DCR and table for the Collector, you can choose 'No'"  `
            -PossibleValues @("Yes", "No") `
            -Value "Yes"

        $DCRInformation.Collection += New-SetupQuestion -Code "DCRName" -Index 2 `
            -Question "What is the DCR Name to create for ingesting data into Azure Monitor ?"  `
            -Description "The DCR Name is visible in the Azure Portal."  `
            -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'Yes'"

        $DCRInformation.Collection += New-SetupQuestion -Code "DCRResourceGroup" -Index 3 `
            -Question "What is the resource Group where we have to create the DCR ?"  `
            -Description "The Resource Group has to already exists."  `
            -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'Yes'"

        $DCRInformation.Collection += New-SetupQuestion -Code "DCRRegion" -Index 4 `
            -Question "What is the region where we have to create the DCR ?"  `
            -Description "The region has to be the same as the Log Analytics Workspace where data will be ingested."  `
            -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'Yes'"

        $DCRInformation.Collection += New-SetupQuestion -Code "DCRPermission" -Index 5 `
            -Question "Do you want to Assign Entra ID Application permission on the DCR ?"  `
            -Description "If you choose 'No', you need to assign manually the permission 'Monitoring Metrics Publisher' to the Entra ID Application on the DCR."  `
            -PossibleValues @("Yes", "No") `
            -Value "Yes"

        $DCRInformation.Collection += New-SetupQuestion -Code "DCRNameForPermission" -Index 6 `
            -Question "What is the name of the DCR to apply 'Metric Publisher' permission ?"  `
            -Description "We will apply the permission on the DCR using Az Powershell modules."  `
            -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'No' -and Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRPermission].Value -eq 'Yes'"

        $DCRInformation.Collection += New-SetupQuestion -Code "endpoint_uri" -Index 7 `
            -Question "What is the DCR endpoint to used for ingesting data into Azure Monitor ?"  `
            -Description "The endpoint used by the Collector to ingest data after collection."  `
            -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'No'"

        $DCRInformation.Collection += New-SetupQuestion -Code "dcrImmutableId" -Index 8 `
            -Question "What is the DCR ImmutableID to use ?"  `
            -Description "The DCR Immutable ID can be found in the Overview page of the DCR in the Azure Portal."  `
            -Condition "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value -eq 'No'"
        
        $EntraIDApplicationInformation.Collection += New-SetupQuestion -Code "DCRImmutableIDForConfiguration" -Index 9 -ConfigurationCode "LogCollection.DCRImmutableId" -Hidden `
            -Question "What is the DCR ImmutableID to use ?"  `
            -Value "UNCONFIGUREDENTRY"

        $EntraIDApplicationInformation.Collection += New-SetupQuestion -Code "ApplicationCertificateForConfiguration" -Index 10 -ConfigurationCode "LogCollection.DataCollectionEndpointURI" -Hidden `
            -Question "What is the DCR endpoint to used for ingesting data into Azure Monitor ?"  `
            -Value "UNCONFIGUREDENTRY"

        $AzureMonitorAPIInformation.Section += $DCRInformation
    #endregion DCR Information

    $SetupConfiguration += $AzureMonitorAPIInformation

    #endregion Azure Monitor API Information

    #region Exchange On-Premises Information
    $ExchangeOnPremisesInformation = New-SetupSection -Code "ExchangeOnPremisesInformation" -Title "Exchange On-Premises Information" -Index 4 `
        -Description "This section is used to setup the Exchange On-Premises Information." `
        -Condition "Root[Basic].Collection[SetupEnvironment].Value -eq 'On-Premises'"

    $ExchangeOnPremisesInformation.Collection += New-SetupQuestion -Code "ExchangeServerBinPath" -Index 1 -ConfigurationCode "Advanced.ExchangeServerBinPath" `
        -Question "What is the Exchange BIN Path ?"  `
        -Description "The Exchange BIN Path is used to collect data from Exchange Servers."  `
        -Value "c:\\Program Files\\Microsoft\\Exchange Server\\V15\\bin"

    $ExchangeOnPremisesInformation.Collection += New-SetupQuestion -Code "ExchangeVersion" -Index 2 `
        -Question "What is the Exchange Version ?"  `
        -Description "The Exchange Version is used to select the good Cmdlets to collect data from Exchange Servers."  `
        -Value "2016"

    $SetupConfiguration += $ExchangeOnPremisesInformation

    #endregion Exchange On-Premises Information

    #region Instance Information
    $InstanceInformation = New-SetupSection -Code "InstanceInformation" -Title "Instance Information" -Index 5 `
        -Description "Multiple Instance of the script could be created to collect data from different source." `
        -Condition "Root[Basic].Collection[EnvironmentExecution].Value -eq 'Server'"

    $InstanceInformation.Collection += New-SetupQuestion -Code "InstanceType" -Index 1 `
        -Question "What is the Instance Type ?"  `
        -Description "The Instance Type is used to define the type of the instance. `nDefault: Collect Exchange Server Information `nIoC: Collect IIS Logs."  `
        -PossibleValues @("Default", "IIS IoC") `
        -Value "Default"

    $SetupConfiguration += $InstanceInformation

    #endregion Instance Information

    #region Server Execution
    $ServerExecution = New-SetupSection -Code "ServerExecution" -Title "Server Execution" -Index 6 `
        -Description "This section is used to setup the Schedule Task on a Server execution." `
        -Condition "Root[Basic].Collection[EnvironmentExecution].Value -eq 'Server'"

    $ServerExecution.Collection += New-SetupQuestion -Code "ScheduleTask" -Index 1 `
        -Question "Do you want to create a Scheduled Task ?"  `
        -Description "The Scheduled Task is used to execute the script on a regular basis."  `
        -PossibleValues @("Yes", "No") `
        -Value "Yes"

    $ServerExecution.Collection += New-SetupQuestion -Code "ScheduleTaskName" -Index 2 `
        -Condition "Root[ServerExecution].Collection[ScheduleTask].Value -eq 'Yes'" `
        -Question "What is the Scheduled Task Name ?"  `
        -Description "The Scheduled Task Name is used to identify the Scheduled Task."  `
        -Value "ESI - Exchange Security Configuration Collector"

    $ServerExecution.Collection += New-SetupQuestion -Code "ScheduleTaskStartTime" -Index 3 `
        -Condition "Root[ServerExecution].Collection[ScheduleTask].Value -eq 'Yes'" `
        -Question "What is the Scheduled Task Start Time ?"  `
        -Description "The Scheduled Task is launched once a day. Start Time is used to define the start time of the Scheduled Task. (format : hh:mmAM or hh:mmPM)"  `
        -regex "^[0-9]{1,2}:[0-9]{1,2}(AM|PM)$" `
        -Value "00:00"

    $ServerExecution.Collection += New-SetupQuestion -Code "ScheduleTaskUser" -Index 4 `
        -Condition "Root[ServerExecution].Collection[ScheduleTask].Value -eq 'Yes'" `
        -Question "What is the user executing the Scheduled Task ?"  `
        -Description "The user account has to have the right to execute the script and collect data from Exchange Servers. Use a Service Account in an UPN fomat."  `
        -regex "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$" `
        -Value ""

    $ServerExecution.Collection += New-SetupQuestion -Code "ScheduleTaskPassword" -Index 5 `
        -Condition "Root[ServerExecution].Collection[ScheduleTask].Value -eq 'Yes'" `
        -Question "What is Service Account Password ?"  `
        -Description "The password of the Service Account used to execute the Scheduled Task."  `
        -ValueType "SecureString" `
        -Value ""

    $SetupConfiguration += $ServerExecution

    #endregion Server Execution

    return $SetupConfiguration
}

function Build-Indexes
{
    Param(
        $SetupInformationStructure
    )

    $Script:CodeIndex = @{}
    $Script:ConfigCodeToCodeMatrix = @{}

    # On all collections and Section, add the Index in CodeIndex

    $SetupInformationStructure | ForEach-Object {
        $Script:CodeIndex[$_.Code.ToLower()] = [Int]$_.Index
        $_.Collection | ForEach-Object {
            $Script:CodeIndex[$_.Code.ToLower()] = [Int]$_.Index
        }
        $_.Section | ForEach-Object {
            $Script:CodeIndex[$_.Code.ToLower()] = [Int]$_.Index

            $_.Collection | ForEach-Object {
                $Script:CodeIndex[$_.Code.ToLower()] = [Int]$_.Index
            }
        }
    }

    $SetupInformationStructure | ForEach-Object {
        $SectionName = "Root[$($_.Code.ToLower())]"
        $_.Collection | ForEach-Object {
            $QuestionName = "$SectionName.Collection[$($_.Code.ToLower())]"
            $Script:ConfigCodeToCodeMatrix[$_.ConfigurationCode.ToLower()] = $QuestionName
        }
        $_.Section | ForEach-Object {
            $SubSectionName = "$SectionName.Section[$($_.Code.ToLower())]"
            $_.Collection | ForEach-Object {
                $QuestionName = "$SubSectionName.Collection[$($_.Code.ToLower())]"
                $Script:ConfigCodeToCodeMatrix[$_.ConfigurationCode.ToLower()] = $QuestionName
            }
        }
    }
}

function Resolve-ConfigurationPath
{
    Param(
        $Information,
        [switch] $IsConfigurationCode
    )

    if ($IsConfigurationCode){
        Write-LogMessage "Configuration Code to resolve: $Information" -NoOutput -Level Verbose
        $Information = $Script:ConfigCodeToCodeMatrix[$Information.ToLower()]
    }

    Write-LogMessage "Path to resolve: $Information" -NoOutput -Level Verbose

    $allmatches = $Information | Select-String -Pattern "\[(?<val>[a-zA-Z0-9]+)\]" -AllMatches
        foreach ($match in $allmatches.Matches)
        {
            $Information = $Information -replace $match.Groups["val"].Value, ($Script:CodeIndex[$match.Groups["val"].Value]-1)
        }

        $Information = $Information -replace "Root", '$Configuration'

        Write-LogMessage "Condition Transformed: $Condition" -NoOutput -Level Verbose

    return $Information
}

function Invoke-ConditionTest
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]
        $Condition,
        [Parameter(Mandatory=$false)]
        $Configuration
    )

    Write-Host "Condition: $Condition"

    if ($null -eq $Condition -or $Condition -eq "")
    {
        return $true
    }
    else 
    {
        $Condition = Resolve-ConfigurationPath -Information $Condition
        Write-Host "Condition Transformed: $Condition"

        return (Invoke-Expression $Condition)
    }
}

function Prompt-SetupInformation
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        $SetupInformationStructure
    )

    $SetupInformationStructure | Sort-Object -Property Index | ForEach-Object {
        $Section = $_
        if ($null -eq $Section.Condition -or $Section.Condition -eq "" -or (Invoke-ConditionTest -Condition $Section.Condition -Configuration $SetupInformationStructure))
        {
            Write-Host ""
            Write-Host "Section: $($Section.Title)"
            Write-Host "Description: $($Section.Description)"
            Write-Host ""

            $Section.Collection | Sort-Object -Property Index | ForEach-Object {
                $Question = $_
                if ($null -eq $Question.Condition -or $Question.Condition -eq "" -or (Invoke-ConditionTest -Condition $Question.Condition -Configuration $SetupInformationStructure))
                {
                    if ([String]::IsNullOrEmpty($Question.PossibleValues) -or ($Question.PossibleValues -split ",").Count -eq 0)
                    {
                        $QuestionValue = Prompt-SetupQuestion -Question $Question.Question -DefaultValue $Question.Value -RegexResult $Question.regex
                    }
                    else {
                        $PossibleValues = $Question.PossibleValues -split ","
                        $QuestionValue = Prompt-SetupQuestion -Question $Question.Question -PossibleValues $PossibleValues -DefaultValue $Question.Value -RegexResult $Question.regex
                    }

                    $Question.Value = $QuestionValue
                    $Question.ToSave = $true
                }
            }

            $Section.Section | Sort-Object -Property Index | ForEach-Object {
                $SubSection = $_
                if ($null -eq $SubSection.Condition -or $SubSection.Condition -eq "" -or (Invoke-ConditionTest -Condition $SubSection.Condition -Configuration $SetupInformationStructure))
                {
                    Write-Host ""
                    Write-Host "SubSection: $($SubSection.Title)"
                    Write-Host "Description: $($SubSection.Description)"
                    Write-Host ""

                    $SubSection.Collection | Sort-Object -Property Index | ForEach-Object {
                        $Question = $_
                        if ($null -eq $Question.Condition -or $Question.Condition -eq "" -or (Invoke-ConditionTest -Condition $Question.Condition -Configuration $SetupInformationStructure))
                        {
                            if ([String]::IsNullOrEmpty($Question.PossibleValues) -or ($Question.PossibleValues -split ",").Count -eq 0)
                            {
                                $QuestionValue = Prompt-SetupQuestion -Question $Question.Question -DefaultValue $Question.Value -RegexResult $Question.regex
                            }
                            else {
                                $PossibleValues = $Question.PossibleValues -split ","
                                $QuestionValue = Prompt-SetupQuestion -Question $Question.Question -PossibleValues $PossibleValues -DefaultValue $Question.Value -RegexResult $Question.regex
                            }

                            $Question.Value = $QuestionValue
                            $Question.ToSave = $true
                        }
                    }
                }
            }
        }
    }

    $Script:Configured = $true

    return $SetupInformationStructure
}

Function Display-SetupInformation
{
    Param(
        $SetupInformationStructure
    )

    $SetupInformationStructure | Sort-Object -Property Index | ForEach-Object {
        $Section = $_
        if ($null -eq $Section.Condition -or $Section.Condition -eq "" -or (Invoke-ConditionTest -Condition $Section.Condition -Configuration $SetupInformationStructure))
        {
            Write-Host ""
            Write-Host "Section: $($Section.Title)"
            Write-Host "Description: $($Section.Description)"
            Write-Host ""

            $Section.Collection | Sort-Object -Property Index | ForEach-Object {
                $Question = $_
                if (-not $Question.Hidden -and ($null -eq $Question.Condition -or $Question.Condition -eq "" -or (Invoke-ConditionTest -Condition $Question.Condition -Configuration $SetupInformationStructure)))
                {
                    Display-SetupQuestion -Question $Question.Question -PossibleValues $Question.PossibleValues -RegexResult $Question.regex -Value $Question.Value
                }
            }

            $Section.Section | Sort-Object -Property Index | ForEach-Object {
                $SubSection = $_
                if ($null -eq $SubSection.Condition -or $SubSection.Condition -eq "" -or (Invoke-ConditionTest -Condition $SubSection.Condition -Configuration $SetupInformationStructure))
                {
                    Write-Host ""
                    Write-Host "SubSection: $($SubSection.Title)"
                    Write-Host "Description: $($SubSection.Description)"
                    Write-Host ""

                    $SubSection.Collection | Sort-Object -Property Index | ForEach-Object {
                        $Question = $_
                        if (-not $Question.Hidden -and ($null -eq $Question.Condition -or $Question.Condition -eq "" -or (Invoke-ConditionTest -Condition $Question.Condition -Configuration $SetupInformationStructure)))
                        {
                            Display-SetupQuestion -Question $Question.Question -PossibleValues $Question.PossibleValues -RegexResult $Question.regex -Value $Question.Value
                        }
                    }
                }
            }
        }
    }
}

function Display-SetupQuestion
{
    Param(
        $Question,
        $PossibleValues = @(),
        $RegexResult = "",
        $Value = ""
    )

    $Prompt = $Question
        if ($PossibleValues.Count -ne 0)
        {
            $Prompt += " [ $($PossibleValues -join ", ") ]"
        }

        if ([String]::IsNullOrEmpty($DefaultValue) -eq $false)
        {
            $Prompt += " (Default: $DefaultValue)"
        }

        if ([String]::IsNullOrEmpty($RegexResult) -eq $false)
        {
            $Prompt += " (Format: $RegexResult)"
        }

    Write-Host "Question: $prompt `t / Value: $Value"
    #Write-Host "Value: $Value"
    #Write-Host ""
}

function Prompt-SetupQuestion
{
    Param(
        $Question,
        $PossibleValues = @(),
        $RegexResult = "",
        $DefaultValue = ""
    )

    $QuestionValue = $null
    while ($null -eq $QuestionValue)
    {
        $Prompt = $Question
        if ($PossibleValues.Count -ne 0)
        {
            $Prompt += " [ $($PossibleValues -join ", ") ]"
        }

        if ([String]::IsNullOrEmpty($DefaultValue) -eq $false)
        {
            $Prompt += " (Default: $DefaultValue)"
        }

        if ([String]::IsNullOrEmpty($RegexResult) -eq $false)
        {
            $Prompt += " (Format: $RegexResult)"
        }

        Write-Host "Description: $($Question.Description)"
        if ($Question.ReadOnly)
        {
            Write-Host "$Prompt - Value: $($Question.Value) - The value is read-only. - Reason : $($Question.ReadOnlyReason)"
            return $Question.Value
        }
        else {
            if ($ValueType -eq "SecureString")
            {
                $QuestionValue = Read-Host -Prompt "$Prompt" -AsSecureString
            }
            else {
                $QuestionValue = Read-Host -Prompt "$Prompt"
            }
        }
        

        if ([String]::IsNullOrEmpty($QuestionValue) -and [String]::IsNullOrEmpty($DefaultValue) -eq $false)
        {
            $QuestionValue = $DefaultValue
            Write-Host "No value entered. Default value will be used : $DefaultValue."
        }

        if ([String]::IsNullOrEmpty($QuestionValue))
        {
            if ($PossibleValues.count -gt 0 -and $PossibleValues -notcontains $QuestionValue)
            {
                Write-Host "The value is not in the list of possible values. [ $($PossibleValues -join ", ") ]"
                $QuestionValue = $null
            }
        }

        if ([String]::IsNullOrEmpty($QuestionValue))
        {
            if ([String]::IsNullOrEmpty($RegexResult) -eq $false)
            {
                if ($QuestionValue -notmatch $RegexResult)
                {
                    Write-Host "The value is not in the correct format. $RegexResult"
                    $QuestionValue = $null
                }
            }
        }

        if ([String]::IsNullOrEmpty($QuestionValue))
        {
            Write-Host "The value is mandatory, please enter a value."
        }

        if (-not [String]::IsNullOrEmpty($Question.ValidationHookFunction))
        {
            $ValidationResult = Invoke-Expression "$($Question.ValidationHookFunction) -QuestionValue $QuestionValue"
            if ($ValidationResult -eq "INVALIDENTRY")
            {
                Write-Host "The value $QuestionValue is not correct. Please enter a correct value."
                $QuestionValue = $null
            }
            else {
                $QuestionValue = $ValidationResult
            }
        }

        
    }

    return $QuestionValue
}

function Display-PartOfSetupInformation {
    Param(
        $SetupInformationStructure,
        $SectionCode = -1,
        $QuestionCode = -1,
        $SubSectionCode = -1
    )

    while ($SectionCode -eq -1)
    {
        Write-Host "`nSections:"

        $SetupInformationStructure | Sort-Object -Property Index | ForEach-Object {
            $Section = $_
            Write-Host "Section: $($Section.Title) - Index: $($Section.Index)"
        }

        $SectionCode = Read-Host -Prompt "Enter the Section Code to display"

        if ($SectionCode -eq "")
        {
            return
        }

        Display-PartOfSetupInformation -SetupInformationStructure $SetupInformationStructure -SectionCode ($SectionCode -1)

        $SectionCode = -1
    }

    if ($SetupInformationStructure[$SectionCode].Section.Count -gt 0)
    {
        # Ask for displaying Subsction or question
        $WhatToDisplay = Read-Host -Prompt "`tDo you want to display SubSection or Question ?"

        if ($WhatToDisplay -eq "")
        {
            return
        }

        if ($WhatToDisplay -ne "SubSection" -and $WhatToDisplay -ne "Question")
        {
            Write-Host "The value is not correct. Please enter SubSection or Question."
            return
        }
        
        while ($SubSectionCode -eq -1 -and $WhatToDisplay -eq "SubSection")
        {
            Write-Host "`tSubSections:"
            # Select SubSection to Display
            # Display All SubSections Title with an Index

            $SetupInformationStructure[$SectionCode].Section | Sort-Object -Property Index | ForEach-Object {
                $SubSection = $_
                Write-Host "`tSubSection: $($SubSection.Title) - Index: $($SubSection.Index)"
            }

            $SubSectionCode = Read-Host -Prompt "`tEnter the SubSection Code to display"

            if ($SubSectionCode -eq "")
            {
                return
            }

            Display-PartOfSetupInformation -SetupInformationStructure $SetupInformationStructure -SectionCode $SectionCode -SubSectionCode ($SubSectionCode -1)

            SubSectionCode = -1
        }
    }

    if ($SetupInformationStructure[$SectionCode].Collection.Count -gt 0)
    {
        while ($QuestionCode -eq -1)
        {
            # Select Question to Display
            # Display All Questions Title with an Index

            if ($SubSectionCode -ne -1)
            {
                Write-Host "`t`tQuestions:"
                $SetupInformationStructure[$SectionCode].Section[$SubSectionCode].Collection | Where-Object {$_.Hidden -eq $false} | Sort-Object -Property Index | ForEach-Object {
                    $Question = $_
                    Write-Host "`t`tQuestion: $($Question.Question) - Index: $($Question.Index)"
                }
            }
            else {

                Write-Host "`tQuestions:"
                $SetupInformationStructure[$SectionCode].Collection | Where-Object {$_.Hidden -eq $false} | Sort-Object -Property Index | ForEach-Object {
                    $Question = $_
                    Write-Host "`tQuestion: $($Question.Question) - Index: $($Question.Index)"
                }
            }

            $QuestionCode = Read-Host -Prompt "Enter the Question Code to display"

            if ($QuestionCode -eq "")
            {
                return
            }

            Display-PartOfSetupInformation -SetupInformationStructure $SetupInformationStructure -SectionCode $SectionCode -SubSectionCode $SubSectionCode -QuestionCode ($QuestionCode -1)

            $QuestionCode = -1
        }
    }

    if ($SubSectionCode -ne -1)
    {
        Display-SetupInformation -SetupInformationStructure $SetupInformationStructure[$SectionCode].Section[$SubSectionCode]
    }
    else {
        Display-SetupInformation -SetupInformationStructure $SetupInformationStructure[$SectionCode]
    }

}


#endregion Prompt Configuration

#region Hook Functions
# Hook Functions are used to execute some code when the configuration is loaded or saved

function Set-EnvironmentIdentification
{
    Param (
        $QuestionValue
    )

    $EnvironmentType = Resolve-ConfigurationPath -Information  "Root[Basic].Collection[SetupEnvironment]"

    $EnvironmentType = (Invoke-Expression $EnvironmentType).Value

    if ($EnvironmentType -eq "Online" -and $QuestionValue -eq "#ForestName#")
    {
        Write-LogMessage "The Environment is Online, the Forest Name is not available. Please set a Name."
        $QuestionValue = "INVALIDENTRY"
    }
    elseif ($QuestionValue -eq "#ForestName#"){
        try{
            $forest = $forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
            $QuestionValue = $forest.ToString()
        }
        catch {
            Write-LogMessage "The Forest Name is not available. Please set a Name."
            $QuestionValue = "INVALIDENTRY"
        }
    }

    try {
        $guid = [Guid] $QuestionValue

        Write-LogMessage "Guid as Environment Name is not authorized. Please set a Name."
        $QuestionValue = "INVALIDENTRY"
    }
    catch {}

    return $QuestionValue
}

function Set-ApplicationCertificate
{
    Param (
        $QuestionValue
    )

    $InternalCertificatePath = Resolve-ConfigurationPath -Information  "Root[Basic].Section[EntraIDApplicationInformation].Collection[ApplicationCertificateForConfiguration]"

    $InternalCertificatePath = Invoke-Expression $InternalCertificatePath
    $InternalCertificatePath.Value = $QuestionValue
    $InternalCertificatePath.ToSave = $true

    return $QuestionValue
}

#endregion Hook Functions

#region Save Configuration

function Load-Configuration
{
    Param(
        $ConfigurationFile
    )

    if (-not (Test-Path $ConfigurationFile))
    {
        Write-Host "The configuration file does not exist. Please set the configuration before saving/Applying."
        return
    }

    Connect-SetupAzure

    $Script:TargetConfiguration = (Get-Content $ConfigurationFile | ConvertFrom-Json)

    foreach ($Section in $Script:Configuration)
    {
        foreach ($Question in $Section.Collection)
        {
            if ($null -ne $Question.ConfigurationCode)
            {
                $QuestionCodePath = $Question.ConfigurationCode
                $QuestionValue = $Script:TargetConfiguration.$QuestionCodePath

                if (-not [String]::IsNullOrEmpty($Question.LoadHookFunction))
                {
                    $InvokeResult = Invoke-Expression $Question.LoadHookFunction
                }

                if ($QuestionValue -contains "UNCONFIGUREDENTRY" -or $InvokeResult -contains "UNCONFIGUREDENTRY")
                {
                    Write-LogMessage "The configuration of $QuestionCodePath is not set. this will not be loaded. Please set the configuration before saving/Applying."
                }
                else {
                    $Question.Value = $QuestionValue
                    $Question.LoadedFromConfiguration = $true
                }
            }
        }

        foreach ($SubSection in $Section.Section)
        {
            foreach ($Question in $SubSection.Collection)
            {
                if ($null -ne $Question.ConfigurationCode)
                {
                    $QuestionCodePath = $Question.ConfigurationCode
                    $QuestionValue = $Script:TargetConfiguration.$QuestionCodePath

                    if (-not [String]::IsNullOrEmpty($Question.LoadHookFunction))
                    {
                        Invoke-Expression $Question.LoadHookFunction
                    }

                    $Question.Value = $QuestionValue
                    $Question.LoadedFromConfiguration = $true
                }
            }
        }
    }

    

    return $Configuration
}

function Save-Configuration
{
    Param(
        $SetupInformationStructure
    )

    if (-not $Script:Configured)
    {
        Write-Host "The configuration is not set. Please set the configuration before saving/Applying."
        return
    }

    # Create Azure Monitor API Requirements
    $AzureMonitorAPI = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[Basic].Collection[MonitorAPICollection].Value")
    if ($AzureMonitorAPI -eq "AzureMonitorAPI")
    {
        # Create Application
        $ApplicationToCreate = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[EntraIDApplicationCreation].Value")
        if ($ApplicationToCreate -eq "Yes")
        {
            Write-LogMessage "Creating Application for Azure Monitor API"
            # Create Application
            $ApplicationName = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[ApplicationName].Value")
            $ApplicationId = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[ApplicationId].Value")
            $ApplicationCertificate = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[EntraIDApplicationInformation].Collection[ApplicationCertificate].Value")

            $CreationResult = Create-EntraIDLogMonitorApplication -ApplicationName $ApplicationName -ApplicationCertificate $ApplicationCertificate


            

        }
        else {
            Write-LogMessage "Application for Azure Monitor API will not be created as requested."

            # Prompt user to Confirm the application is created
            $ApplicationCreated = Read-Host -Prompt "Confirm the Application for Azure Monitor API is already created ? (Yes/No)"
            if ($ApplicationCreated -eq "No")
            {
                Write-LogMessage "Please create the Application for Azure Monitor API before saving the configuration. If you continue without the application, the API injestion will not work."
            }
        }

        # Create DCR
        $DCRToCreate = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRCreation].Value")
        if ($DCRToCreate -eq "Yes")
        {
            $DCRName = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRName].Value")
            $DCRResourceGroup = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRResourceGroup].Value")
            $DCRRegion = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRRegion].Value")
            $DCRPermission = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRPermission].Value")
            $DCRNameForPermission = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRNameForPermission].Value")
            $endpoint_uri = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[endpoint_uri].Value")
            $dcrImmutableId = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[dcrImmutableId].Value")

            if ($DCRPermission -eq "Yes")
            {
                # Assign Permission
                $DCRNameForPermission = Invoke-Expression (Resolve-ConfigurationPath -Information "Root[AzureMonitorAPIInformation].Section[DCRInformation].Collection[DCRNameForPermission].Value")
                Write-LogMessage "Assigning Permission to Application on DCR"

            }
        }
    }

    # Save Configuration in a file

    # Create Schedule Task

    

}

#endregion Save Configuration

$InformationPreference = "Continue"
$start = Get-Date
$DateSuffixForFile = Get-Date -Format "yyyy-MM-dd-HH-mm-ss"
$DateSuffix = Get-Date -Format "yyyy-MM-dd HH:mm:ss K"

$Global:isRunbook = if (-not $IsOutsideAzureAutomation) 
    {
        if (!($null -eq (Get-Command "Get-AutomationVariable" -ErrorAction SilentlyContinue)))
        {
            try {
                $TestVariable = Get-AutomationVariable -Name TenantName -ErrorAction SilentlyContinue
            }
            catch {
                $TestVariable = $null
            }

            if ($null -eq (Get-Module -Name Orchestrator* -ErrorAction SilentlyContinue) -and $null -eq $TestVariable)
            {
                $false
            }
            else {$true}
        }
        else {$false}
    } else {$false}

$Script:UDSLogs = $null
$Script:Configured = $false
$Script:AzConnectionForSaveRefused = $null
$Script:AzConnectionForReadRefused = $null

# Force TLS1.2 to make sure we can download from HTTPS
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if (-not $Global:isRunbook )
{
    $scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
    $Script:scriptFolder = $scriptFolder
    $ScriptLogPath = $scriptFolder + '\Logs'

    Push-Location ($scriptFolder);
    if (! (Test-Path $ScriptLogPath)) { mkdir $ScriptLogPath }

    $ScriptLogFile = "$ScriptLogPath\ScriptLog-$DateSuffixForFile.log"
    Start-Transcript -Path $ScriptLogFile

    CleanFiles -ScriptLogPath $ScriptLogPath -ClearFilesOlderThan $ClearFilesOlderThan
}

$ScriptInstanceID = ([Guid]::NewGuid()).Guid
Write-LogMessage -Message "Launching ESI Setup, with ID $ScriptInstanceID on date $DateSuffix"

$Script:Configuration = New-SetupInformationStructure

# Load Configuration if exists
$Script:TargetConfiguration = Load-Configuration -ConfigurationFile $ConfigurationFile
Build-Indexes -SetupInformationStructure $Script:Configuration

# Prompt to ask for displaying or setting up the configuration
$NoExit = $true
while ($NoExit)
{
    Write-Host "What do you want to do ?"
    Write-Host "1. 'Display' the configuration"
    Write-Host "2. 'Create' EntraID Application for Azure Monitor Injestion API"
    Write-Host "3. 'Create' DCR for Azure Monitor Injestion API"
    Write-Host "4. 'Assign' Permission to EntraID Application on DCR"
    Write-Host "5. 'Setup' the configuration"
    Write-Host "9. 'Save', create instances and Exit"
    Write-Host "X. 'Exit'"
    $DisplayConfiguration = Read-Host -Prompt "Choose an option"

    if ($DisplayConfiguration -eq "Exit" -or $DisplayConfiguration -eq "X")
    {
        $NoExit = $false
    }
    elseif ($DisplayConfiguration -eq "Display" -or $DisplayConfiguration -eq "1")
    {
        Display-PartOfSetupInformation -SetupInformationStructure $Script:Configuration
    }
    elseif ($DisplayConfiguration -eq "Setup" -or $DisplayConfiguration -eq "2"){
        $Script:Configuration = Prompt-SetupInformation -SetupInformationStructure $Script:Configuration
    }
    elseif ($DisplayConfiguration -eq "Save" -or $DisplayConfiguration -eq "9")
    {
        Save-Configuration -SetupInformationStructure $Script:Configuration
        $NoExit = $false
    }
    else{
        Write-Host "The value is not correct. Please enter 'Display', 'Setup', 'Save', 'Exit' or a corresponding number/letter."
    }
}