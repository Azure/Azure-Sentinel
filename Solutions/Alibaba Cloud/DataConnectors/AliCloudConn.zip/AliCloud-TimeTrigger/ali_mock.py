import logging

class LogClient:
    def __init__(self, aliEndpoint, aliAccessKeyId, aliAccessKey, token):
        logging.getLogger().setLevel(logging.INFO)

    def list_project(self, size):
        projects_data = [
            {"projectName": "Project 1"},
            {"projectName": "Project 2"},
            {"projectName": "Project 3"}
        ]
        return Projects(projects_data)
    
    def list_logstores(self, request):
        return ListLogstoresResponse()

    def get_log_all(self, project, logstore, start_time, end_time, topic):
        return [ListLogsResponse(),ListLogsResponse(),ListLogsResponse()]

class Projects:
    def __init__(self, projects):
        self.projects = projects

    def get_projects(self):
        return self.projects

class ListProjectsResponse:
    def __init__(self):
        logging.getLogger().setLevel(logging.WARNING)

    def get_logstores(self):
        return ['logstore_a', 'logstore_b']

class ListLogstoresRequest:
    def __init__(self,project):
        logging.getLogger().setLevel(logging.WARNING)

class ListLogstoresResponse:
    def __init__(self):
        logging.getLogger().setLevel(logging.WARNING)

    def get_logstores(self):
        return ['logstore_a', 'logstore_b']

class ListLogsResponse:
    def __init__(self):
        logging.getLogger().setLevel(logging.WARNING)

    def get_logs(self):
        log1 = LogRecord("a1","a2","a3")
        log2 = LogRecord("b1","b2","b3")
        log3 = LogRecord("c1","c2","c3")
        return [log1,log2,log3]

class LogRecord:
    def __init__(self, timestamp, source, contents):
        self.timestamp = timestamp
        self.source = source
        self.contents = contents