from aliyun.log import *
import os
import requests
import datetime
import hashlib
import hmac
import base64
import logging
from datetime import datetime
import re
import azure.functions as func
import json
import time
from .state_manager import AzureStorageQueueHelper

aliEndpoint = os.environ.get('Endpoint', 'cn-hangzhou.log.aliyuncs.com')
aliAccessKeyId = os.environ.get('AliCloudAccessKeyId', '')
aliAccessKey = os.environ.get('AliCloudAccessKey', '')
token = ""
topic = os.environ.get('Topic', '')
user_projects = os.environ.get("AliCloudProjects", '').replace(" ", "").split(',')
customer_id = os.environ['WorkspaceID']
shared_key = os.environ['WorkspaceKey']
log_type = "AliCloud"
connection_string = os.environ['AzureWebJobsStorage']
chunksize = 2000
QUEUE_NAME = "alibabacloud-queue-items"

logAnalyticsUri = 'https://' + customer_id + '.ods.opinsights.azure.com'
pattern = r'https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$'
match = re.match(pattern, str(logAnalyticsUri))
if (not match):
    raise Exception("Ali Cloud: Invalid Log Analytics Uri")


def build_signature(customer_id, shared_key, date, content_length, method, content_type, resource):
    x_headers = 'x-ms-date:' + date
    string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
    bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
    decoded_key = base64.b64decode(shared_key)
    encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
    authorization = "SharedKey {}:{}".format(customer_id, encoded_hash)
    return authorization


def post_data_to_LA(chunk):
    body = json.dumps(chunk)
    method = 'POST'
    content_type = 'application/json'
    resource = '/api/logs'
    current_date = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
    content_length = len(body)
    signature = build_signature(customer_id, shared_key, current_date, content_length, method, content_type, resource)
    uri = 'https://' + customer_id + '.ods.opinsights.azure.com' + resource + '?api-version=2016-04-01'

    headers = {
        'content-type': content_type,
        'Authorization': signature,
        'Log-Type': log_type,
        'x-ms-date': current_date
    }
    try:
        response = requests.post(uri, data=body, headers=headers)

        if 200 <= response.status_code <= 299:
            logging.info("{} events was injected".format(len(chunk)))
            return response.status_code
        elif response.status_code == 401:
            logging.error(
                "The authentication credentials are incorrect or missing. Error code: {}".format(response.status_code))
        else:
            logging.error("Something wrong. Error code: {}".format(response.status_code))
        return 0
    except Exception as err:
        logging.error("Something wrong. Exception error text: {}".format(err))


def get_data_in_chunks(data, chunk_size=100):
    chunk = []
    for index, line in enumerate(data):
        if index % chunk_size == 0 and index > 0:
            yield chunk
            del chunk[:]
        chunk.append(line)
    yield chunk


def send_data_to_LA_in_chunks(data, start_time, end_time):
    success = 0
    failed = 0
    for chunk in get_data_in_chunks(data, chunk_size=chunksize):
        status_code = post_data_to_LA(chunk)
        if 200 <= status_code <= 299:
            success += len(chunk)
        else:
            failed += len(chunk)
    logging.info("{} successfully added, {} failed. Period(UTC): {} - {}".format(success, failed, start_time, end_time))


def get_list_logstores(client, project):
    request = ListLogstoresRequest(project)
    xx = client.list_logstores(request)
    return xx.get_logstores()


def process_logstores(client, project, start_time, end_time):
    logstores = get_list_logstores(client, project)
    logs_json_all = []
    for logstore in logstores:
        logs_json = []
        res = client.get_log_all(project, logstore, str(start_time), str(end_time), topic)
        for logs in res:
            for log in logs.get_logs():
                logs_json += [{"timestamp": log.timestamp, "source": log.source, "contents": log.contents}]
        logs_json_all += logs_json
        logging.info("Found {} logs from {} logstore from {} project".format(len(logs_json), logstore, project))
    return logs_json_all

def main(queueItem: func.QueueMessage):
    logging.getLogger().setLevel(logging.INFO)
    logging.info('Starting AlibabaCloud-QueueTrigger program at {}'.format(time.ctime(int(time.time()))) )

    if not aliEndpoint or not aliAccessKeyId or not aliAccessKey:
        raise Exception("Endpoint, AliCloudAccessKeyId and AliCloudAccessKey cannot be empty")
    
    message_body = json.loads(queueItem.get_body().decode('ascii').replace("'",'"'))
    queueItemId = queueItem.id
    # enable 2 lines below for testing
    #message_body = {'start_time': '2023-12-03T14:01:00.000000Z', 'end_time': '2023-12-07T15:01:00.000Z', 'project': 'Project 1'}
    #queueItemId = "sss"
    start_time = message_body.get('start_time')
    end_time = message_body.get('end_time')
    project = message_body.get('project')

    mainQueueHelper = AzureStorageQueueHelper(connection_string,QUEUE_NAME)
    # Initialize the queue body with the same values as the message body
    queue_body = {}
    queue_body["start_time"] = start_time
    queue_body["end_time"] = end_time
    queue_body["project"] = project

    logging.info('Queue message received with queue Id: {} body: {}'.format(queueItemId,message_body) )

    if (project == "" or start_time == "" or end_time == ""):
        raise Exception("One of the storage queue message was missing or empty, could not perform operation (project: {} start_time: {} end_time: {})".format(project,start_time,end_time))
    
    start_time_dt = datetime.strptime(start_time, "%Y-%m-%dT%H:%M:%S.%fZ")
    end_time_dt = datetime.strptime(end_time, "%Y-%m-%dT%H:%M:%S.%fZ")

    if (start_time_dt == datetime.min or end_time_dt == datetime.min or start_time_dt >= end_time_dt or end_time_dt > datetime.utcnow()):
        raise Exception("The time range included in the storage queue message was incorrect, could not perform operation (project_name: {} start_time: {} end_time: {})".format(project,start_time,end_time))

    try:
        client = LogClient(aliEndpoint, aliAccessKeyId, aliAccessKey, token)

        result_obj = process_logstores(client, project, start_time_dt, end_time_dt)

        if (result_obj is not None) and (len(result_obj) > 0):
            send_data_to_LA_in_chunks(result_obj, start_time_dt, end_time_dt)
        else:
            logging.info("No events for {} project with {} start time and {} end time".format(project,start_time,end_time))
    
    except Exception as err:
        logging.error("Error: AlibabaCloud data connector queue trigger execution failed with an internal server error. Exception error text: {}".format(err))
        return_message = mainQueueHelper.send_to_queue(queue_body,True)
        #TODO re-enable
        #if return_message is not None and return_message.id is not None:
        #    logging.info("Message sent to queue with encoding with Base64. Message Id: {} Message Content: {} Queue Name: {}".format(return_message.id, queue_body, QUEUE_NAME))       
        #else:
        #    logging.error("Message not sent to queue. Message Content: {} Queue Name: {}".format(queue_body, QUEUE_NAME))
        logging.info(f'Finish script. at {time.ctime(int(time.time()))}')
        raise
    logging.info(f'Finish script. at {time.ctime(int(time.time()))}')