import azure.functions as func
import datetime
import json
import base64
import hashlib
import hmac
import requests
import re
import os
import logging

from urllib.parse import urlparse
from .state_manager import StateManager

ARMORBLOX_API_TOKEN = os.environ["ArmorbloxAPIToken"]
ARMORBLOX_INSTANCE_NAME = os.environ.get("ArmorbloxInstanceName", "").strip()
ARMORBLOX_INSTANCE_URL = os.environ.get("ArmorbloxInstanceURL", "").strip()
INCIDENT_API_PATH = "api/v1beta1/organizations/{}/incidents"
INCIDENT_API_PAGE_SIZE = 100
INCIDENT_API_TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
INCIDENT_API_TIME_DELTA_IN_MINUTES = 60
CUSTOM_TABLE_NAME = "Armorblox"
CHUNKSIZE = 10000
SENTINEL_WORKSPACE_ID = os.environ["WorkspaceID"]
SENTINEL_WORKSPACE_KEY = os.environ["WorkspaceKey"]
CONNECTION_STRING = os.environ["AzureWebJobsStorage"]
LOG_ANALYTICS_URI = os.environ.get("LogAnalyticsUri", "").strip()

if LOG_ANALYTICS_URI == "":
    LOG_ANALYTICS_URI = "https://" + SENTINEL_WORKSPACE_ID + ".ods.opinsights.azure.com"

pattern = r"https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$"
match = re.match(pattern, str(LOG_ANALYTICS_URI))
if not match:
    raise Exception("Armorblox Data Connector: Invalid Log Analytics URI")

if (ARMORBLOX_INSTANCE_NAME == "") and (ARMORBLOX_INSTANCE_URL == ""):
   raise Exception("At least one of Armorblox instance name or URL need to be provided")


class Armorblox:

    def __init__(self):
        self.incidents_list = []
        self.from_date, self.to_date = self.generate_date()

    @staticmethod
    def generate_date():
        current_time = datetime.datetime.utcnow().replace(second=0)
        state = StateManager(connection_string=CONNECTION_STRING)
        past_time = state.get()

        if past_time is not None:
            logging.info("The last time point is: {}".format(past_time))
        else:
            logging.info("There is no last time point, trying to get incidents for last day.")
            past_time = (current_time - datetime.timedelta(minutes=INCIDENT_API_TIME_DELTA_IN_MINUTES)).strftime(INCIDENT_API_TIME_FORMAT)

        state.post(current_time.strftime(INCIDENT_API_TIME_FORMAT))
        return past_time, current_time.strftime(INCIDENT_API_TIME_FORMAT)

    def _process_incidents(self, url, headers, params):
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            response_json = response.json()
            next_page_token = response_json.get("next_page_token", None)
            self.incidents_list.extend(response_json.get("incidents", []))
            if next_page_token is not None:
                params["page_token"] = next_page_token
                self._process_incidents(url, headers, params)

    def get_incidents(self):
        params = {
            "from_date": self.from_date,
            "to_date": self.to_date,
            "page_size": INCIDENT_API_PAGE_SIZE
        }

        headers = {
            "x-ab-authorization": ARMORBLOX_API_TOKEN,
            "Content-Type": "application/json",
        }

        url = ""
        if ARMORBLOX_INSTANCE_URL:
            tenant_name = urlparse(ARMORBLOX_INSTANCE_URL).netloc.split(".")[0]
            path = INCIDENT_API_PATH.format(tenant_name)
            if not ARMORBLOX_INSTANCE_URL.endswith("/"):
                path = "/" + path

            url = ARMORBLOX_INSTANCE_URL + path
        else:
            url = "https://{}.armorblox.io/{}".format(ARMORBLOX_INSTANCE_NAME, INCIDENT_API_PATH.format(ARMORBLOX_INSTANCE_NAME))

        self._process_incidents(url, headers, params)
        return self.incidents_list


class Sentinel:

    @staticmethod
    def gen_chunks_to_object(data):
        chunk = []
        for index, line in enumerate(data):
            if (index % CHUNKSIZE == 0) and index > 0:
                yield chunk
                del chunk[:]
            chunk.append(line)
        yield chunk

    def gen_chunks(self, data):
        for chunk in self.gen_chunks_to_object(data):
            obj_array = []
            for row in chunk:
                if row is not None and row != "":
                    obj_array.append(row)
            body = json.dumps(obj_array)
            self._post_data(body, len(obj_array))

    @staticmethod
    def build_signature(date, content_length, method, content_type, resource):
        x_headers = "x-ms-date:" + date
        string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
        decoded_key = base64.b64decode(SENTINEL_WORKSPACE_KEY)
        encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
        authorization = "SharedKey {}:{}".format(SENTINEL_WORKSPACE_ID, encoded_hash)
        return authorization

    def _post_data(self, body, chunk_count):
        method = "POST"
        content_type = "application/json"
        resource = "/api/logs"
        rfc1123date = datetime.datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
        content_length = len(body)
        signature = self.build_signature(rfc1123date, content_length, method, content_type, resource)
        uri = LOG_ANALYTICS_URI + resource + "?api-version=2016-04-01"
        headers = {
            "content-type": content_type,
            "Authorization": signature,
            "Log-Type": CUSTOM_TABLE_NAME,
            "x-ms-date": rfc1123date
        }
        response = requests.post(uri, data=body, headers=headers)
        if 200 <= response.status_code <= 299:
            logging.info("Chunk was sent to Azure Sentinel({} events)".format(chunk_count))
        else:
            logging.info("Error during sending events to Azure Sentinel. Response code:{}".format(response.status_code))

def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    if mytimer.past_due:
        logging.info("The timer is past due!")

    logging.info("Python timer trigger function ran at %s", utc_timestamp)

    armorblox = Armorblox()
    sentinel = Sentinel()
    incidents_list = armorblox.get_incidents()
    sentinel.gen_chunks(incidents_list)
