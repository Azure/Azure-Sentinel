| **Version** | **Date Modified (DD-MM-YYYY)** | **Change History**                                                 |
|-------------|--------------------------------|--------------------------------------------------------------------|
| 3.0.1       | 09-01-2024                     | 1 **Analytic Rule** updated with improved rule logic             	|  
| 3.0.0       | 18-08-2023                     | Manual deployment instructions updated for **Data Connector**		|  
                                                                                                                 
