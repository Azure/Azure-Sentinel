#!/usr/bin/env python3
"""
TacitRed → Microsoft Defender TI Integration
Azure Function - Lightweight implementation (No azure-identity dependency)
Author: Data443 Engineering
"""

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional

import azure.functions as func
import requests


# Configure logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class TacitRedDefenderBridge:
    """Bridge service to fetch TacitRed findings and upload to Defender TI"""
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize with configuration from environment variables"""
        self.tacitred_api = os.environ.get('TACITRED_API_URL', 'https://app.tacitred.com/api/v1/findings')
        self.workspace_guid = os.environ.get('SENTINEL_WORKSPACE_ID')
        self.source_system = os.environ.get('SOURCE_SYSTEM', 'TacitRed')
        
        # Priority: 1. Provided API Key, 2. Env Var
        if api_key:
            self.tacitred_key = api_key
            logger.info("Using TacitRed API Key provided in request")
        else:
            # Fallback to environment variable
            self.tacitred_key = os.environ.get('TACITRED_API_KEY')
    
    def _get_arm_token(self) -> str:
        """Get Azure ARM access token using Managed Identity endpoint (lightweight)"""
        identity_endpoint = os.environ.get('IDENTITY_ENDPOINT')
        identity_header = os.environ.get('IDENTITY_HEADER')
        
        if not identity_endpoint or not identity_header:
            logger.warning("Managed Identity environment variables not found. Cannot fetch ARM token.")
            # For local debugging, you might want to return a dummy or handle differently
            raise Exception("Managed Identity not available (IDENTITY_ENDPOINT/HEADER missing)")
            
        resource = "https://management.azure.com/"
        params = {
            'resource': resource,
            'api-version': '2019-08-01'
        }
        headers = {
            'X-IDENTITY-HEADER': identity_header
        }
        
        try:
            logger.info("Fetching ARM token from Managed Identity endpoint...")
            resp = requests.get(identity_endpoint, params=params, headers=headers, timeout=10)
            resp.raise_for_status()
            token = resp.json().get('access_token')
            logger.info("Successfully retrieved ARM token")
            return token
        except Exception as e:
            logger.error(f"Failed to get ARM token via MSI: {str(e)}")
            raise

    def fetch_tacitred_findings(self, 
                                domains: List[str],
                                date_from: str,
                                date_until: str,
                                page_size: int = 100) -> List[Dict[str, Any]]:
        """Retrieve findings from TacitRed API"""
        headers = {
            "accept": "application/json",
            "Authorization": self.tacitred_key
        }
        
        params = {
            "types[]": "compromised_credentials",
            "from": date_from,
            "until": date_until,
            "page": 1,
            "page_size": page_size
        }
        
        # Add domains to params
        for domain in domains:
            params.setdefault("domains[]", []).append(domain) if isinstance(params.get("domains[]"), list) else None
        
        # For multiple domains, construct the query properly
        if len(domains) == 1:
            params["domains[]"] = domains[0]
        else:
            # Multiple domains need special handling
            params = {k: v for k, v in params.items() if k != "domains[]"}
            query_string = "&".join([f"{k}={v}" for k, v in params.items()])
            query_string += "&" + "&".join([f"domains[]={d}" for d in domains])
            url = f"{self.tacitred_api}?{query_string}"
            
            logger.info(f"Fetching TacitRed findings from: {url}")
            response = requests.get(url, headers=headers, timeout=60)
            response.raise_for_status()
            return response.json().get("results", [])
        
        logger.info(f"Fetching TacitRed findings with params: {params}")
        response = requests.get(self.tacitred_api, headers=headers, params=params, timeout=60)
        response.raise_for_status()
        
        results = response.json().get("results", [])
        logger.info(f"Retrieved {len(results)} findings from TacitRed")
        return results
    
    def to_stix(self, findings: List[Dict[str, Any]], domain: str = "unknown") -> List[Dict[str, Any]]:
        """Convert TacitRed findings to STIX 2.1 indicator objects using stix2 library"""
        from stix2 import Indicator
        import json
        
        stix_indicators = []
        current_time = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        
        # OASIS recommended namespace UUID for TacitRed
        TACITRED_NAMESPACE = uuid.UUID('a2be534e-6231-4fb0-b8b8-15dbc96e83b7')
        
        for item in findings:
            # Handle nested finding structure (TacitRed API v2/v1 difference)
            finding = item.get("finding", item)
            
            # Extract email/username with fallback to nested fields
            email = finding.get("email")
            if not email:
                email = finding.get("supporting_data", {}).get("credential")
                # Sometimes credential is an object, sometimes a string? Based on logs it's a string.
                if isinstance(email, dict):
                    email = email.get("email")
            
            username = finding.get("username") or email or f"unknown@{domain}"
            first_seen = finding.get("first_seen") or current_time
            
            # Generate deterministic ID based on username to avoid duplicates
            # Added -v2 suffix to distinguish from previous 'unknown' records
            indicator_uuid = str(uuid.uuid5(TACITRED_NAMESPACE, f"tacitred-{username}-{domain}-v2"))
            indicator_id = f"indicator--{indicator_uuid}"
            
            # Use stix2 library to create properly formatted indicator
            indicator = Indicator(
                id=indicator_id,
                type="indicator",
                spec_version="2.1",
                created=current_time,
                modified=current_time,
                name=f"Compromised credential - {username}",
                description=f"Credential discovered via TacitRed threat intelligence feed for {domain}",
                pattern=f"[user-account:account_login = '{username}']",
                pattern_type="stix",
                pattern_version="2.1",
                valid_from=first_seen,
                indicator_types=["compromised-credential"],
                confidence=80,
                labels=["tacitred", domain, "compromised_credentials"],
                external_references=[
                    {
                        "source_name": "TacitRed API",
                        "url": "https://app.tacitred.com/api/v1/findings",
                        "external_id": str(uuid.uuid5(TACITRED_NAMESPACE, f"{username}-{domain}"))
                    }
                ]
            )
            
            # Convert to dict using serialize() for valid STIX JSON
            stix_indicators.append(json.loads(indicator.serialize()))
        
        logger.info(f"Converted {len(stix_indicators)} findings to valid STIX 2.1 indicators")
        return stix_indicators
    
    def _get_workspace_guid(self) -> str:
        """Get workspace GUID (customerId) from ARM resource ID"""
        if not self.workspace_guid:
            raise ValueError("SENTINEL_WORKSPACE_ID environment variable not set")
        
        token = self._get_arm_token()
        headers = {"Authorization": f"Bearer {token}"}
        
        # Get workspace details from ARM
        url = f"https://management.azure.com{self.workspace_guid}?api-version=2021-06-01"
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        workspace_data = response.json()
        customer_id = workspace_data.get("properties", {}).get("customerId")
        
        if not customer_id:
            raise ValueError(f"Could not retrieve customerId for workspace {self.workspace_guid}")
        
        logger.info(f"Retrieved workspace GUID: {customer_id}")
        return customer_id
    
    def upload_to_defender(self, stix_objects: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Upload STIX indicators to Microsoft Sentinel via Upload API"""
        if not self.workspace_guid:
            raise ValueError("SENTINEL_WORKSPACE_ID environment variable not set")
        
        # Get workspace GUID (customerId) - the Upload API requires this, not the workspace name
        workspace_id = self._get_workspace_guid()
        
        # Sentinel Upload API endpoint (from official Microsoft examples)
        base_url = f"https://api.ti.sentinel.azure.com/workspaces/{workspace_id}/threat-intelligence-stix-objects:upload"
        
        # Get access token via MSI
        token = self._get_arm_token()
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }
        
        params = {
            "api-version": "2024-02-01-preview"
        }
        
        logger.info(f"Uploading {len(stix_objects)} indicators to Microsoft Sentinel")
        
        # Payload structure from official Microsoft examples
        payload = {
            "sourcesystem": self.source_system,
            "stixobjects": stix_objects
        }
        
        if stix_objects:
            logger.info(f"Sample STIX object: {json.dumps(stix_objects[0])}")
            
        try:
            response = requests.post(base_url, headers=headers, params=params, json=payload, timeout=60)
            
            # Log response details before checking status
            logger.info(f"Response status: {response.status_code}")
            logger.info(f"Response body: {response.text}")
            
            response.raise_for_status()
            
            # Parse response and check for errors
            response_data = response.json() if response.content else {}
            logger.info(f"Response JSON: {response_data}")
            
            if response_data.get("errors"):
                logger.error(f"Upload API reported errors: {response_data.get('errors')}")
                return {
                    "success": False,
                    "status_code": response.status_code,
                    "error": f"Upload API validation errors: {response_data.get('errors')}",
                    "response": response_data
                }
            
            result = {
                "success": True,
                "status_code": response.status_code,
                "indicators_uploaded": len(stix_objects),
                "response": response_data if response_data else "Success"
            }
            logger.info(f"Successfully uploaded {len(stix_objects)} indicators")
            return result
            
        except requests.exceptions.HTTPError as e:
            logger.error(f"HTTP error uploading to Sentinel: {e}")
            logger.error(f"Response: {e.response.text if e.response else 'No response'}")
            return {
                "success": False,
                "status_code": e.response.status_code if e.response else None,
                "error": str(e),
                "response": e.response.text if e.response else None
            }
        except Exception as e:
            logger.error(f"Error uploading to Sentinel: {str(e)}")
            return {
                "success": False,
                "error": str(e)
            }


def main(req: func.HttpRequest) -> func.HttpResponse:
    """Azure Function entry point"""
    logger.info('TacitRed to Defender TI function triggered')
    
    try:
        # Parse request
        req_body = req.get_json()
        domains = req_body.get('domains', ['usbank.com'])
        date_from = req_body.get('date_from', '2025-01-01')
        date_until = req_body.get('date_until', datetime.now(timezone.utc).strftime('%Y-%m-%d'))
        tacitred_api_key = req_body.get('tacitred_api_key')
        
        logger.info(f"Processing request for domains: {domains}, from {date_from} to {date_until}")
        
        # Initialize bridge
        bridge = TacitRedDefenderBridge(api_key=tacitred_api_key)
        
        # Fetch findings
        findings = bridge.fetch_tacitred_findings(
            domains=domains,
            date_from=date_from,
            date_until=date_until
        )
        
        if not findings:
            logger.info("No findings retrieved from TacitRed")
            return func.HttpResponse(
                json.dumps({
                    "status": "success",
                    "message": "No findings to process",
                    "findings_count": 0
                }),
                mimetype="application/json",
                status_code=200
            )
        
        # Convert to STIX
        stix_objects = bridge.to_stix(findings, domain=domains[0])
        
        # Upload to Defender
        upload_result = bridge.upload_to_defender(stix_objects)
        
        response_data = {
            "status": "success" if upload_result.get("success") else "partial_failure",
            "findings_retrieved": len(findings),
            "indicators_converted": len(stix_objects),
            "upload_result": upload_result,
            "domains": domains,
            "debug_stix_payload": stix_objects,
            "debug_raw_findings": findings[:5]  # Return first 5 raw findings
        }
        
        return func.HttpResponse(
            json.dumps(response_data, indent=2),
            mimetype="application/json",
            status_code=200 if upload_result.get("success") else 500
        )
        
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": "Invalid request", "message": str(e)}),
            mimetype="application/json",
            status_code=400
        )
    except Exception as e:
        logger.error(f"Function error: {str(e)}", exc_info=True)
        return func.HttpResponse(
            json.dumps({"error": "Internal server error", "message": str(e)}),
            mimetype="application/json",
            status_code=500
        )
