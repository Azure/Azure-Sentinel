"""Python APIs for STIX 2 Semantic Equivalence and Similarity.

.. autosummary::
   :toctree: equivalence

   pattern
   graph
   object

|
"""
