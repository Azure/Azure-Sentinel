"""
Azure Function: RunTacitRedSync
Scheduled trigger to run TacitRed to Defender TI sync
"""
import logging
import sys
import os
import azure.functions as func

# Add Scripts directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'Scripts'))

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('RunTacitRedSync function triggered')

    try:
        # Import the sync script functions
        import tacitred_sync
        
        # Run the sync process
        findings = tacitred_sync.fetch_tacitred_findings()
        logging.info(f'Retrieved {len(findings)} findings from TacitRed')
        
        stix_objs = tacitred_sync.to_stix(findings)
        graph_inds = tacitred_sync.to_graph_indicators(stix_objs)
        
        # Capture upload results
        import io
        from contextlib import redirect_stdout
        
        output = io.StringIO()
        with redirect_stdout(output):
            tacitred_sync.upload_to_defender(graph_inds)
        
        result_msg = output.getvalue()
        logging.info(f'Upload completed: {result_msg}')
        
        return func.HttpResponse(
            body=f"Success: Retrieved {len(findings)} findings, created {len(graph_inds)} indicators.\n{result_msg}",
            status_code=200
        )

    except Exception as e:
        error_msg = f"Error: {str(e)}"
        logging.error(error_msg)
        return func.HttpResponse(
            body=error_msg,
            status_code=500
        )
