#!/usr/bin/env python3
"""
TacitRed → Microsoft Defender TI Integration
Azure Function - Lightweight implementation (No azure-identity dependency)
Author: Data443 Engineering
"""

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional

import azure.functions as func
import requests


# Configure logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class TacitRedDefenderBridge:
    """Bridge service to fetch TacitRed findings and upload to Defender TI"""
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize with configuration from environment variables"""
        self.tacitred_api = os.environ.get('TACITRED_API_URL', 'https://app.tacitred.com/api/v1/findings')
        self.workspace_guid = os.environ.get('SENTINEL_WORKSPACE_ID')
        self.source_system = os.environ.get('SOURCE_SYSTEM', 'TacitRed')
        
        # Priority: 1. Provided API Key, 2. Env Var
        if api_key:
            self.tacitred_key = api_key
            logger.info("Using TacitRed API Key provided in request")
        else:
            # Fallback to environment variable
            self.tacitred_key = os.environ.get('TACITRED_API_KEY')
    
    def _get_arm_token(self) -> str:
        """Get Azure ARM access token using Managed Identity endpoint (lightweight)"""
        identity_endpoint = os.environ.get('IDENTITY_ENDPOINT')
        identity_header = os.environ.get('IDENTITY_HEADER')
        
        if not identity_endpoint or not identity_header:
            logger.warning("Managed Identity environment variables not found. Cannot fetch ARM token.")
            # For local debugging, you might want to return a dummy or handle differently
            raise Exception("Managed Identity not available (IDENTITY_ENDPOINT/HEADER missing)")
            
        resource = "https://management.azure.com/"
        params = {
            'resource': resource,
            'api-version': '2019-08-01'
        }
        headers = {
            'X-IDENTITY-HEADER': identity_header
        }
        
        try:
            logger.info("Fetching ARM token from Managed Identity endpoint...")
            resp = requests.get(identity_endpoint, params=params, headers=headers, timeout=10)
            resp.raise_for_status()
            token = resp.json().get('access_token')
            logger.info("Successfully retrieved ARM token")
            return token
        except Exception as e:
            logger.error(f"Failed to get ARM token via MSI: {str(e)}")
            raise

    def fetch_tacitred_findings(self, 
                                domains: Optional[List[str]] = None,
                                date_from: str = None,
                                date_until: str = None,
                                page_size: int = 100) -> List[Dict[str, Any]]:
        """Retrieve findings from TacitRed API. If domains is None or empty, fetches ALL domains."""
        headers = {
            "accept": "application/json",
            "Authorization": self.tacitred_key
        }
        
        params = {
            "types[]": "compromised_credentials",
            "from": date_from,
            "until": date_until,
            "page": 1,
            "page_size": page_size
        }
        
        # Only add domain filter if domains are specified
        if domains and len(domains) > 0:
            if len(domains) == 1:
                params["domains[]"] = domains[0]
                logger.info(f"Fetching TacitRed findings for domain: {domains[0]}")
            else:
                # Multiple domains need special handling
                params_no_domain = {k: v for k, v in params.items()}
                query_string = "&".join([f"{k}={v}" for k, v in params_no_domain.items()])
                query_string += "&" + "&".join([f"domains[]={d}" for d in domains])
                url = f"{self.tacitred_api}?{query_string}"
                
                logger.info(f"Fetching TacitRed findings for domains: {domains}")
                response = requests.get(url, headers=headers, timeout=60)
                response.raise_for_status()
                return response.json().get("results", [])
        else:
            logger.info("Fetching TacitRed findings for ALL domains (no filter)")
        
        logger.info(f"Fetching TacitRed findings with params: {params}")
        response = requests.get(self.tacitred_api, headers=headers, params=params, timeout=60)
        response.raise_for_status()
        
        results = response.json().get("results", [])
        logger.info(f"Retrieved {len(results)} findings from TacitRed")
        return results
    
    def to_stix(self, findings: List[Dict[str, Any]], domain: str = "unknown") -> List[Dict[str, Any]]:
        """Convert TacitRed findings to STIX 2.1 indicator objects using stix2 library"""
        from stix2 import Indicator
        import json
        
        stix_indicators = []
        current_time = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        
        # OASIS recommended namespace UUID for TacitRed
        TACITRED_NAMESPACE = uuid.UUID('a2be534e-6231-4fb0-b8b8-15dbc96e83b7')
        
        for item in findings:
            # Handle nested finding structure (TacitRed API v2/v1 difference)
            finding = item.get("finding", item)
            
            # Extract email/username with fallback to nested fields
            email = finding.get("email")
            if not email:
                email = finding.get("supporting_data", {}).get("credential")
                # Sometimes credential is an object, sometimes a string? Based on logs it's a string.
                if isinstance(email, dict):
                    email = email.get("email")
            
            username = finding.get("username") or email or f"unknown@{domain}"
            first_seen = finding.get("first_seen") or current_time
            
            # Generate deterministic ID based on username to avoid duplicates
            # Added -v2 suffix to distinguish from previous 'unknown' records
            indicator_uuid = str(uuid.uuid5(TACITRED_NAMESPACE, f"tacitred-{username}-{domain}-v2"))
            indicator_id = f"indicator--{indicator_uuid}"
            
            # Manually construct STIX indicator to match Microsoft Sentinel API requirements
            # Based on Microsoft documentation sample format
            indicator = {
                "type": "indicator",
                "spec_version": "2.1",
                "id": indicator_id,
                "name": f"Compromised credential - {username}",
                "created": current_time,
                "modified": current_time,
                "pattern": f"[user-account:account_login = '{username}']",
                "pattern_type": "stix",
                "valid_from": current_time,
                "labels": ["tacitred", domain, "compromised_credentials"],
                "external_references": [
                    {
                        "source_name": "TacitRed API",
                        "url": "https://app.tacitred.com/api/v1/findings",
                        "external_id": str(uuid.uuid5(TACITRED_NAMESPACE, f"{username}-{domain}"))
                    }
                ]
            }
            
            stix_indicators.append(indicator)
        
        logger.info(f"Converted {len(stix_indicators)} findings to valid STIX 2.1 indicators")
        return stix_indicators
    
    def _get_workspace_guid(self) -> str:
        """Get workspace GUID (customerId) from ARM resource ID"""
        if not self.workspace_guid:
            raise ValueError("SENTINEL_WORKSPACE_ID environment variable not set")
        
        token = self._get_arm_token()
        headers = {"Authorization": f"Bearer {token}"}
        
        # Get workspace details from ARM
        url = f"https://management.azure.com{self.workspace_guid}?api-version=2021-06-01"
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        workspace_data = response.json()
        customer_id = workspace_data.get("properties", {}).get("customerId")
        
        if not customer_id:
            raise ValueError(f"Could not retrieve customerId for workspace {self.workspace_guid}")
        
        logger.info(f"Retrieved workspace GUID: {customer_id}")
        return customer_id
    
    def upload_to_defender(self, stix_objects: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Upload indicators to Microsoft Sentinel via ARM createIndicator API"""
        if not self.workspace_guid:
            raise ValueError("SENTINEL_WORKSPACE_ID environment variable not set")
        
        # Get access token via MSI
        token = self._get_arm_token()
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }
        
        # Use ARM-based createIndicator API (more reliable than api.ti.sentinel.azure.com)
        base_url = f"https://management.azure.com{self.workspace_guid}/providers/Microsoft.SecurityInsights/threatIntelligence/main/createIndicator"
        params = {"api-version": "2024-03-01"}
        
        logger.info(f"Uploading {len(stix_objects)} indicators to Microsoft Sentinel via ARM API")
        
        success_count = 0
        error_count = 0
        errors = []
        
        for stix_obj in stix_objects:
            # Convert STIX format to Sentinel indicator format
            username = stix_obj.get("name", "").replace("Compromised credential - ", "")
            
            indicator_payload = {
                "kind": "indicator",
                "properties": {
                    "source": self.source_system,
                    "displayName": stix_obj.get("name", "TacitRed Indicator"),
                    "description": stix_obj.get("description", ""),
                    "pattern": stix_obj.get("pattern", ""),
                    "patternType": "user-account",
                    "validFrom": stix_obj.get("valid_from", ""),
                    "threatTypes": ["compromised-credential"],
                    "labels": stix_obj.get("labels", [])
                }
            }
            
            try:
                response = requests.post(base_url, headers=headers, params=params, json=indicator_payload, timeout=30)
                
                if response.status_code == 200:
                    success_count += 1
                else:
                    error_count += 1
                    if error_count <= 3:  # Log first 3 errors
                        logger.warning(f"Failed to upload indicator: {response.status_code} - {response.text[:200]}")
                        errors.append({"status": response.status_code, "error": response.text[:200]})
                        
            except Exception as e:
                error_count += 1
                if error_count <= 3:
                    logger.warning(f"Exception uploading indicator: {str(e)}")
                    errors.append({"error": str(e)})
        
        logger.info(f"Upload complete: {success_count} succeeded, {error_count} failed")
        
        return {
            "success": error_count == 0,
            "indicators_uploaded": success_count,
            "indicators_failed": error_count,
            "errors": errors if errors else None
        }


def main(req: func.HttpRequest) -> func.HttpResponse:
    """Azure Function entry point"""
    logger.info('TacitRed to Defender TI function triggered')
    
    try:
        # Parse request
        req_body = req.get_json()
        
        # Domains: None or empty list = fetch ALL domains
        domains = req_body.get('domains', None)
        if domains is not None and len(domains) == 0:
            domains = None  # Empty list means fetch all
        
        # Date range: Default to last 30 days if not specified
        from datetime import timedelta
        default_date_from = (datetime.now(timezone.utc) - timedelta(days=30)).strftime('%Y-%m-%d')
        date_from = req_body.get('date_from', default_date_from)
        date_until = req_body.get('date_until', datetime.now(timezone.utc).strftime('%Y-%m-%d'))
        tacitred_api_key = req_body.get('tacitred_api_key')
        
        domain_desc = domains if domains else "ALL DOMAINS"
        logger.info(f"Processing request for domains: {domain_desc}, from {date_from} to {date_until}")
        
        # Initialize bridge
        bridge = TacitRedDefenderBridge(api_key=tacitred_api_key)
        
        # Fetch findings
        findings = bridge.fetch_tacitred_findings(
            domains=domains,
            date_from=date_from,
            date_until=date_until
        )
        
        if not findings:
            logger.info("No findings retrieved from TacitRed")
            return func.HttpResponse(
                json.dumps({
                    "status": "success",
                    "message": "No findings to process",
                    "findings_count": 0,
                    "domains_queried": domain_desc,
                    "date_range": f"{date_from} to {date_until}"
                }),
                mimetype="application/json",
                status_code=200
            )
        
        # Extract domain from first finding for STIX conversion
        first_domain = "tacitred"
        if findings and len(findings) > 0:
            finding = findings[0].get("finding", findings[0])
            email = finding.get("supporting_data", {}).get("credential", "")
            if "@" in str(email):
                first_domain = str(email).split("@")[-1]
        
        # Convert to STIX
        stix_objects = bridge.to_stix(findings, domain=first_domain)
        
        # Upload to Defender
        upload_result = bridge.upload_to_defender(stix_objects)
        
        response_data = {
            "status": "success" if upload_result.get("success") else "partial_failure",
            "findings_retrieved": len(findings),
            "indicators_converted": len(stix_objects),
            "upload_result": upload_result,
            "domains": domains,
            "debug_stix_payload": stix_objects,
            "debug_raw_findings": findings[:5]  # Return first 5 raw findings
        }
        
        return func.HttpResponse(
            json.dumps(response_data, indent=2),
            mimetype="application/json",
            status_code=200 if upload_result.get("success") else 500
        )
        
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": "Invalid request", "message": str(e)}),
            mimetype="application/json",
            status_code=400
        )
    except Exception as e:
        logger.error(f"Function error: {str(e)}", exc_info=True)
        return func.HttpResponse(
            json.dumps({"error": "Internal server error", "message": str(e)}),
            mimetype="application/json",
            status_code=500
        )
