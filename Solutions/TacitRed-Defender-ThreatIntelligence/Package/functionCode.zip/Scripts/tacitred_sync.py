#!/usr/bin/env python3
"""
TacitRed → Microsoft Defender/Sentinel STIX bridge
Author: Data443 Engineering
"""

import requests, json, uuid, datetime, os
from typing import List

# === CONFIGURATION ======================================================
TACITRED_API = "https://app.tacitred.com/api/v1/findings"
# TacitRed API Key - retrieved from Key Vault or env var
TACITRED_KEY = os.getenv("TACITRED_API_KEY", "a2be534e-6231-4fb0-b8b8-15dbc96e83b7")
TACITRED_QUERY = {
    "types[]": "compromised_credentials",
    # Remove domain filter to get findings across all monitored domains
    # "domains[]": "usbank.com",  # Uncomment to filter specific domain
    "from": (datetime.datetime.now(datetime.UTC) - datetime.timedelta(days=30)).strftime("%Y-%m-%d"),  # Last 30 days
    "until": datetime.datetime.now(datetime.UTC).strftime("%Y-%m-%d"),  # Today
    "page": 1,
    "page_size": 100  # Max 100 per request to get diverse findings
}

# Microsoft Graph Security TI Indicators (Defender Intelligence)
TENANT_ID = os.getenv("AZ_TENANT_ID", "a67bbe4c-49aa-49c4-ae48-223a8986af59")
CLIENT_ID = os.getenv("AZ_CLIENT_ID", "37303195-5dc3-4ce7-b046-7615a20b8585")
# Client Secret - retrieved from Key Vault or env var
CLIENT_SECRET = os.getenv("AZ_CLIENT_SECRET", "")
GRAPH_SCOPE = "https://graph.microsoft.com/.default"
GRAPH_TOKEN_URL = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
GRAPH_TI_URL = "https://graph.microsoft.com/beta/security/tiIndicators"
SOURCE_SYSTEM = "TacitRed"

# =======================================================================

def fetch_tacitred_findings():
    """Retrieve findings from TacitRed."""
    # Debug: Check if API key is retrieved
    if not TACITRED_KEY or TACITRED_KEY.startswith("@Microsoft.KeyVault"):
        print(f"[!] ERROR: TACITRED_API_KEY not resolved from Key Vault. Value: {TACITRED_KEY[:50]}...")
        raise ValueError("TACITRED_API_KEY not properly configured")
    
    print(f"[+] Using TacitRed API key (first 10 chars): {TACITRED_KEY[:10]}...")
    headers = {"accept": "application/json", "Authorization": TACITRED_KEY}
    response = requests.get(TACITRED_API, headers=headers, params=TACITRED_QUERY, timeout=60)
    response.raise_for_status()
    return response.json().get("results", [])

def to_stix(findings: List[dict]) -> List[dict]:
    """Convert TacitRed findings to STIX 2.1 indicator objects."""
    stix_list = []
    for f in findings:
        user = f.get("username") or f.get("email") or "unknown@usbank.com"
        password = f.get("password") or "unknown"
        first_seen = f.get("first_seen") or "2025-03-15T00:00:00Z"
        last_seen = f.get("last_seen") or datetime.datetime.now(datetime.UTC).isoformat()

        indicator_id = f"indicator--{uuid.uuid4()}"
        observed_id = f"observed-data--{uuid.uuid4()}"

        observed = {
            "type": "observed-data",
            "spec_version": "2.1",
            "id": observed_id,
            "created": datetime.datetime.now(datetime.UTC).isoformat(),
            "modified": datetime.datetime.now(datetime.UTC).isoformat(),
            "first_observed": first_seen,
            "last_observed": last_seen,
            "number_observed": 1,
            "objects": {
                "0": {"type": "user-account", "account_login": user},
                "1": {"type": "credential", "user_account_ref": "0", "credential_type": "password", "value": "REDACTED"}
            }
        }

        indicator = {
            "type": "indicator",
            "spec_version": "2.1",
            "id": indicator_id,
            "created": datetime.datetime.now(datetime.UTC).isoformat(),
            "modified": datetime.datetime.now(datetime.UTC).isoformat(),
            "name": f"Compromised credential - {user}",
            "description": "Credential discovered via TacitRed threat intelligence feed.",
            "pattern": f"[user-account:account_login = '{user}']",
            "pattern_type": "stix",
            "valid_from": first_seen,
            "valid_until": "2025-10-09T00:00:00Z",
            "indicator_types": ["compromised-credential"],
            "confidence": 80,
            "labels": ["tacitred", "usbank", "compromised_credentials"],
            "external_references": [
                {"source_name": "TacitRed API", "url": TACITRED_API}
            ]
        }

        relationship = {
            "type": "relationship",
            "spec_version": "2.1",
            "id": f"relationship--{uuid.uuid4()}",
            "relationship_type": "based-on",
            "source_ref": indicator_id,
            "target_ref": observed_id
        }

        stix_list.append(indicator)
        stix_list.append(observed)
        stix_list.append(relationship)

    return stix_list

def get_graph_token() -> str:
    data = {
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "scope": GRAPH_SCOPE,
        "grant_type": "client_credentials",
    }
    r = requests.post(GRAPH_TOKEN_URL, data=data, timeout=60)
    r.raise_for_status()
    token = r.json()["access_token"]
    try:
        # Lightweight roles visibility for troubleshooting (no external deps)
        parts = token.split(".")
        if len(parts) >= 2:
            import base64
            padded = parts[1] + "=" * (-len(parts[1]) % 4)
            payload = json.loads(base64.urlsafe_b64decode(padded.encode()).decode())
            roles = payload.get("roles") or []
            if not roles:
                print("[!] Graph token has no application roles. Ensure admin consent for ThreatIndicators.ReadWrite.*")
    except Exception:
        pass
    return token

def to_graph_indicators(stix_objects: List[dict]) -> List[dict]:
    """Map STIX indicators to Microsoft Graph tiIndicators payloads (domainName).
    Note: Graph API only supports domain-based indicators, not individual credentials.
    We create 1 indicator per unique domain found in the findings.
    """
    indicators = []
    domain_map = {}  # Track unique domains and count credentials
    
    for s in stix_objects:
        if s.get("type") != "indicator":
            continue
        
        # Extract email from the indicator name
        name = s.get("name", "")
        email = name.split(" - ")[-1] if " - " in name else "unknown@usbank.com"
        
        # Extract domain from email
        domain = email.split("@")[-1] if "@" in email else "usbank.com"
        
        # Track credential count per domain
        if domain not in domain_map:
            domain_map[domain] = {"count": 0, "description": s.get("description", "")}
        domain_map[domain]["count"] += 1
    
    # Create 1 indicator per unique domain
    for domain, info in domain_map.items():
        expires = (datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=365)).isoformat()
        
        indicators.append({
            "domainName": domain,
            "description": f"Compromised credentials detected for {domain}. {info['count']} affected account(s) found via TacitRed threat intelligence feed.",
            "tlpLevel": "white",
            "confidence": 60,
            "source": SOURCE_SYSTEM,
            "tags": ["tacitred", "compromised_credentials", domain],
            "targetProduct": "Microsoft Defender ATP",
            "threatType": "Compromised",
            "action": "alert",
            "isActive": True,
            "expirationDateTime": expires
        })
    
    print(f"[+] Created {len(indicators)} unique domain indicator(s) from {sum(d['count'] for d in domain_map.values())} credential(s)")
    return indicators

def upload_to_defender(indicators: List[dict]):
    """Create indicators via Microsoft Graph Security tiIndicators (one-by-one)."""
    if not indicators:
        print("[!] No indicators to upload.")
        return
    token = get_graph_token()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    created = 0
    errors = 0
    import time
    for idx, ind in enumerate(indicators):
        # simple backoff for 429
        attempts = 0
        while True:
            attempts += 1
            resp = requests.post(GRAPH_TI_URL, headers=headers, json=ind, timeout=60)
            if 200 <= resp.status_code < 300:
                created += 1
                break
            if resp.status_code == 429 and attempts < 3:
                try:
                    retry_after = int(resp.headers.get("Retry-After", "7"))
                except Exception:
                    retry_after = 7
                time.sleep(retry_after)
                continue
            errors += 1
            try:
                body = resp.json()
            except Exception:
                body = resp.text
            print(f"[!] Graph upload failed: {resp.status_code} {body}")
            break
        # Rate limit: stay under 50/min (1.3s = ~46/min with margin)
        if idx < len(indicators) - 1:
            time.sleep(1.3)
    print(f"[+] Graph upload completed. created={created}, errors={errors}")

def main():
    findings = fetch_tacitred_findings()
    print(f"[+] Retrieved {len(findings)} findings from TacitRed")
    stix_objs = to_stix(findings)
    graph_inds = to_graph_indicators(stix_objs)
    upload_to_defender(graph_inds)

if __name__ == "__main__":
    main()

