DEFAULT_VERSION = '2.1'  # Default version should always be the latest STIX 2.X version
