import os

# AWS config
AWS_KEY = os.environ['AWS_KEY']
AWS_SECRET = os.environ['AWS_SECRET']
AWS_REGION_NAME = os.environ['AWS_REGION_NAME']
SQS_QUEUE_URL = os.environ['SQS_QUEUE_URL']
VISIBILITY_TIMEOUT = 1800
LINE_SEPARATOR = os.environ.get('lineSeparator',  '[\n\r\x0b\v\x0c\f\x1c\x1d\x85\x1e\u2028\u2029]+') # used in aws_queue and queue trigger.py
MAX_SCRIPT_EXEC_TIME_MINUTES = int(os.environ.get('MAX_SCRIPT_EXEC_TIME_MINUTES', 10))
LOGS_TO_CONSUME = os.environ.get('logTypes', 'All')

#Azure config
AZURE_TENANT_ID = os.environ['AZURE_TENANT_ID']
AZURE_CLIENT_ID = os.environ['AZURE_CLIENT_ID']
AZURE_CLIENT_SECRET = os.environ['AZURE_CLIENT_SECRET']
DCE_ENDPOINT = os.environ['DCE_ENDPOINT']
DCR_ID = os.environ['DCR_ID']
LOG_ANALYTICS_URI = os.environ['LOG_ANALYTICS_URI']
FLOW_LOGS_CUSTOM_TABLE = os.environ['FLOW_LOGS_CUSTOM_TABLE']
AUDIT_LOGS_CUSTOM_TABLE = os.environ['AUDIT_LOGS_CUSTOM_TABLE']
WORKSPACE_ID = os.environ['WORKSPACE_ID']
AZURE_STORAGE_CONNECTION_STRING = os.environ['AzureWebJobsStorage'] 
MAX_QUEUE_MESSAGES_MAIN_QUEUE = int(os.environ.get('MAX_QUEUE_MESSAGES_MAIN_QUEUE', 80))