const { app } = require('@azure/functions');
const { PCE_FQDN, PORT, ORG_ID, API_KEY, API_SECRET } = require('./constants');

app.http('changeWorkloadEnforcementState', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log('Inside changeWorkloadEnforcementState')

        let requestBody = await request.json();

        let workloads = requestBody?.visibilityOnlyWorkloads;

        let applyChanges = requestBody?.applyChanges;

        if (!applyChanges) {
            return {
                body: JSON.stringify({
                    response: 'Skipping updating workloads on PCE since applyChanges flag is set to false. This step will change the enforcement mode of a subset of visibility only workloads to selective'
                })
            }
        }

        if (workloads && workloads.length == 0) {
            //context.log("There are no workloads in visibility state for the given port/protocol combination. Hence exiting")
            return {
                body: JSON.stringify({
                    response: 'No visibility only workloads for the given port/protocol combination'
                })
            }
        }

        let response = await changeEnforcementState(workloads, context);

        return {
            body: JSON.stringify({
                //enforcementStateOutput: response['body'],
                status: response['status']
            })
        };
    }
});

async function changeEnforcementState(workloads, context) {
    context.log(`Inside changeEnforcementState method`);
    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/workloads/update`

        // workloads is an arr of objects where each obj has one key, "href" which points to workload href
        var raw = JSON.stringify({
            "enforcement_mode": "selective",
            "workloads": workloads
        });
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var requestOptions = {
            method: 'PUT',
            body: raw,
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => {
                return response.json().then(data => ({
                    status: response.status,
                    body: data
                }));
            })
            .then(parsed_response => {
                context.log('Response Body:', parsed_response); // log the parsed response body
                resolve({ status: parsed_response['status'], body: parsed_response['body'] }); // pass the parsed response to the resolve function
            })
            .catch(error => {
                context.log('error', error)
                reject(error) // return an empty error
            });
    })
}

