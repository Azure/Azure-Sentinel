const { app } = require('@azure/functions');
const {PCE_FQDN, PORT, ORG_ID, API_KEY, API_SECRET, MAX_WORKLOADS, VISIBILITY_ONLY} = require('./constants');

app.http('fetchvisibilityOnlyWorkloadsFromTrafficResults', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Fetch visibility only workloads from traffic results "${request.url}"`);

        requestBody = await request.json();

        let trafficResults = requestBody?.trafficResults;
        let port = requestBody?.port;
        let protocol = requestBody?.protocol;        
        let applyChanges = requestBody?.applyChanges;

        if (port == undefined || protocol==undefined || trafficResults == undefined ) {
            return {
                body: JSON.stringify({
                    visibilityOnlyWorkloads: `Skipping fetching workloads from traffic results since inputs to the function do not confirm with expected values. Inputs: port: ${port}, protocol: ${protocol}, trafficResults: ${trafficResults}`
                })
            };
        }

        trafficResults = JSON.stringify(trafficResults)
        let visibilityOnlyWorkloads = await getInboundWorkloadNames(trafficResults, context)

        return {             
            body: JSON.stringify({
                visibilityOnlyWorkloads: visibilityOnlyWorkloads,
                port: port,
                protocol: protocol,
                applyChanges: applyChanges
            })
        };
    }
});

async function getInboundWorkloadNames(trafficResults, context) {
    let dst_workloads = new Set();
    let visibilityOnlyWorkloads = undefined;
    let workload_map = new Map();
    let results = [];
    trafficResults = JSON.parse(trafficResults);    

    trafficResults.forEach(function (traffic_hash) {
        if (traffic_hash?.dst?.workload?.href != undefined) {
            dst_workloads.add(traffic_hash.dst.workload.hostname);
            workload_map.set(traffic_hash.dst.workload.hostname, traffic_hash.dst.workload.href);
        }        
    });
    
    context.log(`Count of dst workloads in traffic result is ${dst_workloads.size}`);
    visibilityOnlyWorkloads = await getvisibilityOnlyWorkloads(context);
    context.log(`Count of visibilityOnlyWorkloads for org is ${visibilityOnlyWorkloads.size}`);
    if (visibilityOnlyWorkloads.size > 0 && dst_workloads.size > 0) {
        dst_workloads = visibilityOnlyWorkloads.intersection(dst_workloads);
    }
    // return an array of objects such that each object is a map of hostname to href
    dst_workloads.forEach(function (workload) {
        href = workload_map.get(workload);
        context.log(`Workload: ${workload}`);
        results.push({ href: href });
    })

    return results;
}

async function getvisibilityOnlyWorkloads(context) {
    context.log(`Inside filtervisibilityOnlyWorkloads method`);
    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/workloads/?max_results=${MAX_WORKLOADS}&enforcement_modes=["${VISIBILITY_ONLY}"]`

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
        .then(response => response.text())
        .then(result => {
            let responseJson = JSON.parse(result);
            let workload_hostnames = new Set()
            // Loop through the workloads and extract hostnames
            responseJson.forEach(function (workload) {
                let hostname = workload['hostname'];
                workload_hostnames.add(hostname);  // Collect hostnames
            });            

            context.log(`Response from getvisibilityOnlyWorkloads is ${workload_hostnames}`);            
            resolve(workload_hostnames)
        })
        .catch(error => {
            context.log('error', error)
            reject([]) // return an empty error
        });                                
    })
}