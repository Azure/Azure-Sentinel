const { app } = require('@azure/functions');
const {PCE_FQDN, PORT, ORG_ID, API_KEY, API_SECRET, MAX_WORKLOADS, VISIBILITY_ONLY} = require('./constants');

app.http('fetchvisibilityOnlyWorkloadsFromTrafficResults', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Fetch visibility only workloads from traffic results "${request.url}"`);

        requestBody = await request.json();

        let trafficResults = requestBody?.trafficResults;
        let port = requestBody?.port;
        let protocol = requestBody?.protocol;        
        let applyChanges = requestBody?.applyChanges;

        if (port == undefined || protocol==undefined || trafficResults == undefined ) {
            return {
                body: JSON.stringify({
                    visibilityOnlyWorkloads: `Skipping fetching workloads from traffic results since inputs to the function do not confirm with expected values. Inputs: port: ${port}, protocol: ${protocol}, trafficResults: ${trafficResults}`
                })
            };
        }

        trafficResults = JSON.stringify(trafficResults)
        let visibilityOnlyWorkloads = await getVisibilityOnlyWorkloadsWithInboundTraffic(trafficResults, context);

        return {             
            body: JSON.stringify({
                visibilityOnlyWorkloads: visibilityOnlyWorkloads,
                port: port,
                protocol: protocol,
                applyChanges: applyChanges
            })
        };
    }
});


//Parses 'traffic query' results, retrieve destination workloads which have 'visibility_only' mode 
async function getVisibilityOnlyWorkloadsWithInboundTraffic(trafficResults, context) {
    let visibilityOnlyWorkloads = new Set();
    let workloadsSeenSoFar = new Map();
    trafficResults = JSON.parse(trafficResults);    

    trafficResults.forEach(function (traffic_hash) {
        if (traffic_hash?.dst?.workload?.href != undefined) {
            // this is a workload, add it to "results" if its enforcement state is visibility_only
            if (traffic_hash?.dst?.workload?.enforcement_mode == VISIBILITY_ONLY) {
                
                if (workloadsSeenSoFar.get(traffic_hash.dst.workload.hostname) == undefined) {
                    workloadsSeenSoFar.set(traffic_hash.dst.workload.hostname, traffic_hash.dst.workload.href);
                    visibilityOnlyWorkloads.add({href: traffic_hash.dst.workload.href});
                }                
            }        
        }        
    });
            
    context.log(`Count of visibilityOnlyWorkloads for org is ${visibilityOnlyWorkloads.size}`);

    return [...visibilityOnlyWorkloads]; // send it as a list
}