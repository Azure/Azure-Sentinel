const { app } = require('@azure/functions');
const { PCE_FQDN, PORT, ORG_ID, API_KEY, API_SECRET } = require('./constants');


app.http('createVirtualService', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Create virtual service for "${request.url}"`);

        var requestBody = await request.json();

        var port = requestBody?.port;
        var protocol = requestBody?.protocol;
        var applyChanges = requestBody?.applyChanges;
        let visibilityOnlyWorkloads = requestBody.visibilityOnlyWorkloads || [];

        // if customer wants pce updates to be done, then applyChanges need to be set
        if (!applyChanges) {
            return {
                body: JSON.stringify({
                    create_virtual_service_output: `Apply changes is set to false, hence providing a summary of what object would be created. 
                    A virtual service object for port ${port} and protocol ${protocol} would be created such that it can be 
                    binded to visibility only workloads identified via traffic query step.`,
                    applyChanges: applyChanges,
                })
            };
        }

        if (port == undefined || protocol == undefined || (visibilityOnlyWorkloads && visibilityOnlyWorkloads.length == 0) ) {
            return {
                body: JSON.stringify({
                    createVirtualServiceOutput: `Skipping creating virtual service since inputs do not confirm with what is expected. Inputs: port: ${port}, protocol: ${protocol}, visibilityOnlyWorkloads: ${visibilityOnlyWorkloads}`,
                    applyChanges: applyChanges,
                })
            };
        }
        var vshref = await createVirtualService(port, protocol, context);

        if (vshref == undefined) {
            return {
                body: JSON.stringify({
                    createVirtualServiceOutput: 'Object is not created',
                    applyChanges: applyChanges,
                })
            };
        }

        if (vshref.includes("input_validation_error")) {
            context.log("VS creation ran into input validation error, retry with proper payload");
            return {
                body: JSON.stringify({
                    createVirtualServiceOutput: 'Virtual service Input Validation Error',
                    applyChanges: applyChanges,
                })
            };
        }

        else if (vshref.includes("name_must_be_unique")) {
            context.log("VS creation ran into an error that suggests the name used for creating VS already exists on PCE");
            return {
                body: JSON.stringify({
                    createVirtualServiceOutput: 'VS already exists, unable to create with same name',
                    applyChanges: applyChanges
                })
            };
        }

        var provisionStatus = await provisionPolicyObject(vshref, context);
        
        if (vshref.includes('virtual_services')) {
            vshref = vshref.replace("/draft/", "/active/");
        }        

        return {
            body: JSON.stringify({
                vshref: vshref, // at this point, this should return active uri only
                provisionStatus: provisionStatus,
                applyChanges: applyChanges,
                visibilityOnlyWorkloads:visibilityOnlyWorkloads
            })
        };
    }
});

async function createVirtualService(port, protocol, context) {
    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/sec_policy/draft/virtual_services`
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var raw = JSON.stringify({
            "name": `Sentinel_VS_Obj_port_protocol_${port}_${protocol}`,
            "description": `This virtual service has been created via Azure Sentinel for port ${port} and ${protocol}`,
            "service_ports": [{ "proto": protocol, "port": port }],
            "apply_to": "host_only",
            "ip_overrides": [],
            "labels": [],
            "service_addresses": []
        });

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            redirect: 'follow',
            body: raw
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => response.json())
            .then(data => {
                var vshref = data.href;
                context.log(data);
                context.log('Virtual service href:', vshref);
                // handle error cases
                if (data[0]?.token == 'input_validation_error') {
                    resolve("input_validation_error");
                }
                else if (data[0]?.token == 'rule_name_in_use') {
                    resolve("rule_name_in_use");                
                }
                else if (data[0]?.token == 'name_must_be_unique') {
                    resolve("name_must_be_unique");                
                }
                resolve(vshref);
            })
            .catch(error => {
                context.log('error', error)
                reject(error);
            });
    })
}

async function provisionPolicyObject(vshref, context) {
    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/sec_policy`

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var raw = JSON.stringify({
            "update_description": `Provisioning changes from Sentinel Playbook for ${vshref}`,
            "change_subset": { "virtual_services": [{ "href": vshref }] }
        })

        var requestOptions = {
            method: 'POST',
            body: raw,
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => response.json()) // parse the JSON from the response
            .then(data => {
                context.log('Response Body:', data); // log the parsed response body        
                resolve(data); // pass the parsed response to the resolve function
            })
            .catch(error => {
                context.log('error', error)
                reject(error) // return an empty error
            });
    })
}
