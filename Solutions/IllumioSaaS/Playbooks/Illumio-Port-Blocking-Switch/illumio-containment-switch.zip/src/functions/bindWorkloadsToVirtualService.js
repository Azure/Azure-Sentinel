const { app } = require('@azure/functions');
const { PCE_FQDN, PORT, ORG_ID, API_KEY, API_SECRET } = require('./constants');

app.http('bindWorkloadsToVirtualService', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Binding workloads to virtual service "${request.url}"`);

        requestBody = await request.json();

        let applyChanges = requestBody?.applyChanges;
        let workloads = requestBody?.visibilityOnlyWorkloads || [];
        let vshref = requestBody?.vshref;

        // if customer wants pce updates to be done, then applyChanges need to be set
        if (!applyChanges) {
            return {
                body: JSON.stringify({
                    bindWorkloadVSOutput: `Skipping binding workloads to virtual service since applyChanges is set to false, this step binds workloads to previously created virtual service.`,
                    applyChanges: applyChanges,
                })
            };
        }

        if ((workloads.length == 0) || (vshref == undefined)) {
            return {
                body: JSON.stringify({
                    bindWorkloadVSOutput: `Skipping binding workloads to virtual service since inputs do not confirm with what is expected. Inputs: visibilityOnlyWorkloads: ${workloads}, vshref: ${vshref}`,
                    applyChanges: applyChanges,
                })
            };
        }

        var bindWorkloadVSOutput = await bindWorkloadsToVirtualService(vshref, workloads, context);
        context.log(`Output of bindWorkloadVSOutput is ${bindWorkloadVSOutput['body']} and status is ${bindWorkloadVSOutput['status']}`)
        return {
            body: JSON.stringify({
                bindWorkloadVSOutput: bindWorkloadVSOutput['body'],
                status: bindWorkloadVSOutput['status'],
                vshref: vshref,
                applyChanges: applyChanges,
            })
        };
    }
});

async function bindWorkloadsToVirtualService(vshref, workloads, context) {

    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/service_bindings`

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        workloads.forEach(function (workload) {
            // workload is a hash with a key called 'href' and value being the href
            context.log(`Workload inside bind method is ${JSON.stringify(workload)}`);
            var raw = JSON.stringify({
                "virtual_service":
                    { "href": vshref },
                "workload":
                    { "href": workload.href },
                "port_overrides": []
            });

            var requestOptions = {
                method: 'POST',
                body: JSON.stringify([JSON.parse(raw)]),
                headers: myHeaders,
                redirect: 'follow'
            };

            fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
                .then(response => {
                    return response.json().then(data => ({
                        status: response.status,
                        body: data
                    }));
                })
                .then(parsed_response => {
                    resolve({ body: parsed_response['body'], status: parsed_response['status'] });
                })
                .catch(error => {
                    context.log('error', error)
                    reject([]) // return an empty error
                });
        });
    })
}