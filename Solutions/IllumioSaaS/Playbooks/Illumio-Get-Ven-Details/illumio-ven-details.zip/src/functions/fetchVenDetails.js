const { app } = require('@azure/functions');
const { PCE_FQDN, PORT, ORG_ID, API_KEY, API_SECRET } = require('./constants');

app.http('fetchVenDetails', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Fetching ven details for entities in "${request.url}"`);
        let requestBody = await request.json();
        let results = [];
        let ipMap, hostMap;
        ipMap = new Map();
        hostMap = new Map();
        requestBody = requestBody.body?.Entities;

        for (const entity of requestBody) { // expect Host and IP as entities only
            // Declare variables within the loop

            let hostname = undefined;
            let ipaddress = undefined;

            // Check for properties and assign values
            if (entity['Type'] == 'host') {
                hostname = entity['HostName'];
            }
            else if (entity['Type'] == 'ip') {
                ipaddress = entity['Address'];
            }
            else {
                continue;
            }

            context.log(entity);

            // Fetch VEN details asynchronously
            let venResults = await fetchVenDetails({ hostname: hostname, ipaddress: ipaddress }, context);

            // Push results if they exist
            if (venResults.length > 0) {
                if ((ipMap.get(venResults[0]['public_ip']) != undefined) || (hostMap.get(venResults[0]['hostname']) != undefined)) {
                    ipMap.set(venResults[0]['public_ip'], 1);
                    hostMap.set(venResults[0]['hostname'], 1);
                }
                else {
                    context.log(`pushing ${venResults[0]['public_ip']}`)
                    results.push(venResults);
                    ipMap.set(venResults[0]['public_ip'], 1);
                    hostMap.set(venResults[0]['hostname'], 1);
                }
            }
        }

        return {
            body: JSON.stringify({
                response: results
            })
        };
    }
});

async function fetchVenDetails(ven_details, context) {
    return new Promise((resolve, reject) => {

        let hostname = ven_details?.hostname || undefined;
        let ip = ven_details?.ipaddress || undefined;
        let path = undefined;

        if (hostname != undefined && ip != undefined) {
            path = `/api/v2/orgs/${ORG_ID}/workloads?ip_address=${ip}&hostname=${hostname}`
        }
        else if (hostname != undefined) {
            path = `/api/v2/orgs/${ORG_ID}/workloads?hostname=${hostname}`
        }
        else {
            path = `/api/v2/orgs/${ORG_ID}/workloads?ip_address=${ip}`
        }


        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => {
                //context.log(response);
                return response.json();
            })
            .then(data => {
                //context.log('Response Body from GET /workloads :', data); // log the parsed response body            
                resolve(data); // pass the parsed response to the resolve function
            })
            .catch(error => {
                context.log('error', error)
                reject(error) // return an empty error
            });

    })
}

