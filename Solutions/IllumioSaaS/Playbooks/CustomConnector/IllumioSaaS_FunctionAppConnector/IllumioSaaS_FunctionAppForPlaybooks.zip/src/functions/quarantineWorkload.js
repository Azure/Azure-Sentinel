const { app } = require('@azure/functions');
const { PCE_FQDN, PORT, ORG_ID, API_KEY, API_SECRET } = require('./constants');


app.http('quarantineWorkloadHTTPTrigger', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Begin quarantine workload routine "${request.url}"`);

        var requestBody = await request.json();
        /*
        Accept either a single workload or a list of workloads by hostnames only
        Context that function app needs, is the labels that it needs to apply
        This replaces existing labels with new labels.
        */

        var workloads = requestBody?.workloads;
        var inputLabels = requestBody?.labels;

        var labelHrefs = [];        
        for (const label of inputLabels) {
            let labelHref = await getLabelHref(label, context);
            labelHrefs.push(labelHref);
        }

        if (workloads.length > 0 && labelHrefs.length > 0) {

            context.log(`Label hrefs from get label href method: ${JSON.stringify(labelHrefs)}`);
            for (const workload of workloads) {
                var workloadDetail = await getWorkloadHref(workload, context);
                let workloadHref = workloadDetail['href']                
                let existingLabelTypes = workloadDetail['existingLabelTypes']                
                if (workloadHref) {
                    context.log('Workload href is: ', workloadHref);
                    var applyLabelResponse = await applyLabels(workloadHref, labelHrefs, existingLabelTypes, context);
                }
                else {
                    return {
                        body: JSON.stringify({
                            responseCode: { 'ApplylabelResponse': 'Invalid Workload Input' }
                        })
                    };                    
                }
            }
        }
        else {
            context.log(" Workloads are not provided in input.");
        }

        return {
            body: JSON.stringify({
                responseCode: { 'ApplylabelResponse': applyLabelResponse }
            })
        };
    }
});

async function getWorkloadHref(hostname, context) {
    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/workloads?hostname=${hostname}`

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => {
                return response.json().then(data => ({
                    status: response.status,
                    body: data
                }));
            })
            .then(parsed_response => {

                var data = parsed_response['body'];
                //context.log('Data of workload is: ', data)
                if (data.length == 0) {
                    // empty response
                    resolve({ body: data });
                }
                else {
                    let workloadDetail = data[0];
                    //context.log(`Existing labels of workload:  ${JSON.stringify(workloadDetail['labels'])}`);
                    let existingLabels = workloadDetail['labels']
                    let existingLabelTypes = []
                    for (let label of existingLabels) {
                        existingLabelTypes.push(label['key']);
                    }
                    if (workloadDetail['href']) {                        
                        var labelHref = workloadDetail['href'];
                        resolve({ href: labelHref, status: parsed_response['status'], body: data, existingLabelTypes: existingLabelTypes }); // pass the parsed response to the resolve function            
                    }
                }
            })
            .catch(error => {
                context.log('error', error)
                reject(error) // return an empty error
            });
    });

}

async function getLabelHref(labelName, context) {

    return new Promise((resolve, reject) => {

        let path = `/api/v2/orgs/${ORG_ID}/labels?value=${labelName}`

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => {
                return response.json().then(data => ({
                    status: response.status,
                    body: data
                }));
            })
            .then(parsed_response => {
                //context.log('Response Body:', parsed_response); // log the parsed response body
                var data = parsed_response['body'];
                if (data?.[0]?.href) {
                    var labelHref = data[0]['href'];
                    resolve(labelHref); // pass the parsed response to the resolve function                
                }
            })
            .catch(error => {
                context.log('error', error)
                reject(error) // return an empty error
            });
    });

}

async function applyLabels(workloadHref, labelhrefs, existingLabelTypes, context) {
    context.log("Applying labels to workloads:  ", workloadHref, " and existing label types are ", existingLabelTypes);
    var labelHrefPayload = []
    for (const labelHref of labelhrefs) {
        labelHrefPayload.push({ "href": labelHref })
    }

    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/workloads/set_labels`

        var raw = JSON.stringify({
            "workloads": [{ "href": workloadHref }], "labels": labelHrefPayload, "delete_existing_keys": existingLabelTypes
        })
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var requestOptions = {
            method: 'PUT',
            body: raw,
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => {
                return response.json().then(data => ({
                    status: response.status,
                    body: data
                }));
            })
            .then(parsed_response => {                                
                resolve({ status: parsed_response['status'] }); // pass the parsed response to the resolve function            
            })
            .catch(error => {
                context.log('error', error)
                reject(error) // return an empty error
            });
    });

}