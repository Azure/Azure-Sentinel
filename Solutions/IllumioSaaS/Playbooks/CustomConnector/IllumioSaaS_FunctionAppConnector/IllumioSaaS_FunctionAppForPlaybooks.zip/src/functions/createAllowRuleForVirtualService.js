const { app } = require('@azure/functions');
const { PCE_FQDN, PORT, ORG_ID, API_KEY, API_SECRET } = require('./constants');

app.http('createAllowRuleForVirtualService', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Create ruleset and an allow rule "${request.url}"`);

        var requestBody = await request.json();

        var vshref = requestBody?.vshref;
        var applyChanges = requestBody?.applyChanges;
        var provisionStatus = undefined;

        if (!applyChanges) {
            return {
                body: JSON.stringify({
                    ruleSetCreationOutput: 'This step will create a ruleset and an allow rule between virtual service and workloads, skipping updating PCE with allow rule since applyChanges flag is set to false'
                })
            };
        }

        if (vshref == undefined) {
            return {
                body: JSON.stringify({
                    bindWorkloadVSOutput: `Virtual service href is undefined, please pass href of virtual service`,
                    vshref: vshref
                })
            };
        }

        let anyIPListHref = await getIPListHref(context);

        let ruleSetOutput = await createRuleSet(context);

        context.log(` Ruleset output is ${JSON.stringify(ruleSetOutput)}`);

        if (ruleSetOutput['status'] == 406) {
            if (ruleSetOutput['body'].includes('input_validation_error')) {
                return {
                    body: JSON.stringify({
                        ruleSetCreationOutput: 'Ruleset Input Validation Error',
                    })
                };
            }
            else if (ruleSetOutput['body'].includes('rule_set_name_in_use')) {
                return {
                    body: JSON.stringify({
                        ruleSetCreationOutput: 'Ruleset already exists, unable to create with same name',
                    })
                };
            }
        }

        let ruleOutput = await createRule(ruleSetOutput['href'], vshref, anyIPListHref, context);

        context.log(` Allow Rule output is ${JSON.stringify(ruleOutput)}`);

        if (ruleOutput['status'] == 406) {
            if (ruleOutput['body'].includes("input_validation_error")) {
                context.log("Ruleset creation ran into input validation error, retry with proper payload");
                return {
                    body: JSON.stringify({
                        ruleCreationOutput: 'Rule Input Validation Error',
                    })
                };
            }

            else if (ruleOutput['body'].includes("rule_name_in_use")) {
                context.log("Rule creation ran into ruleset name in use error, the rule already exists");
                return {
                    body: JSON.stringify({
                        ruleCreationOutput: 'Rule already exists, unable to create with same name',
                    })
                };
            }
        }

        if (ruleSetOutput['status'] == '201' && ruleOutput['status'] == '201') {
            provisionStatus = await provisionPolicyObject(ruleSetOutput['href'], context);
        }


        return {
            body: JSON.stringify({
                ruleSetCreationOutput: ruleSetOutput['href'],
                ruleSetCreationStatus: ruleSetOutput['status'],
                ruleCreationOutput: ruleOutput['href'],
                ruleCreationStatus: ruleOutput['status'],
                provisionStatus: provisionStatus,
                applyChanges: applyChanges
            })
        };
    }
});

async function getIPListHref(context) {
    return new Promise((resolve, reject) => {
        const name = encodeURIComponent("Any (0.0.0.0/0 and ::/0)");
        let path = `/api/v2/orgs/${ORG_ID}/sec_policy/active/ip_lists?name=${name}`

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => response.json())
            .then(data => {
                context.log('Response Body for GET Any iplist definition is :', data); // log the parsed response body
                let iplistHref = data[0].href
                resolve(iplistHref); // pass the parsed response to the resolve function
            })
            .catch(error => {
                context.log('error', error)
                reject(error) // return an empty error
            });
    })
}

async function provisionPolicyObject(ruleSetHref, context) {
    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/sec_policy`

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var raw = JSON.stringify({
            "update_description": `Provisioning changes from Sentinel Playbook for ${ruleSetHref} containing allow rule`,
            "change_subset": { "rule_sets": [{ "href": ruleSetHref }] }
        })

        var requestOptions = {
            method: 'POST',
            body: raw,
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => response.json()) // parse the JSON from the response
            .then(data => {
                context.log('Response Body:', data); // log the parsed response body        
                resolve(data); // pass the parsed response to the resolve function
            })
            .catch(error => {
                context.log('error', error)
                reject(error) // return an empty error
            });
    })
}

async function createRuleSet(context) {
    context.log(`Inside create rule set method`);
    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/sec_policy/draft/rule_sets`
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var raw = JSON.stringify({ "name": `Microsoft Sentinel Containment Switch Playbook: Ruleset`, "description": "", "scopes": [[]] });
        var requestOptions = {
            method: 'POST',
            body: raw,
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => {
                return response.json().then(data => ({
                    status: response.status,
                    body: data
                }));
            })
            .then(parsed_response => {
                context.log(`Response Body for create ruleset is : ${JSON.stringify(parsed_response['body'])}`);
                if ('href' in parsed_response['body']) {
                    context.log('Creating ruleset is a success');
                    var data = parsed_response['body'];
                    var rsHref = data.href;
                }
                else {
                    context.log('Creating ruleset is a failure');
                    var data = parsed_response['body'][0];
                }
                // handle error cases                
                if ('token' in data && data['token'] == 'input_validation_error') {
                    resolve({ href: '', status: parsed_response['status'], body: "input_validation_error" });
                }
                else if ('token' in data && data['token'] == 'rule_set_name_in_use') {
                    resolve({ href: '', status: parsed_response['status'], body: "rule_set_name_in_use" });
                }
                resolve({ href: rsHref, status: parsed_response['status'], body: data }); // pass the parsed response to the resolve function
            })
            .catch(error => {
                //context.log(`error, ${error}`);
                reject(error); // return an empty error
            });
    })
}

async function createRule(ruleSetHref, vshref, iplistHref, context) {
    return new Promise((resolve, reject) => {
        let id = ruleSetHref.split('/')[ruleSetHref.split('/').length - 1];
        //context.log(id);
        let path = `/api/v2/orgs/${ORG_ID}/sec_policy/draft/rule_sets/${id}/sec_rules`
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var raw = JSON.stringify({ "providers": [{ "virtual_service": { "href": vshref } }], "consumers": [{ "ip_list": { "href": iplistHref } }], "enabled": true, "ingress_services": [], "egress_services": [], "network_type": "brn", "description": "", "consuming_security_principals": [], "sec_connect": false, "machine_auth": false, "stateless": false, "unscoped_consumers": false, "use_workload_subnets": [], "resolve_labels_as": { "consumers": ["workloads"], "providers": ["virtual_services"] } })
        var requestOptions = {
            method: 'POST',
            body: raw,
            headers: myHeaders,
            redirect: 'follow'
        };
        console.log(requestOptions);

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => {
                return response.json().then(data => ({
                    status: response.status,
                    body: data
                }));
            })
            .then(parsed_response => {
                //context.log(parsed_response); 
                if ('href' in parsed_response['body']) {
                    context.log('Creating rule is a success');
                    var data = parsed_response['body'];
                    var ruleHref = data.href;
                }
                else {
                    context.log('Creating rule is a failure');
                    var data = parsed_response['body'][0];
                }                // handle error cases
                if ('token' in data && data['token'] == 'input_validation_error') {
                    resolve({ href: '', status: parsed_response['status'], body: "input_validation_error" });
                }
                else if ('token' in data && data['token'] == 'rule_name_in_use') {
                    resolve({ href: '', status: parsed_response['status'], body: "rule_name_in_use" });
                }
                resolve({ href: ruleHref, status: parsed_response['status'], body: data }); // pass the parsed response to the resolve function
            })
            .catch(error => {
                //context.log(`error: ${error}`);
                reject(error); // return an empty error
            });
    })
};