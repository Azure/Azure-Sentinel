const { app } = require('@azure/functions');
const { PCE_FQDN, PORT, ORG_ID, API_KEY, API_SECRET } = require('./constants');


app.http('createDenyRule', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        let requestBody = await request.json();
        let port = requestBody?.port;
        let protocol = requestBody?.protocol;
        let visibilityOnlyWorkloads = requestBody.visibilityOnlyWorkloads;
        let applyChanges = requestBody?.applyChanges;

        if (!applyChanges) {
            return {
                body: JSON.stringify({
                    denyRuleCreationOutput: 'Skipping updating PCE with deny rule since applyChanges flag is set to false'
                })
            };
        }

        if ((visibilityOnlyWorkloads && visibilityOnlyWorkloads.length == 0) || (port == undefined || protocol==undefined)) {
            return {
                body: JSON.stringify({
                    denyRuleCreationOutput: `Skipping creating deny rule inputs to the function do not confirm with expected values. Inputs: port: ${port}, protocol: ${protocol}, visibilityOnlyWorkloads: ${visibilityOnlyWorkloads}`
                })
            };
        }

        context.log(`visibility only workloads are ${JSON.stringify(visibilityOnlyWorkloads)}`);

        let IpListOutput = await getIPListHref(context);

        context.log(`Iplist href is ${IpListOutput['href']} and status is ${IpListOutput['status']} }`);

        let enforcementBoundaryOutput = await createEnforcementBoundary(port, protocol, IpListOutput['href'], context);

        context.log(`enforcementBoundaryOutput is ${JSON.stringify(enforcementBoundaryOutput)}`);

        if ('data' in enforcementBoundaryOutput && enforcementBoundaryOutput['data'].includes("input_validation_error")) {
            context.log("Deny rule creation ran into input validation error, retry with proper payload");
            return {
                body: JSON.stringify({
                    denyRuleCreationOutput: 'Deny Rule Input Validation Error',
                })
            };
        }

        else if ('data' in enforcementBoundaryOutput && enforcementBoundaryOutput['data'].includes("rule_name_in_use")) {
            context.log("Deny rule creation ran into rule name in use error, the rule name already exists");
            return {
                body: JSON.stringify({
                    denyRuleCreationOutput: 'Deny rule already exists, unable to create with same name',
                })
            };
        }

        var provisionStatus = await provisionPolicyObject(enforcementBoundaryOutput['href'], context);

        return {
            body: JSON.stringify({
                denyRuleCreationOutput: enforcementBoundaryOutput['href'],
                provisionStatus: provisionStatus,
                applyChanges: applyChanges
            })
        };
    }
});

async function getIPListHref(context) {
    return new Promise((resolve, reject) => {
        const name = encodeURIComponent("Any (0.0.0.0/0 and ::/0)");
        let path = `/api/v2/orgs/${ORG_ID}/sec_policy/active/ip_lists?name=${name}`

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => {
                return response.json().then(data => ({
                    status: response.status,
                    body: data
                }));
            })
            .then(parsed_response => {
                context.log('Response Body:', parsed_response); // log the parsed response body
                let data = parsed_response['body'];
                let iplistHref = data[0].href;
                resolve({ href: iplistHref, status: parsed_response['status'] }); // pass the parsed response to the resolve function
            })
            .catch(error => {
                context.log('error', error)
                reject(error) // return an empty error
            });
    })
}

// Create enforcement boundary from all ips to all workloads on provided port/protocol
async function createEnforcementBoundary(port, protocol, anyIPListHref, context) {
    if (port == undefined || protocol == undefined || anyIPListHref == undefined) {
        return undefined;
    }

    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/sec_policy/draft/enforcement_boundaries`

        // workloads is an arr of objects where each obj has one key, "href" which points to workload href
        var raw = JSON.stringify({
            "name": `Sentinel Playbook Enforcement Boundary for port - ${port} and protocol - ${protocol}`,
            "enabled": true,
            "providers": [{ "actors": "ams" }],
            "consumers": [{ "ip_list": { "href": anyIPListHref } }],
            "network_type": "brn",
            "ingress_services": [{ "proto": protocol, "port": port }]
        });

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var requestOptions = {
            method: 'POST',
            body: raw,
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => {
                return response.json().then(data => ({
                    status: response.status,
                    body: data
                }));
            })
            .then(parsed_response => {
                context.log('Response Body:', parsed_response); // log the parsed response body
                let data = parsed_response['body'];
                let ebHref = data.href;
                // handle error cases
                if (data[0]?.token == 'input_validation_error') {
                    resolve({ href: '', data: "input_validation_error", status: parsed_response['status'] });
                }
                else if (data[0]?.token == 'rule_name_in_use') {
                    resolve({ href: '', data: "rule_name_in_use", status: parsed_response['status'] });
                }
                resolve({ href: ebHref, data: '', status: parsed_response['status'] }); // pass the parsed response to the resolve function
            })
            .catch(error => {
                context.log('error', error);
                reject(error); // return an empty error
            });
    })

}

async function provisionPolicyObject(ebHref, context) {
    if (ebHref == undefined) {
        return undefined;
    }

    return new Promise((resolve, reject) => {
        let path = `/api/v2/orgs/${ORG_ID}/sec_policy`

        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Authorization", 'Basic ' + Buffer.from(`${API_KEY}:${API_SECRET}`).toString('base64'));

        var raw = JSON.stringify({
            "update_description": `Provisioning changes from Sentinel Playbook for ${ebHref}`,
            "change_subset": { "enforcement_boundaries": [{ "href": ebHref }] }
        })

        var requestOptions = {
            method: 'POST',
            body: raw,
            headers: myHeaders,
            redirect: 'follow'
        };

        fetch(`https://${PCE_FQDN}:${PORT}${path}`, requestOptions)
            .then(response => response.json()) // parse the JSON from the response
            .then(data => {
                context.log('Response Body:', data); // log the parsed response body        
                resolve(data); // pass the parsed response to the resolve function
            })
            .catch(error => {
                context.log('error', error)
                reject(error) // return an empty error
            });
    })
}