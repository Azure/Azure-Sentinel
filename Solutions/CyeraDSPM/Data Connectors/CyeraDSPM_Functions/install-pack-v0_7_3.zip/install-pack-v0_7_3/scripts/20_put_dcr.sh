#!/usr/bin/env bash
set -euo pipefail

: "${SUBID?}"; : "${RG?}"; : "${REGION?}"; : "${WS?}"
: "${DCR_NAME?}"; : "${DCE_NAME?}"

PACK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")"/.. && pwd)"
TEMPLATE="$PACK_ROOT/dcr/dcr.v5.template.json"

api="2023-03-11"

WS_ID=$(az monitor log-analytics workspace show -g "$RG" -n "$WS" --query id -o tsv)
DCE_ID=$(az monitor data-collection endpoint show -g "$RG" -n "$DCE_NAME" --query id -o tsv)

if [[ -z "$WS_ID" || -z "$DCE_ID" ]]; then
  echo "ERROR: Could not resolve WS_ID or DCE_ID"; exit 1
fi

tmp=$(mktemp)
# Inject placeholders
sed -e "s|__WORKSPACE_RESOURCE_ID__|$WS_ID|g"     -e "s|__DCE_RESOURCE_ID__|$DCE_ID|g"     -e "s|__LOCATION__|$REGION|g"     "$TEMPLATE" > "$tmp"

# Safety: strip server-managed fields if they sneak in
jq 'del(.etag) | del(.properties.immutableId)' "$tmp" > "${tmp}.clean" && mv "${tmp}.clean" "$tmp"

echo "PUT DCR '$DCR_NAME' in $REGION ..."
az rest --method put   --uri "https://management.azure.com/subscriptions/$SUBID/resourceGroups/$RG/providers/Microsoft.Insights/dataCollectionRules/$DCR_NAME?api-version=$api"   --body @"$tmp" >/dev/null

rm -f "$tmp"
echo "Done."
