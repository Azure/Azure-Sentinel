#!/usr/bin/env bash
set -euo pipefail

# ========= Required env =========
: "${SUBID?Set SUBID (source 00_env.sh or ./.last_env)}"
: "${RG?Set RG (source 00_env.sh or ./.last_env)}"
: "${DCE_NAME?Set DCE_NAME (source 00_env.sh)}"
: "${DCR_IMMUTABLE_ID?Set DCR_IMMUTABLE_ID (run ./30_show_resources.sh then: . ./.last_env)}"

# ========= Options =========
SAMPLES_DIR="${SAMPLES_DIR:-../samples}"
ONLY=""
if [[ "${1-}" == "--only" && -n "${2-}" ]]; then
  case "$2" in
    assets|identities|issues|classifications) ONLY="$2";;
    *) echo "Invalid value for --only (use: assets|identities|issues|classifications)"; exit 2;;
  esac
fi

# ========= Discover DCE endpoint (robust) =========
DCE_ID="/subscriptions/$SUBID/resourceGroups/$RG/providers/Microsoft.Insights/dataCollectionEndpoints/$DCE_NAME"
DCE_ENDPOINT=$(
  az rest --method get \
    --url "https://management.azure.com${DCE_ID}?api-version=2023-03-11" -o json \
  | jq -r '
      if .properties.logsIngestion.endpoint then
        .properties.logsIngestion.endpoint
      elif .properties.configurationAccess.endpoint then
        (.properties.configurationAccess.endpoint | sub("handler\\.control\\.";"ingest."))
      else
        empty
      end
    '
)
DCE_ENDPOINT="${DCE_ENDPOINT%%[$'\r\n']}"
if [[ -z "$DCE_ENDPOINT" ]]; then
  echo "ERROR: Could not resolve DCE logsIngestion endpoint. Check DCE publicNetworkAccess or API version." >&2
  exit 1
fi
export DCE_ENDPOINT

# ========= Token (Monitor audience) =========
get_token() {
  az account get-access-token --resource https://monitor.azure.com --query accessToken -o tsv
}
AZURE_TOKEN="$(get_token || true)"
if [[ -z "${AZURE_TOKEN:-}" ]]; then
  echo "ERROR: Could not obtain Azure Monitor token" >&2
  exit 1
fi

# ========= Helpers =========
assert_array_file() {
  local f="$1"
  if ! jq -e 'type=="array"' "$f" >/dev/null 2>&1; then
    echo "ERROR: $f must be a top-level JSON array" >&2
    exit 1
  fi
}

do_post() {
  local stream="$1"
  local file="$2"

  local url="$DCE_ENDPOINT/dataCollectionRules/$DCR_IMMUTABLE_ID/streams/$stream?api-version=2023-01-01"
  echo "POST -> $stream"
  echo "URL  -> $url"
  echo "FILE -> $file"

  # First attempt
  local code
  code=$(curl -sS -o /dev/null -w "%{http_code}" \
    -X POST "$url" \
    -H "Authorization: Bearer $AZURE_TOKEN" \
    -H "Content-Type: application/json" \
    --data-binary @"$file" || echo "000")

  # If token expired, refresh once and retry
  if [[ "$code" == "401" ]]; then
    echo "Got 401; refreshing token and retrying once..."
    AZURE_TOKEN="$(get_token || true)"
    code=$(curl -sS -o /dev/null -w "%{http_code}" \
      -X POST "$url" \
      -H "Authorization: Bearer $AZURE_TOKEN" \
      -H "Content-Type: application/json" \
      --data-binary @"$file" || echo "000")
  fi

  echo "HTTP $code"
  if [[ "$code" != "204" ]]; then
    echo "WARNING: Non-204 for $stream (saw $code). Check DCR/DCE/role and file shape." >&2
  fi
  echo
}

# ========= Validate files =========
declare -A MAP=(
  [assets]="$SAMPLES_DIR/assets.records.json"
  [identities]="$SAMPLES_DIR/identities.records.json"
  [issues]="$SAMPLES_DIR/issues.records.json"
  [classifications]="$SAMPLES_DIR/classifications.records.json"
)
for k in assets identities issues classifications; do
  [[ -f "${MAP[$k]}" ]] || { echo "ERROR: Missing ${MAP[$k]}"; exit 1; }
  assert_array_file "${MAP[$k]}"
done

# ========= Post in requested order =========
post_assets()          { do_post "Custom-CyeraAssets"          "${MAP[assets]}"; }
post_identities()      { do_post "Custom-CyeraIdentities"      "${MAP[identities]}"; }
post_issues()          { do_post "Custom-CyeraIssues"          "${MAP[issues]}"; }
post_classifications() { do_post "Custom-CyeraClassifications" "${MAP[classifications]}"; }

if [[ -n "$ONLY" ]]; then
  "post_${ONLY}" && echo "Seed complete (only: $ONLY)."
  exit 0
fi

post_assets
post_identities
post_issues
post_classifications

echo "Seed complete."

