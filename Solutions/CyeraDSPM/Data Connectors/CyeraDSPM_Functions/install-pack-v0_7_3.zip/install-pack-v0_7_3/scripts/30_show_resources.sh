#!/usr/bin/env bash
set -euo pipefail

# Requires: SUBID, RG, DCE_NAME, DCR_NAME
: "${SUBID?}"; : "${RG?}"; : "${DCE_NAME?}"; : "${DCR_NAME?}"

DCR_ID="/subscriptions/${SUBID}/resourceGroups/${RG}/providers/Microsoft.Insights/dataCollectionRules/${DCR_NAME}"
DCE_ID="/subscriptions/${SUBID}/resourceGroups/${RG}/providers/Microsoft.Insights/dataCollectionEndpoints/${DCE_NAME}"

# ---- DCR (use API that returns immutableId reliably)
DCR_JSON=$(az rest --method get \
  --url "https://management.azure.com${DCR_ID}?api-version=2023-03-11" \
  --output json)

DCR_IMMUTABLE_ID=$(echo "$DCR_JSON" | jq -r '.properties.immutableId // empty')
DCR_DCE_ID=$(echo "$DCR_JSON" | jq -r '.properties.dataCollectionEndpointId // empty')
DCR_LOCATION=$(echo "$DCR_JSON" | jq -r '.location // empty')

echo "DCR:"
jq -n --arg dce "$DCR_DCE_ID" --arg imm "$DCR_IMMUTABLE_ID" --arg loc "$DCR_LOCATION" \
  '{dce:$dce, immutableId:$imm, location:$loc}'
echo

# ---- DCE (stable API; derive logs endpoint if missing)
DCE_JSON=$(az rest --method get \
  --url "https://management.azure.com${DCE_ID}?api-version=2023-03-11" \
  --output json)

DCE_HANDLER=$(echo "$DCE_JSON" | jq -r '.properties.configurationAccess.endpoint // empty')
DCE_LOGS=$(echo "$DCE_JSON"    | jq -r '.properties.logsIngestion.endpoint // empty')
DCE_LOCATION=$(echo "$DCE_JSON"| jq -r '.location // empty')
DCE_PNA=$(echo "$DCE_JSON"     | jq -r '.properties.networkAcls.publicNetworkAccess // empty')

# Fallback: derive logs ingestion endpoint from handler if logs is null
if [[ -z "$DCE_LOGS" ]]; then
  if [[ -n "$DCE_HANDLER" ]]; then
    DCE_ENDPOINT="${DCE_HANDLER/handler.control./ingest.}"
  else
    DCE_ENDPOINT=""
  fi
else
  DCE_ENDPOINT="$DCE_LOGS"
fi

echo "DCE:"
jq -n --arg endpoint "$DCE_ENDPOINT" --arg loc "$DCE_LOCATION" --arg pna "$DCE_PNA" \
  '{endpoint:$endpoint, location:$loc, publicNetworkAccess:$pna}'
echo

# ---- Guard: fail early if we couldn't resolve the two critical values
if [[ -z "${DCR_IMMUTABLE_ID}" ]]; then
  echo "ERROR: DCR immutableId is empty. Verify the DCR exists and API version." >&2
  exit 1
fi
if [[ -z "${DCE_ENDPOINT}" ]]; then
  echo "ERROR: DCE logsIngestion endpoint is empty. Check public network access or use correct API version." >&2
  exit 1
fi

# ---- Helpful exports for current shell
echo "export DCR_IMMUTABLE_ID=$DCR_IMMUTABLE_ID"
echo "export DCE_ENDPOINT=$DCE_ENDPOINT"

# ---- Persist for future shells
{
  echo "export DCR_IMMUTABLE_ID=$DCR_IMMUTABLE_ID"
  echo "export DCE_ENDPOINT=$DCE_ENDPOINT"
} > .last_env
echo "Wrote exports to .last_env  (load with:  . ./.last_env )"

