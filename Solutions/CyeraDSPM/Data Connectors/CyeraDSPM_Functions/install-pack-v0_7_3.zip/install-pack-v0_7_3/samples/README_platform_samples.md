# Databricks & Snowflake Sample Assets (manual push)

This folder contains **realistic example assets** for Databricks and Snowflake that map cleanly into the
existing transforms (MS projection + Extended) and can be ingested via **Logs Ingestion**.

## Files
- `databricks_sample.json` — workspace, catalog, schema, table, cluster
- `snowflake_sample.json` — account, database, schema, table, stage
- `assets.records.json` - 100 sample records de-identified
- `classifications.records.json` - 100 sample records de-identified
- `identities.records.json` - 100 sample records de-identified
- `issues.records.json` - 100 sample records de-identified

## Quick start
```bash
# One-off push from Cloud Shell
DCE_ENDPOINT="https://<dce-name>.<region>-1.ingest.monitor.azure.com"
DCR_IMMUTABLE_ID="dcr-<immutable-id>"

Ensure that the environment settings are correctly set.
Use the 30_show_resources.sh file in the scripts folder to ensure these are set
Confirm that data is shown for all variables

## Set permissions
Permissions must be assigned to the current user for the curl command. This must be set for the DCR & DCE
These can be added via the IAM configuration section for both.
Add the user with the 'Monitoring Metrics Publisher' permissions as this is what is used for the sending of events
Propagation may take several minutes to complete

## Sending events
Use the 40_seed_samples.sh script to send the events.
The script only processes the 4 types of event data, Assets, Identities, Classifications & Issues
It does not automatically process the Snowflake or Databricks sample events.
Either utilize a direct curl command for this, or change the names when needed

Rename the assets.records.json file to assets.records.json.bak
Rename the snowflake_sample.json to assets.records.json and then use script to process them

## Notes
- These records include the fields our transforms expect (`engine`, `regions`, `issues`, `recordCountBySensitivity`, etc.).
- `provider` is set to `"databricks"` or `"snowflake"`; that value shows up in the **Extended** view’s `provider` column.
- If your DCR’s `streamDeclarations` or transforms differ, adjust field names accordingly or let me know and I'll adapt the samples.
