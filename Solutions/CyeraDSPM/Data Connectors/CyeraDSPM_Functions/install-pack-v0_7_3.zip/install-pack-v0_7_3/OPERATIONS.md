# Operations

## Retention
- Start with 30–90 days on raw tables.
- Keep MS view for the horizon of dashboards using it.

## Auth & tokens
- Always request token for **https://monitor.azure.com** (not management).
- POST in chunks (0.5–2 MB) to avoid 413.

## Retry & backoff
- Retry 5xx with exponential backoff (cap ~60s).
- Obey 429 `Retry-After`.
- Do not retry other 4xx without fixing.

## Idempotency
- Re-posts create duplicates; dedupe in KQL by `uid` with `arg_max(ingestion_time(), *)` when needed.

## Change management
- New nested fields? Mark them `dynamic` in input streamDeclarations; passthrough continues to work.
- Avoid renaming columns; if needed, add new columns and project both for a period.
