# Troubleshooting

## 204 but no rows
- Token audience must be **https://monitor.azure.com**
- POST body must be a **top-level JSON array** of records
- DCR must link to a DCE: `properties.dataCollectionEndpointId` (with **Id**) must be non-null
- DCE must expose an endpoint: `properties.logsIngestion.endpoint` must be non-null
- Transforms must start with `source`
- Output streams must be `Custom-<TableName_CL>` and those tables must exist
- In `streamDeclarations`, use `boolean` (not `bool`)

## InvalidOutputTable / InvalidStream
- Tables are named `<Name>_CL` (no “Custom-”).
- `outputStream` must be `Custom-<ExactTableName_CL>`, e.g. `Custom-CyeraAssets_v5_CL`.

## DCR refuses to keep DCE link
- Use **api-version = 2023-03-11** for DCR PUT/PATCH.
- Property name must be `dataCollectionEndpointId`.

## KQL compile error: “extraneous input '|'”
- Your `transformKql` must start with `source` (first non-comment, non-empty line).

## KQL compile error: specific field undefined
- The transform references a field not in your input stream. Use only declared fields.

## Duplicates
- Reposts create duplicates; dedupe in KQL by `uid` with `arg_max(ingestion_time(), *)` if needed.
