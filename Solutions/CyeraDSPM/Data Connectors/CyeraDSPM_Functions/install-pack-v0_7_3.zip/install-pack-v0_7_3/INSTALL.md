# Cyera DSPM for Microsoft Sentinel — v5 Install Pack

This pack deploys the v5 integration using **DCE + DCR (Direct)** and custom **Log Analytics tables**.
Please follow the steps in the CyeraConnector folder for the Azure Function install

## Prereqs
- Azure CLI (`az`) logged in
- Logged in 'az' session might expire before install is finished - if odd errors occur, use 'az login'
- `jq` installed
- Existing Log Analytics Workspace - create this via the Azure Portal UI

## 1) Configure env
```bash
cd scripts
EDITOR=<your editor of choice like vi / nano>
cp 00_env.sample 00_env.sh && $EDITOR 00_env.sh
chmod +x 00_env.sh
source ./00_env.sh
```

## 2) Create/Update tables
```bash
./10_put_tables.sh
```
- Any errors at this stage can create incomplete tables
- Tables can be deleted via the UI for the Log Analytics workspace

## 3) Create/Update DCR (Direct)

- Data Collection Endpoint must be created before the next step:

az monitor data-collection endpoint create \
  -g "$RG" -n "$DCE_NAME" -l "$REGION" \
  --public-network-access Enabled

- Verify this is completed successfully. It is important to do this manually
- Use the following command to check (not API version - incorrect version will not return data)

az rest --method get \
  --url "https://management.azure.com${DCE_ID}?api-version=2023-03-11" \
  --query "properties.configurationAccess.endpoint" -o tsv)

```bash
./20_put_dcr.sh
```

## 4) Verify resources
```bash
./30_show_resources.sh
```
Ensure:
- `immutableId` is non-empty
- `dataCollectionEndpointId` shows your DCE ARM ID
- DCE `logsIngestion.endpoint` is a real URL
- once run, the shell script will produce a .last_env file containing any corrected data
- Contains DCR_IMMUTABLE_ID and DCE_ENDPOINT - retrieved from platform
- apply the updated using 'source .last_env' to ensure all variables are set


## 5) (Optional) Seed sample data

- Warning, must set permissions for local user in bash shell to have permissions for DCE
- Must have "Monitoring Metrics Publisher", but this can be removed later when testing finished
- Use following commands to assign local logged in user to the DCR scope

# IDs
SUBID=$(az account show --query id -o tsv)
DCR_ID="/subscriptions/$SUBID/resourceGroups/$RG/providers/Microsoft.Insights/dataCollectionRules/$DCR_NAME"

# Who am I?
ME=$(az ad signed-in-user show --query id -o tsv)

# Assign role at the DCR scope
az role assignment create \
  --assignee "$ME" \
  --role "Monitoring Metrics Publisher" \
  --scope "$DCR_ID"

```bash
./40_seed_samples.sh
```

- The posts of the sample events may result in a 403 error. Most likely this is an RBAC issue.
- Wait for the permission to propagate. This can take upwards of 20 minutes.
- Expect to see a 204 code when pushed correctly

## 6) Validate in Logs
Open `scripts/50_verify.kql` and run the queries in the Logs blade.

- For the initial push of the sample data, or the Azure Function to run, it can take 15 minutes or more to fill the tables
- Wait for the tables to be populated if the KQL queries return nothing at first.
- Additionally, ensure you use the ingestion_time option:

CyeraAssets_MS_CL
| where ingestion_time () > ago(30m)
