# Cyera DSPM Sentinel Integration — Changelog

This changelog tracks major updates to the Cyera DSPM connector and deployment packages for Microsoft Sentinel.

---
## [v7.0.3] — 2025-Oct-29
**Status:** Current (Active)
### Highlights
- Corrected field for FeedType
  - Changed from Snapshot to Changefeed to reflect clarification on type
- Updated KQL for the ms_assets-v5.kql file, was incorrectly the older version
  - Correct updated one reflecting the 3 new fields added

---

## [v7.0.2] — 2025-Oct-28
**Status:** Out of date (Inactive)
### Highlights
- Introduced **Extended CyeraAssets_MS_CL table**:
  - `CyeraAssets_MS_CL` (normalized “MS view”)
  - Three additional fields added to the table - AADTenantID, IsAssetRemoved, FeedType
  - Used to indicate additional state of the asset for use with other components
- Delivered new **install-pack-v0_7_2** with:
  - Updates to scripts (`30_show_resources.sh, 40_seed_samples.sh`)
  - Stronger testing & verification of settings for scripts with more error messages
  - Dynamic **DCR template** (kind: Direct)
  - DCR template update incorporates the updated table schema
- Added fixed API versions for certain tasks - some versions do not operate correctly.
  - 2023-03-11 (DCR/DCE), 2022-10-01 (Tables), 2023-01-01 (Ingest) - now hard coded to scripts

---

## [v7.0.1] — 2025-Oct-23
**Status:** Out of date (Inactive)
### Highlights
- Introduced **v5 Log Analytics tables**:
  - `CyeraAssets_CL`
  - `CyeraIdentities_CL`
  - `CyeraIssues_CL`
  - `CyeraClassifications_CL`
  - `CyeraAssets_MS_CL` (normalized “MS view”)
  - This is used to bring the Azure Function connector to use the same tables as the CCF one
  - This allows both connectors to use the same set of tables
- Delivered new **install-pack-v0_7_1** with:
  - Updates to scripts (`00_env.sample`, `10_put_tables.sh`, `20_put_dcr.sh`, etc.)
  - Dynamic **DCR template** (kind: Direct)
- Added **CHANGELOG.md**, **README.md** deprecation stubs for legacy folders.

---

## [v7.0.0] — 2025-Oct-18
**Status:** Out of date (Inactive)
### Highlights
- Added full support for **two ingestion mechanisms**:
  - **Codeless Connector Framework (CCF)** — Microsoft Sentinel native ingestion connector.
  - **Azure Function + DCR/DCE (Direct)** — Lightweight function-based ingestion via the Azure Monitor Logs Ingestion API.
- Introduced **v5 Log Analytics tables**:
  - `CyeraAssets_v5_CL`
  - `CyeraIdentities_v5_CL`
  - `CyeraIssues_v5_CL`
  - `CyeraClassifications_v5_CL`
  - `CyeraAssets_MS_v5_CL` (normalized “MS view”)
- Provided unified documentation and automation for both ingestion options.
- Delivered new **install-pack-v0_7_0** with:
  - Parametric scripts (`00_env.sample`, `10_put_tables.sh`, `20_put_dcr.sh`, etc.)
  - Dynamic **DCR template** (kind: Direct)
  - Reference KQL transforms and sample payloads
  - Troubleshooting, operations, and workbook guidance
- Added **CHANGELOG.md**, **README.md** deprecation stubs for legacy folders.

---

## [v6.0.0] — 2024-Sept
**Status:** Previous generation (Maintenance)
### Summary
- Introduced the **Codeless Connector Framework (CCF)** connector.
- Added early support for v5 table naming but limited schema coverage.
- Provided baseline Bicep deployment automation (legacy `infra/` folder).

---

## Migration Notes
- v6 → v7: No data model changes; simply adopt the updated deployment scripts or CCF option.
- The **Azure Function** and **CCF** connectors share the same tables structures and can coexist if configured for separate tenants or environments.

---

**Repository structure since v7:**
