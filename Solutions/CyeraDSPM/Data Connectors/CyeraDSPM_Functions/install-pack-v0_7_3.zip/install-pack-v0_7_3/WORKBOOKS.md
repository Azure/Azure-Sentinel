# Workbook Panels (starter KQL)

## Sensitivity totals (from dynamic bag)
```kusto
CyeraAssets_CL
| extend rc=todynamic(recordCountBySensitivity)
| mv-apply k = bag_keys(rc) on (project k, v = tolong(rc[k]))
| summarize total = sum(v) by k
| order by total desc
```

## Issues trend by severity (14d)
```kusto
CyeraIssues_CL
| where ingestion_time() > ago(14d)
| summarize count() by bin(TimeGenerated, 1d), severity
| order by TimeGenerated asc
```

## MS view: top risky workloads
```kusto
CyeraAssets_MS_CL
| where ingestion_time() > ago(7d)
| summarize totalRisks=sum(Risks) by Workload, SubWorkload
| top 10 by totalRisks desc
```
