# v5 Table Schemas

Place your validated table JSONs here, named exactly:
- CyeraAssets_v5_CL.json
- CyeraIdentities_v5_CL.json
- CyeraIssues_v5_CL.json
- CyeraClassifications_v5_CL.json
- CyeraAssets_MS_v5_CL.json

These files are workspace-agnostic and safe to commit.
Use `scripts/10_put_tables.sh` to create/update in your target workspace.
