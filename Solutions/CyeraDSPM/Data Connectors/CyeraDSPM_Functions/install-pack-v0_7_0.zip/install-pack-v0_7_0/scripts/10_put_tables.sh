#!/usr/bin/env bash
set -euo pipefail

: "${SUBID?}"; : "${RG?}"; : "${WS?}"; : "${TABLES_DIR:=../tables}"

api="2022-10-01"
base="https://management.azure.com/subscriptions/$SUBID/resourceGroups/$RG/providers/Microsoft.OperationalInsights/workspaces/$WS/tables"

tables=(   "CyeraAssets_v5_CL"   "CyeraIdentities_v5_CL"   "CyeraIssues_v5_CL"   "CyeraClassifications_v5_CL"   "CyeraAssets_MS_v5_CL" )

echo "Putting tables into workspace '$WS'..."
for t in "${tables[@]}"; do
  body="$TABLES_DIR/$t.json"
  if [[ ! -f "$body" ]]; then
    echo "ERROR: Missing table JSON: $body" >&2; exit 1
  fi
  echo "  -> $t"
  az rest --method put     --uri "$base/$t?api-version=$api"     --body @"$body" >/dev/null
done
echo "Done."
