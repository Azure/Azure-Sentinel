#!/usr/bin/env bash
set -euo pipefail

: "${RG?}"; : "${DCR_NAME?}"; : "${DCE_NAME?}"

echo "DCR:"
az monitor data-collection rule show -g "$RG" -n "$DCR_NAME"   --query "{immutableId:properties.immutableId, dce:properties.dataCollectionEndpointId, location:location}" -o jsonc

echo -e "\nDCE:"
az monitor data-collection endpoint show -g "$RG" -n "$DCE_NAME"   --query "{endpoint:properties.logsIngestion.endpoint, publicNetworkAccess:properties.networkAcls.publicNetworkAccess, location:location}" -o jsonc

# Persist DCR immutableId to local env if present
DCR_IMM=$(az monitor data-collection rule show -g "$RG" -n "$DCR_NAME" --query properties.immutableId -o tsv)
if [[ -n "$DCR_IMM" ]]; then
  if [[ -f "./00_env.sh" ]]; then
    if grep -q "^export DCR_IMMUTABLE_ID=" ./00_env.sh; then
      sed -i.bak "s|^export DCR_IMMUTABLE_ID=.*|export DCR_IMMUTABLE_ID=\"$DCR_IMM\"|" ./00_env.sh
    else
      echo "export DCR_IMMUTABLE_ID=\"$DCR_IMM\"" >> ./00_env.sh
    fi
    echo "Updated 00_env.sh with DCR_IMMUTABLE_ID=$DCR_IMM"
  else
    echo "DCR_IMMUTABLE_ID=$DCR_IMM  (export this before seeding)"
  fi
fi
