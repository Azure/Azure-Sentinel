# Workbook Panels (KQL)

## Sensitivity totals (from dynamic bag)
```kusto
CyeraAssets_v5_CL
| extend rc=todynamic(recordCountBySensitivity)
| mv-apply k = bag_keys(rc) on (project k, v = tolong(rc[k]))
| summarize total = sum(v) by k
| order by total desc


Issues trend by severity (14d)
CyeraIssues_v5_CL
| where ingestion_time() > ago(14d)
| summarize count() by bin(TimeGenerated, 1d), severity
| order by TimeGenerated asc


MS view: top risky workloads
CyeraAssets_MS_v5_CL
| where ingestion_time() > ago(7d)
| summarize totalRisks=sum(Risks) by Workload, SubWorkload
| top 10 by totalRisks desc
