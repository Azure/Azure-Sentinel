#!/usr/bin/env bash
set -euo pipefail

# Requires: SUBID, RG, REGION, DCE_NAME, DCR_NAME
: "${SUBID?}"; : "${RG?}"; : "${DCE_NAME?}"; : "${DCR_NAME?}"

DCR_ID="/subscriptions/${SUBID}/resourceGroups/${RG}/providers/Microsoft.Insights/dataCollectionRules/${DCR_NAME}"
DCE_ID="/subscriptions/${SUBID}/resourceGroups/${RG}/providers/Microsoft.Insights/dataCollectionEndpoints/${DCE_NAME}"

# --- DCR (use GA API that returns immutableId & endpoint link)
DCR_JSON=$(az rest --method get \
  --url "https://management.azure.com${DCR_ID}?api-version=2022-06-01" \
  --output json)

DCR_IMMUTABLE_ID=$(echo "$DCR_JSON" | jq -r '.properties.immutableId // empty')
DCR_DCE_ID=$(echo "$DCR_JSON" | jq -r '.properties.dataCollectionEndpointId // empty')
DCR_LOCATION=$(echo "$DCR_JSON" | jq -r '.location')

echo "DCR:"
jq -n --arg dce "$DCR_DCE_ID" --arg imm "$DCR_IMMUTABLE_ID" --arg loc "$DCR_LOCATION" '
  {dce:$dce, immutableId:$imm, location:$loc}
'
echo

# --- DCE (use newer API; derive logs endpoint if missing)
DCE_JSON=$(az rest --method get \
  --url "https://management.azure.com${DCE_ID}?api-version=2023-03-11" \
  --output json)

DCE_HANDLER=$(echo "$DCE_JSON" | jq -r '.properties.configurationAccess.endpoint // empty')
DCE_LOGS=$(echo "$DCE_JSON" | jq -r '.properties.logsIngestion.endpoint // empty')
DCE_LOCATION=$(echo "$DCE_JSON" | jq -r '.location')
DCE_PNA=$(echo "$DCE_JSON" | jq -r '.properties.networkAcls.publicNetworkAccess // empty')

# Fallback: derive logs ingestion endpoint from handler if logs is null
if [[ -z "$DCE_LOGS" || "$DCE_LOGS" == "null" ]]; then
  if [[ -n "$DCE_HANDLER" && "$DCE_HANDLER" != "null" ]]; then
    DCE_ENDPOINT="${DCE_HANDLER/handler.control./ingest.}"
  else
    DCE_ENDPOINT=""
  fi
else
  DCE_ENDPOINT="$DCE_LOGS"
fi

echo "DCE:"
jq -n --arg endpoint "$DCE_ENDPOINT" --arg loc "$DCE_LOCATION" --arg pna "$DCE_PNA" '
  {endpoint:$endpoint, location:$loc, publicNetworkAccess:$pna}
'
echo

# Helpful exports for next steps (copy-paste if desired)
if [[ -n "${DCR_IMMUTABLE_ID:-}" ]]; then
  echo "export DCR_IMMUTABLE_ID=$DCR_IMMUTABLE_ID"
fi
if [[ -n "${DCE_ENDPOINT:-}" ]]; then
  echo "export DCE_ENDPOINT=$DCE_ENDPOINT"
fi

