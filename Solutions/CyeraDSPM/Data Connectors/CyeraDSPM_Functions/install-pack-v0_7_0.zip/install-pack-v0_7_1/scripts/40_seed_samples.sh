#!/usr/bin/env bash
set -euo pipefail

: "${SAMPLES_DIR:=../samples}"; : "${DCR_IMMUTABLE_ID?}"; : "${RG?}"; : "${DCE_NAME?}"

DCE_ENDPOINT=$(az monitor data-collection endpoint show -g "$RG" -n "$DCE_NAME"   --query "properties.logsIngestion.endpoint" -o tsv)
if [[ -z "$DCE_ENDPOINT" ]]; then
  echo "ERROR: DCE endpoint is empty; check public access / private link."; exit 1
fi

AZURE_TOKEN=$(az account get-access-token --resource https://monitor.azure.com --query accessToken -o tsv)
if [[ -z "$AZURE_TOKEN" ]]; then
  echo "ERROR: Could not obtain monitor token"; exit 1
fi

post() {
  local stream="$1"; local file="$2"
  echo "POST -> $stream  ($file)"
  curl -sS -o /dev/null -w "HTTP %{http_code}\n"     -X POST "$DCE_ENDPOINT/dataCollectionRules/$DCR_IMMUTABLE_ID/streams/$stream?api-version=2023-01-01"     -H "Authorization: Bearer $AZURE_TOKEN"     -H "Content-Type: application/json"     --data-binary @"$file"
}

for f in assets.records.json identities.records.json issues.records.json classifications.records.json; do
  if ! jq -e 'type=="array"' "$SAMPLES_DIR/$f" >/dev/null; then
    echo "ERROR: $f must be a top-level JSON array"; exit 1
  fi
done

post "Custom-CyeraAssets"          "$SAMPLES_DIR/assets.records.json"
post "Custom-CyeraIdentities"      "$SAMPLES_DIR/identities.records.json"
post "Custom-CyeraIssues"          "$SAMPLES_DIR/issues.records.json"
post "Custom-CyeraClassifications" "$SAMPLES_DIR/classifications.records.json"

echo "Seed complete."
