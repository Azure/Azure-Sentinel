# Cyera DSPM Sentinel Integration — Changelog

This changelog tracks major updates to the Cyera DSPM connector and deployment packages for Microsoft Sentinel.

---

## [v7.1.0] — 2025-Oct-23
**Status:** Current (Active)
### Highlights
- Introduced **v5 Log Analytics tables**:
  - `CyeraAssets_CL`
  - `CyeraIdentities_CL`
  - `CyeraIssues_CL`
  - `CyeraClassifications_CL`
  - `CyeraAssets_MS_CL` (normalized “MS view”)
  - This is used to bring the Azure Function connector to use the same tables as the CCF one
  - This allows both connectors to use the same set of tables
- Delivered new **install-pack-v0_7_1** with:
  - Updates to scripts (`00_env.sample`, `10_put_tables.sh`, `20_put_dcr.sh`, etc.)
  - Dynamic **DCR template** (kind: Direct)
- Added **CHANGELOG.md**, **README.md** deprecation stubs for legacy folders.

---

## [v7.0.0] — 2025-Oct-18
**Status:** Current (Active)
### Highlights
- Added full support for **two ingestion mechanisms**:
  - **Codeless Connector Framework (CCF)** — Microsoft Sentinel native ingestion connector.
  - **Azure Function + DCR/DCE (Direct)** — Lightweight function-based ingestion via the Azure Monitor Logs Ingestion API.
- Introduced **v5 Log Analytics tables**:
  - `CyeraAssets_v5_CL`
  - `CyeraIdentities_v5_CL`
  - `CyeraIssues_v5_CL`
  - `CyeraClassifications_v5_CL`
  - `CyeraAssets_MS_v5_CL` (normalized “MS view”)
- Provided unified documentation and automation for both ingestion options.
- Delivered new **install-pack-v0_7_0** with:
  - Parametric scripts (`00_env.sample`, `10_put_tables.sh`, `20_put_dcr.sh`, etc.)
  - Dynamic **DCR template** (kind: Direct)
  - Reference KQL transforms and sample payloads
  - Troubleshooting, operations, and workbook guidance
- Added **CHANGELOG.md**, **README.md** deprecation stubs for legacy folders.

---

## [v6.0.0] — 2024-Sept
**Status:** Previous generation (Maintenance)
### Summary
- Introduced the **Codeless Connector Framework (CCF)** connector.
- Added early support for v5 table naming but limited schema coverage.
- Provided baseline Bicep deployment automation (legacy `infra/` folder).

---

## Migration Notes
- v6 → v7: No data model changes; simply adopt the updated deployment scripts or CCF option.
- The **Azure Function** and **CCF** connectors share the same tables structures and can coexist if configured for separate tenants or environments.

---

**Repository structure since v7:**
