# Databricks & Snowflake Sample Assets (manual push)

This folder contains **realistic example assets** for Databricks and Snowflake that map cleanly into the
existing transforms (MS projection + Extended) and can be ingested via **Logs Ingestion**.

## Files
- `databricks.assets.sample.json` — workspace, catalog, schema, table, cluster
- `snowflake.assets.sample.json` — account, database, schema, table, stage
- `push_any.sh` — generic helper to POST any JSON array file to a specific stream

## Canonical source stream
Use the **assets** source stream:
- `Custom-CyeraAssets_SRC`

## Quick start
```bash
# One-off push from Cloud Shell
DCE="https://<dce-name>.<region>-1.ingest.monitor.azure.com"
DCR="dcr-<immutable-id>"

# Databricks
./push_any.sh "$DCE" "$DCR" "Custom-CyeraAssets_SRC" < databricks.assets.sample.json

# Snowflake
./push_any.sh "$DCE" "$DCR" "Custom-CyeraAssets_SRC" < snowflake.assets.sample.json
```

## Notes
- These records include the fields our transforms expect (`engine`, `regions`, `issues`, `recordCountBySensitivity`, etc.).
- `provider` is set to `"databricks"` or `"snowflake"`; that value shows up in the **Extended** view’s `provider` column.
- If your DCR’s `streamDeclarations` or transforms differ, adjust field names accordingly or let me know and I'll adapt the samples.
