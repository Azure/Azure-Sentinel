import logging
import azure.functions as func

async def main(mytimer: func.TimerRequest):
    logging.info("Creating SQS connection")
