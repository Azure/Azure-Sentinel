"""Upwind API client for fetching threat detections."""

import logging
from datetime import datetime

from .upwind_client import (
    UpwindClient,
    rename_reserved_columns,
    severities_at_least,
)

# "title" and "type" are reserved/invalid Log Analytics custom-table column
# names, so they're renamed before upload. The DCR/table schema uses the
# renamed names.
_COLUMN_RENAME_MAP = {"title": "title_text", "type": "event_type"}


class UpwindThreatDetectionsClient(UpwindClient):
    """Client for the Upwind threat detections API."""

    def fetch_threat_detections(
        self, window_start: datetime, window_end: datetime, on_page
    ) -> int:
        """
        Fetch threat detections last seen within the run's time window.

        :param window_start: Start of the run's time window, shared by every
            dataset in the run.
        :param window_end: End of the run's time window (when the run started).
        :param on_page: Callback invoked with each page of threat detections.
        :return: Total number of threat detections fetched.
        :raises RuntimeError: If the API returns errors after exhausting retries.
        """

        url = f"{self.api_base_url}/v1/organizations/{self.org_id}/threat-detections"
        time_fmt = "%Y-%m-%dT%H:%M:%SZ"

        params = {
            "per-page": self.page_size,
            "min-last-seen-time": window_start.strftime(time_fmt),
            "max-last-seen-time": window_end.strftime(time_fmt),
        }

        # Unlike threat events, this endpoint validates `severity` as a single
        # enum value rather than splitting it, so a comma-separated list is
        # rejected with a 400. Filter on the way out instead, which also avoids
        # depending on whether the parameter means "exactly" or "at least".
        severities = severities_at_least(
            self.config.get("upwind_min_severity_threat_detections")
        )
        if severities:
            logging.info(
                "Filtering threat detections to severities: %s", ", ".join(severities)
            )

        def emit(items):
            if severities:
                items = [
                    item
                    for item in items
                    if str(item.get("severity", "")).strip().lower() in severities
                ]
            on_page(rename_reserved_columns(items, _COLUMN_RENAME_MAP))

        total = self._fetch_page_paginated(url, params, emit)
        logging.info("Fetched %d total threat detections.", total)
        return total
