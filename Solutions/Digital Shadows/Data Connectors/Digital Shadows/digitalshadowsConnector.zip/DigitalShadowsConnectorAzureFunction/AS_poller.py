""" polls data from azure sentinel incidents to DS """

class poller:
    pass