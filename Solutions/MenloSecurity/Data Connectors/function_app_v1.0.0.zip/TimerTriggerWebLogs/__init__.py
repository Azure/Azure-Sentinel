import azure.functions as func
from ..shared_code.base_log_trigger import run_log_processing

_FIELD_RENAMES = {
    'content-type': 'content_type',
    'user-agent': 'user_agent',
    'x-client-country': 'x_client_country',
    'x-client-ip': 'x_client_ip',
}

# Fields that the Menlo Log Fetch API may return either as a single string or as
# an array of strings. They are backed by multi-value dimensions in the source
# datasource (pnr_page_request), so a record with one value arrives as a scalar
# string and a record with several arrives as an array. Normalise the scalar case
# to a single-element array so the ingested schema is consistently an array.
_ARRAY_FIELDS = {
    # Destination / resource / group fields (already normalised historically)
    'resource', 'dst', 'groups', 'groupsMatched',
    # Category / risk classifications
    'categories', 'threats', 'threat_types',
    # Policy enforcement
    'pe_reason', 'pe_rulename',
    # Google Push (Menlo File REST API) inspection
    'gpush_changes',
    # Votiro CDR
    'votiro_cdr_changes',
    # Sandbox / HEAT Shield
    'sandboxActivity', 'ra_rule_id',
    # Proxy service events
    'proxyEventType', 'proxyEventDetail',
}

def _transform_web_events(events):
    result = []
    for event in events:
        transformed = {_FIELD_RENAMES.get(k, k): v for k, v in event.items()}
        for field in _ARRAY_FIELDS:
            if field in transformed and isinstance(transformed[field], str):
                transformed[field] = [transformed[field]]
        result.append(transformed)
    return result

def main(timer: func.TimerRequest) -> None:
    run_log_processing(timer, log_type="web", stream_name="Custom-MenloWeb", events_transform=_transform_web_events)
