import os
import logging

from azure.identity import ManagedIdentityCredential
from azure.monitor.ingestion import LogsIngestionClient
from azure.core.exceptions import HttpResponseError

class SentinelConnector:
    """
    Handles formatting and sending data to Azure Log Analytics via the Log Ingestion API.
    """

    def __init__(self, dce_ingestion_url: str, dcr_immutable_id: str, stream_name: str):
        """
        Initializes the SentinelConnector for the Log Ingestion API.

        Args:
            dce_ingestion_url: The full logs ingestion endpoint URL from the Data Collection Endpoint (DCE).
            dcr_immutable_id: The immutable ID of the Data Collection Rule (DCR).
            stream_name: The name of the stream in the DCR to send data to.
        """
        if not all([dce_ingestion_url, dcr_immutable_id, stream_name]):
            raise ValueError("DCE URL, DCR ID, and Stream Name must all be provided.")

        self.dcr_immutable_id = dcr_immutable_id
        self.stream_name = stream_name
        
        credential = ManagedIdentityCredential()
        self.client = LogsIngestionClient(endpoint=dce_ingestion_url, credential=credential, logging_enable=True)

    def send_logs(self, logs: list):
        """
        Sends a list of log events to the Log Ingestion API.

        Args:
            logs: A list of log event dictionaries.
        """
        if not logs:
            logging.info("No logs to send to Sentinel.")
            return

        try:
            self.client.upload(rule_id=self.dcr_immutable_id, stream_name=self.stream_name, logs=logs)
            logging.info(f"Successfully sent {len(logs)} events to DCR stream '{self.stream_name}'.")
        except HttpResponseError as e:
            logging.error(f"Error sending logs to Log Ingestion API: {e}", exc_info=True)
            raise
