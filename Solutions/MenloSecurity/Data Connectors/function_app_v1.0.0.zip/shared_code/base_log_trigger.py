import logging
import time
import datetime
import os
import json
import pathlib
import concurrent.futures
import contextvars
import azure.functions as func

# Import shared code using relative imports
from .state_manager import StateManager
from .menlo_api import MenloApiClient
from .sentinel import SentinelConnector

# Suppress verbose Azure SDK logging.
logging.getLogger('azure.core.pipeline.policies.http_logging_policy').setLevel(logging.WARNING)

def _fmt(ts: int) -> str:
    return datetime.datetime.utcfromtimestamp(ts).strftime('%Y-%m-%dT%H:%M:%SZ')

def process_chunk(menlo_client, sentinel_connector, log_type, start_time, end_time, events_transform=None):
    logging.info(f"Processing sub-interval: {_fmt(start_time)} to {_fmt(end_time)}")
    logs = menlo_client.fetch_logs(
        log_type=log_type,
        start_time=start_time,
        end_time=end_time
    )
    if logs:
        if events_transform:
            logs = events_transform(logs)
        sentinel_connector.send_logs(logs)
    else:
        logging.info(f"No new '{log_type}' logs found for sub-interval {_fmt(start_time)} to {_fmt(end_time)}.")

def run_log_processing(timer: func.TimerRequest, log_type: str, stream_name: str, events_transform=None) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if timer.past_due:
        logging.info('The timer is past due!')

    # Load configuration
    # Assumes config.json is in the same directory as this file (shared_code)
    config_path = pathlib.Path(__file__).parent / "config.json"
    with open(config_path, "r") as f:
        full_config = json.load(f)

    function_config = full_config.get(log_type, {})
    prefix = log_type.upper()
    INITIAL_LOOKBACK_MINUTES = int(os.environ.get(f"{prefix}_INITIAL_LOOKBACK_MINUTES", function_config.get("INITIAL_LOOKBACK_MINUTES", 43200)))
    CHUNK_SIZE_MINUTES = int(os.environ.get(f"{prefix}_CHUNK_SIZE_MINUTES", function_config.get("CHUNK_SIZE_MINUTES", 3)))
    LAG_TIME_MINUTES = int(os.environ.get(f"{prefix}_LAG_TIME_MINUTES", function_config.get("LAG_TIME_MINUTES", 3)))
    MAX_THREADS = int(os.environ.get(f"{prefix}_MAX_THREADS", function_config.get("MAX_THREADS", 1)))
    DEPLOYMENT_VERSION = function_config.get("DEPLOYMENT_VERSION", "unknown")
    
    STATE_BLOB_NAME = f"last_sync_{log_type}.txt"

    logging.info(f'Starting "{log_type}" log processing job at %s (Version: {DEPLOYMENT_VERSION})', utc_timestamp)
    logging.info(f"Config: INITIAL_LOOKBACK_MINUTES={INITIAL_LOOKBACK_MINUTES}, CHUNK_SIZE_MINUTES={CHUNK_SIZE_MINUTES}, "
                 f"LAG_TIME_MINUTES={LAG_TIME_MINUTES}, MAX_THREADS={MAX_THREADS}")

    try:
        # 1. Initialize managers
        container_name = "menlo-log-state" # As defined in local.settings.json
        state_manager = StateManager(container_name=container_name, blob_name=STATE_BLOB_NAME)
        menlo_client = MenloApiClient()
        sentinel_connector = SentinelConnector(
            dce_ingestion_url=os.environ.get('DceLogsIngestionUrl'),
            dcr_immutable_id=os.environ.get('DcrImmutableId'),
            stream_name=stream_name
        )

        # 2. Determine time range
        # Stop N minutes before current time to ensure logs are available
        final_end_time = int(time.time()) - (LAG_TIME_MINUTES * 60)
        start_time = state_manager.get_last_sync_timestamp()

        if start_time is None:
            start_time = final_end_time - (INITIAL_LOOKBACK_MINUTES * 60)
            logging.info(f"No last sync timestamp found. Starting initial run from {_fmt(start_time)} to {_fmt(final_end_time)}.")
        else:
            logging.info(f"Found last sync timestamp. Fetching logs from {_fmt(start_time)} to {_fmt(final_end_time)}.")
        
        chunk_seconds = CHUNK_SIZE_MINUTES * 60
        current_start = start_time

        while current_start < final_end_time:
            current_end = min(current_start + chunk_seconds, final_end_time)
            logging.info(f"Processing chunk: {_fmt(current_start)} to {_fmt(current_end)}")

            # Divide current chunk into sub-intervals for threading
            chunk_duration = current_end - current_start
            actual_threads = min(MAX_THREADS, max(1, int(chunk_duration)))
            sub_intervals = []
            
            for i in range(actual_threads):
                s = int(current_start + (i * chunk_duration / actual_threads))
                e = int(current_start + ((i + 1) * chunk_duration / actual_threads))
                if i == actual_threads - 1:
                    e = current_end
                sub_intervals.append((s, e))

            with concurrent.futures.ThreadPoolExecutor(max_workers=actual_threads) as executor:
                futures = []
                for s, e in sub_intervals:
                    # Capture the context of the main thread per task (contains Invocation ID)
                    ctx = contextvars.copy_context()
                    futures.append(executor.submit(ctx.run, process_chunk, menlo_client, sentinel_connector, log_type, s, e, events_transform))

                # Wait for all to complete. If any raise exception, it will bubble up here.
                for future in concurrent.futures.as_completed(futures):
                    future.result()

            # 5. Update state
            state_manager.update_last_sync_timestamp(current_end)
            
            current_start = current_end

        logging.info(f"Log processing job for '{log_type}' completed successfully.")

    except Exception as e:
        logging.error(f"An error occurred during '{log_type}' log processing job.", exc_info=True)
        # Re-raise the exception to ensure the function execution is marked as failed.
        raise e
    