import os
import logging
import datetime
from azure.storage.blob import BlobServiceClient, BlobClient, ContainerClient
from azure.identity import ManagedIdentityCredential

class StateManager:
    """
    Manages reading and writing the state (last sync timestamp)
    to an Azure Blob Storage container.
    """

    def __init__(self, container_name: str, blob_name: str):
        """
        Initializes the StateManager.

        Args:
            container_name: The name of the blob container.
            blob_name: The name of the blob to store the state in.
        """
        account_name = os.environ.get('StateStorageAccountName')
        if not account_name:
            raise ValueError("StateStorageAccountName is not set in environment settings.")

        account_url = f"https://{account_name}.blob.core.windows.net"
        blob_service_client = BlobServiceClient(account_url, credential=ManagedIdentityCredential())
        container_client = blob_service_client.get_container_client(container_name)

        self.blob_client = container_client.get_blob_client(blob_name)
        logging.info(f"StateManager initialized for blob: {container_name}/{blob_name}")

    def get_last_sync_timestamp(self) -> int:
        """
        Retrieves the last sync timestamp from the blob.

        Returns:
            The last sync timestamp as a Unix integer, or None if not found.
        """
        try:
            logging.info("Attempting to download state blob.")
            downloader = self.blob_client.download_blob(max_concurrency=1)
            timestamp_str = downloader.readall().decode('utf-8')
            logging.info(f"State blob downloaded successfully. Content: {timestamp_str}")
            return int(timestamp_str)
        except Exception as e:
            logging.warning(f"Could not retrieve state blob. It might not exist yet. Error: {e}")
            return None

    def update_last_sync_timestamp(self, timestamp: int):
        """
        Updates the last sync timestamp in the blob.

        Args:
            timestamp: The new timestamp to save (Unix integer).
        """
        try:
            timestamp_str = str(timestamp)
            self.blob_client.upload_blob(timestamp_str, overwrite=True)
            logging.info(f"Successfully updated state blob with timestamp: {datetime.datetime.utcfromtimestamp(timestamp).strftime('%Y-%m-%dT%H:%M:%SZ')}")
        except Exception as e:
            logging.error(f"Failed to update state blob. Error: {e}", exc_info=True)
            raise
