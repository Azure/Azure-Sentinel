import os
import time
import json
import logging
import datetime
import threading
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from typing import List, Dict, Optional

class MenloApiClient:
    """
    A client for interacting with the Menlo Security Log Fetch API.
    """

    def __init__(self, api_version: str = 'v2', limit: int = 10000):
        """
        Initializes the Menlo API client.
        """
        self.hostname = os.environ.get('MenloApiHostname', 'logs.menlosecurity.com')
        self.token = os.environ.get('MenloApiToken')
        self.api_version = api_version
        self.limit = limit
        self.base_url = (f'https://{self.hostname}/api/rep/{self.api_version}/fetch/client_select'
                         f'?format=JSON&limit={self.limit}')

        if not self.token:
            raise ValueError("MenloApiToken is not set.")

        self._retry_strategy = Retry(
            total=5,
            backoff_factor=2,  # Waits 1s, 2s, 4s, 8s, 16s between retries
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["POST"]
        )
        # requests.Session is not thread-safe, and fetch_logs runs concurrently across
        # worker threads (see base_log_trigger.run_log_processing). Each thread therefore
        # gets its own Session, created lazily and cached in thread-local storage.
        self._local = threading.local()
        # (connect_timeout, read_timeout): 10s to establish connection,
        # 60s max silence between received bytes (does not limit total transfer size).
        self.timeout = (10, 60)

    @property
    def session(self) -> requests.Session:
        """Return a thread-local requests.Session.

        Sharing a single Session across the ThreadPoolExecutor workers is unsafe
        (requests.Session is not thread-safe). Each thread gets its own Session,
        which also preserves connection reuse across pagination pages within a call.
        """
        session = getattr(self._local, "session", None)
        if session is None:
            session = requests.Session()
            adapter = HTTPAdapter(max_retries=self._retry_strategy)
            session.mount("https://", adapter)
            session.mount("http://", adapter)
            self._local.session = session
        return session

    def fetch_logs(self, log_type: str, start_time: int, end_time: int) -> List[Dict]:
        """
        Fetches logs for a given type and time range, handling pagination.

        Args:
            log_type: The type of log to fetch (e.g., 'audit', 'bandwidth').
            start_time: The start of the time range (Unix timestamp).
            end_time: The end of the time range (Unix timestamp).

        Returns:
            A list of all event dictionaries fetched from the API.
        """
        all_events = []
        
        url = f"{self.base_url}&start={start_time}&end={end_time}"
        headers = {'Content-Type': 'application/json'}
        payload = {'token': self.token, 'log_type': log_type}

        page_count = 0
        while True:
            page_count += 1
            logging.info(f"Fetching {log_type} logs: page {page_count}, from {datetime.datetime.utcfromtimestamp(start_time).strftime('%Y-%m-%dT%H:%M:%SZ')} to {datetime.datetime.utcfromtimestamp(end_time).strftime('%Y-%m-%dT%H:%M:%SZ')}")

            try:
                response = self.session.post(url, headers=headers, data=json.dumps(payload), timeout=self.timeout)
                response.raise_for_status()
            except requests.exceptions.RequestException as e:
                logging.error(f"Error calling Menlo API: {e}", exc_info=True)
                if e.response is not None:
                    logging.error(f"Response from Menlo API: {e.response.text}")
                # Depending on the desired error handling, you might want to break or retry.
                # For a function, it's often best to raise and let the function fail and retry.
                raise 

            if not response.text:
                logging.info("API responded with no data. Ending pagination.")
                break

            response_json = response.json()
            if not response_json:
                logging.error("API did not respond with any content.")
                break
            
            response_data = response_json[0]
            result = response_data.get('result', {})
            events = result.get('events', [])

            if events:
                # The actual log is nested inside the 'event' key
                all_events.extend([item['event'] for item in events])
                logging.info(f"Fetched {len(events)} events on page {page_count}, from {datetime.datetime.utcfromtimestamp(start_time).strftime('%Y-%m-%dT%H:%M:%SZ')} to {datetime.datetime.utcfromtimestamp(end_time).strftime('%Y-%m-%dT%H:%M:%SZ')}")
            else:
                logging.info(f"No more events found on page {page_count}. Pagination finished.")
                break
            
            if result.get('last_iteration'):
                logging.info("Received last_iteration=True. Pagination finished.")
                break
            
            # Update paging identifiers for the next request
            paging_identifiers = result.get('pagingIdentifiers')
            if paging_identifiers:
                payload.setdefault('pagingIdentifiers', {}).update(paging_identifiers)
            else:
                # If there are no more paging identifiers, we are done.
                logging.info("No more paging identifiers. Pagination finished.")
                break

        logging.info(f"Total events fetched for '{log_type}': {len(all_events)}, from {datetime.datetime.utcfromtimestamp(start_time).strftime('%Y-%m-%dT%H:%M:%SZ')} to {datetime.datetime.utcfromtimestamp(end_time).strftime('%Y-%m-%dT%H:%M:%SZ')}")
        return all_events
