import azure.functions as func
from ..shared_code.base_log_trigger import run_log_processing

# Fields that the Menlo bandwidth log API may return either as a single string or
# as an array of strings. They are backed by multi-value dimensions in the source
# datasource (bandwidth_31), so a record with one value arrives as a scalar string
# and a record with several arrives as an array. Normalise the scalar case to a
# single-element array so the ingested schema is consistently an array.
_ARRAY_FIELDS = {'categories', 'user_groups'}

def _transform_bandwidth_events(events):
    result = []
    for event in events:
        transformed = dict(event)
        for field in _ARRAY_FIELDS:
            if field in transformed and isinstance(transformed[field], str):
                transformed[field] = [transformed[field]]
        result.append(transformed)
    return result

def main(timer: func.TimerRequest) -> None:
    run_log_processing(timer, log_type="bandwidth", stream_name="Custom-MenloBandwidth", events_transform=_transform_bandwidth_events)
