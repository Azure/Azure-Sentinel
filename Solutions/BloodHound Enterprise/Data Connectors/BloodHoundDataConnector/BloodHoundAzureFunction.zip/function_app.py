import logging
import azure.functions as func

from audit_logs_collector import bloodhound_audit_logs_collector_main_function
from finding_trends_collector import run_finding_trends_collection_process
from posture_history_collector import run_posture_history_collection_process
from attack_path_collector import run_attack_paths_collection_process
from attack_path_timeline_collector import run_attack_paths_timeline_collection_process
from tier_zero_assets_collector import run_tier_zero_assets_collection_process

import azure.durable_functions as df

# Initialize the Azure Functions App
app = func.FunctionApp()

@app.entity_trigger(context_name="context")
def simple_entity(context: df.DurableEntityContext):
    state = context.get_state(lambda: None)
    op = context.operation_name
    if op == "set":
        new_value = context.get_input()
        if new_value is None:
            # instead of crashing, just ignore or keep old state
            new_value = state if state is not None else 0
        context.set_state(new_value)
        context.set_result(new_value)

    elif op == "reset":
        context.set_state({})
    elif op == "get":
        context.set_result(state)

# @app.timer_trigger(
#     schedule="0 */3 * * * *", 
#     arg_name="myTimer",
#     run_on_startup=True,
#     use_monitor=False,
# )
# @app.durable_client_input(client_name="client")
# async def bloodhound_audit_logs_collector(
#     myTimer: func.TimerRequest, client: df.DurableOrchestrationClient
# ) -> None:
#     logging.info("Timer triggered: bloodhound_audit_logs_collector executed.")

#     if myTimer.past_due:
#         logging.warning("The timer trigger is past due!")

#     entity_name = "audit_logs_last_timestamp_durable_audit_2_days_10"
#     entity_id = df.EntityId("simple_entity", entity_name)

#     # Fetch previous value from entity
#     entity_state = await client.read_entity_state(entity_id)
#     last_audit_logs_timestamp = entity_state.entity_state if entity_state.entity_exists else {}

#     print("**************************************************************************", 'last_value', last_audit_logs_timestamp)
#     # Call main function with last value
#     new_audit_logs_timestamp = bloodhound_audit_logs_collector_main_function(last_audit_logs_timestamp)
#     print("**************************************************************************", 'new_value', new_audit_logs_timestamp)

#     # Update entity with new value
#     await client.signal_entity(entity_id, "set", new_audit_logs_timestamp)
#     logging.info(f"Entity '{entity_name}' updated with new value: {new_audit_logs_timestamp}")

# @app.timer_trigger(
#     schedule="0 */2 * * * *", 
#     arg_name="myTimer",
#     run_on_startup=True,
#     use_monitor=False,
# )
# @app.durable_client_input(client_name="client")
# async def bloodhound_attack_paths_collector(
#     myTimer: func.TimerRequest, client: df.DurableOrchestrationClient
# ) -> None:
#     logging.info("Timer triggered: bloodhound_attack_paths_collector executed.")

#     if myTimer.past_due:
#         logging.warning("The timer trigger is past due!")

#     entity_name = "attack_path_last_timestamps_array_durable_2_days_16"
#     entity_id = df.EntityId("simple_entity", entity_name)

#     # Fetch previous value from entity
#     entity_state = await client.read_entity_state(entity_id)
#     last_attack_path_timestamps = entity_state.entity_state if entity_state.entity_exists else {}

#     print("**************************************************************************", 'last_value', last_attack_path_timestamps)
#     # Call main function with last value
#     new_attack_path_timestamps = run_attack_paths_collection_process(last_attack_path_timestamps)
#     print("**************************************************************************", 'new_value', new_attack_path_timestamps)

#     # Update entity with new value
#     await client.signal_entity(entity_id, "set", new_attack_path_timestamps)
#     logging.info(f"Entity '{entity_name}' updated with new value: {new_attack_path_timestamps}")

# @app.timer_trigger(
#     schedule="0 */5 * * * *", 
#     arg_name="myTimer",
#     run_on_startup=True,
#     use_monitor=False,
# )
# @app.durable_client_input(client_name="client")
# async def bloodhound_posture_history_collector(
#     myTimer: func.TimerRequest, client: df.DurableOrchestrationClient
# ) -> None:
#     logging.info("Timer triggered: bloodhound_posture_history_collector executed.")

#     if myTimer.past_due:
#         logging.warning("The timer trigger is past due!")

#     entity_name = "posture_history_last_timestamps_array_durable_8"
#     entity_id = df.EntityId("simple_entity", entity_name)

#     # Fetch previous value from entity
#     entity_state = await client.read_entity_state(entity_id)
#     last_posture_history_timestamps = entity_state.entity_state if entity_state.entity_exists else {}

#     print("**************************************************************************", 'last_value', last_posture_history_timestamps)
#     # Call main function with last value
#     new_posture_history_timestamps = run_posture_history_collection_process(last_posture_history_timestamps)
#     print("**************************************************************************", 'new_value', new_posture_history_timestamps)

#     # Update entity with new value
#     await client.signal_entity(entity_id, "set", new_posture_history_timestamps)
#     logging.info(f"Entity '{entity_name}' updated with new value: {new_posture_history_timestamps}")

# @app.timer_trigger(
#     schedule="0 */8 * * * *", 
#     arg_name="myTimer",
#     run_on_startup=True,
#     use_monitor=False,
# )
# @app.durable_client_input(client_name="client")
# async def bloodhound_attack_path_timeline_collector(
#     myTimer: func.TimerRequest, client: df.DurableOrchestrationClient
# ) -> None:
#     logging.info("Timer triggered: bloodhound_attack_path_timeline_collector executed.")

#     if myTimer.past_due:
#         logging.warning("The timer trigger is past due!")

#     entity_name = "attack_path_timeline_timestamps_object_durable_days_13"
#     entity_id = df.EntityId("simple_entity", entity_name)

#     # Fetch previous value from entity
#     entity_state = await client.read_entity_state(entity_id)
#     last_attack_path_timeline_timestamps = entity_state.entity_state if entity_state.entity_exists else {}

#     print("**************************************************************************", 'last_value', last_attack_path_timeline_timestamps)
#     # Call main function with last value
#     new_attack_path_timeline_timestamps = run_attack_paths_timeline_collection_process(last_attack_path_timeline_timestamps)
#     print("**************************************************************************", 'new_value', new_attack_path_timeline_timestamps)

#     # Update entity with new value
#     await client.signal_entity(entity_id, "set", new_attack_path_timeline_timestamps)
#     logging.info(f"Entity '{entity_name}' updated with new value: {new_attack_path_timeline_timestamps}")


# @app.timer_trigger(
#     schedule="0 */1 * * * *",
#     arg_name="myTimer",
#     run_on_startup=True,
#     use_monitor=False,
# )
# def bloodhound_finding_trends(myTimer: func.TimerRequest) -> None:

#     if myTimer.past_due:
#         logging.info("The timer is past due!")

#     run_finding_trends_collection_process()

#     logging.info("Python timer trigger function executed.")


# @app.timer_trigger(
#     schedule="0 */10 * * * *",
#     arg_name="myTimer",
#     run_on_startup=True,
#     use_monitor=False,
# )
# def bloodhound_tier_zero_assets(myTimer: func.TimerRequest) -> None:

#     if myTimer.past_due:
#         logging.info("The timer is past due!")

#     run_tier_zero_assets_collection_process()

#     logging.info("Python timer trigger function executed.")