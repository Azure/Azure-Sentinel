class MimecastEndpoints:

    get_threat_intel_feed = "/api/ttp/threat-intel/get-feed"
    refresh_access_key = "/api/login/login"
