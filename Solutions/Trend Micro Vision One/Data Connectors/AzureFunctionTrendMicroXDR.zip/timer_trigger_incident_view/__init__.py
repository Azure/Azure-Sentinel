import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple

import azure.functions as func
from shared_code import configurations, utils
from shared_code.customized_logger import custom_event_logger
from shared_code.customized_logger.customized_json_logger import (
    get_customized_json_logger,
)
from shared_code.data_collector import LogAnalytics
from shared_code.decorators.timer import timer
from shared_code.models.workbench import IncidentViewMessage
from shared_code.trace_utils.trace import trace_manager

WORKSPACE_ID = configurations.get_workspace_id()
WORKSPACE_KEY = configurations.get_workspace_key()
API_TOKENS = configurations.get_api_tokens()
MAX_IV_QUERY_MINUTES = configurations.get_max_iv_query_minutes()
DEFAULT_IV_QUERY_MINUTES = configurations.get_default_iv_query_minutes()
DATETIME_FORMAT = configurations.get_incident_view_datetime_format()
LOG_TYPE = configurations.get_region_health_check_log_type()
CONNECTOR_REGION = configurations.get_connector_location()

TABLE_NAME = "XdrIVConnectorStatus"
PARTITION_KEY = "last_success_time"

logger = get_customized_json_logger()


@timer
def generate_time(clp_id: str) -> Tuple[Optional[datetime], Optional[datetime]]:
    end_time = datetime.now(timezone.utc).replace(microsecond=0)
    last_success_time = utils.get_last_success_time(TABLE_NAME, clp_id)
    last_enabled_time = utils.get_last_enabled_time(clp_id)

    # select the later one from last_enabled_time and last_success_time
    start_time = None
    if last_success_time and last_enabled_time:
        start_time = max(last_success_time, last_enabled_time)
    else:
        start_time = last_success_time or last_enabled_time

    logger.info(
        f"last_success_time: {last_success_time}, last_enabled_time: {last_enabled_time}, start_time: {start_time}"
    )

    if start_time is not None:
        start_time = start_time + timedelta(seconds=1)

    if start_time is None:
        start_time = end_time - timedelta(minutes=DEFAULT_IV_QUERY_MINUTES)
    elif start_time + timedelta(minutes=MAX_IV_QUERY_MINUTES) < end_time:
        end_time = start_time + timedelta(minutes=MAX_IV_QUERY_MINUTES)

    if start_time >= end_time:
        return None, None

    return start_time, end_time


@timer
def process_last_success_time_and_send_message(clp_id):
    start_time, end_time = generate_time(clp_id)
    if start_time is None or end_time is None:
        logger.warning(
            f"Start time or End time is None, Stop processing clp: {clp_id}."
        )
        return

    start_time_str = start_time.strftime(DATETIME_FORMAT)
    end_time_str = end_time.strftime(DATETIME_FORMAT)

    logger.info(
        f"start to send Incident View events clp_id: {clp_id} "
        f"from {start_time_str} to {end_time_str}."
    )

    utils.send_message_to_storage_queue(
        configurations.get_incident_view_queue_name(),
        IncidentViewMessage(
            clp_id=clp_id,
            start_time=start_time_str,
            end_time=end_time_str,
            task_id=trace_manager.task_id,
        ).json(),
    )

    utils.update_last_success_time(TABLE_NAME, clp_id, end_time)

    return start_time_str, end_time_str


def main(myTimer: func.TimerRequest) -> None:
    if utils.is_time_to_work():
        logger.info("Timer for IV starts to work.")
    else:
        return

    log_analytics = LogAnalytics(WORKSPACE_ID, WORKSPACE_KEY, LOG_TYPE)
    error = None

    for token in API_TOKENS:
        clp_id = ""
        try:
            trace_manager.task_id = str(uuid.uuid4())
            clp_id = utils.get_clp_id(token)
            health_check_data = {
                "clpId": clp_id,
                "region": CONNECTOR_REGION,
                "type": "incident view",
                "lastUpdatedTime": datetime.now(timezone.utc).strftime(DATETIME_FORMAT),
            }

            start_time_str, end_time_str = process_last_success_time_and_send_message(
                clp_id
            )

            # write custom event
            custom_event = {
                "item": "Timer",
                "func_name": "timer_trigger_incident_view",
                "event_name": "DataConnector.Incident.Timer",
                "level": "Info",
                "clp_id": clp_id,
                "trace_id": trace_manager.trace_id,
                "start_date_time": start_time_str,
                # 'end_date_time': end_time_str,
            }
            custom_event_logger.write_custom_event(custom_event)

        except Exception as e:
            logger.exception(f"Internal error. clp_id:{clp_id}")

            error_message = str(e)
            error, health_check_data["error"] = e, error_message

            # write custom error event
            error_event = {
                "item": "Timer",
                "func_name": "timer_trigger_incident_view",
                "event_name": "DataConnector.Incident.Timer",
                "level": "Error",
                "clp_id": clp_id,
                "task_id": trace_manager.task_id,
                "trace_id": trace_manager.trace_id,
                "message": error_message,
            }
            custom_event_logger.write_custom_event(error_event)

        finally:
            log_analytics.post_data(health_check_data)

    if error:
        raise error
