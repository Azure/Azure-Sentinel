from datetime import datetime, timezone
from typing import Optional, Union

from pydantic import BaseModel, Field, HttpUrl, conint, validator

from shared_code import configurations

CUSTOM_EVENT_DATETIME_FORMAT = configurations.get_custom_event_datetime_format()


class CustomEvent(BaseModel):
    def __init__(self, data_dict: dict):
        super().__init__(**data_dict)

    def _get_error_fields(self) -> dict:
        return {
            "item",
            "func_name",
            "asc_time",
            "clp_id",
            "message",
            "level",
            "task_id",
            "trace_id",
            "request_url",
            "request_time",
            "response_code",
            "response_time",
        }

    def get_event_properties(self) -> dict:
        # assign ascTime before exporting
        self.asc_time = datetime.now(timezone.utc).strftime(
            CUSTOM_EVENT_DATETIME_FORMAT
        )[:-3]

        if self.level == "Error":
            return self.dict(
                include=self._get_error_fields(),
                exclude_none=True,
                by_alias=True,
            )

        return self.dict(exclude={"event_name"}, exclude_none=True, by_alias=True)

    # required fields
    asc_time: str = Field(
        alias="ascTime",
        default=datetime.now(timezone.utc).strftime(CUSTOM_EVENT_DATETIME_FORMAT)[:-3],
    )

    item: str
    event_name: str
    func_name: str = Field(alias="functionName")
    level: str = Field(regex="Info|Error")
    clp_id: str = Field(alias="clpId")
    task_id: str = Field(alias="taskId")
    trace_id: str = Field(alias="traceId")

    # optional fields
    message: Optional[str]

    # query period info
    start_date_time: Optional[datetime] = Field(alias="startDateTime")
    end_date_time: Optional[datetime] = Field(alias="endDateTime")

    # for external http request
    request_time: Optional[datetime] = Field(alias="requestTime")
    request_url: Optional[HttpUrl] = Field(alias="requestUrl")
    response_code: Optional[conint(ge=200, le=599)] = Field(alias="responseCode")
    response_time: Optional[datetime] = Field(alias="responseTime")

    # wb
    wb_count: Optional[conint(ge=0)] = Field(alias="wbCount")
    wb_id: Optional[str] = Field(alias="wbId")
    wb_severity: Optional[str] = Field(alias="wbSeverity")
    rca_count: Optional[conint(ge=0)] = Field(alias="rcaCount")
    incident_count: Optional[conint(ge=0)] = Field(alias="incidentCount")

    # oat
    pipeline_id: Optional[str] = Field(alias="pipelineId")
    packages_count: Optional[str] = Field(alias="packagesCount")

    package_id: Optional[str] = Field(alias="packageId")
    oat_count: Optional[conint(ge=0)] = Field(alias="oatCount")
    package_size: Optional[conint(ge=0)] = Field(alias="packageSize")

    # validators
    @validator("start_date_time", "end_date_time", "request_time", "response_time")
    @classmethod
    def to_datetime_str(cls, v: datetime) -> Union[None, str]:
        return v.strftime(CUSTOM_EVENT_DATETIME_FORMAT)[:-3] if v else None

    @validator("request_url")
    @classmethod
    def to_url_str(cls, v):
        return str(v)

    # configuration
    class Config:
        allow_population_by_field_name = True
        json_encoders = {
            datetime: lambda v: v.strftime(CUSTOM_EVENT_DATETIME_FORMAT)[:-3]
        }
