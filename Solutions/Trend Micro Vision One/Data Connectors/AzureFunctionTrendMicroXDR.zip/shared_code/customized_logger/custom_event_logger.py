from applicationinsights import TelemetryClient

from shared_code import configurations
from shared_code.customized_logger.customized_json_logger import (
    get_customized_json_logger,
)
from shared_code.events.custom_event import CustomEvent

logger = get_customized_json_logger()


def write_custom_event(custom_event_data: dict):
    try:
        instrumentation_key = configurations.get_app_insights_instrumentation_key()

        custom_event = CustomEvent(custom_event_data)
        event_name = custom_event.event_name
        event_properties = custom_event.get_event_properties()

        logger.info(
            f"[write_custom_event] instrumentation_key: {instrumentation_key}, event_name: {event_name}, event_properties: {event_properties}"
        )

        tc = TelemetryClient(instrumentation_key)
        tc.track_event(event_name, event_properties)
        tc.flush()
    except Exception as e:
        logger.error(f"[write_custom_event] error message: {e}")
