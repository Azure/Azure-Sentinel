import uuid
from datetime import datetime, timezone
from typing import List, Optional, Tuple

import requests

from shared_code import configurations
from shared_code.customized_logger.customized_json_logger import (
    get_customized_json_logger,
)
from shared_code.trace_utils.trace import trace_manager

logger = get_customized_json_logger()

XDR_HOST_URL = configurations.get_xdr_host_url()
HTTP_TIMEOUT = configurations.get_workbench_api_timeout_seconds()


def get_header(headers=None):
    headers = headers or {}

    trace_manager.trace_id = headers["x-trace-id"] = str(uuid.uuid4())

    if trace_manager.task_id:
        headers["x-task-id"] = trace_manager.task_id

    headers["User-Agent"] = configurations.get_user_agent()

    return headers


def get_trace_log(headers):
    log = "headers is empty."
    if headers:
        task_id = headers.get("x-task-id")
        trace_id = headers.get("x-trace-id")
        log = f"task id: {task_id}, trace id: {trace_id}."
    return log


# Get List of Events
def get_workbench_list(
    token,
    start_time,
    end_time,
    query_all_workbench,
    offset=0,
    limit=200,
    custom_event: Optional[dict] = None,
):
    query_params = {
        "source": "all",
        "investigationStatus": "null",
        "sortBy": "createdTime",
        "queryTimeField": "createdTime",
        "offset": offset,
        "limit": limit,
        "startDateTime": start_time,
        "endDateTime": end_time,
        "modelType": "all" if query_all_workbench else "preset",
    }

    headers = get_header(
        {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json;charset=utf-8",
        }
    )
    url = f"{XDR_HOST_URL}/v2.0/siem/events"
    logger.info(f"Get workbench list url: {url}")

    # assign request information to custom event
    if custom_event:
        custom_event["request_url"] = url
        custom_event["request_time"] = datetime.now(timezone.utc)

    response = requests.get(
        url, headers=headers, params=query_params, timeout=HTTP_TIMEOUT
    )

    # assign response information to custom event
    if custom_event:
        custom_event["response_time"] = datetime.now(timezone.utc)
        custom_event["response_code"] = response.status_code

    logger.info(
        f"Get workbench list response: {response.text}"
        f"Get workbench list trace: {get_trace_log(response.headers)}"
    )
    response.raise_for_status()
    response_data = response.json()

    workbench_records = response_data["data"]["workbenchRecords"]
    total_count = response_data["data"]["totalCount"]

    return total_count, workbench_records


# Get List of Events
def get_workbench_detail(token, workbench_id):
    url = f"{XDR_HOST_URL}/v2.0/xdr/workbench/workbenches/{workbench_id}"
    headers = get_header(
        {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json;charset=utf-8",
        }
    )
    logger.info(f"Get workbench detail url: {url}")
    response = requests.get(url, headers=headers, timeout=HTTP_TIMEOUT)
    logger.info(
        f"Get workbench detail response: {response.text}."
        f"Get workbench detail trace: {get_trace_log(response.headers)}"
    )
    response.raise_for_status()
    response_data = response.json()

    return response_data["data"]


def get_workbench_detail_v3(
    token: str,
    workbench_id: str,
    custom_event: Optional[dict] = None,
):
    url = f"{XDR_HOST_URL}/v3.0/workbench/alerts/{workbench_id}"
    headers = get_header(
        {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json;charset=utf-8",
        }
    )
    logger.info(f"Get workbench detail v3 url: {url}")

    # assign request information to custom event
    if custom_event:
        custom_event["request_url"] = url
        custom_event["request_time"] = datetime.now(timezone.utc)

    response = requests.get(url, headers=headers, timeout=HTTP_TIMEOUT)

    # assign response information to custom event
    if custom_event:
        custom_event["response_time"] = datetime.now(timezone.utc)
        custom_event["response_code"] = response.status_code

    logger.info(
        f"Get workbench detail v3 response: {response.text}."
        f"Get workbench detail v3 trace: {get_trace_log(response.headers)}"
    )
    response.raise_for_status()
    response_data = response.json()

    # assign wb information
    if custom_event:
        custom_event["wb_severity"] = response_data.get("severity")

    return response_data


def get_rca_task(
    token,
    workbench_id,
    custom_event: dict = None,
):
    url = f"{XDR_HOST_URL}/v3.0/xdr/mssp/workbench/workbenches/{workbench_id}/tasks/rca"
    headers = get_header(
        {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json;charset=utf-8",
        }
    )
    logger.info(f"Get rca task url: {url}")

    # assign request information to custom event
    if custom_event:
        custom_event["request_url"] = url
        custom_event["request_time"] = datetime.now(timezone.utc)

    response = requests.get(url, headers=headers, timeout=HTTP_TIMEOUT)

    # assign response information to custom event
    if custom_event:
        custom_event["response_time"] = datetime.now(timezone.utc)
        custom_event["response_code"] = response.status_code

    logger.info(
        f"Get rca task response: {response.text}"
        f"Get rca task trace: {get_trace_log(response.headers)}"
    )
    response.raise_for_status()
    response_data = response.json()

    return response_data["data"]


def get_rca_task_detail(
    token,
    task_id,
    endpoint_guid,
    custom_event: Optional[dict] = None,
):
    url = f"{XDR_HOST_URL}/v3.0/xdr/mssp/workbench/tasks/rca/{task_id}/results/{endpoint_guid}"
    headers = get_header(
        {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json;charset=utf-8",
        }
    )
    logger.info(f"Get rca task detail url: {url}")

    # assign request information to custom event
    if custom_event:
        custom_event["request_url"] = url
        custom_event["request_time"] = datetime.now(timezone.utc)

    response = requests.get(url, headers=headers, timeout=HTTP_TIMEOUT)

    # assign response information to custom event
    if custom_event:
        custom_event["response_time"] = datetime.now(timezone.utc)
        custom_event["response_code"] = response.status_code

    logger.info(
        f"Get rca detail response: {response.text}"
        f"Get rca detail trace: {get_trace_log(response.headers)}"
    )
    response.raise_for_status()
    response_data = response.json()

    return response_data["data"]


def get_incident_view_list(
    token: str,
    incident_id=None,
    workbench_id=None,
    start_time=None,
    end_time=None,
    next_link=None,
    custom_event: Optional[dict] = None,
) -> Tuple[int, List[dict], Optional[str]]:
    if not any((incident_id, workbench_id, (start_time and end_time), next_link)):
        logger.error(
            "[get_incident_view_list] please assign incident_id, workbench_id or start_time/end_time."
        )
        return 0, [], None

    # API doc: https://adc.github.trendmicro.com/pages/CoreTech-SG/xdr-doc/?urls.primaryName=public-awb%20(workbench)#/
    url = f"{XDR_HOST_URL}/v3.0/xdr/mssp/workbench/mssp/incidents"

    headers = get_header(
        {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json;charset=utf-8",
        }
    )

    if workbench_id:
        headers["TMV1-Filter"] = f"associatedAlertId eq '{workbench_id}'"

    if incident_id:
        headers["TMV1-Filter"] = f"id eq '{incident_id}'"

    query_params = {
        "dateTimeTarget": "updatedDateTime",
        "orderBy": "createdDateTime asc",
    }

    if start_time and end_time:
        query_params["startDateTime"] = start_time
        query_params["endDateTime"] = end_time

    if next_link:
        query_params = None  # clear query params
        url = next_link

    logger.info(f"[get_incident_view_list] Get incident view v3 url: {url}")

    # assign request information to custom event
    if custom_event:
        custom_event["request_url"] = url
        custom_event["request_time"] = datetime.now(timezone.utc)

    response = requests.get(
        url, headers=headers, params=query_params, timeout=HTTP_TIMEOUT
    )

    logger.info(
        f"[get_incident_view_list] Get incident view v3 response: {response.text}. "
        f"trace: {get_trace_log(response.headers)}"
    )

    # assign response information to custom event
    if custom_event:
        custom_event["response_time"] = datetime.now(timezone.utc)
        custom_event["response_code"] = response.status_code

    response.raise_for_status()
    response_data = response.json()

    total_count = response_data["totalCount"]
    incident_view_records = response_data["items"]
    next_link = response_data.get("nextLink", None)

    return total_count, incident_view_records, next_link


def get_associated_incident_id(
    incident_view_records: List[dict],
    incident_id=None,
    workbench_id=None,
) -> Tuple[str, List[dict]]:
    """
    incident_view_records example:
    {
        "id": "IC-9002-20230710-00002",
        "score": 24,
        "title": "Unit test",
        "description": "Unit test",
        "lastUpdatedDateTime": "2023-07-10T08:21:47Z",
        "createdDateTime": "2023-07-10T08:21:18Z",
        "associatedAlerts": [
            {
                "id": "WB-9002-20220906-00025",
                "relationship": ["Endpoints are the same"],
            },
            {
                "id": "WB-9002-20230710-00069",
                "relationship": ["Endpoints are the same"],
            },
        ],
        "updateLogs": [],
    }
    """

    if not any((incident_id, workbench_id)):
        logger.error(
            "[get_associated_incident_id] please assign incident_id or workbench_id."
        )
        return "", []

    for incident_view_record in incident_view_records:
        if "id" not in incident_view_record:
            continue

        if incident_id:
            # check with incident_id
            if incident_view_record["id"] == incident_id:
                logger.info(
                    f"[get_associated_incident_id] get associated alerts for incident_id: {incident_id}."
                )
                return incident_id, incident_view_record["associatedAlerts"]
        else:
            # TODO: this can be removed after workbench api is updated
            # check with workbench_id
            incident_id = incident_view_record["id"]
            for workbench in incident_view_record["associatedAlerts"]:
                if workbench["id"] == workbench_id:
                    logger.info(
                        f"[get_associated_incident_id] get incident_id and associated alerts: {incident_id} for workbench id: {workbench_id}."
                    )
                    return incident_id, incident_view_record["associatedAlerts"]

    logger.info(
        f"[get_associated_incident_id] can not get incident_id for workbench id: {workbench_id}."
    )
    return "", []
