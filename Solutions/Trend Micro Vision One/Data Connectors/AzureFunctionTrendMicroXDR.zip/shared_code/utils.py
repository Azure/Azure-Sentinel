import json
from datetime import datetime, timedelta, timezone
from typing import Optional

import jwt
import pytz
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError
from azure.data.tables import TableClient, TableServiceClient, UpdateMode
from azure.storage.queue import QueueClient, TextBase64EncodePolicy
from shared_code import configurations
from shared_code.customized_logger.customized_json_logger import (
    get_customized_json_logger,
)
from shared_code.decorators.timer import timer

STORAGE_CONNECTION_STRING = configurations.get_storage_connection_string()
SHARED_STORAGE_CONNECTION_STRING = configurations.get_shared_storage_connection_string()
DATETIME_FORMAT = configurations.get_datetime_format()
LAST_SUCCESS_TIME_PARTITION_KEY = 'last_success_time'
REGISTER_STATUS_TABLE = 'XdrOatRegisterStatus'
WB_LIST_QUERY_SLOT_CNT = configurations.get_wb_list_query_slot_cnt()
WB_LIST_QUERY_SLOT_TIME_SPAN = configurations.get_wb_list_query_slot_time_span()

logger = get_customized_json_logger()


class ConnectorNumber:
    PRIMARY = 'primary'
    SECONDARY = 'secondary'


def get_clp_id(token):
    return jwt.decode(token, options={"verify_signature": False}).get('cid')


def find_token_by_clp(clp_id, api_tokens):
    return next(filter(lambda token: get_clp_id(token) == clp_id, api_tokens), None)


@timer
def get_last_success_time(table_name, clp_id):
    try:
        table_service_client = TableServiceClient.from_connection_string(
            conn_str=SHARED_STORAGE_CONNECTION_STRING
        )
        table_service_client.create_table_if_not_exists(table_name)

        table_client = TableClient.from_connection_string(
            conn_str=SHARED_STORAGE_CONNECTION_STRING, table_name=table_name
        )

        entity = table_client.get_entity(LAST_SUCCESS_TIME_PARTITION_KEY, clp_id)
        return pytz.utc.localize(
            datetime.strptime(entity['last_success_time'], DATETIME_FORMAT)
        )
    except ResourceNotFoundError:
        return None


@timer
def get_last_enabled_time(clp_id: str) -> Optional[datetime]:
    all_last_enabled_time = json.loads(configurations.get_all_last_enabled_time())
    last_enabled_time = all_last_enabled_time.get(clp_id, None)
    if last_enabled_time:
        return pytz.utc.localize(
            datetime.strptime(
                last_enabled_time,
                configurations.get_last_enabled_time_datetime_format(),
            )
        )
    return None


@timer
def update_last_success_time(table_name, clp_id, time):
    table_client = TableClient.from_connection_string(
        conn_str=SHARED_STORAGE_CONNECTION_STRING, table_name=table_name
    )
    table_client.upsert_entity(
        {
            'PartitionKey': LAST_SUCCESS_TIME_PARTITION_KEY,
            'RowKey': clp_id,
            'last_success_time': time.strftime(DATETIME_FORMAT),
        },
        mode=UpdateMode.MERGE,
    )


# TODO: enhancement for querying wb api separately
def get_schedule_time_for_wb_list_query(clp_id):
    ascii_sum = 0
    for char in clp_id:
        ascii_sum += ord(char)
    slot = ascii_sum % WB_LIST_QUERY_SLOT_CNT
    scheduled_time = datetime.now(timezone.utc) + timedelta(
        seconds=slot * WB_LIST_QUERY_SLOT_TIME_SPAN
    )

    logger.info(
        f'The clp_id: {clp_id} will get wb list on {scheduled_time}.'
        f'scheduled_time = now + {ascii_sum}%{WB_LIST_QUERY_SLOT_CNT}*{WB_LIST_QUERY_SLOT_TIME_SPAN}'
    )

    return scheduled_time


@timer
def send_message_to_storage_queue(
    queue_name, message, conn_str=STORAGE_CONNECTION_STRING
):
    queue_client = QueueClient.from_connection_string(
        conn_str,
        queue_name,
        message_encode_policy=TextBase64EncodePolicy(),
    )

    try:
        queue_client.create_queue()
    except ResourceExistsError:
        pass

    queue_client.send_message(message)


def is_time_to_work():
    time_now_minute = datetime.now(timezone.utc).minute
    connector_number = configurations.get_connector_ordinal_number()
    execution_time = configurations.get_execution_time().get(connector_number)
    return True if time_now_minute in execution_time else False
