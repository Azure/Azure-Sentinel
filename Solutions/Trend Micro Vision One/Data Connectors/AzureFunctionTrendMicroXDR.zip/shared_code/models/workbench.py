from typing import Dict

from pydantic import BaseModel


class WBListMessage(BaseModel):
    clp_id: str
    start_time: str
    end_time: str
    task_id: str


class WBDetailMessage(BaseModel):
    clp_id: str
    start_time: str
    workbench_record: Dict
    task_id: str


class RCATaskMessage(BaseModel):
    clp_id: str
    workbench_id: str
    rca_task_id: str
    task_name: str
    target_guid: str
    target_info: Dict
    task_id: str


class IncidentViewMessage(BaseModel):
    clp_id: str
    task_id: str
    start_time: str
    end_time: str


ALLOWED_WORKBENCH_LIST_COLUMN = [
    "priorityScore",
    "workbenchName",
]


ALLOWED_WORKBENCH_DETAILED_COLUMN = [
    "id",
    "investigationStatus",
    "workbenchLink",
    "severity",
    "alertProvider",
    "model",
    "description",
    "impactScope",
    "indicators",
    "matchedRules",
    "createdDateTime",
    "updatedDateTime",
]


XDR_INDICATORS_COLUMN_NAME = {
    "ip": "IPAddress",
    "detection_name": "MalwareName",
    "filename": "FileName",
    "fullpath": "FileDirectory",
    "command_line": "ProcessCommandLine",
    "domain": "DomainName",
    "file_sha1": "FileHashValue",
    "registry_key": "RegistryKey",
    "registry_value_data": "RegistryValue",
    "registry_value": "RegistryValueName",
    "url": "URL",
    "emailAddress": "MailboxPrimaryAddress",
}

WB_OVERSIZED_FIELDS = [
    ["indicators"],
    ["impactScope", "entities"],
    ["associatedAlerts"],
    ["impactScope_Summary"],
]
