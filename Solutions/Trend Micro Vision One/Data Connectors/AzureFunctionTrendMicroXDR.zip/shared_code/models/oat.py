from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel


class RiskLevel(str, Enum):
    UNDEFINED = 'undefined'
    INFO = 'info'
    LOW = 'low'
    MEDIUM = 'medium'
    HIGH = 'high'
    CRITICAL = 'critical'


class OATDetectionResult(BaseModel):
    total_count: int
    detections: List[Dict]
    search_api_post_data: List[Dict]
    next_batch_token: Optional[str]


class OATTaskMessage(BaseModel):
    clp_id: str
    token: Optional[str]
    start_time: str
    end_time: str
    task_id: Optional[str]


class OATFileMessage(BaseModel):
    clp_id: str
    token: Optional[str]
    package_id: str
    task_id: Optional[str]
    pipeline_id: str


class OATDetail(BaseModel):
    act: Optional[Any]
    actResult: Optional[Any]
    additionalEventData: Optional[Any]
    aggregatedCount: Optional[Any]
    app: Optional[Any]
    appDexSha256: Optional[Any]
    appGroup: Optional[Any]
    application: Optional[Any]
    aptRelated: Optional[Any]
    attachmentFileHash: Optional[Any]
    attachmentFileHashSha1: Optional[Any]
    attachmentFileHashSha256: Optional[Any]
    attachmentFileHashSha256s: Optional[Any]
    attachmentFileHashes: Optional[Any]
    attachmentFileHashs: Optional[Any]
    attachmentFileName: Optional[Any]
    attachmentFileSize: Optional[Any]
    attachmentFileTlshes: Optional[Any]
    attachmentFileTlshs: Optional[Any]
    attachmentFileType: Optional[Any]
    attachmentSha1: Optional[Any]
    attachmentSha256: Optional[Any]
    attachmentSize: Optional[Any]
    attachmentSource: Optional[Any]
    attachmentTlsh: Optional[Any]
    attachmentUrls: Optional[Any]
    behaviorCat: Optional[Any]
    blocking: Optional[Any]
    bmGroup: Optional[Any]
    botCmd: Optional[Any]
    botUrl: Optional[Any]
    cat: Optional[Any]
    cccaDestination: Optional[Any]
    cccaDestinationFormat: Optional[Any]
    cccaDetection: Optional[Any]
    cccaDetectionSource: Optional[Any]
    cccaRiskLevel: Optional[Any]
    channel: Optional[Any]
    clientFlag: Optional[Any]
    clientIp: Optional[Any]
    compressedFileHash: Optional[Any]
    compressedFileHashSha256: Optional[Any]
    compressedFileName: Optional[Any]
    compressedFileSize: Optional[Any]
    compressedFileType: Optional[Any]
    computerDomain: Optional[Any]
    confidence: Optional[Any]
    correlationCat: Optional[Any]
    correlationData: Optional[Any]
    cve: Optional[Any]
    cves: Optional[Any]
    dOSName: Optional[Any]
    dUser1: Optional[Any]
    data0: Optional[Any]
    data0Name: Optional[Any]
    data1: Optional[Any]
    data1Name: Optional[Any]
    data2: Optional[Any]
    dataType: Optional[Any]
    description: Optional[Any]
    destinationPath: Optional[Any]
    detailTrace: Optional[Any]
    detectionName: Optional[Any]
    detectionType: Optional[Any]
    deviceDirection: Optional[Any]
    deviceGUID: Optional[Any]
    deviceMacAddress: Optional[Any]
    dhost: Optional[Any]
    direction: Optional[Any]
    dmac: Optional[Any]
    dnsQueryType: Optional[Any]
    domainName: Optional[Any]
    dpt: Optional[Any]
    dst: Optional[Any]
    dstGroup: Optional[Any]
    dstZone: Optional[Any]
    duser: Optional[Any]
    dvchost: Optional[Any]
    endpointGUID: Optional[Any]
    endpointGuid: Optional[Any]
    endpointHostName: Optional[Any]
    endpointIp: Optional[Any]
    endpointMacAddress: Optional[Any]
    endpointModel: Optional[Any]
    engineOperation: Optional[Any]
    errorMessage: Optional[Any]
    eventClass: Optional[Any]
    eventDataAuthenticationPackageName: Optional[Any]
    eventDataConsumer: Optional[Any]
    eventDataIpAddress: Optional[Any]
    eventDataLogonProcessName: Optional[Any]
    eventDataLogonType: Optional[Any]
    eventDataPath: Optional[Any]
    eventDataProviderName: Optional[Any]
    eventDataProviderPath: Optional[Any]
    eventDataScriptBlockText: Optional[Any]
    eventID: Optional[Any]
    eventId: Optional[Any]
    eventName: Optional[Any]
    eventSourceType: Optional[Any]
    eventSubClass: Optional[Any]
    eventSubId: Optional[Any]
    eventSubName: Optional[Any]
    eventTime: Optional[Any]
    extraInfo: Optional[Any]
    fileCreation: Optional[Any]
    fileExt: Optional[Any]
    fileHash: Optional[Any]
    fileHashSha256: Optional[Any]
    fileName: Optional[Any]
    fileOperation: Optional[Any]
    filePath: Optional[Any]
    filePathName: Optional[Any]
    fileSize: Optional[Any]
    fileType: Optional[Any]
    filterName: Optional[Any]
    filterRiskLevel: Optional[Any]
    filterType: Optional[Any]
    firstAct: Optional[Any]
    firstActResult: Optional[Any]
    firstSeen: Optional[Any]
    forensicFileHash: Optional[Any]
    forensicFilePath: Optional[Any]
    fullPath: Optional[Any]
    highlightedText: Optional[Any]
    hostName: Optional[Any]
    hostSeverity: Optional[Any]
    hotFix: Optional[Any]
    httpLocation: Optional[Any]
    httpReferer: Optional[Any]
    httpXForwardedForIp: Optional[Any]
    interestedGroup: Optional[Any]
    interestedHost: Optional[Any]
    interestedIp: Optional[Any]
    interestedMacAddress: Optional[Any]
    ircChannelName: Optional[Any]
    ja3Hash: Optional[Any]
    ja3sHash: Optional[Any]
    k8sNamespace: Optional[Any]
    lastSeen: Optional[Any]
    logonUser: Optional[Any]
    mDevice: Optional[Any]
    mailAttachmentHash: Optional[Any]
    mailBccAddresses: Optional[Any]
    mailCcAddresses: Optional[Any]
    mailDeliveryTime: Optional[Any]
    mailDirection: Optional[Any]
    mailFolder: Optional[Any]
    mailFromAddresses: Optional[Any]
    mailHeaderHash: Optional[Any]
    mailHelo: Optional[Any]
    mailMetaData: Optional[Any]
    mailMetaText: Optional[Any]
    mailMsgSubject: Optional[Any]
    mailReceivedTime: Optional[Any]
    mailReplyToAddresses: Optional[Any]
    mailRuleId: Optional[Any]
    mailScore: Optional[Any]
    mailSenderIp: Optional[Any]
    mailSmtpFromAddresses: Optional[Any]
    mailSmtpOriginalRecipients: Optional[Any]
    mailSmtpRecipients: Optional[Any]
    mailSourceDomain: Optional[Any]
    mailTagHash: Optional[Any]
    mailTagHashRawSignature: Optional[Any]
    mailTextHash: Optional[Any]
    mailThreatType: Optional[Any]
    mailToAddresses: Optional[Any]
    mailUrlHash: Optional[Any]
    mailUrlsRealLink: Optional[Any]
    mailUrlsVisibleLink: Optional[Any]
    mailUserAgent: Optional[Any]
    mailWholeHeader: Optional[Any]
    mailXMailer: Optional[Any]
    mailbox: Optional[Any]
    malDst: Optional[Any]
    malFamily: Optional[Any]
    malName: Optional[Any]
    malSrc: Optional[Any]
    malSubType: Optional[Any]
    malType: Optional[Any]
    malTypeGroup: Optional[Any]
    metaPwdSprayClientAppUsed: Optional[Any]
    metaPwdSprayClientDeviceBrowser: Optional[Any]
    metaPwdSprayIp: Optional[Any]
    metaPwdSprayIpSignInFailCount: Optional[Any]
    metaPwdSprayIpSignInSuccessCount: Optional[Any]
    metaPwdSprayIpUserCount: Optional[Any]
    metaPwdSprayUserSignInFailCount: Optional[Any]
    metaPwdSprayUserSignInSuccessCount: Optional[Any]
    metaSuspiciousMailboxRulesForwardAddresses: Optional[Any]
    metaType: Optional[Any]
    mitreMapping: Optional[Any]
    moduleName: Optional[Any]
    msgUuidChain: Optional[Any]
    objectApiHookNum: Optional[Any]
    objectApiName: Optional[Any]
    objectAppName: Optional[Any]
    objectBmData: Optional[Any]
    objectCmd: Optional[Any]
    objectCmdNormalized: Optional[Any]
    objectContentName: Optional[Any]
    objectFileCreation: Optional[Any]
    objectFileGroupName: Optional[Any]
    objectFileHashSha1: Optional[Any]
    objectFileHashSha256: Optional[Any]
    objectFileIsRemoteAccess: Optional[Any]
    objectFileModifiedTime: Optional[Any]
    objectFileName: Optional[Any]
    objectFileOwnerSid: Optional[Any]
    objectFilePath: Optional[Any]
    objectFileRemoteAccess: Optional[Any]
    objectFileSaclString: Optional[Any]
    objectFileSize: Optional[Any]
    objectFirstRecorded: Optional[Any]
    objectFirstSeen: Optional[Any]
    objectHostName: Optional[Any]
    objectIp: Optional[Any]
    objectIps: Optional[Any]
    objectLastSeen: Optional[Any]
    objectLaunchTime: Optional[Any]
    objectName: Optional[Any]
    objectPort: Optional[Any]
    objectRawDataStr: Optional[Any]
    objectRegType: Optional[Any]
    objectRegistryData: Optional[Any]
    objectRegistryKeyHandle: Optional[Any]
    objectRegistryRoot: Optional[Any]
    objectRegistryValue: Optional[Any]
    objectRunAsLocalAccount: Optional[Any]
    objectSigner: Optional[Any]
    objectSignerValid: Optional[Any]
    objectSubTrueType: Optional[Any]
    objectTrueType: Optional[Any]
    objectType: Optional[Any]
    objectUser: Optional[Any]
    objectUserDomain: Optional[Any]
    objectUserGroup: Optional[Any]
    osName: Optional[Any]
    osType: Optional[Any]
    osVer: Optional[Any]
    pAttackPhase: Optional[Any]
    pComp: Optional[Any]
    pTags: Optional[Any]
    parentCmd: Optional[Any]
    parentCmdNormalized: Optional[Any]
    parentFileCreation: Optional[Any]
    parentFileGroupName: Optional[Any]
    parentFileHashSha1: Optional[Any]
    parentFileHashSha256: Optional[Any]
    parentFileModifiedTime: Optional[Any]
    parentFilePath: Optional[Any]
    parentFileRemoteAccess: Optional[Any]
    parentFileSize: Optional[Any]
    parentLaunchTime: Optional[Any]
    parentName: Optional[Any]
    parentSigner: Optional[Any]
    parentSignerValid: Optional[Any]
    parentSubTrueType: Optional[Any]
    parentTrueType: Optional[Any]
    parentUser: Optional[Any]
    parentUserDomain: Optional[Any]
    pcapUUID: Optional[Any]
    peerGroup: Optional[Any]
    peerHost: Optional[Any]
    peerIp: Optional[Any]
    plang: Optional[Any]
    pname: Optional[Any]
    policyId: Optional[Any]
    policyName: Optional[Any]
    policyTemplate: Optional[Any]
    policyUuid: Optional[Any]
    principalName: Optional[Any]
    processCmd: Optional[Any]
    processCmdNormalized: Optional[Any]
    processFileCreation: Optional[Any]
    processFileGroupName: Optional[Any]
    processFileHashSha1: Optional[Any]
    processFileHashSha256: Optional[Any]
    processFileModifiedTime: Optional[Any]
    processFilePath: Optional[Any]
    processFileRemoteAccess: Optional[Any]
    processFileSaclString: Optional[Any]
    processFileSize: Optional[Any]
    processLaunchTime: Optional[Any]
    processName: Optional[Any]
    processPid: Optional[Any]
    processSigner: Optional[Any]
    processSignerValid: Optional[Any]
    processSubTrueType: Optional[Any]
    processTrueType: Optional[Any]
    processUser: Optional[Any]
    processUserDomain: Optional[Any]
    proto: Optional[Any]
    rating: Optional[Any]
    rawDataStr: Optional[Any]
    rawDstIp: Optional[Any]
    rawDstPort: Optional[Any]
    remarks: Optional[Any]
    request: Optional[Any]
    requestBase: Optional[Any]
    requestClientApplication: Optional[Any]
    requestHeaders: Optional[Any]
    requests: Optional[Any]
    riskConfidenceLevel: Optional[Any]
    riskLevel: Optional[Any]
    rt: Optional[Any]
    rtHour: Optional[Any]
    ruleId: Optional[Any]
    ruleName: Optional[Any]
    ruleSetName: Optional[Any]
    ruleType: Optional[Any]
    ruleVer: Optional[Any]
    sAttackPhase: Optional[Any]
    sOSName: Optional[Any]
    sUser1: Optional[Any]
    samUser: Optional[Any]
    scanTs: Optional[Any]
    scanType: Optional[Any]
    score: Optional[Any]
    secondAct: Optional[Any]
    secondActResult: Optional[Any]
    sender: Optional[Any]
    senderIp: Optional[Any]
    severity: Optional[Any]
    shost: Optional[Any]
    signInHighlightAppNames: Optional[Any]
    signInHighlightEventTimestamps: Optional[Any]
    signInHighlightIps: Optional[Any]
    signer: Optional[Any]
    smac: Optional[Any]
    smbSharedName: Optional[Any]
    spt: Optional[Any]
    src: Optional[Any]
    srcFileCreation: Optional[Any]
    srcFileCurrentOwnerName: Optional[Any]
    srcFileGroupName: Optional[Any]
    srcFileHashSha1: Optional[Any]
    srcFileHashSha256: Optional[Any]
    srcFileIsRemoteAccess: Optional[Any]
    srcFileModifiedTime: Optional[Any]
    srcFileOwnerName: Optional[Any]
    srcFilePath: Optional[Any]
    srcFileSize: Optional[Any]
    srcFirstSeen: Optional[Any]
    srcGroup: Optional[Any]
    srcLastSeen: Optional[Any]
    srcSigner: Optional[Any]
    srcSignerValid: Optional[Any]
    srcZone: Optional[Any]
    subRuleId: Optional[Any]
    subRuleName: Optional[Any]
    suid: Optional[Any]
    suser: Optional[Any]
    suspiciousObject: Optional[Any]
    suspiciousObjectType: Optional[Any]
    tacticId: Optional[Any]
    tags: Optional[Any]
    targetShare: Optional[Any]
    targetType: Optional[Any]
    threatName: Optional[Any]
    threatType: Optional[Any]
    timezone: Optional[Any]
    urlCat: Optional[Any]
    userDepartment: Optional[Any]
    userDomain: Optional[Any]
    uuid: Optional[Any]
    winEventId: Optional[Any]


class OATAllowlistSchema(BaseModel):
    detectionTime: str
    endpoint: dict
    filters: List[dict]
    entityType: str
    entityName: str
    detail: OATDetail


ALLOWED_OAT_FIELDS = [
    "detectionTime",
    "endpoint",
    "filters",
    "entityType",
    "entityName",
]


ALLOWED_OAT_DETAIL_FIELDS = [
    "act",
    "actResult",
    "additionalEventData",
    "aggregatedCount",
    "app",
    "appDexSha256",
    "appGroup",
    "application",
    "aptRelated",
    "attachmentFileHash",
    "attachmentFileHashSha1",
    "attachmentFileHashSha256",
    "attachmentFileHashSha256s",
    "attachmentFileHashes",
    "attachmentFileHashs",
    "attachmentFileName",
    "attachmentFileSize",
    "attachmentFileTlshes",
    "attachmentFileTlshs",
    "attachmentFileType",
    "attachmentSha1",
    "attachmentSha256",
    "attachmentSize",
    "attachmentSource",
    "attachmentTlsh",
    "attachmentUrls",
    "behaviorCat",
    "blocking",
    "bmGroup",
    "botCmd",
    "botUrl",
    "cat",
    "cccaDestination",
    "cccaDestinationFormat",
    "cccaDetection",
    "cccaDetectionSource",
    "cccaRiskLevel",
    "channel",
    "clientFlag",
    "clientIp",
    "compressedFileHash",
    "compressedFileHashSha256",
    "compressedFileName",
    "compressedFileSize",
    "compressedFileType",
    "computerDomain",
    "confidence",
    "correlationCat",
    "correlationData",
    "cve",
    "cves",
    "dOSName",
    "dUser1",
    "data0",
    "data0Name",
    "data1",
    "data1Name",
    "data2",
    "dataType",
    "description",
    "destinationPath",
    "detailTrace",
    "detectionName",
    "detectionType",
    "deviceDirection",
    "deviceGUID",
    "deviceMacAddress",
    "dhost",
    "direction",
    "dmac",
    "dnsQueryType",
    "domainName",
    "dpt",
    "dst",
    "dstGroup",
    "dstZone",
    "duser",
    "dvchost",
    "endpointGUID",
    "endpointGuid",
    "endpointHostName",
    "endpointIp",
    "endpointMacAddress",
    "endpointModel",
    "engineOperation",
    "errorMessage",
    "eventClass",
    "eventDataAuthenticationPackageName",
    "eventDataConsumer",
    "eventDataIpAddress",
    "eventDataLogonProcessName",
    "eventDataLogonType",
    "eventDataPath",
    "eventDataProviderName",
    "eventDataProviderPath",
    "eventDataScriptBlockText",
    "eventID",
    "eventId",
    "eventName",
    "eventSourceType",
    "eventSubClass",
    "eventSubId",
    "eventSubName",
    "eventTime",
    "extraInfo",
    "fileCreation",
    "fileExt",
    "fileHash",
    "fileHashSha256",
    "fileName",
    "fileOperation",
    "filePath",
    "filePathName",
    "fileSize",
    "fileType",
    "filterName",
    "filterRiskLevel",
    "filterType",
    "firstAct",
    "firstActResult",
    "firstSeen",
    "forensicFileHash",
    "forensicFilePath",
    "fullPath",
    "highlightedText",
    "hostName",
    "hostSeverity",
    "hotFix",
    "httpLocation",
    "httpReferer",
    "httpXForwardedForIp",
    "interestedGroup",
    "interestedHost",
    "interestedIp",
    "interestedMacAddress",
    "ircChannelName",
    "ja3Hash",
    "ja3sHash",
    "k8sNamespace",
    "lastSeen",
    "logonUser",
    "mDevice",
    "mailAttachmentHash",
    "mailBccAddresses",
    "mailCcAddresses",
    "mailDeliveryTime",
    "mailDirection",
    "mailFolder",
    "mailFromAddresses",
    "mailHeaderHash",
    "mailHelo",
    "mailMetaData",
    "mailMetaText",
    "mailMsgSubject",
    "mailReceivedTime",
    "mailReplyToAddresses",
    "mailRuleId",
    "mailScore",
    "mailSenderIp",
    "mailSmtpFromAddresses",
    "mailSmtpOriginalRecipients",
    "mailSmtpRecipients",
    "mailSourceDomain",
    "mailTagHash",
    "mailTagHashRawSignature",
    "mailTextHash",
    "mailThreatType",
    "mailToAddresses",
    "mailUrlHash",
    "mailUrlsRealLink",
    "mailUrlsVisibleLink",
    "mailUserAgent",
    "mailWholeHeader",
    "mailXMailer",
    "mailbox",
    "malDst",
    "malFamily",
    "malName",
    "malSrc",
    "malSubType",
    "malType",
    "malTypeGroup",
    "metaPwdSprayClientAppUsed",
    "metaPwdSprayClientDeviceBrowser",
    "metaPwdSprayIp",
    "metaPwdSprayIpSignInFailCount",
    "metaPwdSprayIpSignInSuccessCount",
    "metaPwdSprayIpUserCount",
    "metaPwdSprayUserSignInFailCount",
    "metaPwdSprayUserSignInSuccessCount",
    "metaSuspiciousMailboxRulesForwardAddresses",
    "metaType",
    "mitreMapping",
    "moduleName",
    "msgUuidChain",
    "objectApiHookNum",
    "objectApiName",
    "objectAppName",
    "objectBmData",
    "objectCmd",
    "objectCmdNormalized",
    "objectContentName",
    "objectFileCreation",
    "objectFileGroupName",
    "objectFileHashSha1",
    "objectFileHashSha256",
    "objectFileIsRemoteAccess",
    "objectFileModifiedTime",
    "objectFileName",
    "objectFileOwnerSid",
    "objectFilePath",
    "objectFileRemoteAccess",
    "objectFileSaclString",
    "objectFileSize",
    "objectFirstRecorded",
    "objectFirstSeen",
    "objectHostName",
    "objectIp",
    "objectIps",
    "objectLastSeen",
    "objectLaunchTime",
    "objectName",
    "objectPort",
    "objectRawDataStr",
    "objectRegType",
    "objectRegistryData",
    "objectRegistryKeyHandle",
    "objectRegistryRoot",
    "objectRegistryValue",
    "objectRunAsLocalAccount",
    "objectSigner",
    "objectSignerValid",
    "objectSubTrueType",
    "objectTrueType",
    "objectType",
    "objectUser",
    "objectUserDomain",
    "objectUserGroup",
    "osName",
    "osType",
    "osVer",
    "pAttackPhase",
    "pComp",
    "pTags",
    "parentCmd",
    "parentCmdNormalized",
    "parentFileCreation",
    "parentFileGroupName",
    "parentFileHashSha1",
    "parentFileHashSha256",
    "parentFileModifiedTime",
    "parentFilePath",
    "parentFileRemoteAccess",
    "parentFileSize",
    "parentLaunchTime",
    "parentName",
    "parentSigner",
    "parentSignerValid",
    "parentSubTrueType",
    "parentTrueType",
    "parentUser",
    "parentUserDomain",
    "pcapUUID",
    "peerGroup",
    "peerHost",
    "peerIp",
    "plang",
    "pname",
    "policyId",
    "policyName",
    "policyTemplate",
    "policyUuid",
    "principalName",
    "processCmd",
    "processCmdNormalized",
    "processFileCreation",
    "processFileGroupName",
    "processFileHashSha1",
    "processFileHashSha256",
    "processFileModifiedTime",
    "processFilePath",
    "processFileRemoteAccess",
    "processFileSaclString",
    "processFileSize",
    "processLaunchTime",
    "processName",
    "processPid",
    "processSigner",
    "processSignerValid",
    "processSubTrueType",
    "processTrueType",
    "processUser",
    "processUserDomain",
    "proto",
    "rating",
    "rawDataStr",
    "rawDstIp",
    "rawDstPort",
    "remarks",
    "request",
    "requestBase",
    "requestClientApplication",
    "requestHeaders",
    "requests",
    "riskConfidenceLevel",
    "riskLevel",
    "rt",
    "rtHour",
    "ruleId",
    "ruleName",
    "ruleSetName",
    "ruleType",
    "ruleVer",
    "sAttackPhase",
    "sOSName",
    "sUser1",
    "samUser",
    "scanTs",
    "scanType",
    "score",
    "secondAct",
    "secondActResult",
    "sender",
    "senderIp",
    "severity",
    "shost",
    "signInHighlightAppNames",
    "signInHighlightEventTimestamps",
    "signInHighlightIps",
    "signer",
    "smac",
    "smbSharedName",
    "spt",
    "src",
    "srcFileCreation",
    "srcFileCurrentOwnerName",
    "srcFileGroupName",
    "srcFileHashSha1",
    "srcFileHashSha256",
    "srcFileIsRemoteAccess",
    "srcFileModifiedTime",
    "srcFileOwnerName",
    "srcFilePath",
    "srcFileSize",
    "srcFirstSeen",
    "srcGroup",
    "srcLastSeen",
    "srcSigner",
    "srcSignerValid",
    "srcZone",
    "subRuleId",
    "subRuleName",
    "suid",
    "suser",
    "suspiciousObject",
    "suspiciousObjectType",
    "tacticId",
    "tags",
    "targetShare",
    "targetType",
    "threatName",
    "threatType",
    "timezone",
    "urlCat",
    "userDepartment",
    "userDomain",
    "uuid",
    "winEventId",
]


OAT_OVERSIZED_FIELDS = [
    ["detail", "objectRegistryData"],
    ["detail", "objectRawDataStr"],
    ["detail", "rawDataStr"],
    ["detail", "remarks"],
    ["detail", "requests"],
    ["detail", "mailToAddresses"],
    ["detail", "mailUrlsVisibleLink"],
    ["detail", "mailUrlsRealLink"],
    ["detail", "mailTagHashRawSignature"],
    ["filters"]
]
