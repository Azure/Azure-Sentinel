import json
import os
from datetime import datetime, timedelta, timezone

import azure.functions as func
import pytz
from azure.storage.queue import QueueClient, TextBase64EncodePolicy
from shared_code import configurations
from shared_code.customized_logger.customized_json_logger import (
    get_customized_json_logger,
)

MAX_PROACTIVE_RETRY_MINUTES = configurations.get_max_proactive_retry_minutes()
PROACTIVE_RETRY_TIME_INTERVAL_MINUTES = (
    configurations.get_proactive_retry_time_interval_minutes()
)
RETRY_TIME_INTERVAL_MINUTES = configurations.get_retry_time_interval_minutes()
DATETIME_FORMAT = configurations.get_datetime_format()

logger = get_customized_json_logger()


def main(wbPoisonMsg: func.QueueMessage) -> None:
    try:
        queue_client = QueueClient.from_connection_string(
            os.environ["AzureWebJobsStorage"],
            configurations.get_wb_list_queue_name(),
            message_encode_policy=TextBase64EncodePolicy(),
        )

        poison_msg = wbPoisonMsg.get_body().decode()
        poison_msg_json = json.loads(poison_msg)
        start_time = poison_msg_json.get("start_time", None)

        if not start_time:
            logger.info(
                f"poison_msg_json:{poison_msg_json}. No start_time in message."
                f"Use default retry interval: {RETRY_TIME_INTERVAL_MINUTES} minutes"
            )
            queue_client.send_message(
                poison_msg, visibility_timeout=RETRY_TIME_INTERVAL_MINUTES * 60
            )
            return

        start_time = pytz.utc.localize(datetime.strptime(start_time, DATETIME_FORMAT))
        logger.info(f"poison_msg_json:{poison_msg_json}, start_time:{start_time}")

        current_time = datetime.now(timezone.utc)
        visibility_timeout = (
            RETRY_TIME_INTERVAL_MINUTES * 60
            if start_time
            < current_time - timedelta(minutes=MAX_PROACTIVE_RETRY_MINUTES)
            else PROACTIVE_RETRY_TIME_INTERVAL_MINUTES * 60
        )

        queue_client.send_message(poison_msg, visibility_timeout=visibility_timeout)

    except Exception as e:
        logger.error(f"Fail to process WB poison message: {e}")
        raise
