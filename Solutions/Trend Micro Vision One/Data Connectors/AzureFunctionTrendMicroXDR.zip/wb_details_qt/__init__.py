import typing

import azure.functions as func
from requests.exceptions import HTTPError
from shared_code import configurations, transform_utils, utils
from shared_code.customized_logger import custom_event_logger
from shared_code.customized_logger.customized_json_logger import (
    get_customized_json_logger,
)
from shared_code.data_collector import LogAnalytics
from shared_code.models.workbench import RCATaskMessage, WBDetailMessage
from shared_code.services.workbench_service import (
    get_associated_incident_id,
    get_incident_view_list,
    get_rca_task,
    get_workbench_detail_v3,
)
from shared_code.trace_utils.trace import trace_manager
from shared_code import transform_utils


WORKSPACE_ID = configurations.get_workspace_id()
WORKSPACE_KEY = configurations.get_workspace_key()
API_TOKENS = configurations.get_api_tokens()
XDR_HOST_URL = configurations.get_xdr_host_url()
WB_LOG_TYPE = configurations.get_wb_log_type()
RCA_TASK_LOG_TYPE = configurations.get_rca_task_log_type()


logger = get_customized_json_logger()


def main(wbMsg: func.QueueMessage, rcaMsg: func.Out[typing.List[str]]) -> None:
    """_summary_

    Args:
        wbMsg (func.QueueMessage): {
            'clp_id': 'clp_id',
            'workbench_record': {
                "investigationStatus": 1,
                "priorityScore": 60,
                "workbenchName": "Heartbeat Model",
                "workbenchId": "WB-2-20200214-0003",
                "workbenchLink": "https://THE_WORKBENCH_URL",
                "createdTime": "2020-02-14T10:05:09Z",
                "updatedTime": "2020-02-15T10:05:09Z",
                "severity": "critical",
                "impactScope": {
                    "desktopCount": 10,
                    "serverCount": 0,
                    "accountCount": 1,
                    "emailAddressCount": 0
                }
            },
            'task_id':'task_id'
        }
        rcaMsg (func.Out[typing.List[str]]): _description_

    Raises:
        Exception: _description_
    """

    custom_event = {}

    try:
        payload = WBDetailMessage.parse_obj(wbMsg.get_json())

        clp_id = payload.clp_id
        workbench_record = payload.workbench_record
        workbench_id = workbench_record["workbenchId"]
        trace_manager.task_id = payload.task_id
        logger.info(f"Event from workbench-queue: {payload}")

        token = utils.find_token_by_clp(clp_id, API_TOKENS)
        if not token:
            # See: https://jr.trendmicro.com/browse/MDR-500
            logger.warning(f"Account token not found, clp: {clp_id}, stop current job.")
            return

        # init custom event
        custom_event = {
            "item": "Workbench",
            "func_name": "wb_details_qt",
            "event_name": "DataConnector.WB.Details",
            "level": "Info",
            "clp_id": clp_id,
            "task_id": trace_manager.task_id,
            "trace_id": trace_manager.trace_id,
            "wb_id": workbench_id,
        }

        workbench_detail = get_workbench_detail_v3(
            token, workbench_id, custom_event=custom_event
        )

        # write custom event
        custom_event_logger.write_custom_event(custom_event)

        incident_id = workbench_detail.get("incidentId")
        incident_view_records = None
        associated_alerts = None

        # get optional associated incident view id
        if incident_id and incident_id.strip():
            _, incident_view_records, _ = get_incident_view_list(
                token, incident_id=incident_id
            )
            _, associated_alerts = get_associated_incident_id(
                incident_view_records, incident_id=incident_id
            )
        else:
            # TODO: this can be removed after workbench api is updated
            _, incident_view_records, _ = get_incident_view_list(
                token, workbench_id=workbench_id
            )
            incident_id, associated_alerts = get_associated_incident_id(
                incident_view_records, workbench_id=workbench_id
            )

        # transform data
        customized_workbench_json = transform_utils.customize_workbench_json(
            clp_id, workbench_detail, workbench_record, incident_id, associated_alerts
        )

        # send to log analytics
        log_analytics = LogAnalytics(WORKSPACE_ID, WORKSPACE_KEY, WB_LOG_TYPE)
        log_analytics.post_data(customized_workbench_json)
        logger.info(f"Send workbench data successfully. Workbench id: {workbench_id}.")

        ### RCA Task ###
        # init custom event
        custom_event = {
            "item": "Workbench",
            "func_name": "wb_details_qt",
            "event_name": "DataConnector.RCA.List",
            "level": "Info",
            "clp_id": clp_id,
            "task_id": trace_manager.task_id,
            "trace_id": trace_manager.trace_id,
            "wb_id": workbench_id,
        }

        rca_tasks = []
        rac_task_log = []

        # get rca task
        rca_raw_tasks = get_rca_task(token, workbench_id, custom_event=custom_event)

        for task in rca_raw_tasks:
            task_status = task["status"]
            if task_status != "PROCESS_COMPLETE":
                logger.warning(
                    f"Get rca task with status: {task_status}, Workbench id: {workbench_id}. No need to get rca detail."
                )
                continue

            # process prca task info
            rac_task_log.append(
                transform_utils.transform_rca_task(clp_id, workbench_id, task)
            )

            for target in task["targets"]:
                target_status = target["targetStatus"]

                if target_status != "PROCESS_COMPLETE":
                    logger.warning(
                        f"Get rca target with status: {target_status}, Workbench id: {workbench_id}. No need to get rca detail."
                    )
                    continue
                target_info = target.copy()
                target_info.pop("targetStatus")

                rca_tasks.append(
                    RCATaskMessage(
                        clp_id=clp_id,
                        workbench_id=workbench_id,
                        rca_task_id=task["id"],
                        task_name=task["name"],
                        target_guid=target["guid"],
                        target_info=target_info,
                        task_id=trace_manager.task_id,
                    ).json()
                )

        rca_count = len(rac_task_log)
        custom_event["rca_count"] = rca_count

        if rca_count > 0:
            log_analytics = LogAnalytics(WORKSPACE_ID, WORKSPACE_KEY, RCA_TASK_LOG_TYPE)
            log_analytics.post_data(rac_task_log)

            logger.info(
                f"Send prca task data successfully. Workbench id: {workbench_id}, Count: {rca_count}."
            )

        if rca_tasks:
            rcaMsg.set(rca_tasks)

        # write custom event
        custom_event_logger.write_custom_event(custom_event)

    except (HTTPError, Exception) as err:
        error_type = type(err).__name__
        error_message = str(err)

        if error_type == "HTTPError":
            logger.exception(
                f"Fail to get workbench detail! Exception: {error_message}",
            )
        else:
            logger.exception(f"Internal error. Exception: {error_message}.")

        # write custom error event
        custom_error_event = custom_event.copy()
        custom_error_event["level"] = "Error"
        custom_error_event["message"] = error_message
        custom_event_logger.write_custom_event(custom_error_event)

        raise
