# TimerTrigger - Python

The `TimerTrigger` makes it incredibly easy to have your functions executed on a schedule. This sample demonstrates a simple use case of calling your function every 5 minutes.

## How it works

For a `TimerTrigger` to work, you provide a schedule in the form of a [cron expression](https://en.wikipedia.org/wiki/Cron#CRON_expression)(See the link for full details). A cron expression is a string with 6 separate expressions which represent a given schedule via patterns. The pattern we use to represent every 5 minutes is `0 */5 * * * *`. This, in plain text, means: "When seconds is equal to 0, minutes is divisible by 5, for any hour, day of the month, month, day of the week, or year".

## Learn more


## Prepare dev environment
```
cd TrendMicroXDR-LogPuller
pip install pre-commit
pre-commit install
```
<TODO> Documentation

## Build flow

In order to generate build on local, you have install container management tool, podman, to build from container. After executing package_podman.sh, it will generate a compressed file, AzureFunctionTrendMicroXDR.zip. You have to upload it in the storage account on Azure.

### Podman installation

```shell
# remove and install the latest version
$ brew uninstall podman
$ brew install podman

```

### Start to generate build file for non-ADDA site
```shell
$ cd TrendMicroXDR-LogPuller
$ bash ./package_podman.sh

# output: AzureFunctionTrendMicroXDR.zip

```

### Upload the build file in the storage account on Azure

Storage account list:
  - [sentineldeployapp](https://portal.azure.com/#@TrendMicro.onmicrosoft.com/resource/subscriptions/f58ad48f-4d1f-43f7-a7aa-4e9330721062/resourceGroups/sentineldeployapp/providers/Microsoft.Storage/storageAccounts/sentineldeployapp/storagebrowser)
  - sentineldeployappau1
  - sentineldeployappeu1
  - sentineldeployappin1
  - sentineldeployappjp1
  - sentineldeployappsg1
  - sentineldeployappmea1
  - sentineldeployappqa

Upload AzureFunctionTrendMicroXDR.zip in the storage account, sentineldeployapp, on Azure and check it is uploaded successfully on the the following folders:
  - connector-file-> dev-> beta
  - connector-file-> dev-> prod

You can start your connector deployment for different phases via Jenkins: https://rd-jenkins.luwak.trendmicro.com/job/Connector%20Deployment/
