import typing

import azure.functions as func
from requests.exceptions import HTTPError
from shared_code import configurations, utils
from shared_code.customized_logger import custom_event_logger
from shared_code.customized_logger.customized_json_logger import (
    get_customized_json_logger,
)
from shared_code.data_collector import LogAnalytics
from shared_code.models.workbench import WBDetailMessage, WBListMessage
from shared_code.services.workbench_service import get_workbench_list
from shared_code.trace_utils.trace import trace_manager

API_TOKENS = configurations.get_api_tokens()
WORKSPACE_ID = configurations.get_workspace_id()
WORKSPACE_KEY = configurations.get_workspace_key()
LOG_TYPE = configurations.get_health_check_log_type()
QUERY_ALL_WORKBENCH = configurations.get_query_all_workbench()


logger = get_customized_json_logger()


def main(wbListMsg: func.QueueMessage, wbMsg: func.Out[typing.List[str]]) -> None:
    clp_id = ""
    error = None
    custom_event = {}
    try:
        log_analytics = LogAnalytics(WORKSPACE_ID, WORKSPACE_KEY, LOG_TYPE)
        health_check_data = {}
        event = WBListMessage.parse_obj(wbListMsg.get_json())

        clp_id = event.clp_id
        start_time_str = event.start_time
        end_time_str = event.end_time
        trace_manager.task_id = event.task_id

        logger.info(f"Event from workbench-list-queue: {event}")

        health_check_data = {
            "clpId": clp_id,
            "queryStartTime": start_time_str,
            "queryEndTime": end_time_str,
        }

        token = utils.find_token_by_clp(clp_id, API_TOKENS)

        if not token:
            # See: https://jr.trendmicro.com/browse/MDR-500
            logger.warning(f"Account token not found, clp: {clp_id}, stop current job.")
            return

        logger.info(
            f"start to poll workbench list from {start_time_str} to {end_time_str}."
            f"clp_id:{clp_id}."
        )

        # init custom event
        custom_event = {
            "item": "Workbench",
            "func_name": "wb_list_qt",
            "event_name": "DataConnector.WB.List",
            "level": "Info",
            "clp_id": clp_id,
            "task_id": trace_manager.task_id,
            "trace_id": trace_manager.trace_id,
            "start_date_time": start_time_str,
            "end_date_time": end_time_str,
        }

        # get workbench ids
        total_count, workbench_records = get_workbench_list(
            token,
            start_time_str,
            end_time_str,
            QUERY_ALL_WORKBENCH,
            custom_event=custom_event,
        )
        while total_count > len(workbench_records):
            workbench_records.extend(
                get_workbench_list(
                    token,
                    start_time_str,
                    end_time_str,
                    QUERY_ALL_WORKBENCH,
                    offset=len(workbench_records),
                )[1]
            )

        wbMsg.set(
            [
                WBDetailMessage(
                    clp_id=clp_id,
                    workbench_record=workbench_record,
                    task_id=trace_manager.task_id,
                    start_time=start_time_str,
                ).json()
                for workbench_record in workbench_records
            ]
        )

        logger.debug(f"workbench_records: {workbench_records}")
        logger.info(f"{total_count} workbench events received.")

        wb_count = len(workbench_records)
        health_check_data["newWorkbenchCount"] = wb_count

        # write custom event
        custom_event["wb_count"] = wb_count
        custom_event_logger.write_custom_event(custom_event)

    except (HTTPError, Exception) as err:
        error_type = type(err).__name__
        error_message = str(err)

        if error_type == "HTTPError":
            logger.exception(
                f"Fail to get workbench list! Exception: {err}. clp_id:{clp_id}",
            )
        else:
            logger.exception(f"Internal error. clp_id:{clp_id}")

        error, health_check_data["error"] = err, error_message

        # write custom error event
        custom_error_event = custom_event.copy()
        custom_error_event["level"] = "Error"
        custom_error_event["message"] = error_message
        custom_event_logger.write_custom_event(custom_error_event)

    finally:
        log_analytics.post_data(health_check_data)

    if error:
        raise error
