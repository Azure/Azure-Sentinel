import azure.functions as func
from requests.exceptions import HTTPError
from shared_code import configurations, transform_utils, utils
from shared_code.customized_logger import custom_event_logger
from shared_code.customized_logger.customized_json_logger import (
    get_customized_json_logger,
)
from shared_code.data_collector import LogAnalytics
from shared_code.models.workbench import RCATaskMessage
from shared_code.services.workbench_service import get_rca_task_detail
from shared_code.trace_utils.trace import trace_manager

WORKSPACE_ID = configurations.get_workspace_id()
WORKSPACE_KEY = configurations.get_workspace_key()
API_TOKENS = configurations.get_api_tokens()

logger = get_customized_json_logger()


def main(rcaMsg: func.QueueMessage) -> None:
    try:
        payload = RCATaskMessage.parse_obj(rcaMsg.get_json())

        clp_id = payload.clp_id
        workbench_id = payload.workbench_id
        trace_manager.task_id = payload.task_id
        rca_task_id = payload.rca_task_id
        task_name = payload.task_name
        target_guid = payload.target_guid
        target_info = payload.target_info

        logger.info(
            f"Event from rca-queue: clp:{clp_id}, workbench_id:{workbench_id},"
            f" task_id:{rca_task_id}, task_name:{task_name}, target_guid{target_guid}"
        )

        token = utils.find_token_by_clp(clp_id, API_TOKENS)
        if not token:
            # See: https://jr.trendmicro.com/browse/MDR-500
            logger.warning(f"Account token not found, clp: {clp_id}, stop current job.")
            return

        # init custom event
        custom_event = {
            "item": "Workbench",
            "func_name": "rca_qt",
            "event_name": "DataConnector.RCA.Details",
            "level": "Info",
            "clp_id": clp_id,
            "task_id": trace_manager.task_id,
            "trace_id": trace_manager.trace_id,
        }

        rca_task_detail = get_rca_task_detail(
            token, rca_task_id, target_guid, custom_event=custom_event
        )

        target_info = {
            "xdrCustomerID": clp_id,
            "taskId": rca_task_id,
            "taskName": task_name,
            "agentEntity": target_info,
            "workbenchId": workbench_id,
        }

        rca_task_result_log = transform_utils.transform_rca_result(
            target_info, rca_task_detail
        )

        if len(rca_task_result_log) > 0:
            log_type = configurations.get_rca_log_type()
            log_analytics = LogAnalytics(WORKSPACE_ID, WORKSPACE_KEY, log_type)
            log_analytics.post_data(rca_task_result_log)

        logger.info(
            f"Send rca data successfully. Task id: {rca_task_id}, Task name: {task_name},Target guid: {target_guid}"
        )

        # write custom event
        custom_event_logger.write_custom_event(custom_event)

    except (HTTPError, Exception) as err:
        error_type = type(err).__name__
        error_message = str(err)

        if error_type == "HTTPError":
            logger.exception(
                f"Fail to get rca detail!  Exception: {error_message}",
            )
        else:
            logger.exception(f"Internal error. Exception: {error_message}.")

        # write custom error event
        custom_error_event = custom_event.copy()
        custom_error_event["level"] = "Error"
        custom_error_event["message"] = error_message
        custom_event_logger.write_custom_event(custom_error_event)

        raise
