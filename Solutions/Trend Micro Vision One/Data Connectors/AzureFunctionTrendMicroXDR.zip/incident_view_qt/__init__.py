import azure.functions as func
from requests.exceptions import HTTPError
from shared_code import configurations, utils
from shared_code.customized_logger import custom_event_logger
from shared_code.customized_logger.customized_json_logger import (
    get_customized_json_logger,
)
from shared_code.data_collector import LogAnalytics
from shared_code.models.workbench import IncidentViewMessage
from shared_code.services.workbench_service import get_incident_view_list
from shared_code.trace_utils.trace import trace_manager

API_TOKENS = configurations.get_api_tokens()
WORKSPACE_ID = configurations.get_workspace_id()
WORKSPACE_KEY = configurations.get_workspace_key()
LOG_TYPE = configurations.get_iv_log_type()
HEALTH_CHECK_LOG_TYPE = configurations.get_iv_health_check_log_type()


logger = get_customized_json_logger()


def main(ivMsg: func.QueueMessage) -> None:
    clp_id = ""
    error = None
    inserted_count = 0
    try:
        log_analytics = LogAnalytics(WORKSPACE_ID, WORKSPACE_KEY, LOG_TYPE)
        health_check_data = {}
        event = IncidentViewMessage.parse_obj(ivMsg.get_json())

        clp_id = event.clp_id
        start_time_str = event.start_time
        end_time_str = event.end_time
        trace_manager.task_id = event.task_id

        logger.info(f"Event from incident-view-queue: {event}")

        health_check_data = {
            "clpId": clp_id,
            "queryStartTime": start_time_str,
            "queryEndTime": end_time_str,
        }

        token = utils.find_token_by_clp(clp_id, API_TOKENS)

        if not token:
            # See: https://jr.trendmicro.com/browse/MDR-500
            logger.warning(f"Account token not found, clp: {clp_id}, stop current job.")
            return

        logger.info(
            f"start to poll incident view from {start_time_str} to {end_time_str}."
            f"clp_id:{clp_id}."
        )

        # init custom event
        custom_event = {
            "item": "Workbench",
            "func_name": "incident_view_qt",
            "event_name": "DataConnector.Incident.List",
            "level": "Info",
            "clp_id": clp_id,
            "task_id": trace_manager.task_id,
            "trace_id": trace_manager.trace_id,
            "start_date_time": start_time_str,
            "end_date_time": end_time_str,
        }

        # get incident view records
        total_count, incident_view_records, next_link = get_incident_view_list(
            token,
            start_time=start_time_str,
            end_time=end_time_str,
            custom_event=custom_event,
        )

        logger.info(f"{total_count} incident view records received.")
        logger.debug(f"incident_view_records: {incident_view_records}")
        inserted_count += len(incident_view_records)
        log_analytics.post_data(incident_view_records)

        while next_link:
            (
                total_count,
                incident_view_records,
                next_link,
            ) = get_incident_view_list(token, next_link=next_link)
            logger.debug(f"incident_view_records: {incident_view_records}")
            logger.info(
                f"Get incident view by link, count: {len(incident_view_records)}"
            )
            inserted_count += len(incident_view_records)
            log_analytics.post_data(incident_view_records)

        health_check_data["newIncidentViewCount"] = inserted_count

        # write custom event
        custom_event["incident_count"] = inserted_count
        custom_event_logger.write_custom_event(custom_event)

    except (HTTPError, Exception) as err:
        error_type = type(err).__name__
        error_message = str(err)

        if error_type == "HTTPError":
            logger.exception(
                f"Fail to get incident view records! Exception: {error_message}. clp_id: {clp_id}"
            )
        else:
            logger.exception(f"Internal error. clp_id:{clp_id}")

        error, health_check_data["error"] = err, error_message

        # write custom error event
        custom_error_event = custom_event.copy()
        custom_error_event["level"] = "Error"
        custom_error_event["message"] = error_message
        custom_event_logger.write_custom_event(custom_error_event)

    finally:
        health_log_analytics = LogAnalytics(
            WORKSPACE_ID, WORKSPACE_KEY, HEALTH_CHECK_LOG_TYPE
        )
        health_log_analytics.post_data(health_check_data)

    if error:
        raise error
