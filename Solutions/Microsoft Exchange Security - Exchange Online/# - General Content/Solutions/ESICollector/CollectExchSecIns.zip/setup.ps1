Param (
    [String] $JSONFileCondiguration = ".\Config\CollectExchSecConfiguration.json",
    $Instance = "Default",
    $AdditionalName = ""
)

$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
$jsonConfig = Get-Content $JSONFileCondiguration | ConvertFrom-Json

function Read-RequiredValue {
    param(
        [Parameter(Mandatory=$true)]
        [string] $Prompt
    )

    do {
        $value = Read-Host -Prompt $Prompt
        if ([string]::IsNullOrWhiteSpace($value)) {
            Write-Host "A value is required. Retry."
        }
    } while ([string]::IsNullOrWhiteSpace($value))

    return $value.Trim()
}

# Ask questions
$IngestionAPI = Read-Host -Prompt "Which ingestion API do you want to use? Azure Monitor Log Ingestion API (AM, default) or legacy Log Analytics API (LA)"
if ([string]::IsNullOrWhiteSpace($IngestionAPI)) {
    $IngestionAPI = "AM"
}
else {
    $IngestionAPI = $IngestionAPI.Trim().ToUpperInvariant()
}

while ($IngestionAPI -notin @("AM", "LA")) {
    Write-Host "Value $IngestionAPI not accepted. Enter AM or LA."
    $IngestionAPI = Read-Host -Prompt "Which ingestion API do you want to use? Azure Monitor Log Ingestion API (AM, default) or legacy Log Analytics API (LA)"
    if ([string]::IsNullOrWhiteSpace($IngestionAPI)) {
        $IngestionAPI = "AM"
    }
    else {
        $IngestionAPI = $IngestionAPI.Trim().ToUpperInvariant()
    }
}

if ($IngestionAPI -eq "AM") {
    $jsonConfig.LogCollection.SentinelLogIngestionAPIActivated = "true"
    $jsonConfig.LogCollection.DataCollectionEndpointURI = Read-RequiredValue -Prompt "Azure Monitor Data Collection Endpoint URI"
    $jsonConfig.LogCollection.DCRImmutableId = Read-RequiredValue -Prompt "Data Collection Rule immutable ID"

    $UseManagedIdentity = Read-Host -Prompt "Use managed identity for Azure Monitor authentication? (Y/n, default Y)"
    if ([string]::IsNullOrWhiteSpace($UseManagedIdentity)) {
        $UseManagedIdentity = "Y"
    }
    else {
        $UseManagedIdentity = $UseManagedIdentity.Trim().ToUpperInvariant()
    }

    while ($UseManagedIdentity -notin @("Y", "N")) {
        Write-Host "Value $UseManagedIdentity not accepted. Enter Y or N."
        $UseManagedIdentity = Read-Host -Prompt "Use managed identity for Azure Monitor authentication? (Y/n, default Y)"
        if ([string]::IsNullOrWhiteSpace($UseManagedIdentity)) {
            $UseManagedIdentity = "Y"
        }
        else {
            $UseManagedIdentity = $UseManagedIdentity.Trim().ToUpperInvariant()
        }
    }

    $jsonConfig.LogCollection.UseManagedIdentity = if ($UseManagedIdentity -eq "Y") { "true" } else { "false" }
    if ($UseManagedIdentity -eq "N") {
        $jsonConfig.LogCollection.TargetLogTenantID = Read-RequiredValue -Prompt "Entra tenant ID used for ingestion authentication"
        $jsonConfig.LogCollection.TargetLogAppID = Read-RequiredValue -Prompt "Entra application (client) ID"
        $jsonConfig.LogCollection.TargetLogCertificateThumbprint = Read-RequiredValue -Prompt "Certificate thumbprint"
    }
}
else {
    $jsonConfig.LogCollection.SentinelLogIngestionAPIActivated = "false"
    $jsonConfig.LogCollection.UseManagedIdentity = "false"
    $jsonConfig.LogCollection.WorkspaceId = Read-RequiredValue -Prompt "Log Analytics Workspace ID"
    $jsonConfig.LogCollection.WorkspaceKey = Read-RequiredValue -Prompt "Log Analytics Workspace Key"
}

$jsonConfig.Global.EnvironmentIdentification = Read-Host -Prompt "Specific name to identify the environment. You can leave it by default and the forest name will be used"

$InstanceType = Read-Host -Prompt "Do you want to process default analysis ('Def') or the IIS IoC analysis ('IoC') ?"
$validated = $false
while (-not $validated)
{
    if ($InstanceType -ne 'Def' -and $InstanceType -ne 'IoC')
    {
        Write-Host "Value $InstanceType not accepted. Retry"
        $InstanceType = Read-Host -Prompt "Do you want to process default analysis ('Def') or the IIS IoC analysis ('IoC') ?"
    }
    else  { $validated = $true }
}

if ($InstanceType -eq 'IoC') 
{
    if ($Instance -ne 'Default') { Write-Host "For IIS IoC type, the instance $Instance will be renamed to IIS-IoC. (Only 1 instance processing IIS-IoC can be created)" }
    $Instance = 'IIS-IoCs'
    $jsonConfig.Global.ESIProcessingType = "On-Premises"
}
else {
    $InstanceType = Read-Host -Prompt "Is an instance for On-Premises (OP) or Online (OL) ?"
    $validated = $false
    while (-not $validated)
    {
        if ($InstanceType -ne 'OP' -and $InstanceType -ne 'OL')
        {
            Write-Host "Value $InstanceType not accepted. Retry"
            $InstanceType = Read-Host -Prompt "Is an instance for On-Premises (OP) or Online (OL) ?"
        }
        else  { $validated = $true }
    }

    if ($InstanceType -eq 'OL') { $jsonConfig.Global.ESIProcessingType = "Online" }
    else {$jsonConfig.Global.ESIProcessingType = "On-Premises"}

    $Script:ExchangeType = $InstanceType
}

if ($Script:ExchangeType -eq 'OP')
{
    $InstanceType = Read-Host -Prompt "What is the Exchange BIN Path ? (Default : 'c:\\Program Files\\Microsoft\\Exchange Server\\V15\\bin')"
    $validated = $false
    
    if (-not [String]::IsNullOrEmpty($InstanceType))
    {
        $jsonConfig.Advanced.ExchangeServerBinPath = $InstanceType
    }
}


Write-Host "Saving information into $JSONFileCondiguration"
$jsonConfig | ConvertTo-Json -Depth 20 | Set-Content $JSONFileCondiguration

# Creating Scheduled Task
Write-Host "Schedule Task Creation ..."

$DailyHour = Read-Host -Prompt "At which hour the instance $Instance can be executed each day ? (format : hh:mmAM or hh:mmPM)"
$validated = $false
while (-not $validated)
{
    if ($DailyHour -notmatch "^[0-9]{1,2}:[0-9]{1,2}(AM|PM)$")
    {
        Write-Host "Value $DailyHour not accepted. Retry"
        $DailyHour = Read-Host -Prompt "At which hour the instance $Instance can be executed each day ? (format : hh:mmAM or hh:mmPM)"
    }
    else  { $validated = $true }
}

$TaskUserAccount = Read-Host -Prompt "What is the account (in UPN format svc@contoso.com) used to launch the instance $Instance ?"
$TaskUserPass = Read-Host -Prompt "What is the Password of the user $TaskUserAccount used to launch the instance $Instance ?" -AsSecureString
$PwdPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($TaskUserPass)
$PlainTextPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto($PwdPointer)
[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($PwdPointer)

$scriptExecute = $scriptFolder + "\CollectExchSecIns.ps1"
if ($Instance -ne "Default")
{
    $scriptExecute += " -InstanceName '$Instance'"
}
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "$scriptExecute"
$trigger = New-ScheduledTaskTrigger -Daily -At $DailyHour
$STSet = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 23) -MultipleInstances IgnoreNew -RestartCount 5 -RestartInterval (New-TimeSpan -Hours 1)

$TaskName = "ESI - Exchange Security Configuration Collector - $Instance"
if ($AdditionalName -ne "") { $TaskName += " - $AdditionalName" }

Register-ScheduledTask -TaskName $TaskName -Trigger $trigger -User $TaskUserAccount -Password $PlainTextPassword -Action $action -Settings $STSet

Read-Host -Prompt "Press any key to continue ..."