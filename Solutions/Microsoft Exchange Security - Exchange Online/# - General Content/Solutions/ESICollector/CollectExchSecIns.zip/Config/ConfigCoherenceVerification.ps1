<#

INTERNAL ONLY - NOT TO BE DISTRIBUTED

Disclaimer:
This sample script is not supported under any Microsoft standard support program or service.
The sample script is provided AS IS without warranty of any kind. Microsoft further disclaims
all implied warranties including, without limitation, any implied warranties of merchantability
or of fitness for a particular purpose. The entire risk arising out of the use or performance of
the sample scripts and documentation remains with you. In no event shall Microsoft, its authors,
or anyone else involved in the creation, production, or delivery of the scripts be liable for any
damages whatsoever (including, without limitation, damages for loss of business profits, business
interruption, loss of business information, or other pecuniary loss) arising out of the use of or
inability to use the sample scripts or documentation, even if Microsoft has been advised of the
possibility of such damages
#>
<#
.Synopsis
    This script verify the coherence between the CollectExchSecConfigurationCloud.json and the list of Add-Ons
.DESCRIPTION
    This script verify the coherence between the CollectExchSecConfigurationCloud.json and the list of Add-Ons

.EXAMPLE
.INPUTS
    .\ConfigCoherenceVerification.ps1
        
.OUTPUTS
    The output a csv file of collected data
.NOTES
    Developed by ksangui@microsoft.com and Nicolas Lepagnez
        Version : 1.0 - Released : No - nilepagn
        - first version
#>

Write-Host "Verify if Category exists"
$Categories = @()
$Categories += Convert-Path ./Add-Ons
$ContentChanged = @()
if (Test-Path ./Add-Ons/Categories)
{
    foreach ($dir in (Get-ChildItem -Path ./Add-Ons/Categories -Directory))
    {
        $Categories += $dir.FullName
    }
}

foreach ($dir in $Categories)
{
    $shortDir = $dir -split '\\'
    $shortDir = $shortDir[$shortDir.count -1]
    Write-Host "`Retrieve Add-On files $shortDir" -ForegroundColor Green
    $files = Get-ChildItem -Path $dir -Filter "ESICollector-*.json"
    $AuditFunctionsList = @()
    $ContentCheckSum = @{}

    foreach($file in $files) 
    { 
        $content = Get-Content -Path $file.FullName | ConvertFrom-Json
        $AuditFunctionsList += $content.AuditFunctions 

        $ContentToHash = "";
        foreach ($AuditFunction in $content.AuditFunctions )
        {
            $ContentToHash += $AuditFunction.Cmdlet + ($AuditFunction.PropertySelection | ConvertTo-Json)
            if ($null -ne $AuditFunction.CustomExpressionForSelection) {$ContentToHash += ($AuditFunction.CustomExpressionForSelection | ConvertTo-Json)}
        }

        $stringAsStream = [System.IO.MemoryStream]::new()
        $writer = [System.IO.StreamWriter]::new($stringAsStream)
        $writer.write($ContentToHash)
        $writer.Flush()
        $stringAsStream.Position = 0
        $calculatedCheckSum = (Get-FileHash -InputStream $stringAsStream -Algorithm SHA256).Hash

        $ContentCheckSum[$file.Name] = @{'FileInfo' = $file; 'FileCheckSum'=(Get-FileHash $file.FullName -Algorithm SHA256).Hash; 'ContentCheckSum'=$calculatedCheckSum}
        
    }

    $ChecksumFileNameInDisk = "$dir/ESIChecksumFiles.json"

    Write-Host "Compare Checksum File with stored one $shortDir" -ForegroundColor Green
    $NoDifference = $true

    if (Test-Path $ChecksumFileNameInDisk) 
    { 
        $ChecksumOriginalFile = Get-Content -Path $ChecksumFileNameInDisk | ConvertFrom-Json; 
    }
    else 
    { 
        $ChecksumOriginalFile = $null
        Write-Host "`tNo Checksum file."; 
        $NoDifference = $false 
    }

    $TargetCheckSumTable = @{}
    $ChecksumToReview = @()

    foreach ($originalCCS in $ChecksumOriginalFile.Files)
    {
        Write-Host "`t`t compare $($originalCCS.FileChecksum) with $($ContentCheckSum[$originalCCS.FileName].FileCheckSum)."; 
        if ($originalCCS.FileChecksum -ne $ContentCheckSum[$originalCCS.FileName].FileCheckSum)
        {
            $NoDifference = $false;
            if ($null -eq $ContentCheckSum[$originalCCS.FileName])
            {
                Write-Host "`tNo file $($originalCCS.FileName) found, will be deleted on Checksum file $shortDir."
            }
            else 
            {
                Write-Host "`tChecksum difference found on file $($originalCCS.FileName) $shortDir."
                $ChecksumToReview += $originalCCS
            }
        }
        else {
            $TargetCheckSumTable[$originalCCS.FileName] = @{'FileCheckSum'=$originalCCS.FileCheckSum; 'ContentCheckSum'=$originalCCS.ContentCheckSum}
        }
    }

    # Calculate Content CheckSum in the file
    foreach ($fileReview in $ChecksumToReview)
    {
        Write-Host "`tChange Content CheckSum on File $($fileReview.FileName)"
        $FullFileName = $ContentCheckSum[$fileReview.FileName].FileInfo.FullName
        $content = Get-Content -Path $FullFileName
        $jsonContent = $content | ConvertFrom-Json
        write-host "`tOld content CheckSum : $($jsonContent.AuditFunctionProtectedArea.ContentCheckSum) / New Content CheckSum : $($ContentCheckSum[$fileReview.FileName].ContentCheckSum)"

        $CheckInfo = [regex]::Match($content,'"ContentCheckSum":(?<checksum>"[a-zA-Z0-9]*")')
        $contentReplace = $CheckInfo.Groups[0].Value
        $contentReplace = $contentReplace.replace($CheckInfo.Groups["checksum"].Value, '"'+$ContentCheckSum[$fileReview.FileName].ContentCheckSum+'"')

        $content = $content.replace($CheckInfo.Groups[0].Value,$contentReplace)
        $content | Set-Content -Path $FullFileName

        $text = [IO.File]::ReadAllText($FullFileName) -replace "`r`n", "`n"
        [IO.File]::WriteAllText($FullFileName, $text)

        $TargetCheckSumTable[$fileReview.FileName] = @{'FileCheckSum'=(Get-FileHash $FullFileName -Algorithm SHA256).Hash; 'ContentCheckSum'=$ContentCheckSum[$fileReview.FileName].ContentCheckSum}
    }

    if ($TargetCheckSumTable.Keys.Count -lt $ContentCheckSum.Keys.Count)
    {
        Write-Host "`tNew file detected."
        $NoDifference = $false;
        $MissingFiles = @();
        foreach ($key in $ContentCheckSum.Keys)
        {
            if ($null -eq $TargetCheckSumTable[$key]) { $MissingFiles += $key}
        }

        Write-Host "`tFile list : $($MissingFiles -join ', ')"
        foreach ($fileReview in $MissingFiles)
        {
            Write-Host "`tChange Content CheckSum on File $($fileReview.FileName)"
            $FullFileName = $ContentCheckSum[$fileReview].FileInfo.FullName
            $content = Get-Content -Path $FullFileName
            $jsonContent = $content | ConvertFrom-Json
            write-host "`tOld content CheckSum : $($jsonContent.AuditFunctionProtectedArea.ContentCheckSum) / New Content CheckSum : $($ContentCheckSum[$fileReview].ContentCheckSum)"

            $CheckInfo = [regex]::Match($content,'"ContentCheckSum":(?<checksum>"[a-zA-Z0-9]*")')
            $contentReplace = $CheckInfo.Groups[0].Value
            $contentReplace = $contentReplace.replace($CheckInfo.Groups["checksum"].Value, '"'+$ContentCheckSum[$fileReview].ContentCheckSum+'"')

            $content = $content.replace($CheckInfo.Groups[0].Value,$contentReplace)
            $content | Set-Content -Path $FullFileName

            $text = [IO.File]::ReadAllText($FullFileName) -replace "`r`n", "`n"
            [IO.File]::WriteAllText($FullFileName, $text)

            $TargetCheckSumTable[$fileReview] = @{'FileCheckSum'=(Get-FileHash $FullFileName -Algorithm SHA256).Hash; 'ContentCheckSum'=$ContentCheckSum[$fileReview].ContentCheckSum}
        }
    }


    if (-not $NoDifference)
    {
        Write-Host "`tBuild new Checksum File for $shortDir"
        $ChecksumFile = New-Object PSObject
        $ChecksumFile | Add-Member Noteproperty -Name UpdatedDate -value (Get-Date)
        $ChecksumFile | Add-Member Noteproperty -Name Files -value @()

        foreach ($CCS in $TargetCheckSumTable.Keys)
        {
            $CCSObject = New-Object PSObject
            $CCSObject | Add-Member Noteproperty -Name FileName -value $CCS
            $CCSObject | Add-Member Noteproperty -Name FileCheckSum -value $TargetCheckSumTable[$CCS].FileCheckSum
            $CCSObject | Add-Member Noteproperty -Name ContentCheckSum -value $TargetCheckSumTable[$CCS].ContentCheckSum

            $ChecksumFile.Files += $CCSObject
        }

        $ChecksumFile | ConvertTo-Json | Set-Content -Path $ChecksumFileNameInDisk

        $text = [IO.File]::ReadAllText($ChecksumFileNameInDisk) -replace "`r`n", "`n"
        [IO.File]::WriteAllText($ChecksumFileNameInDisk, $text)

        $ContentChanged += "`tChecksum file updated for $shortDir"
    }
    else 
    { 
        Write-Host "`tNo difference, no Checksum file update for $shortDir"
        $ContentChanged += "`tNo Checksum file update for $shortDir"
    }

}

$globalCloudVersion = Get-Content CollectExchSecConfiguration-CopyCloud.json | ConvertFrom-Json
$globalOnPremisesVersion = Get-Content CollectExchSecConfiguration-CopyOnPremises.json | ConvertFrom-Json
$globalVersion = Get-Content CollectExchSecConfiguration.json | ConvertFrom-Json

$UpdateConfig = Get-Content UpdaterConfig.json | ConvertFrom-Json
$UpdateConfigForOnline = Get-Content UpdaterConfig-CopyCloud.json | ConvertFrom-Json

$MissingAuditFunction = @()

Write-Host "`n`nTest Missing AuditFunctions in Global Cloud file" -ForegroundColor Green
foreach ($AuditFunction in $AuditFunctionsList)
{
    $result = $globalCloudVersion.AuditFunctions.Where{$_.Cmdlet -eq $AuditFunction.Cmdlet -and $_.Section -eq $AuditFunction.Section}
    if ($null -eq $result)
    {
        $MissingAuditFunction += $AuditFunction
    }
}

if ($MissingAuditFunction.count -gt 0)
{
    Write-Host "`tAudit Functions missing or incorrectly configured :"
    $MissingAuditFunction
}
else {
    Write-Host "`tNo missing Audit Function"
}

function CheckRecursive
{
    Param(
        $JsonSegment,
        $JsonTestSegment,
        $TestType,
        $Path = "Root"
    )

    $ErrorCount = 0
    $memberlist = $JsonSegment | Get-Member -MemberType NoteProperty

    foreach ($attribMember in $memberlist)
    {
        if ($attribMember.Name -like "AuditFunctions") {continue;}
        if ($attribMember.Name -like "VersionInformation") {continue;}
    
        $errorTest = $false
        if ($null -eq $JsonTestSegment.($attribMember.Name))
        {
            Write-Host "`tEntry $Path\$($attribMember.Name) is missing in $TestType Version of configuration" -ForegroundColor Yellow
            $ErrorCount ++
            $errorTest = $true
        }
        else {
            Write-Host "`tEntry $Path\$($attribMember.Name) exists in $TestType Version of configuration"
        }
        $subResult = $JsonSegment.($attribMember.Name)
        $subTestResult = $JsonTestSegment.($attribMember.Name)

        if (-not $errorTest -and $null -ne $subResult -and $attribMember.Definition.StartsWith("System.Management.Automation.PSCustomObject"))
        {
            $Path += "\$($attribMember.Name)"
            $ErrorCount += CheckRecursive -JsonSegment $subResult -JsonTestSegment $subTestResult -TestType $TestType -Path $Path
        }
    }

    return $ErrorCount
}

Write-Host "`n`nTest missing parameter Global Cloud file" -ForegroundColor Green
$CloudErrorCount = CheckRecursive -JsonSegment $globalVersion -JsonTestSegment $globalCloudVersion -TestType "Global Cloud"

Write-Host "`n`nTest missing parameter Global On-Premises file" -ForegroundColor Green
$OPErrorCount = CheckRecursive -JsonSegment $globalVersion -JsonTestSegment $globalOnPremisesVersion -TestType "Global On-Premises"

Write-Host "`n`nTest missing parameter for Updater Config for Cloud file" -ForegroundColor Green
$UpdaterErrorCount = CheckRecursive -JsonSegment $UpdateConfig -JsonTestSegment $UpdateConfigForOnline -TestType "Updater Config for Cloud"

Write-Host "`n`n`nSummary :" -ForegroundColor Green
Write-Host "`tNumber of Errors in Cloud Version : $CloudErrorCount"
Write-Host "`tNumber of Errors in On-Premises Version : $OPErrorCount"
Write-Host "`tNumber of Errors in Updater Cloud Version : $UpdaterErrorCount"
Write-Host "`tNumber of Missing AuditFunction in Cloud Version : $($MissingAuditFunction.count)"
foreach ($text in $ContentChanged)
{
    write-host $text
}