| **Version** | **Date Modified (DD-MM-YYYY)** | **Change History**                                                 |
|-------------|--------------------------------|--------------------------------------------------------------------|
| 3.0.0       | 18-07-2025                     | New **CCF Connector** added to Solution - *Lookout Mobile Threat Detection Connector*.    |