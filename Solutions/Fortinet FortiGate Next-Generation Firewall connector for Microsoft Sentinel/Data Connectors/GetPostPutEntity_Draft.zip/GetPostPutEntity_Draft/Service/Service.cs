using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Net.Security;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http.Features.Authentication;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Sentinel.Fortinet.Helpers;

namespace Microsoft.Sentinel.Fortinet.Service
{
 public static class Service
{
   public static async Task <dynamic> HTTPPutService(string endpointURL,string json,string key)
   {
     dynamic obj=null;
     var clientHandler = new HttpClientHandler();
     clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
     using (var httpClient = new HttpClient(clientHandler))
     {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls13;
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer "+ key);
            var content=new StringContent(json, UnicodeEncoding.UTF8, "application/json");
            using(var response =  await httpClient.PutAsync(endpointURL,content).ConfigureAwait(false))
            {
             var responseJson = await response.Content.ReadAsStringAsync();
             if (responseJson != null)
             {
              obj = await JSONHelper.JsonDeserialize<dynamic>(responseJson);
     
             }
             else
             {
               //Response null
             } 
          }
          
     }
     
    return obj;
   }
public static async Task <dynamic> HTTPGetService(string endpointURL,string baseURL,string key,string entity, string filter)
   {
     dynamic obj=null;
     var clientHandler = new HttpClientHandler();
     clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
     using (var httpClient = new HttpClient(clientHandler))
     {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls13;
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            var httpRequest = new HttpRequestMessage(HttpMethod.Get,  new Uri(endpointURL + baseURL + entity + "?" + filter));
            httpRequest.Headers.Add("Authorization", "Bearer "+ key);
            using(var response =  await httpClient.SendAsync(httpRequest).ConfigureAwait(false))
            {
             var responseJson = await response.Content.ReadAsStringAsync();
             if (responseJson != null)
             {
              obj = await JSONHelper.JsonDeserialize<dynamic>(responseJson);
     
             }
             else
             {
               //Response null
             } 
          }
          
     }
     if(obj!=null)
     {
       return obj.results;
     }
    return obj;
   }

   public static async Task <dynamic> HTTPPostService(string endpointURL,string json,string key)
   {
     dynamic obj=null;
     var clientHandler = new HttpClientHandler();
     clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
     using (var httpClient = new HttpClient(clientHandler))
     {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls13;
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer "+ key);
            var content=new StringContent(json, UnicodeEncoding.UTF8, "application/json");
            using(var response =  await httpClient.PostAsync(endpointURL,content).ConfigureAwait(false))
            {
             var responseJson = await response.Content.ReadAsStringAsync();
             if (responseJson != null)
             {
              obj = await JSONHelper.JsonDeserialize<dynamic>(responseJson);
     
             }
             else
             {
               //Response null
             } 
          }
          
     }
     
    return obj;
   }
   
}

}