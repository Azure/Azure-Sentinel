""" Finance & Operations Data Collector v1.1.0 """
import logging
import os
from datetime import datetime, timedelta
import json
import httpx
import azure.functions as func
from azure.identity import ManagedIdentityCredential
from azure.monitor.ingestion import LogsIngestionClient
from azure.storage.blob import ContainerClient
from azure.core.exceptions import ResourceNotFoundError, HttpResponseError

LAST_UPDATE_CONTAINER = "lastupdate"
LAST_UPDATE_FILENAME = "lastupdate.json"
AZURE_WEB_JOBS_STORAGE = os.environ["AzureWebJobsStorage"]
DCR_IMMUTABLE_ID = os.environ["DCR_IMMUTABLE_ID"]
DCR_STREAM_NAME = os.environ["DCR_STREAM_NAME"]
DCR_DCE_URL = os.environ["DCR_DCE_URL"]
ODATA_API_HOST = os.environ["ODATA_API_HOST"]
ODATA_API_TIMEOUT_SECONDS = int(os.environ["ODATA_API_TIMEOUT_SECONDS"])
ODATA_API_MAX_PAGE_SIZE = int(os.environ["ODATA_API_MAX_PAGE_SIZE"])
FUNCTION_SHUTDOWN_TIMEOUT_MINS = int(os.environ["FUNCTION_SHUTDOWN_TIMEOUT_MINS"])
TIMER_SCHEDULE_MINS = os.environ["TIMER_SCHEDULE_MINS"]
MAX_LOOKBACK_DURATION_HOURS = int(os.environ["MAX_LOOKBACK_DURATION_HOURS"])
QUERY_WINDOW_OFFSET_MINS = int(os.environ["QUERY_WINDOW_OFFSET_MINS"])
CROSS_COMPANY_QUERY = os.environ["CROSS_COMPANY_QUERY"]

azure_http_logger = logging.getLogger(
    "azure.core.pipeline.policies.http_logging_policy"
)
azure_http_logger.setLevel(logging.WARNING)

app = func.FunctionApp()


@app.function_name(name="FinanceOperationsDataConnector")
@app.schedule(
    schedule=f"0 */{TIMER_SCHEDULE_MINS} * * * *",
    arg_name="FinanceOperationsDataConnector",
    run_on_startup=False,
    use_monitor=True,
)
# pylint: disable=invalid-name
def main(FinanceOperationsDataConnector: func.TimerRequest) -> None:
    """Main function for the Azure Function App"""

    function_start_time_utc = datetime.utcnow().replace(microsecond=0)
    max_lookback_duration = function_start_time_utc - timedelta(
        hours=MAX_LOOKBACK_DURATION_HOURS
    )
    query_window_end = (
        function_start_time_utc - timedelta(minutes=QUERY_WINDOW_OFFSET_MINS)
    ).isoformat()

    if FinanceOperationsDataConnector.past_due:
        logging.info("The timer is past due!")

    last_update_blob_container = ContainerClient.from_connection_string(
        conn_str=AZURE_WEB_JOBS_STORAGE, container_name=LAST_UPDATE_CONTAINER
    )
    if not last_update_blob_container.exists():
        logging.info("Creating blob storage container for last update timestamp")
        last_update_blob_container.create_container(public_access=None)

    try:
        logging.info("Downloading last update timestamp file")
        last_update_blob = json.loads(
            last_update_blob_container.download_blob(LAST_UPDATE_FILENAME).readall()
        )
        query_window_start = last_update_blob["lastUpdate"]

        if datetime.fromisoformat(query_window_start) < max_lookback_duration:
            logging.warning(
                "Last update date exceeds limit of %s hours. Older events will not be collected",
                MAX_LOOKBACK_DURATION_HOURS,
            )
            query_window_start = max_lookback_duration.isoformat()

    except ResourceNotFoundError:
        logging.info(
            "No last update timestamp file found in blob storage. Using %s hour query window.",
            MAX_LOOKBACK_DURATION_HOURS,
        )
        query_window_start = max_lookback_duration.isoformat()

    def get_data(client: httpx.Client, url: str) -> list:
        try:
            response = client.get(
                url=url,
            )
            response.raise_for_status()
        except httpx.TimeoutException as exc:
            logging.error("Request timed out: %s", exc)
            raise
        except httpx.HTTPStatusError as exc:
            logging.error(
                "HTTP error: %s, %s", exc.response.status_code, exc.response.text
            )
            raise
        return response

    managed_identity_credential = ManagedIdentityCredential()
    finance_operations_token = managed_identity_credential.get_token(
        f"{ODATA_API_HOST}/.default"
    ).token

    logs_ingestion_client = LogsIngestionClient(
        endpoint=DCR_DCE_URL, credential=managed_identity_credential
    )

    last_data_timestamp = False

    with httpx.Client(
        base_url=ODATA_API_HOST, timeout=ODATA_API_TIMEOUT_SECONDS
    ) as client:

        next_page_link = True

        client.headers = {
            "Content-Type": "application/json;odata.metadata=none",
            "Prefer": f"odata.maxpagesize={ODATA_API_MAX_PAGE_SIZE}",
            "authorization": f"Bearer {finance_operations_token}",
        }

        api_path = "/data/DatabaseLogs"
        query_string = f"?$filter=LogCreatedDateTime gt {query_window_start}Z and LogCreatedDateTime le {query_window_end}Z"
        cross_company_parameter = f"&cross-company={CROSS_COMPANY_QUERY}"
        request_url = f"{api_path}{query_string}{cross_company_parameter}"

        while next_page_link:

            logging.info("GET %s", request_url)
            response = get_data(url=request_url, client=client)
            response_json = response.json()
            next_page_link = response_json.get("@odata.nextLink", False)

            if next_page_link:
                request_url = next_page_link

            data = response_json.get("value", False)

            if data:

                last_data_timestamp = datetime.fromisoformat(
                    data[-1]["LogCreatedDateTime"].replace("Z", "")
                ).isoformat()

                try:
                    logging.info("Uploading %s logs to Ingestion API", len(data))
                    # pylint: disable=no-value-for-parameter
                    logs_ingestion_client.upload(
                        rule_id=DCR_IMMUTABLE_ID, stream_name=DCR_STREAM_NAME, logs=data
                    )
                except HttpResponseError as exc:
                    logging.error("Error sending data to Logs Ingestion API: %s", exc)
                    raise

                if datetime.utcnow() > function_start_time_utc + timedelta(
                    minutes=FUNCTION_SHUTDOWN_TIMEOUT_MINS
                ):
                    logging.info("Shutting down due to time limit.")
                    next_page_link = False

            else:
                logging.info("No data to upload")

    if last_data_timestamp:
        logging.info(
            "Uploading last update timestamp JSON to blob storage %s",
            last_data_timestamp,
        )
        last_updated_data = {"lastUpdate": last_data_timestamp}
        last_update_blob_container.upload_blob(
            data=json.dumps(last_updated_data),
            name=LAST_UPDATE_FILENAME,
            overwrite=True,
        )
