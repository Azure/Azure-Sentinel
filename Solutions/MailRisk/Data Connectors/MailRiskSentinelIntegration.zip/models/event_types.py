
METADATA_RECEIVED = 'metadata_received'
CONTENTS_RECEIVED = 'contents_received'
EMAIL_REPORTED = 'email_reported'
EMAIL_REVOKED = 'email_revoked'
FEEDBACK_REQUESTED = 'feedback_requested'
FEEDBACK_GIVEN = 'feedback_given'
FEEDBACK_CANCELLED = 'feedback_cancelled'
RISK_CHANGED = 'risk_changed'
