---
type: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--
     Please provide more in depth description of the use case for this idea and other details that might be useful.
-->