from __future__ import print_function
import pickle
from googleapiclient.discovery import build
import json
import base64
import hashlib
import hmac
import requests
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import azure.functions as func
import logging
import os
import json
import time
import re
from .state_manager import StateManager
from datetime import datetime, timedelta

customer_id = os.environ['WorkspaceID']
fetchDelay = os.getenv('FetchDelay',10)
chunksize = 500
MaxEventCount = 2000
calendarFetchDelay = os.getenv('CalendarFetchDelay',6)
chatFetchDelay = os.getenv('ChatFetchDelay',1)
userAccountsFetchDelay = os.getenv('UserAccountsFetchDelay',3)
loginFetchDelay = os.getenv('LoginFetchDelay',6)
shared_key = os.environ['WorkspaceKey']
pickle_str = os.environ['GooglePickleString']
pickle_string = base64.b64decode(pickle_str)
connection_string = os.environ['AzureWebJobsStorage']
logAnalyticsUri = os.environ.get('logAnalyticsUri')
SCOPES = ['https://www.googleapis.com/auth/admin.reports.audit.readonly']
activities = [
            "access_transparency", 
            "admin",
            "calendar",
            "chat",
            "drive",
            "gcp",
            "gplus",
            "groups",
            "groups_enterprise",
            "jamboard", 
            "login", 
            "meet", 
            "mobile", 
            "rules", 
            "saml", 
            "token", 
            "user_accounts", 
            "context_aware_access", 
            "chrome", 
            "data_studio"
            ]

if ((logAnalyticsUri in (None, '') or str(logAnalyticsUri).isspace())):
    logAnalyticsUri = 'https://' + customer_id + '.ods.opinsights.azure.com'
pattern = r'https:\/\/([\w\-]+)\.ods\.opinsights\.azure.([a-zA-Z\.]+)$'
match = re.match(pattern,str(logAnalyticsUri))
if(not match):
    raise Exception("Google Workspace Reports: Invalid Log Analytics Uri.")

# Function to convert string to datetime
def convert(date_time,format):
    #format = '%b %d %Y %I:%M%p'  # The format
    datetime_str = datetime.strptime(date_time, format) 
    return datetime_str

def get_credentials():
    creds = None
    if pickle_string:
        try:
            creds = pickle.loads(pickle_string)
        except Exception as pickle_read_exception:
            logging.error('Error while loading pickle string: {}'.format(pickle_read_exception))
    else:
        raise Exception("Google Workspace Reports: Pickle_string is empty. Exit.")
    return creds

def GetEndTime(logType):
    end_time = datetime.utcnow().replace(second=0, microsecond=0)
    if logType == "calendar":
        end_time = (end_time - timedelta(hours=int(calendarFetchDelay)))
    if logType == "chat":
        end_time = (end_time - timedelta(day=int(chatFetchDelay)))
    if logType == "user_accounts":
        end_time = (end_time - timedelta(hours=int(userAccountsFetchDelay)))
    if logType == "login":
        end_time = (end_time - timedelta(hours=int(loginFetchDelay)))
    else:
         end_time = (end_time - timedelta(minutes=int(fetchDelay)))

    return end_time

def isBlank (myString):
    return not (myString and myString.strip())

def isNotBlank (myString):
    return bool(myString and myString.strip())

def GetDates(logType):
    end_time = GetEndTime(logType)
    state = StateManager(connection_string=connection_string)
    past_time = state.get()
    activity_list = {}
    if past_time is not None and len(past_time) > 0:
        logging.info("The last time point is: {}".format(past_time))
        activity_list = past_time
    else:
        logging.info("There is no last time point, trying to get events for last one day.")
        past_time = (end_time - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
        for activity in activities:
            activity_list[activity] = past_time.strftime("%Y-%m-%dT%H:%M:%SZ")
        activity_list = json.dumps(activity_list)
    return json.loads(activity_list) if (isBlank(logType)) else (json.loads(activity_list)[logType],end_time.strftime("%Y-%m-%dT%H:%M:%SZ"))

def get_result(activity,start_time, end_time):
    result_activities = []
    service = build('admin', 'reports_v1', credentials=creds, cache_discovery=False)
    results = service.activities().list(userKey='all', applicationName=activity,
                                              maxResults=1000, startTime=start_time, endTime=end_time).execute()
    next_page_token = results.get('nextPageToken', None)
    result = results.get('items', [])
    result_activities.extend(result)
    while next_page_token is not None:
        results = service.activities().list(userKey='all', applicationName=activity,
                                            maxResults=1000, startTime=start_time, endTime=end_time, pageToken=next_page_token).execute()
        next_page_token = results.get('nextPageToken', None)
        result = results.get('items', [])
        result_activities.extend(result)
    if result_activities == None or len(result_activities) == 0:
        logging.info("Logs not founded for {} activity".format(activity))
        logging.info("Activity - {}, processing {} events)".format(activity, len(result_activities)))
    else:
        logging.info("Activity - {}, processing {} events)".format(activity, len(result_activities)))
        return result_activities

def build_signature(customer_id, shared_key, date, content_length, method, content_type, resource):
    x_headers = 'x-ms-date:' + date
    string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
    bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
    decoded_key = base64.b64decode(shared_key)
    encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
    authorization = "SharedKey {}:{}".format(customer_id,encoded_hash)
    return authorization

def post_data(customer_id, shared_key, body, log_type,chunk_count):
    method = 'POST'
    content_type = 'application/json'
    resource = '/api/logs'
    rfc1123date = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
    content_length = len(body)
    signature = build_signature(customer_id, shared_key, rfc1123date, content_length, method, content_type, resource)
    uri = logAnalyticsUri + resource + '?api-version=2016-04-01'

    headers = {
        'content-type': content_type,
        'Authorization': signature,
        'Log-Type': log_type,
        'x-ms-date': rfc1123date,
        'time-generated-field': "id_time"
    }
    response = requests.post(uri,data=body, headers=headers)
    if (response.status_code >= 200 and response.status_code <= 299):
        logging.info("Logs with {} activity was processed into Azure".format(log_type))
        logging.info("Chunk was processed{} events".format(chunk_count))
    else:
        logging.warn("Response code: {}".format(response.status_code))

def expand_data(obj):
    new_obj = []
    for event in obj:
        nested_events_arr = event["events"]
        for nested in nested_events_arr:
            head_event_part = event.copy()
            head_event_part.pop("events")
            if 'name' in nested:
                head_event_part.update({'event_name': nested["name"]})
            if 'type' in nested:
                head_event_part.update({'event_type': nested["type"]})
            if 'parameters' in nested:
                for parameter in nested["parameters"]:
                    if 'name' in parameter:
                        for param_name in ["value", "boolValue", "multiValue", "multiMessageValue", "multiIntValue", "messageValue", "intValue"]:
                            if param_name in parameter:
                                head_event_part.update({parameter["name"]: parameter[param_name]})
            new_obj.append(head_event_part)
    return new_obj

def gen_chunks_to_object(data,chunksize=100):
    chunk = []
    for index, line in enumerate(data):
        if (index % chunksize == 0 and index > 0):
            yield chunk
            del chunk[:]
        chunk.append(line)
    yield chunk

def gen_chunks(data,log_type):
    chunks = [data[i:i+chunksize] for i in range(0, len(data), chunksize)]
    logging.info("Entered into the chunks mode")
    latest_timestamp = "";
    i = 0
    for chunk in chunks:
        try:
            i = i+1
            logging.debug("Iteration chunk {}".format(i))
            body = json.dumps(chunk)
            logging.debug(body)
            latest_timestamp = chunk[-1]["id"]["time"]
            post_data(customer_id, shared_key,body,log_type, len(chunk))
        except Exception as err:
            logging.error("Something wrong. Exception error text: {}".format(err))
        else:
            dt = datetime.strptime(latest_timestamp, '%Y-%m-%dT%H:%M:%S.%fZ')
            dt += timedelta(milliseconds=1)
            latest_timestamp = dt.strftime('%Y-%m-%dT%H:%M:%S.%f')
            latest_timestamp = latest_timestamp[:-3] + 'Z'
            logging.info("Chunk Timestamp {}".format(latest_timestamp))
    return latest_timestamp

def main(mytimer: func.TimerRequest) -> None:
    if mytimer.past_due:
        logging.info('The timer is past due!')
    logging.info('Starting program')
    global creds
    creds = get_credentials()
    latest_timestamp = ""
    postactivity_list = GetDates("")
    for line in activities:
      try:
        start_time,end_time = GetDates(line)
        logging.info('Data processing. Period(UTC): {} - {}'.format(start_time,end_time))
        latest_timestamp = start_time
        logging.info('Logging the startTime for Activity. Period(UTC): {} - {}' .format(line,start_time))
        result_obj = get_result(line,latest_timestamp,end_time)
        if result_obj is not None:
            result_obj = expand_data(result_obj)
            sorted_data = sorted(result_obj, key=lambda x: x["id"]["time"],reverse=False)
            #if(line == "login") and [x for x in result_obj if x['event_type'] == 'password_change']:
                #sorted_data = list(filter(lambda x: x['event_type'] != 'password_change', sorted_data))
                #result_obj = list(filter(lambda x: x['event_type'] != 'password_change', result_obj))
            if(len(result_obj)) > 0 and len(result_obj) <= MaxEventCount:
            # Sort the json based on the "timestamp" key
                body = json.dumps(result_obj)
                logging.debug(body)
                post_data(customer_id, shared_key,body,line, len(result_obj))
                latest_timestamp = sorted_data[-1]["id"]["time"]
                dt = datetime.strptime(latest_timestamp, '%Y-%m-%dT%H:%M:%S.%fZ')
                dt += timedelta(milliseconds=1)
                latest_timestamp = dt.strftime('%Y-%m-%dT%H:%M:%S.%f')
                latest_timestamp = latest_timestamp[:-3] + 'Z'
            elif(len(result_obj) > MaxEventCount):
                latest_timestamp = gen_chunks(sorted_data, "GWorkspace_ReportsAPI_"+line)
                # Fetch the latest timestamp
                logging.info("The latest timestamp got from api activity is {} - {}".format(line,latest_timestamp))
        postactivity_list[line] = latest_timestamp
      except Exception as err:
        logging.error("Something wrong. Exception error text: {}".format(err))
        logging.error( "Error: Google Workspace Reports data connector execution failed with an internal server error.")
        raise
    logging.info("No exceptions hence posting the data to fileshare")
    state = StateManager(connection_string)
    state.post(str(json.dumps(postactivity_list)))