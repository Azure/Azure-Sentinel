SUPPORTED_EVENT_TYPES = set(["observation", "suricata", "detections"])

ORCHESTRATION_NAME = "SingletonEternalOrchestrator"

DEFAULT_BUCKET_NAME = "fortindr-cloud-metastream"
