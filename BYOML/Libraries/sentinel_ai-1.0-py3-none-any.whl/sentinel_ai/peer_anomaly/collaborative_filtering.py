__author__ = 'rolevin'

import numpy as np

from surprise import *

# debug methods
class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    
def warn(cond, msg):
    if not cond:
        print(bcolors.WARNING + 'Warning: ' + msg + bcolors.ENDC)

def str_detailed(param_name, param):
    return 'detailed {0} type {1} value {2}'.format(param_name, type(param), param)

def print_detailed(param_name, param):
    print(str_detailed(param_name, param))
    
def validate_nparrays(arr):
    ll = None
    
    for e in arr:
        assert isinstance(e, np.ndarray), str_detailed('validate_nparrays::e', e)
        curr_ll = len(e)
        
        if (ll is None):
            ll = curr_ll
        else:
            assert ll == curr_ll, 'len {0} != {1}'.format(ll, curr_ll)
            
    return True

# helper methods
def hasnan(vec):
    for x in vec:
        if np.isnan(x):
            return True
        
    return False

def _tolst(lst):
    return [float(x) for x in np.array(lst, dtype='float32')]

def _scan(rows, key_getter, targetKey):
    i = 0
    
    for row in rows:
        key = key_getter(row)
        
        if key == targetKey:
            return i
        
        i = i + 1

    return -1

def _bsearch(rows, key_getter, target_key):
    size = len(rows)
    start = 0

    end = size - 1

    while (size > 0):
        i = start + size//2
        row = rows[i]
        key = key_getter(row)
        
        if (key == target_key):
            return i
        elif (key < target_key):
            start = i + 1
        else:
            end = i - 1

        size = end - start + 1

    return -1

# object wrappers
class UserProps:
    @staticmethod
    def check(tup):
        assert len(tup) == 3
        return (not np.isnan(tup[0])) & (not hasnan(tup[1])) & (not hasnan(tup[2]))

    @staticmethod
    def get_values(user_name, u, alg):
        assert u == alg.trainset.to_inner_uid(user_name)
        assert len(alg.trainset.ur) == len(alg.bu)
        assert len(alg.bu) == len(alg.pu), 'len({0}) == len({1})'.format(len(alg.bu), len(alg.pu))

        if isinstance(alg, SVDpp):
            Iu = len(alg.trainset.ur[u])
            assert not np.isnan(Iu), Iu
            u_impl_feedback = sum(alg.yj[j] for (j, _) in alg.trainset.ur[u]) / np.sqrt(Iu)
        else:
            u_impl_feedback = np.zeros(len(alg.pu[u]))

        return (float(alg.bu[u]), list(u_impl_feedback), list(alg.pu[u]))

    def __init__(self, user_name, u, alg):
        if ( (user_name is not None) & (u is not None) & (alg is not None) ):
            tup = UserProps.get_values(user_name, u, alg)
# TBD surprise may have a bug in which some vectors turn out with nans
#            assert UserProps.check(tup), tup
            self.pctor(user_name, tup[0], tup[1], tup[2])

    @staticmethod
    def make(user_name, user_bias, u_impl_feedback, ufeatures):
        up = UserProps(None, None, None)
        return up.pctor(user_name, user_bias, u_impl_feedback, ufeatures)

    def pctor(self, user_name, user_bias, u_impl_feedback, ufeatures):
        self.user_name = user_name
        self.user_bias = float(user_bias)
        self.u_impl_feedback = list(u_impl_feedback)
        self.ufeatures = list(ufeatures)
        
        return self

    def get_name(self):
        return self.user_name
    
    def serialize(self):
        return (self.user_name, self.user_bias, self.u_impl_feedback, self.ufeatures)
    
    def serialize_json(self):
        import json

        return json.dumps({
            'user_name': self.user_name,
            'user_bias': self.user_bias,
            'u_impl_feedback': self.u_impl_feedback,
            'ufeatures': self.ufeatures
        })
    
    @staticmethod
    def deserialize_json(json_ser):
        import json 
        jj = json.loads(json_ser)

        up = UserProps(None, None, None)
        up.user_name = jj['user_name']
        up.user_bias = jj['user_bias']
        up.u_impl_feedback = jj['u_impl_feedback']
        up.ufeatures = jj['ufeatures']
        return up

    @staticmethod
    def deserialize(tup):
        up = UserProps(None, None, None)
        assert len(tup) == 4
        up.user_name = tup[0]
        up.user_bias = tup[1]
        up.u_impl_feedback = tup[2]
        up.ufeatures = tup[3]
        return up

    def vector(self, global_mean):
        return _tolst(np.append(
            np.add(self.u_impl_feedback, self.ufeatures), 
            [global_mean + self.user_bias, 1.0]
        ))

    def to_string(self):
        u_impl_feedback_str = ', '.join([str(f) for f in self.u_impl_feedback])
        ufeatures_str = ', '.join([str(f) for f in self.ufeatures])
        return '{0};{1};{2};{3}'.format(self.user_name, self.user_bias, u_impl_feedback_str, ufeatures_str)

class ResProps:
    @staticmethod
    def check(tup):
        assert len(tup) == 2
        return (not np.isnan(tup[0])) & (not hasnan(tup[1]))
    
    @staticmethod
    def get_values(res_name, i, alg):
        assert i == alg.trainset.to_inner_iid(res_name)
        return (float(alg.bi[i]), list(alg.qi[i]))

    def __init__(self, res_name, i, alg):
        if ( (res_name is not None) & (i is not None) & (alg is not None) ):
            tup = ResProps.get_values(res_name, i, alg)
# TBD surprise may have a bug in which some vectors turn out with nans
#            assert ResProps.check(tup), tup
            self.pctor(res_name, tup[0], tup[1])

    @staticmethod
    def make(res_name, res_bias, rfeatures):
        rp = ResProps(None, None, None)
        return rp.pctor(res_name, res_bias, rfeatures)

    def pctor(self, res_name, res_bias, rfeatures):
        self.res_name = res_name
        self.res_bias = float(res_bias)
        self.rfeatures = list(rfeatures)
        
        return self

    def get_name(self):
        return self.res_name
    
    def serialize(self):
        return (self.res_name, self.res_bias, self.rfeatures)
    
    def serialize_json(self):
        import json

        return json.dumps({
            'res_name': self.res_name,
            'res_bias': self.res_bias,
            'rfeatures': self.rfeatures
        })
    
    @staticmethod
    def deserialize_json(json_ser):
        import json 
        jj = json.loads(json_ser)

        rp = ResProps(None, None, None)
        rp.res_name = jj['res_name']
        rp.res_bias = jj['res_bias']
        rp.rfeatures = jj['rfeatures']
        return rp
        
    @staticmethod
    def deserialize(tup):
        rp = ResProps(None, None, None)
        assert len(tup) == 3
        rp.res_name = tup[0]
        rp.res_bias = tup[1]
        rp.rfeatures = tup[2]
        return rp

    def vector(self, global_mean):
        return _tolst(np.append(self.rfeatures, [1.0, self.res_bias]))

    def to_string(self):
        rfeatures_str = ', '.join([str(f) for f in self.rfeatures])
        return '{0};{1};{2}'.format(self.res_name, self.res_bias, rfeatures_str)

class ModelData:
    @staticmethod
    def check_users(alg):
        bad_user_count = 0
        all_user_count = 0

        for u in alg.trainset.all_users():
            if not UserProps.check(UserProps.get_values(alg.trainset.to_raw_uid(u), u, alg)):
                bad_user_count = bad_user_count + 1

            all_user_count = all_user_count + 1

        return (bad_user_count, all_user_count)
    
    def __init__(self, alg):
        if (alg is not None):
            self.pctor(
                alg.trainset.global_mean - alg.trainset.offset,
                [UserProps(alg.trainset.to_raw_uid(u), u, alg) for u in alg.trainset.all_users() if alg.trainset.knows_user(u)],
                [ResProps(alg.trainset.to_raw_iid(i), i, alg) for i in alg.trainset.all_items() if alg.trainset.knows_item(i)]
            )

    def pctor(self, global_mean, user_props, res_props):
        self.global_mean = global_mean
        self.user_props = user_props
        self.res_props = res_props
        return self
    
    def num_users(self):
        return len(self.user_props)
    
    def num_resources(self):
        return len(self.res_props)
    
    def find_user_props(self, user_name):
        for up in self.user_props:
            if up.user_name == user_name:
                return up
    
        return None
    
    def find_res_props(self, res_name):
        for rp in self.res_props:
            if rp.res_name == res_name:
                return rp
    
        return None
    
    def get_props(self, tt):
        if tt == 'users':
            return self.user_props
        elif tt == 'resources':
            return self.res_props
        else:
            assert False, tt

    @staticmethod
    def empty():
        md = ModelData(None)
        md.global_mean = 0.0
        md.user_props = []
        md.res_props = []
        return md

    def serialize(self):
        return (
            float(self.global_mean), 
            [up.serialize() for up in self.user_props], 
            [rp.serialize() for rp in self.res_props]
        )

    def serialize_json(self):
        import json

        return json.dumps({
            'global_mean': self.global_mean,
            'user_properties': [up.serialize_json() for up in self.user_props],
            'res_properties': [rp.serialize_json() for rp in self.res_props]
        })
    
    @staticmethod
    def deserialize_json(json_ser):
        import json 
        jj = json.loads(json_ser)

        md = ModelData(None)
        md.global_mean = jj['global_mean']
        md.user_props = [UserProps.deserialize_json(t) for t in jj['user_properties']]
        md.res_props = [ResProps.deserialize_json(t) for t in jj['res_properties']]
        return md

    @staticmethod
    def deserialize(tup):
        md = ModelData(None)
        md.global_mean = tup[0]
        md.user_props = [UserProps.deserialize(t) for t in tup[1]]
        md.res_props = [ResProps.deserialize(t) for t in tup[2]]
        return md

    def to_dict(self):
        avg_user_bias = np.mean([up.user_bias for up in self.user_props], axis=0)
        avg_u_impl_feedback = np.mean([up.u_impl_feedback for up in self.user_props], axis=0)
        avg_ufeatures = np.mean([up.ufeatures for up in self.user_props], axis=0)
        avg_userprops = UserProps.make('avg_user', avg_user_bias, avg_u_impl_feedback, avg_ufeatures)

        avg_res_bias = np.mean([rp.res_bias for rp in self.res_props], axis=0)
        avg_rfeatures = np.mean([rp.rfeatures for rp in self.res_props], axis=0)
        avg_resprops = ResProps.make('avg_resource', avg_res_bias, avg_rfeatures)
        
        return sorted(list({
            'user_map': list(sorted([(up.user_name, up) for up in self.user_props], key=lambda row: row[0])),
            'resource_map': list(sorted([(rp.res_name, rp) for rp in self.res_props], key=lambda row: row[0])),
            'avg_user': avg_userprops,
            'avg_resource': avg_resprops,
            'global_mean': self.global_mean
        }.items()), key=lambda row: row[0])

    @staticmethod
    def props_estimate(global_mean, up, rp):
        assert (up is not None) and (rp is not None)
        return float(np.dot(up.vector(global_mean), rp.vector(global_mean)))
        
    def estimate(self, user_name, res_name):
        return ModelData.props_estimate(
            self.global_mean,
            self.find_user_props(user_name),
            self.find_res_props(res_name)
        )
        
    def estimate_deprecated(self, user_name, res_name):
        uprops = next((up for up in self.user_props if up.user_name == user_name), None)
        rprops = next((rp for rp in self.res_props if rp.res_name == res_name), None)

        if ( (uprops is not None) & (rprops is not None) ):
            return self.global_mean + uprops.user_bias + rprops.res_bias + np.dot(
                np.array(uprops.ufeatures) + np.array(uprops.u_impl_feedback),
                np.array(rprops.rfeatures)
            )
        else:
            return None
        
# SURPRISE library usage
def to_surprise_dataset(pdf, usercol, rescol, scorecol):
    from surprise import Dataset
    from surprise import Reader
#    from math import floor, ceil  

    low = min(pdf['score'])
    high = max(pdf['score'])
    reader = Reader(rating_scale=(low, high))
    return Dataset.load_from_df(pdf[[usercol, rescol, scorecol]], reader)

def cnts(ten_it):
    return 1

def create_model(
    pdf,
    usercol='user_index',
    rescol='res_index',
    scorecol='score',
    rank=10,
    max_iter=10,
    lr_param=0.05,
    reg_param=0.75,
    algo_type='SVD',
    return_algo=False):

    cnt = pdf.size
    sds = to_surprise_dataset(pdf, usercol, rescol, scorecol)

    if algo_type == 'SVDpp':
        algo = SVDpp(n_factors=rank, n_epochs=max_iter, lr_all=lr_param, reg_all=reg_param)
    elif algo_type == 'SVD':
        algo = SVD(n_factors=rank, n_epochs=max_iter, lr_all=lr_param, reg_all=reg_param)
    elif algo_type == 'NMF':
        algo = NMF(n_factors=rank, n_epochs=max_iter)
    else:
        assert False, '{0} not supported'.format(algo_type)

#    from surprise.model_selection import cross_validate
#    cross_validate(algo, sds, measures=['RMSE', 'MAE'], cv=5, verbose=True)
    algo.fit(sds.build_full_trainset())

# TODO: may be a bug in surprise, sometimes model contains all nan vectors
#    bad_user_count, all_user_count = ModelData.check_users(algo)
#    assert bad_user_count == 0, 'found {0}/{1} bad user vectors pdf: {2}'.format(
#        bad_user_count, 
#        all_user_count, 
#        pdf.to_string()
#    )
    
    return (algo, ModelData(algo)) if return_algo else ModelData(algo)

# model private APIs
def _svdpp_predict(global_mean, uprops, rprops):
    return ModelData.props_estimate(
        global_mean,
        uprops,
        rprops
    )

# ------------------------------------------------------------------------------
def get(dict_arr, key, default_value=None):
#    return dict_arr[key]
    assert isinstance(dict_arr, list), dict_arr
    assert (len(dict_arr) == 0) or (len(dict_arr[0]) > 0), dict_arr

    idx = _bsearch(dict_arr, lambda row: row[0], key)
    return dict_arr[idx][1] if idx >= 0 else default_value

# model public APIs
def svdpp_predict(dict_model, user, resource):
    global_mean = get(dict_model, 'global_mean')

    usermap = get(dict_model, 'user_map')
#    avguser = get(dict_model, 'avg_user')
    avguser = None
    uprops = get(usermap, user, avguser)
    assert uprops is not None

    resmap = get(dict_model, 'resource_map')
#    avgres = get(dict_model, 'avg_resource')
    avgres = None
    rprops = get(resmap, resource, avgres)
    assert rprops is not None

    return _svdpp_predict(global_mean, uprops, rprops)

def svdpp_predict_all(dict_model, pdf, output_column_name='predicted_score'):
    global_mean = get(dict_model, 'global_mean')

#    avguser = get(dict_model, 'avg_user')
    avguser = None
    
#    avgres = get(dict_model, 'avg_resource')
    avgres = None

    user_map = get(dict_model, 'user_map')
    resource_map = get(dict_model, 'resource_map')

    def row_svdpp_predict(r):
        uprops = get(user_map, r['user_index'], avguser)
        assert uprops is not None
        
        rprops = get(resource_map, r['res_index'], avgres)
        assert rprops is not None

        return _svdpp_predict(global_mean, uprops, rprops)

    new_series = pdf.apply(row_svdpp_predict, axis=1)
    pdf_copy = pdf.copy()
    pdf_copy[output_column_name] = new_series
    return pdf_copy

def algo_predict_all(algo, pdf, output_column_name='predicted_score'):
    def row_svdpp_predict(r):
        return algo.predict(r['user_index'], r['res_index']).est

    new_series = pdf.apply(row_svdpp_predict, axis=1)
    pdf_copy = pdf.copy()
    pdf_copy[output_column_name] = new_series
    return pdf_copy

def to_pdf(ratings):
    assert len(ratings) > 0
    assert len(ratings[0]) == 3

    users = [r[0] for r in ratings]
    resources = [r[1] for r in ratings]
    scores = [r[2] for r in ratings]

    import pandas as pd

    return pd.DataFrame(
        data={
            'user_index': users,
            'res_index': resources,
            'score': scores
        }
    )

# ------------------------------------------------------------------------------
# unit tests
def _ut_get_acc_exp():
    return 10

def _ut_create_training_data():
    import random
    
    num_users = 1000
    num_resources = 5000
    num_ratings = 10000
    
    seen_pairs = set()
    users = []
    resources = []
    scores = []

    for i in range(num_ratings):
        u = random.randint(0, num_users)
        r = random.randint(0, num_resources)
        s = random.uniform(1, 5)

        if ~((u, r) in seen_pairs):
            users.append(u)
            resources.append(r)
            scores.append(s)

        seen_pairs.add((u, r))

    import pandas as pd

    return pd.DataFrame(
        data={
            'user_index': users,
            'res_index': resources,
            'score': scores
        }
    )

def _ut_create_hard_training_data():
    users = [
        6, 2, 8, 6, 7, 8, 2, 8, 10, 3, 11, 6, 7, 3, 2, 10, 11, 1, 8, 4, 9, 3, 5, 6, 7
    ]
    
    resources = [
        2, 8, 2, 8, 2, 6, 4, 1, 5, 5, 6, 1, 6, 7, 6, 3, 3, 4, 4, 8, 2, 1, 7, 7, 5
    ]
    
    scores = [
        1.0,
        1.0, 
        1.0, 
        1.0, 
        1.0, 
        1.0, 
        1.0, 
        1.0, 
        1.0, 
        1.0, 
        1.0, 
        1.0, 
        1.0, 
        1.0, 
        46.77678298950195, 
        35.94552993774414,
        36.470367431640625,
        33.59884262084961,
        10.0,
        43.84599304199219,
        14.908903121948242,
        10.0,
        19.817806243896484,
        21.398120880126953,
        14.908903121948242
    ]
    
    import pandas as pd

    return pd.DataFrame(
        data={
            'user_index': users,
            'res_index': resources,
            'score': [(s*0.3 if s > 1.0 else s) for s in scores]
        }
    )

def _ut_svdpp_predict_all(algo, dict_model, test):
    import math

    pred_pdf = svdpp_predict_all(dict_model, test)
    assert len(pred_pdf) > 10

    algo_pred_pdf = algo_predict_all(algo, test)
    assert len(pred_pdf) == len(algo_pred_pdf)

    avg_pred_score = np.mean(pred_pdf['predicted_score'])
    algo_avg_pred_score = np.mean(algo_pred_pdf['predicted_score'])

    assert len([True for pu in algo.pu if hasnan(pu)]) == 0, str(algo.pu[0])

    if np.isnan(avg_pred_score):
        display(pred_pdf)
        display(algo_pred_pdf)

        print(algo.predict(2, 6))

    assert isinstance(avg_pred_score, float) and (not np.isnan(avg_pred_score)), str((avg_pred_score, algo_avg_pred_score))

    for _, row in pred_pdf.iterrows():
        u = row['user_index']
        r = row['res_index']
        pred_score = row['predicted_score']
        true_pred_score = algo.predict(u, r).est

        assert not np.isnan(pred_score), pred_score
        assert not np.isnan(true_pred_score), true_pred_score

        if abs(true_pred_score - pred_score) > math.pow(10, -_ut_get_acc_exp()):
            print('_ut_svdpp_predict_all warning: found score delta {0} |{1}-{2}|'.format(
                abs(true_pred_score - pred_score), 
                true_pred_score, 
                pred_score
            ))

def _ut_check_model(algo_type, training, test=None):
    if test is None:
        test = training
    
    algo, model = create_model(training, return_algo=True, algo_type=algo_type)
    dict_model = model.to_dict()

    _ut_svdpp_predict_all(algo, dict_model, test)
        
def _ut_runall():
    for _ in range(5):
        print('_ut_runall::_ut_create_training_data()::SVD')
        _ut_check_model('SVD', _ut_create_training_data())

    for _ in range(5):
        print('_ut_runall::_ut_create_training_data()::SVDpp')
        _ut_check_model('SVDpp', _ut_create_training_data())

    print('_ut_runall::_ut_create_hard_training_data()::SVD')
    _ut_check_model('SVD', _ut_create_hard_training_data())
    
    print('_ut_runall::_ut_create_hard_training_data()::SVDpp')
    _ut_check_model('SVDpp', _ut_create_hard_training_data())