__author__ = 'rolevin'

def get_spark(df):
    import pyspark.sql
    return df.sql_ctx.sparkSession

def materialize(df, fn=None):
    spark = get_spark(df)
    fn = make_rand_filename(spark) if fn is None else fn
    df.write.parquet(fn, mode='overwrite')
    return (fn, spark.read.parquet(fn))
    
def make_rand_filename(spark, root=None):
    import uuid
    root = get_checkpointdir(spark) if root is None else root
    return '{root}/tmp/{uuid}'.format(root=root, uuid=uuid.uuid4())

def add2hadoop_conf(spark, d):
    for k in d.keys():
        vv = d[k]
        spark.sparkContext._jsc.hadoopConfiguration().set(k, vv)

def get_hadoop_conf(spark, k, default_value=None):
    return spark.sparkContext._jsc.hadoopConfiguration().get(k, default_value)

def getkeys_hadoop_conf(spark):
    it = spark.sparkContext._jsc.hadoopConfiguration().iterator()
    keys = []
    
    for ent in it:
        keys.append(ent.getKey())
    
    return keys

def set_usepreset(spark, usepreset):
    assert isinstance(usepreset, bool)
    add2hadoop_conf(spark, {'spark.usepreset': str(usepreset)})
    
def get_usepreset(spark):
    usepreset = get_hadoop_conf(spark, 'spark.usepreset', 'True')
    assert (usepreset == 'False') | (usepreset == 'True')
    return False if usepreset == 'False' else True

def set_checkpointdir(spark, path):
    add2hadoop_conf(spark, {'spark.checkpointdir': path})
    spark.sparkContext.setCheckpointDir(path)
    
def get_checkpointdir(spark):
    return get_hadoop_conf(spark, 'spark.checkpointdir')

def getorcreate_df(spark, fullpath, maker):
    if (not get_usepreset(spark)) | (not exists(spark, fullpath)):
        df = maker()
        df.write.parquet(fullpath, mode='overwrite')

    return spark.read.parquet(fullpath)

def get_min_max(df, col_name):
    the_stats = df.select(col_name).distinct().rdd.map(lambda row: row[col_name]).stats()
    return the_stats.min(), the_stats.max()

def df_stats(df):
    print('num entries = {0}'.format(df.count()))
    print('num partitions = {0}'.format(df.rdd.getNumPartitions()))
    print('schema = {0}'.format(df.schema))
    print('partition stats:')
    print(df.rdd.glom().map(len).stats())

def df_zip_with_index(df, start_index=0, col_name='rowId', part_col_arr=[], order_by_cols_arr=[]):
    import pyspark.sql.functions as f
    
    assert part_col_arr is not None
    assert order_by_cols_arr is not None
    
    part_col_arr = part_col_arr if isinstance(part_col_arr, list) else [part_col_arr]
    order_by_cols_arr = order_by_cols_arr if isinstance(order_by_cols_arr, list) else [order_by_cols_arr]

    if len(part_col_arr) > 0:
        from pyspark.sql.window import Window

        cols = [f.col(cn) for cn in part_col_arr]
        ocols = [f.col(cn) for cn in order_by_cols_arr]

        window = Window.partitionBy(*cols).orderBy(*ocols)

        return df.withColumn(
            col_name,
            f.rank().over(window) - 1 + start_index
        )
    else:
#        return df.withColumn(col_name, start_index + f.monotonically_increasing_id())
        def with_col(row, colname, colval):
            from pyspark.sql import Row

            temp = row.asDict()
            temp[colname] = colval

            return Row(**temp)

        from pyspark.sql import types as t
        
        new_schema = t.StructType(
            [t.StructField(col_name, t.LongType(), True)] + df.schema.fields
        )

        return df.rdd.zipWithIndex().map(lambda t: with_col(t[0], col_name, t[1] + start_index)).toDF(new_schema)

def partition_by(df, part_col_arr, idx_col=None, start_index=0, hash_mod=None):
    part_col = part_col_arr if isinstance(part_col_arr, list) else ([] if part_col_arr is None else [part_col_arr])

    def withColumn(row, col_name_value_pairs):
        from pyspark.sql import Row

        d = row.asDict().copy()

        if not isinstance(col_name_value_pairs, list):
            col_name_value_pairs = [col_name_value_pairs]

        for x in col_name_value_pairs:
            d[x[0]] = x[1]

        return Row(**d)

    def index_partition(it):
        from pyspark.sql import Row

        i = start_index

        for row in it:
            yield withColumn(row, (idx_col, i))
            i = i + 1

    def get_part(row):
        if isinstance(part_col, list):
            return str([row[pc] for pc in part_col])
        else:
            return row[part_col]

    if (len(part_col) > 0) & (hash_mod is None):
        d = dict(df.select(part_col).distinct().orderBy(part_col).rdd.map(get_part).zipWithIndex().collect())
        sz = len(d)

        rdd = df.rdd.keyBy(lambda row: (get_part(row), row)).partitionBy(
            sz,
            lambda x: d[x[0]]
        ).map(lambda x: x[1])
    elif (len(part_col) > 0) & (hash_mod is not None):
        rdd = df.rdd.keyBy(lambda row: (get_part(row), row)).partitionBy(
            hash_mod,
            lambda x: abs(hash(x[0]))%hash_mod
        ).map(lambda x: x[1])
    else:
        rdd = df.rdd

    if (idx_col):
        rdd = rdd.mapPartitions(index_partition)

    return rdd.toDF()

def get_hadoopfs(spark, root):
    sc = spark.sparkContext

    URI           = sc._gateway.jvm.java.net.URI
    FileSystem    = sc._gateway.jvm.org.apache.hadoop.fs.FileSystem

    return FileSystem.get(URI(root), sc._jsc.hadoopConfiguration())

def get_root_subpath(fullpath):
    delim = '/' if '/' in fullpath else '\\' 
    token = '__SL_SL__'
    
    parts = fullpath.replace('//', token).split(delim, 1)
    root = parts[0].replace(token, '//')
    subpath = delim + parts[1]
    
    # for local run
    if (len(root) == 2) and (root[1] == ':'):
        root = 'localhost'
    
    return (root, subpath)

def exists(spark, fullpath):
    Path = spark.sparkContext._gateway.jvm.org.apache.hadoop.fs.Path
    root, subpath = get_root_subpath(fullpath)
    return get_hadoopfs(spark, root).exists(Path(subpath))

def delete(spark, fullpath):
    Path = spark.sparkContext._gateway.jvm.org.apache.hadoop.fs.Path
    root, subpath = get_root_subpath(fullpath)

    return get_hadoopfs(spark, root).delete(Path(subpath), True)

def write(spark, fullpath, data):
    sc = spark.sparkContext

    spark.createDataFrame(
        sc.parallelize([data]), __st.StringType()
    ).coalesce(1).write.csv(
        fullpath,
        mode='overwrite'
    )

def read(spark, fullpath):
    return spark.read.csv(fullpath).rdd.map(lambda row: row['_c0']).first()