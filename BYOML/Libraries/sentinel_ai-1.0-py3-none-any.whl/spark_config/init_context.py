"""
Initialize Spark Context
"""

import os
import py4j
from pyspark.context import SparkContext
from pyspark.sql import SparkSession


ADDRESS_CLUSTER = 'https://researchsparkcluster.azurehdinsight.net/'
PYTHON_PATH = '/usr/bin/anaconda/envs/py35/bin/python3'


def initialize_session(memory=None, packages=None, adress_cluster=ADDRESS_CLUSTER, 
                       python_path=PYTHON_PATH):
    '''
    Initialize a Spark session, and returns it
    - packages (optionnal): list of Spark packages to add. Example: ['com.databricks:spark-xml_2.11:0.4.1']
    '''
    
    os.environ['PYSPARK_PYTHON'] = python_path
    if packages:
        os.environ['PYSPARK_SUBMIT_ARGS'] = '--packages {} pyspark-shell'.format(','.join(packages))
        
    if os.environ.get('SPARK_EXECUTOR_URI'):
        SparkContext.setSystemProperty('spark.executor.uri', os.environ['SPARK_EXECUTOR_URI'])
    if memory:
        SparkContext.setSystemProperty('spark.executor.memory', memory)
    SparkContext._ensure_initialized()
    try:
        SparkContext._jvm.org.apache.hadoop.hive.conf.HiveConf()
        spark = SparkSession.builder.enableHiveSupport().getOrCreate()
    except py4j.protocol.Py4JError:
        spark = SparkSession.builder.getOrCreate()
    except TypeError:
        spark = SparkSession.builder.getOrCreate()
    except:
        return None

    print(adress_cluster + 'yarnui/hn/proxy/' + spark.sparkContext.applicationId)
    return spark


if __name__ == '__main__':
    spark = initialize_session()
    sc = spark.sparkContext