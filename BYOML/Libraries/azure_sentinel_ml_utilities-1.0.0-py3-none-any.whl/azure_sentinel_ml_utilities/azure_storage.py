#
# Class for accessing append blobs on Storage
#
from azure.storage.blob import AppendBlobService
import datetime as dt
import json
from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession

class append_blob_manager(object):

    sc = SparkContext.getOrCreate()
    spark = SparkSession(sc)

    def __init__(self, storage_account, storage_key):
        self.append_blob_service =  AppendBlobService(account_name=storage_account, account_key=storage_key)

        # Spark conf set for spark.read.json to work
        append_blob_manager.spark.conf.set("fs.azure.account.key." + storage_account + ".blob.core.windows.net", storage_key)
      
    #
    # Enumerate the blobs in the 'minute' folders and filter out to match the minute range
    #     Layout - {root}/y=2020/m=08/d=07/h=19/m=00/PT1H.json
    #
    def enumerate_blob_names(self, start_time, end_time, container, root):
        if not root.endswith('/'):
            root = root + '/'
        num_windows = int((end_time - start_time).total_seconds() / 60)
        time_list = [end_time - dt.timedelta(minutes=i) for i in range(num_windows + 1)]
        folder_suffix = ['y={:0>4d}/m={:0>2d}/d={:0>2d}/h={:0>2d}/'.format(t.year, t.month, t.day, t.hour) for t in time_list]
        distinct_folder_suffix = set(folder_suffix)
        folders_to_enumerate = [root + fs for fs in distinct_folder_suffix]

        # Actual blobs to return (subset in the hours - actually only 1st and last needs to be checked)
        # It is important to have the trialing '/' in the prefixes
        # Note: this method of enumerating storage is faster than checking if a blob exists in each given minute
        blob_prefixes = [
            root + 'y={:0>4d}/m={:0>2d}/d={:0>2d}/h={:0>2d}/m={:0>2d}/'.format(t.year, t.month, t.day, t.hour, t.minute) for t in time_list]
        blob_names = []
        for folder in folders_to_enumerate:
            blob_enumerator = self.append_blob_service.list_blobs(container_name=container, prefix=folder)
            for blob in blob_enumerator:
                blob_names.append(blob.name)
        return [b for b in blob_names if any(b.startswith(item) for item in blob_prefixes)]
    
    #
    # Static Blob service that will be used in the rdd map function for reading the blobs
    #
    @staticmethod
    def get_append_blob_service(storage_account, storage_key):
        return AppendBlobService(account_name=storage_account, account_key=storage_key)
      
    #
    # Read the data in the blobs: 
    # !! Note that currently Spark does not support APPEND_BLOBs, hence we cannot read the json with spark.read.json.
    # Using work around to read the individual blobs and parse json lines.
    # Passing in AppendBlobService to avoid Spark complaining
    def get_raw_df(self, start_time, end_time, container, root, schema, static_append_blob_service):
        blob_names = self.enumerate_blob_names(start_time, end_time, container, root)
        rdd = append_blob_manager.spark.sparkContext \
                   .parallelize(blob_names) \
                   .map(lambda blob_name: static_append_blob_service.get_blob_to_bytes(container, blob_name).content.decode('utf-8').splitlines()) \
                   .flatMap(lambda lines: [json.loads(l) for l in lines])
        return append_blob_manager.spark.read.json(rdd, schema)


#
# Class for accessing block blobs on Storage with a specific folder layout
#
from azure.storage.blob import BlockBlobService

class block_blob_manager(object):

    sc = SparkContext.getOrCreate()
    spark = SparkSession(sc)

    def __init__(self, storage_account, storage_key):
        self.blob_service = BlockBlobService(account_name=storage_account, account_key=storage_key)
        self.storage_account = storage_account

        # Spark conf set for spark.read.csv to work
        block_blob_manager.spark.conf.set("fs.azure.account.key." + storage_account + ".blob.core.windows.net", storage_key)
          
    #
    # Enumerate the blobs in the 'minute' folders and filter out to match the minute range
    #       layout - {root}/2020/07/25/14/52/01.csv.gz
    #
    def enumerate_blob_names(self, start_time, end_time, container, root):
        if not root.endswith('/'):
            root = root + '/'
        num_windows = int((end_time - start_time).total_seconds() / 60)
        time_list = [end_time - dt.timedelta(minutes=i) for i in range(num_windows + 1)]
        folder_suffix = ['{:0>4d}/{:0>2d}/{:0>2d}/{:0>2d}/'.format(t.year, t.month, t.day, t.hour) for t in time_list]
        distinct_folder_suffix = set(folder_suffix)
        folders_to_enumerate = [root + fs for fs in distinct_folder_suffix]

        # Actual blobs to return (subset in the hours - actually only 1st and last needs to be checked)
        # It is important to have the trialing '/' in the prefixes
        # Note: this method of enumerating storage is faster than checking if a blob exists in each given minute
        blob_prefixes = [
            root + '{:0>4d}/{:0>2d}/{:0>2d}/{:0>2d}/{:0>2d}/'.format(t.year, t.month, t.day, t.hour, t.minute) for t in
            time_list]
        blob_names = []
        for folder in folders_to_enumerate:
            blob_enumerator = self.blob_service.list_blobs(container_name=container, prefix=folder)
            for blob in blob_enumerator:
                blob_names.append(blob.name)
        return [b for b in blob_names if any(b.startswith(item) for item in blob_prefixes)]
      
      #
      # Get the raw data from Azure Storage
      #
    def get_raw_df(self, start_time, end_time, container, root, schema):
        blob_names = self.enumerate_blob_names(start_time, end_time, container, root)
        full_blob_names = ["wasbs://" + container + "@" + self.storage_account + ".blob.core.windows.net/" + bn for bn in blob_names]     
        return block_blob_manager.spark.read.csv(full_blob_names, schema=schema, sep='\t', header=False)