#
# Class for accessing append blobs on Storage using Azure Storage SDK v12
#
import datetime as dt
import json
import re
from azure.storage.blob import BlobServiceClient, ContainerClient
from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession

class storage_blob_manager(object):

    sc = SparkContext.getOrCreate()
    spark = SparkSession(sc)

    def __init__(self, storage_conn_str):
        self.blob_service_client = BlobServiceClient.from_connection_string(conn_str=storage_conn_str)

        key_pattern = 'DefaultEndpointsProtocol=(\w+);AccountName=(\w+);AccountKey=([^;]+);'
        #extract storage key from connection string
        match = re.match(key_pattern, storage_conn_str)
        storage_account = match.group(2)
        storage_key = match.group(3)

        # Spark conf set for spark.read.json to work
        storage_blob_manager.spark.conf.set("fs.azure.account.key." + storage_account + ".blob.core.windows.net", storage_key)
      
    #
    # Enumerate the blobs in the 'minute' folders and filter out to match the minute range
    #     Layout - {root}/y=2020/m=08/d=07/h=19/m=00/PT1H.json
    #
    def enumerate_blob_names(self, start_time, end_time, container, root):
        if not root.endswith('/'):
            root = root + '/'
        num_windows = int((end_time - start_time).total_seconds() / 60)
        time_list = [end_time - dt.timedelta(minutes=i) for i in range(num_windows + 1)]
        folder_suffix = ['y={:0>4d}/m={:0>2d}/d={:0>2d}/h={:0>2d}/'.format(t.year, t.month, t.day, t.hour) for t in time_list]
        distinct_folder_suffix = set(folder_suffix)
        folders_to_enumerate = [root + fs for fs in distinct_folder_suffix]

        # get a container client for enumerating blobs
        container_client = self.blob_service_client.get_container_client(container=container)
        
        # Actual blobs to return (subset in the hours - actually only 1st and last needs to be checked)
        # It is important to have the trialing '/' in the prefixes
        # Note: this method of enumerating storage is faster than checking if a blob exists in each given minute
        blob_prefixes = [
            root + 'y={:0>4d}/m={:0>2d}/d={:0>2d}/h={:0>2d}/m={:0>2d}/'.format(t.year, t.month, t.day, t.hour, t.minute) for t in time_list]
        blob_names = []
        for folder in folders_to_enumerate:
            blob_enumerator = container_client.list_blobs(name_starts_with=folder)
            for blob in blob_enumerator:
                blob_names.append(blob.name)
        return [b for b in blob_names if any(b.startswith(item) for item in blob_prefixes)]
    
    #
    # Static Blob service that will be used in the rdd map function for reading the blobs
    #
    @staticmethod
    def get_blob_service_client(storage_conn_str):
        return BlobServiceClient.from_connection_string(conn_str=storage_conn_str)
      
    #
    # Read the data in the blobs: 
    # !! Note that currently Spark does not support APPEND_BLOBs, hence we cannot read the json with spark.read.json.
    # Using work around to read the individual blobs and parse json lines.
    # Passing in AppendBlobService to avoid Spark complaining
    def get_raw_df(self, start_time, end_time, container, root, schema, static_blob_service_client):
        blob_names = self.enumerate_blob_names(start_time, end_time, container, root)
        rdd = storage_blob_manager.spark.sparkContext \
                   .parallelize(blob_names) \
                   .map(lambda blob_name: static_blob_service_client.get_blob_client(container=container, blob=blob_name).download_blob().readall().decode('utf-8').splitlines()) \
                   .flatMap(lambda lines: [json.loads(l) for l in lines])
        return storage_blob_manager.spark.read.json(rdd, schema)