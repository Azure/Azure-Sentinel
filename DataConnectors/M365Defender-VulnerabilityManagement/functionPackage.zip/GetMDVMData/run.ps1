﻿# Input bindings are passed in via param block.
param($Timer)

$lawResourceId = $env:LAW_RESOURCE_ID
$tenantId = $env:TENANT_ID
$appId = $env:APP_ID
$appSecret = $env:APP_SECRET
$dcrImmutableId = $env:DCR_IMMUTABLE_ID
$dceURI = $env:DCE_URI
$snapshotTime = Get-Date -Format s
$fullImport = $env:FULL_IMPORT

#Function to get AAD OAuth tokens for REST API calls.
function Get-AADToken {
    param ($resource, $scope, $oAuthUri, $clientId, $clientSecret)
    if ($null -ne $resource) {
        $oAuthUri = "https://login.microsoftonline.com/$TenantId/oauth2/token"
        $authBody = "client_id=$clientId&resource=$resource&client_secret=$clientSecret&grant_type=client_credentials"
    }
    else {
        $oAuthUri = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
        $authBody = "client_id=$clientId&scope=$scope&client_secret=$clientSecret&grant_type=client_credentials"
    }
    $authHeaders = @{"Content-Type" = "application/x-www-form-urlencoded" }
    $authResponse = Invoke-RestMethod -Method Post -Uri $oAuthUri -Body $authBody -Headers $authHeaders -ErrorAction Stop
    return $authResponse.access_token
}

#Function to create HTTP headers for REST API calls.
function Get-RequestHeaders {
    param ($token)
    return @{"Authorization" = "Bearer $token"; "Content-Type" = "application/json"}
}

#Function to get data via REST API and send to Azure Monitor/Sentinel.
function Import-Data {
    param ($SourceUri, $SourceToken, $DestinationUri, $DestinationToken, $TimeGenerated, $DataSourceName, $JsonDepth, $BodyMaxSize)
    $count = 1
    $startIndex = 0
    $queryString = ''
    do {
        Write-Host "Getting $DataSourceName, request #" $count...
        if ($DataSourceName -eq 'NIST CVE KB') {
            $response = Invoke-WebRequest -Method Get -Uri ($SourceUri + $queryString)
            $content = ($response.Content | ConvertFrom-Json).vulnerabilities
        }
        else {
            $response = Invoke-WebRequest -Method Get -Uri $SourceUri -Headers (Get-RequestHeaders -token $SourceToken)
            $content = ($response.Content | ConvertFrom-Json).value
        }
        $bodies = New-BodyArray -Content $content -MaxSize $BodyMaxSize -TimeGenerated $TimeGenerated -JsonDepth $JsonDepth
        $bodiesCount = 1
        foreach ($body in $bodies) {
            Write-Host "Sending $DataSourceName, request #" ($count) "- batch:" $bodiesCount "of" $bodies.Count...
            try {
                Invoke-RestMethod -Uri $DestinationUri -Method "Post" -Body $body -Headers (Get-RequestHeaders -token $DestinationToken)    
            }
            catch {
                $errorDetails = $_.ErrorDetails | ConvertFrom-Json
                switch ($errorDetails.error.code) {
                    'ContentLengthLimitExceeded' {
                        Write-Host "Request is too large, skipping this object..."
                    }
                    'TokenExpired' {
                        Write-Host "Access token has expired, renewing..."
                        $DestinationToken = Get-AADToken -scope ([System.Web.HttpUtility]::UrlEncode("https://monitor.azure.com//.default")) -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"
                        Write-Host "Sending $DataSourceName, request #" ($count) "- batch:" $bodiesCount "of" $bodies.Count...
                        Invoke-RestMethod -Uri $DestinationUri -Method "Post" -Body $body -Headers (Get-RequestHeaders -token $DestinationToken)
                    }
                }          
            }
            finally {
                $bodiesCount += 1
            }
        }
        if ($DataSourceName -eq 'NIST CVE KB') {
            $startIndex += ($response.Content | ConvertFrom-Json).resultsPerPage
            if ($SourceUri -like '*lastModStartDate*') {$queryString = "&startIndex=$startIndex"} else {$queryString = "?startIndex=$startIndex"}
            Start-Sleep -Seconds 1
            if (($response.Content | ConvertFrom-Json).resultsPerPage -eq ($response.Content | ConvertFrom-Json).totalResults -Or ($response.Content | ConvertFrom-Json).resultsPerPage -eq 0) {$loopDone = $true}
        } else {
            $SourceUri = ($response.Content | ConvertFrom-Json).'@odata.nextLink'
            if ($null -eq $SourceUri) {$loopDone = $true}
        }
        $count += 1
    } until ($loopDone -eq $true)
}

#Function to take a large array of objects and split into smaller JSON arrays.
function New-BodyArray {
    param ($Content, $MaxSize, $TimeGenerated, $JsonDepth)
    $array = New-Object System.Collections.ArrayList
    $bodies = New-Object System.Collections.ArrayList
    foreach ($item in ($Content)) {
        $item | Add-Member -NotePropertyName 'TimeGenerated' -NotePropertyValue $TimeGenerated
        switch ($DataSourceName) {
            'MDVM Recommendations' { $item | Add-Member -MemberType AliasProperty -Name recId -Value Id }
            'MDVM Vulnerabilities by Device' { $item | Add-Member -MemberType AliasProperty -Name vulnId -Value Id }
            'MDVM CVE KB' { $item | Add-Member -MemberType AliasProperty -Name cveId -Value Id }
        }
        $array.Add($item) | Out-Null
    }
    $body = $array | ConvertTo-Json -Depth $JsonDepth
    if ($body.Length -gt $MaxSize) {
        $maxSizePercentOfBodySize = $MaxSize / $body.Length
        $batchSize = $array.Count * $maxSizePercentOfBodySize
        $batchSize = $batchSize + (0 - ($batchSize % 100))
        if ($batchSize -eq 0) { $batchSize = 50 }
        Write-Host "Estimated batch size being used:" $batchSize
        $skip = 0
        do {
            $reducedBatchSize = $batchSize
            $body = $array | Select-Object -Skip $skip | Select-Object -First $reducedBatchSize | ConvertTo-Json -Depth 8
            if ($body.Length -gt $MaxSize) {
                do {
                    if ($reducedBatchSize -lt 20) { $reducedBatchSize -= 1 } else { $reducedBatchSize -= 10 }                    
                    $body = $array | Select-Object -Skip $skip | Select-Object -First $reducedBatchSize | ConvertTo-Json -Depth 8
                } until ($body.Length -lt $MaxSize -Or $reducedBatchSize -lt 2)
                Write-Host "Body is too large, reducing number of objects in current batch to:" $reducedBatchSize ...
            }
            if ($reducedBatchSize -eq 1) {
                Write-Error ("Object is too large, skipping...")
            }
            else {
                $bodies.Add($body) | Out-Null
            }
            $skip += $reducedBatchSize
        } until ($skip -ge $array.Count)
    }
    else {
        $bodies.Add($body) | Out-Null
    }
    return $bodies
}

#Connect Azure Powershell module via Service Principal.
$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $appId, (ConvertTo-SecureString $appSecret -AsPlainText -Force)
Connect-AzAccount -ServicePrincipal -TenantId $tenantId -Credential $credential -Subscription $lawResourceId.Split('/')[2]

#Get Log Analytics workspace Id.
$lawId = (Get-AzOperationalInsightsWorkspace -ResourceGroupName $lawResourceId.Split('/')[4] -Name $lawResourceId.Split('/')[8]).CustomerId

#Get OAuth token for Defender API.
$defenderToken = Get-AADToken -resource 'https://api.securitycenter.microsoft.com' -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"
#Get OAuth token for Azure Monitor API.
$azMonToken = Get-AADToken -scope ([System.Web.HttpUtility]::UrlEncode("https://monitor.azure.com//.default")) -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"

#Ingest Vulnerabilities by Device.
$defenderUri = "https://api.securitycenter.windows.com/api/machines/SoftwareVulnerabilitiesByMachine"
$table = 'MDVMVulnerabilitiesByDevice_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationUri $azMonUri -DestinationToken $azMonToken -TimeGenerated $snapshotTime -DataSourceName 'MDVM Vulnerabilities by Device' -JsonDepth 2 -BodyMaxSize 1048576

#Ingest Recommendations.
$defenderUri = 'https://api.securitycenter.windows.com/api/recommendations'
$table = 'MDVMRecommendations_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationUri $azMonUri -DestinationToken $azMonToken -TimeGenerated $snapshotTime -DataSourceName 'MDVM Recommendations' -JsonDepth 2 -BodyMaxSize 1048576

#Ingest CVE KB. 
$lawQuery = 'MDVMCVEKB_CL | order by todatetime(updatedOn) desc | take 1 | project updatedOn'
$mdvmKbLastUpdate = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId  -Query $lawQuery -Timespan 730D

$lawQuery = 'MDVMCVEKB_CL | summarize min(TimeGenerated) | project OldestRecord = format_timespan(now() - min_TimeGenerated, "d")'
$mdvmKBOldestRecord = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$mdvmKbRetention = (Get-AzOperationalInsightsTable ($lawResourceId.Split('/'))[4] -WorkspaceName ($lawResourceId.Split('/'))[8] -TableName 'MDVMCVEKB_CL' | Select-Object RetentionInDays)[0].RetentionInDays

if ($null -eq $mdvmKbLastUpdate.Results.updatedOn -Or $mdvmKBOldestRecord.Results.OldestRecord -ge ($mdvmKbRetention - 5) -Or $fullImport -eq 1) {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities'
}
else {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities?$filter=updatedOn+gt+' + $mdvmKbLastUpdate.Results.updatedOn
}

$table = 'MDVMCVEKB_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationUri $azMonUri -DestinationToken $azMonToken -TimeGenerated $snapshotTime -DataSourceName 'MDVM CVE KB' -JsonDepth 2 -BodyMaxSize 1048576

#Ingest NIST CVE KB data.
$lawQuery = 'NISTCVEKB_CL | extend LastModified = cve.lastModified | order by todatetime(LastModified) desc | take 1 | project LastModified'
$nistKbLastUpdate = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId  -Query $lawQuery -Timespan 730D

$lawQuery = 'NISTCVEKB_CL | summarize min(TimeGenerated) | project OldestRecord = format_timespan(now() - min_TimeGenerated, "d")'
$nistKBOldestRecord = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$nistKbRetention = (Get-AzOperationalInsightsTable ($lawResourceId.Split('/'))[4] -WorkspaceName ($lawResourceId.Split('/'))[8] -TableName 'NISTCVEKB_CL' | Select-Object RetentionInDays)[0].RetentionInDays

if ($null -eq $nistKbLastUpdate.Results.LastModified -Or $nistKBOldestRecord.Results.OldestRecord -ge ($nistKbRetention - 5) -Or $fullImport -eq 1) {
    $nistUri = 'https://services.nvd.nist.gov/rest/json/cves/2.0'
} else {
    $nistUri = 'https://services.nvd.nist.gov/rest/json/cves/2.0/?lastModStartDate=' + $nistKbLastUpdate.Results.LastModified + '&lastModEndDate=' + $snapshotTime
}

$table = 'NISTCVEKB_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
Import-Data -SourceUri $nistUri -DestinationUri $azMonUri -DestinationToken $azMonToken -TimeGenerated $snapshotTime -DataSourceName 'NIST CVE KB' -JsonDepth 8 -BodyMaxSize 1048576