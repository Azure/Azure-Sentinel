﻿# Input bindings are passed in via param block.
param($Timer)

$lawResourceId = $env:LAW_RESOURCE_ID
$tenantId = $env:TENANT_ID
$appId = $env:APP_ID
$appSecret = $env:APP_SECRET
$dcrImmutableId = $env:DCR_IMMUTABLE_ID
$dceURI = $env:DCE_URI
$snapshotTime = (Get-Date -Format s) + 'Z'
$fullImport = $env:FULL_IMPORT
$maxBodySize = $env:MAX_BODY_SIZE

function Get-AADToken {
    param ($resource, $scope, $oAuthUri, $clientId, $clientSecret)
    if ($null -ne $resource) {
        $oAuthUri = "https://login.microsoftonline.com/$TenantId/oauth2/token"
        $authBody = "client_id=$clientId&resource=$resource&client_secret=$clientSecret&grant_type=client_credentials"
    }
    else {
        $oAuthUri = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
        $authBody = "client_id=$clientId&scope=$scope&client_secret=$clientSecret&grant_type=client_credentials"
    }
    $authHeaders = @{"Content-Type" = "application/x-www-form-urlencoded" }
    $authResponse = Invoke-RestMethod -Method Post -Uri $oAuthUri -Body $authBody -Headers $authHeaders -ErrorAction Stop
    $token = New-Object PSObject
    $token | Add-Member -MemberType NoteProperty -Name AccessToken -Value $authResponse.access_token
    $token | Add-Member -MemberType NoteProperty -Name TimeGenerated -Value (Get-Date)
    $token | Add-Member -MemberType NoteProperty -Name ExpiresIn -Value $authResponse.expires_in
    return $token
}

#Function to create HTTP headers for REST API calls.
function Get-RequestHeaders {
    param ($token)
    return @{"Authorization" = "Bearer $token"; "Content-Type" = "application/json" }
}

#Function to get data via REST API and send to Azure Monitor/Sentinel.
function Import-Data {
    param ($SourceUri, $SourceToken, $DestinationUri, $DestinationToken, $TimeGenerated, $DataSourceName, $JsonDepth, `
            $BodyMaxSize, $TableName, $RecommendationId, $AzureResources)
    $count = 1
    $startIndex = 0
    $queryString = ''
    $totalObjectsReceived = 0
    $totalObjectsSent = 0
    do {
        Write-Host "Getting $DataSourceName, request #" $count...

        if ($DataSourceName -eq 'NIST CVE KB') {
            $response = Invoke-WebRequest -Method Get -Uri ($SourceUri + $queryString) -MaximumRetryCount 2 -RetryIntervalSec 5
            $content = ($response.Content | ConvertFrom-Json).vulnerabilities | Select-Object -ExpandProperty cve
        }
        else {
            if ($SourceToken.ExpiresIn - (New-TimeSpan -Start $SourceToken.TimeGenerated -End (Get-Date)).TotalSeconds -lt 120) {
                Write-Host "Access token has expired. Renewing..."
                $SourceToken = Get-AADToken -resource 'https://api.securitycenter.microsoft.com' -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"
            } 
            $response = Invoke-WebRequest -Method Get -Uri $SourceUri -Headers (Get-RequestHeaders -token $SourceToken.AccessToken) -MaximumRetryCount 2 -RetryIntervalSec 5
            $content = ($response.Content | ConvertFrom-Json).value
            if ($DataSourceName -eq 'MDVM Recommendations') {
                $recommendations += $content
            }
        }
        $objectsReceived = $content.Count
        $totalObjectsReceived += $objectsReceived
        Write-Host "Objects Received in current Request:" $content.Count
        if ($objectsReceived -eq 0) { return }
        $bodies = New-BodyArray -Content $content -MaxSize $BodyMaxSize -TimeGenerated $TimeGenerated -JsonDepth $JsonDepth -RecommendationId $RecommendationId -AzureResources $AzureResources -DataSourceName $DataSourceName
        $totalObjectsSentInBatch = 0
        foreach ($body in $bodies) {
            $objectsSent = ($body | ConvertFrom-Json).Count
            $totalObjectsSentInBatch += $objectsSent
            $totalObjectsSent += $objectsSent
            if ($DestinationToken.ExpiresIn - (New-TimeSpan -Start $DestinationToken.TimeGenerated -End (Get-Date)).TotalSeconds -lt 120) {
                Write-Host "Access token has expired. Renewing..."
                $DestinationToken = Get-AADToken -scope ([System.Web.HttpUtility]::UrlEncode("https://monitor.azure.com//.default")) -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"
            } 
            $postResponse = Invoke-RestMethod -Uri $DestinationUri -Method "Post" -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) -Headers (Get-RequestHeaders -token $DestinationToken.AccessToken)
            $percentComplete = [math]::Round(($totalObjectsSentInBatch / $content.Count), 3)
            Write-Progress -Activity "Sending objects to Azure Monitor" -Status ("Sent $totalObjectsSentInBatch out of $objectsReceived objects.") -PercentComplete ([math]::Round($percentComplete * 100))
        }
        if ($DataSourceName -eq 'NIST CVE KB') {
            $startIndex += ($response.Content | ConvertFrom-Json).resultsPerPage
            if ($SourceUri -like '*lastModStartDate*') { $queryString = "&startIndex=$startIndex" } else { $queryString = "?startIndex=$startIndex" }
            if (($response.Content | ConvertFrom-Json).resultsPerPage -lt 2000 -Or ($response.Content | ConvertFrom-Json).resultsPerPage -eq 0) { $loopDone = $true }
            Start-Sleep -Seconds 1
        }
        else {
            $SourceUri = ($response.Content | ConvertFrom-Json).'@odata.nextLink'
            if ($null -eq $SourceUri) { $loopDone = $true }
        }
        Write-Progress -Id 0 -Completed -Activity 'Sending objects to Azure Monitor'
        Write-Host ("Total Objects So Far Received: $totalObjectsReceived / Sent: $totalObjectsSent")
        $count += 1
    } until ($loopDone -eq $true)

    if ($DataSourceName -eq 'MDVM Recommendations') {
        return $recommendations
    }
}

#Function to take a large array of objects and split into smaller JSON arrays.
function New-BodyArray {
    param ($Content, $MaxSize, $TimeGenerated, $JsonDepth, $RecommendationId, $AzureResources, $DataSourceName)
    $array = New-Object System.Collections.ArrayList
    $bodies = New-Object System.Collections.ArrayList
    foreach ($item in ($Content)) {
        $item | Add-Member -NotePropertyName 'TimeGenerated' -NotePropertyValue $TimeGenerated
        switch ($DataSourceName) {
            'MDVM Recommendations' { $item | Add-Member -MemberType NoteProperty -Name recId -Value $item.Id }
            'MDVM Recommendations Machine References' { 
                $item | Add-Member -MemberType NoteProperty -Name recordId -Value $item.Id
                $item | Add-Member -MemberType NoteProperty -Name recommendationId -Value $RecommendationId
            }
            'MDVM Vulnerabilities by Device' {
                $item | Add-Member -MemberType NoteProperty -Name vulnId -Value $item.Id
                $azSearch = $AzureResources | Where-Object deviceName -eq $item.deviceName.Substring(0, $item.deviceName.IndexOf('.')).ToLower()
                if ($null -ne $azSearch) {
                    $item | Add-Member -MemberType NoteProperty -Name azResourceId -Value $azSearch.id
                }
                else {
                    $item | Add-Member -MemberType NoteProperty -Name azResourceId -Value ''
                }
            }
            'MDVM CVE KB' { $item | Add-Member -MemberType NoteProperty -Name cveId -Value $item.Id }
            'NIST CVE KB' { $item | Add-Member -MemberType NoteProperty -Name cveId -Value $item.Id }
        }
        if ($null -ne $item.id) { $item.PSObject.Properties.Remove('id') }
        $array.Add($item) | Out-Null
    }
    $body = $array | ConvertTo-Json -Depth $JsonDepth
    if ([System.Text.Encoding]::UTF8.GetBytes($body).Length -gt $MaxSize) {
        $maxSizePercentOfBodySize = $MaxSize / [System.Text.Encoding]::UTF8.GetBytes($body).Length
        $estimatedBatchSize = $array.Count * $maxSizePercentOfBodySize
        $estimatedBatchSize = $estimatedBatchSize + (0 - ($estimatedBatchSize % 100))
        if ($estimatedBatchSize -eq 0) { $estimatedBatchSize = 50 }
        Write-Host "Estimated batch size being used:" $estimatedBatchSize
        $skip = 0
        do {
            $body = $array | Select-Object -Skip $skip | Select-Object -First $estimatedBatchSize | ConvertTo-Json -Depth $JsonDepth
            $actualBatchSize = $estimatedBatchSize
            if ([System.Text.Encoding]::UTF8.GetBytes($body).Length -gt $MaxSize) {
                do {
                    if ($actualBatchSize -lt 20) { $actualBatchSize -= 1 } else { $actualBatchSize -= 10 }             
                    $body = $array | Select-Object -Skip $skip | Select-Object -First $actualBatchSize | ConvertTo-Json -Depth $JsonDepth
                    if ($actualBatchSize -eq 1 -And [System.Text.Encoding]::UTF8.GetBytes($body).Length -gt $MaxSize -And ($body | ConvertFrom-Json | Get-Member configurations)) {
                        Write-Error ("Object is too large, removing configurations object to reduce the size. Length:" + ([math]::round([System.Text.Encoding]::UTF8.GetBytes($body).Length/1kb)) + ' KB')
                        $body = $body | ConvertFrom-Json
                        $body.PSObject.Properties.Remove('configurations')
                        $body = $body | ConvertTo-Json -Depth $JsonDepth -AsArray
                    }
                    elseif ($actualBatchSize -eq 1 -And [System.Text.Encoding]::UTF8.GetBytes($body).Length -gt $MaxSize) {
                        Write-Error ("Object is too large, skipping...")
                        $body = $null
                    }
                    elseif ($actualBatchSize -eq 1) {
                        $body = $body | ConvertFrom-Json
                        $body = $body | ConvertTo-Json -Depth $JsonDepth -AsArray
                    }
                } until ([System.Text.Encoding]::UTF8.GetBytes($body).Length -lt $MaxSize -Or $actualBatchSize -lt 2)
                if ($null -ne $body) {Write-Host ("Body is too large, reducing number of objects in current batch to: $actualBatchSize" + ". New size: " + ([math]::round([System.Text.Encoding]::UTF8.GetBytes($body).Length/1kb)) + ' KB')}
            }
            if ($null -ne $body) { $bodies.Add($body) | Out-Null }
            $skip += $actualBatchSize
        } until ($skip -ge $array.Count)
    }
    else {
        $bodies.Add($body) | Out-Null
    }
    return $bodies
}

#Connect Azure Powershell module via Service Principal.
$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $appId, (ConvertTo-SecureString $appSecret -AsPlainText -Force)
Connect-AzAccount -ServicePrincipal -TenantId $tenantId -Credential $credential -Subscription $lawResourceId.Split('/')[2]

#Get Log Analytics workspace Id.
$lawId = (Get-AzOperationalInsightsWorkspace -ResourceGroupName $lawResourceId.Split('/')[4] -Name $lawResourceId.Split('/')[8]).CustomerId

#Get OAuth token for Defender API.
$defenderToken = Get-AADToken -resource 'https://api.securitycenter.microsoft.com' -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"
#Get OAuth token for Azure Monitor API.
$azMonToken = Get-AADToken -scope ([System.Web.HttpUtility]::UrlEncode("https://monitor.azure.com//.default")) -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"

#Get Azure VM inventory
$azureVMsQuery = "
resources
| where type in ('microsoft.compute/virtualmachines', 'microsoft.hybridcompute/machines')
| extend deviceName = properties.extended.instanceView.computerName
| extend deviceName = iif(deviceName == '', name, deviceName)
| project id = tolower(id), deviceName = tolower(deviceName)"

$azResources = $null
$response = $null
do {
    $response = Search-AzGraph -Query $azureVMsQuery -SkipToken $response.SkipToken -First 1000
    $azResources += $response
} until ($null -eq $response.SkipToken)

#Ingest Vulnerabilities by Device.
$defenderUri = "https://api.securitycenter.windows.com/api/machines/SoftwareVulnerabilitiesByMachine"
$table = 'MDVMVulnerabilitiesByDevice_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationUri $azMonUri -DestinationToken $azMonToken -TimeGenerated $snapshotTime `
    -DataSourceName 'MDVM Vulnerabilities by Device' -JsonDepth 2 -BodyMaxSize $maxBodySize -TableName $table -AzureResources $azResources

#Ingest Recommendations.
$defenderUri = 'https://api.securitycenter.windows.com/api/recommendations'
$table = 'MDVMRecommendations_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
$recommendations = Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationUri $azMonUri -DestinationToken $azMonToken -TimeGenerated $snapshotTime `
    -DataSourceName 'MDVM Recommendations' -JsonDepth 2 -BodyMaxSize $maxBodySize -TableName $table

#Ingest Recommendations Machine References.
$table = 'MDVMRecommendationsMachineReferences_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
foreach ($recommendation in $recommendations) {
    $defenderUri = 'https://api.securitycenter.microsoft.com/api/recommendations/' + $recommendation.recId + '/machineReferences'
    Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationUri $azMonUri -DestinationToken $azMonToken -TimeGenerated $snapshotTime `
        -DataSourceName 'MDVM Recommendations Machine References' -JsonDepth 2 -BodyMaxSize $maxBodySize -TableName $table -RecommendationId $recommendation.recId
}

#Ingest CVE KB. 
$lawQuery = 'MDVMCVEKB_CL | order by todatetime(updatedOn) desc | take 1 | project updatedOn'
$mdvmKbLastUpdate = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId  -Query $lawQuery -Timespan 730D

$lawQuery = 'MDVMCVEKB_CL | summarize min(TimeGenerated) | project OldestRecord = format_timespan(now() - min_TimeGenerated, "d")'
$mdvmKBOldestRecord = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$mdvmKbRetention = (Get-AzOperationalInsightsTable ($lawResourceId.Split('/'))[4] -WorkspaceName ($lawResourceId.Split('/'))[8] -TableName 'MDVMCVEKB_CL' | Select-Object RetentionInDays)[0].RetentionInDays

if ($null -eq $mdvmKbLastUpdate.Results.updatedOn -Or $mdvmKBOldestRecord.Results.OldestRecord -ge ($mdvmKbRetention - 5) -Or $fullImport -eq 1) {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities'
}
else {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities?$filter=updatedOn+gt+' + $mdvmKbLastUpdate.Results.updatedOn
}


$table = 'MDVMCVEKB_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationUri $azMonUri -DestinationToken $azMonToken -TimeGenerated $snapshotTime `
    -DataSourceName 'MDVM CVE KB' -JsonDepth 2 -BodyMaxSize $maxBodySize -TableName $table

#Ingest NIST CVE KB data.
$lawQuery = 'MDVMNISTCVEKB_CL | extend LastModified = lastModified | order by todatetime(LastModified) desc | take 1 | project LastModified'
$nistKbLastUpdate = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$lawQuery = 'MDVMNISTCVEKB_CL | summarize min(TimeGenerated) | project OldestRecord = format_timespan(now() - min_TimeGenerated, "d")'
$nistKBOldestRecord = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$nistKbRetention = (Get-AzOperationalInsightsTable ($lawResourceId.Split('/'))[4] -WorkspaceName ($lawResourceId.Split('/'))[8] -TableName 'MDVMNISTCVEKB_CL' | Select-Object RetentionInDays)[0].RetentionInDays

if ($null -eq $nistKbLastUpdate.Results.LastModified -Or $nistKBOldestRecord.Results.OldestRecord -ge ($nistKbRetention - 5) -Or $fullImport -eq 1) {
    $nistUri = 'https://services.nvd.nist.gov/rest/json/cves/2.0'
}
else {
    $nistUri = 'https://services.nvd.nist.gov/rest/json/cves/2.0/?lastModStartDate=' + $nistKbLastUpdate.Results.LastModified + '&lastModEndDate=' + $snapshotTime
}

$table = 'MDVMNISTCVEKB_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
Import-Data -SourceUri $nistUri -DestinationUri $azMonUri -DestinationToken $azMonToken -TimeGenerated $snapshotTime -DataSourceName 'NIST CVE KB' `
    -JsonDepth 8 -BodyMaxSize $maxBodySize -TableName $table