﻿# Input bindings are passed in via param block.
param($Timer)

#Define global variables.
$lawResourceId = $env:LawResourceId
$dcrImmutableId = $env:DcrImmutableId
$dceUri = $env:DceUri
$uamiClientId = $env:UamiClientId
$transactionId = (New-Guid).Guid
$fullImport = $env:FullImport

#Function to create HTTP headers for REST API calls.
function Get-RequestHeaders {
    param ($Token)
    return @{"Authorization" = "Bearer $Token"; "Content-Type" = "application/json" }
}

#Function to get data via REST API and send to Azure Monitor.
function Import-Data {
    param ($SourceUri, $SourceToken, $Table, $DataSourceName, $JsonDepth, $RecommendationId, $AzureResources)
    $count = 1
    $startIndex = 0
    $queryString = ''
    $totalObjectsReceived = 0
    $totalConfigurationObjectsReceived = 0
    do {
        Write-Host ("Getting $DataSourceName, request # $count...")
        if ($DataSourceName -eq 'NIST CVE KB') {
            try {
                $response = Invoke-RestMethod -Method Get -Uri ($SourceUri + $queryString) -MaximumRetryCount 2 -RetryIntervalSec 5
            }
            catch {
                Write-Error ("Unable to retrieve data from REST API and cannot continue with this data source. Error details: " + $_.ErrorDetails)
                return
            }
            $content = $response.vulnerabilities | Select-Object -ExpandProperty cve
        }
        else {
            try {
                $response = Invoke-RestMethod -Method Get -Uri $SourceUri -Headers (Get-RequestHeaders -Token $SourceToken.Token) -MaximumRetryCount 2 -RetryIntervalSec 5
            }
            catch {
                Write-Error ("Unable to retrieve data from REST API and cannot continue with this data source. Error details: " + $_.ErrorDetails)
                return
            }
            $content = $response.value
            if ($DataSourceName -eq 'MDVM Recommendations') {
                $recommendations += $content
            }
        }
        $objectsReceived = $content.Count
        $totalObjectsReceived += $objectsReceived
        Write-Host "Objects received in current request:" $content.Count
        if ($objectsReceived -eq 0) { return }
        $content | Add-Member -NotePropertyName 'TimeGenerated' -NotePropertyValue (Get-Date -Format 'yyyy-MM-ddThh:mm:ssZ' -AsUTC)
        $content | Add-Member -NotePropertyName 'transactionId' -NotePropertyValue $transactionId
        switch ($DataSourceName) {
            'MDVM Recommendations' { 
                $content | Add-Member -MemberType AliasProperty -Name recId -Value id
            }
            'MDVM Recommendations Machine References' { 
                $content | Add-Member -MemberType AliasProperty -Name recordId -Value id
                $content | Add-Member -NotePropertyName recommendationId -NotePropertyValue $RecommendationId
            }
            'MDVM Vulnerabilities by Device' {
                $content | Add-Member -MemberType AliasProperty -Name vulnId -Value id
                foreach ($item in $content) {
                    $azSearch = $AzureResources.($item.deviceName.Substring(0, $item.deviceName.IndexOf('.')).ToLower())
                    if ($null -ne $azSearch) {
                        $item | Add-Member -NotePropertyName azResourceId -NotePropertyValue $azSearch.id
                    }
                    else {
                        $item | Add-Member -NotePropertyName azResourceId -NotePropertyValue ''
                    }
                }
            }
            'MDVM CVE KB' {
                $content | Add-Member -NotePropertyName cveId -NotePropertyValue id 
            }
            'NIST CVE KB' { 
                $content | Add-Member -MemberType AliasProperty -Name cveId -Value id
                $configurations = New-Object System.Collections.ArrayList
                foreach ($item in $content | Where-Object configurations -ne $null) {
                    $configurationNumber = 0
                    foreach ($configuration in $item.configurations) {
                        $configurationNumber += 1
                        $nodes = $configuration | Select-Object -ExpandProperty nodes
                        foreach ($node in $nodes) {
                            $cpes = $node | Select-Object -ExpandProperty cpeMatch
                            $cpes | Add-Member -NotePropertyMembers @{
                                configurationNumber   = $configurationNumber
                                configurationOperator = $configuration.operator
                                configurationNegate   = $configuration.negate
                                nodeOperator          = $node.operator
                                nodeNegate            = $node.negate
                                cveId                 = $item.cveId
                                TimeGenerated         = $item.TimeGenerated
                                transactionId         = $transactionId
                            } -PassThru | Out-Null
                            foreach ($cpe in $cpes) {
                                $configurations.Add($cpe) | Out-Null
                            }
                        }
                    }
                    $item.PSObject.Properties.Remove('configurations')
                }
            }
        }
        $logIngestionClient.UploadAsync($dcrImmutableId, "Custom-$Table", ($content | ConvertTo-Json -Depth $JsonDepth -AsArray)) | Out-Null
        if ($configurations.Count -ne 0) {
            $configurationObjectsReceived = $configurations.Count
            $totalConfigurationObjectsReceived += $configurationObjectsReceived
            Write-Host "Sending NIST Configurations KB..."
            $skip = 0
            do {
                $batchedConfigurations = $configurations | Select-Object -Skip $skip | Select-Object -First 30000
                $logIngestionClient.UploadAsync($dcrImmutableId, "Custom-MDVMNISTConfigurations_CL", ($batchedConfigurations | ConvertTo-Json -AsArray)) | Out-Null
                $skip += 30000
            } until (
                $skip -ge $configurations.Count
            )
        }
        Write-Host ("Total objects received and sent to Azure Monitor so far: $totalObjectsReceived $($DataSourceName -eq 'NIST CVE KB' ? "(Configuration Objects: $totalConfigurationObjectsReceived)": '')")
        if ($DataSourceName -eq 'NIST CVE KB') {
            $startIndex += $response.resultsPerPage
            if ($SourceUri -like '*lastModStartDate*') { $queryString = "&startIndex=$startIndex" } else { $queryString = "?startIndex=$startIndex" }
            if ($startIndex -ge $response.totalResults) { $loopDone = $true } else { Start-Sleep -Seconds 1 }
        }
        else {
            $SourceUri = $response.'@odata.nextLink'
            if ($null -eq $SourceUri) { $loopDone = $true }
        }
        $count += 1
    } until ($loopDone -eq $true)
    
    if ($tableStats | Where-Object TableName -eq $Table) {
        ($tableStats | Where-Object TableName -eq $Table).TotalObjectsReceived += $totalObjectsReceived
    }
    else {
        $tableStatsObject = New-Object psobject
        $tableStatsObject | Add-Member -NotePropertyName 'TableName' -NotePropertyValue $Table
        $tableStatsObject | Add-Member -NotePropertyName 'TotalObjectsReceived' -NotePropertyValue $totalObjectsReceived
        $tableStats.Add($tableStatsObject) | Out-Null
        if ($totalConfigurationObjectsReceived -gt 0) {
            $tableStatsObject = New-Object psobject
            $tableStatsObject | Add-Member -NotePropertyName 'TableName' -NotePropertyValue 'MDVMNISTConfigurations_CL'
            $tableStatsObject | Add-Member -NotePropertyName 'TotalObjectsReceived' -NotePropertyValue $totalConfigurationObjectsReceived
            $tableStats.Add($tableStatsObject) | Out-Null
        }
    }
    if ($DataSourceName -eq 'MDVM Recommendations') {
        return $recommendations
    }
}

#Add required .Net assemblies.
Add-Type -Path .\GetMDVMData\Azure.Monitor.Ingestion.dll
Add-Type -Path .\GetMDVMData\Azure.Identity.dll

#Connect Azure Powershell via User Assigned Managed Identity.
Connect-AzAccount -Identity -AccountId $uamiClientID -Subscription $lawResourceId.Split('/')[2] | Out-Null

#Create Azure.Identity credential via User Assigned Managed Identity.
$credential = New-Object Azure.Identity.ManagedIdentityCredential($uamiClientId)
#Create LogsIngestionClient to handle sending data to Azure Monitor.
$logIngestionClient = New-Object Azure.Monitor.Ingestion.LogsIngestionClient($dceURI, $credential)

#Create array to hold obect counts for each data source so we can compare to total records written later.
$tableStats = New-Object System.Collections.ArrayList
$azMonResponses = New-Object System.Collections.ArrayList

#Get Log Analytics workspace Id.
$lawId = (Get-AzOperationalInsightsWorkspace -ResourceGroupName $lawResourceId.Split('/')[4] -Name $lawResourceId.Split('/')[8]).CustomerId

#Get OAuth token for Defender API.
$defenderToken = Get-AzAccessToken -ResourceUrl 'https://api.securitycenter.microsoft.com'

#Get Azure VM inventory
$azureVMsQuery = "
resources
| where type in ('microsoft.compute/virtualmachines', 'microsoft.hybridcompute/machines')
| extend deviceName = properties.extended.instanceView.computerName
| extend deviceName = iif(deviceName == '', name, deviceName)
| project id = tolower(id), deviceName = tolower(deviceName)"

do {
    $response = Search-AzGraph -Query $azureVMsQuery -SkipToken $response.SkipToken -First 1000
    $azResources += $response
} until ($null -eq $response.SkipToken)
$azResources = $azResources | Group-Object -AsHashTable -Property deviceName

#Ingest Vulnerabilities by Device.
$defenderUri = "https://api.securitycenter.windows.com/api/machines/SoftwareVulnerabilitiesByMachine"
Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DceUri $dceURI -DataSourceName 'MDVM Vulnerabilities by Device' `
    -JsonDepth 2 -Table 'MDVMVulnerabilitiesByDevice_CL' -AzureResources $azResources

#Ingest Recommendations.
$defenderUri = 'https://api.securitycenter.windows.com/api/recommendations'
$recommendations = Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DataSourceName 'MDVM Recommendations' `
    -JsonDepth 2 -Table 'MDVMRecommendations_CL'

#Ingest Recommendations Machine References.
foreach ($recommendation in $recommendations) {
    $defenderUri = 'https://api.securitycenter.microsoft.com/api/recommendations/' + $recommendation.recId + '/machineReferences'
    Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DataSourceName 'MDVM Recommendations Machine References' `
        -JsonDepth 2 -Table 'MDVMRecommendationsMachineReferences_CL' -RecommendationId $recommendation.recId
    Start-Sleep -Milliseconds 500
}

#Ingest CVE KB. 
$lawQuery = 'MDVMCVEKB_CL | order by todatetime(updatedOn) desc | take 1 | project updatedOn'
$mdvmKbLastUpdate = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId  -Query $lawQuery -Timespan 730D

$lawQuery = 'MDVMCVEKB_CL | summarize min(TimeGenerated) | project OldestRecord = format_timespan(now() - min_TimeGenerated, "d")'
$mdvmKBOldestRecord = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$mdvmKbRetention = (Get-AzOperationalInsightsTable -ResourceGroupName ($lawResourceId.Split('/'))[4] -WorkspaceName ($lawResourceId.Split('/'))[8] -TableName 'MDVMCVEKB_CL' | Select-Object RetentionInDays)[0].RetentionInDays

if ($null -eq $mdvmKbLastUpdate.Results.updatedOn -Or $mdvmKBOldestRecord.Results.OldestRecord -ge ($mdvmKbRetention - 5) -Or $fullImport -eq 1) {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities'
}
else {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities?$filter=updatedOn+gt+' + $mdvmKbLastUpdate.Results.updatedOn
    Write-Host ("Checking for MDVM CVE KB data updated since " + $mdvmKbLastUpdate.Results.updatedOn + "...")
}

Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DataSourceName 'MDVM CVE KB' `
    -JsonDepth 2 -Table 'MDVMCVEKB_CL'

#Ingest NIST CVE KB data.
$lawQuery = 'MDVMNISTCVEKB_CL | summarize LastTimeModified = max(lastModified) | project LastTimeModified'
$nistKbLastUpdate = (Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D)

$lawQuery = 'MDVMNISTCVEKB_CL | summarize min(TimeGenerated) | project OldestRecord = format_timespan(now() - min_TimeGenerated, "d")'
$nistKBOldestRecord = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$nistKbRetention = (Get-AzOperationalInsightsTable -ResourceGroupName ($lawResourceId.Split('/'))[4] -WorkspaceName ($lawResourceId.Split('/'))[8] -TableName 'MDVMNISTCVEKB_CL' | Select-Object RetentionInDays)[0].RetentionInDays

if ($null -eq [datetime]$nistKbLastUpdate.Results.LastTimeModified -Or $nistKBOldestRecord.Results.OldestRecord -ge ($nistKbRetention - 5) -Or $fullImport -eq 1) {
    $nistUri = 'https://services.nvd.nist.gov/rest/json/cves/2.0'
}
else {
    $lastModifiedTime = (([datetime]$nistKbLastUpdate.Results.LastTimeModified).AddMilliseconds(1)).ToUniversalTime().ToString('yyyy-MM-ddThh:mm:ss.fffZ')
    $nistUri = 'https://services.nvd.nist.gov/rest/json/cves/2.0/?lastModStartDate=' + $lastModifiedTime + '&lastModEndDate=' + (Get-Date -Format 'yyyy-MM-ddThh:mm:ss.fffZ' -AsUTC)
    Write-Host ("Checking for NIST CVE KB data updated since " + $lastModifiedTime + "...")
}

Import-Data -SourceUri $nistUri -DataSourceName 'NIST CVE KB' -JsonDepth 8 -Table 'MDVMNISTCVEKB_CL'

#Validate data was written to Azure Monitor.
Write-Host "Waiting 3 minutes to allow for all data to get written to Azure Monitor before checking for any mismatches..."
Start-Sleep -Seconds 180
$lawQuery = "union withsource=MDVMTableName MDVM*
    | where transactionId == '$transactionId'
    | summarize Count = count() by MDVMTableName, transactionId"
$lawCounts = (Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 1D ).Results
foreach ($table in $tableStats) {
    $table | Add-Member -NotePropertyName TotalRecordsWrittenToAzureMonitor -NotePropertyValue (($lawCounts | Where-Object MDVMTableName -eq $table.TableName).Count)
    if (($table.TotalObjectsReceived + ($lawCounts | Where-Object MDVMTableName -eq $table.TableName).Count) / 2 -ne $table.TotalObjectsReceived) { $mismatch = $true } else { $mismatch = $false }
    $table | Add-Member -NotePropertyName Mismatch -NotePropertyValue $mismatch
    $report += ($table.TableName + ": Records Received: " + $table.TotalObjectsReceived + " / Records Written: " + $table.TotalRecordsWrittenToAzureMonitor + " to Azure Monitor.`n")
}

if ($tableStats | Where-Object Mismatch -eq $true) {
    Write-Error -Message ("There is a mismatch between data received and written to Azure Monitor. Per table details are below:`n" + $report)
}
else {
    Write-Host ("All data has been successfully written to Azure Monitor. Per table details are below: `n" + $report)
}
