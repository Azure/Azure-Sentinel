﻿# Input bindings are passed in via param block.
param($Timer)

$lawResourceId = $env:LAW_RESOURCE_ID
$tenantId = $env:TENANT_ID
$appId = $env:APP_ID
$appSecret = $env:APP_SECRET
$dcrImmutableId = $env:DCR_IMMUTABLE_ID
$dceURI = $env:DCE_URI
$snapshotTime = Get-Date -Format s
$batchSize = $env:BATCH_SIZE
$fullImport = $env:FULL_IMPORT

#Function to get AAD OAuth tokens for REST API calls.
function Get-AADToken {
    param ($resource, $scope, $oAuthUri, $clientId, $clientSecret)
    if ($null -ne $resource) {
        $oAuthUri = "https://login.microsoftonline.com/$TenantId/oauth2/token"
        $authBody = "client_id=$clientId&resource=$resource&client_secret=$clientSecret&grant_type=client_credentials"
    }
    else {
        $oAuthUri = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
        $authBody = "client_id=$clientId&scope=$scope&client_secret=$clientSecret&grant_type=client_credentials"
    }
    $authHeaders = @{"Content-Type" = "application/x-www-form-urlencoded"}
    $authResponse = Invoke-RestMethod -Method Post -Uri $oAuthUri -Body $authBody -Headers $authHeaders -ErrorAction Stop
    return $authResponse.access_token
}

#Function to create HTTP headers for REST API calls.
function Get-RequestHeaders {
    param ($token)
    return @{"Authorization" = "Bearer $token"; "Content-Type" = "application/json" }
}

#Function to get data via REST API and send to Azure Monitor/Sentinel.
function Import-Data {
    param ($SourceUri, $SourceToken, $DestinationUri, $DestintationToken, $TimeGenerated, $DataSourceName)
    $count = 1
    do {
        Write-Host "Getting $DataSourceName, request #" $count...
        $response = Invoke-WebRequest -Method Get -Uri $SourceUri -Headers (Get-RequestHeaders -token $SourceToken) -ErrorAction Stop
        $body = New-Object System.Collections.ArrayList
        foreach ($item in ($response.Content | ConvertFrom-Json).value) {
            $item | Add-Member -NotePropertyName 'TimeGenerated' -NotePropertyValue $TimeGenerated
            $item | Add-Member -MemberType AliasProperty -Name vulnId -Value Id
            $body.Add($item) | Out-Null
        }
        $skip = 0
        do {
            Write-Host "Sending $DataSourceName, request #" $count "- records:" $skip "-" ($skip + $batchSize)...
            Invoke-RestMethod -Uri $DestinationUri -Method "Post" -Body ($body | Select-Object -ExcludeProperty Id -Skip $skip | Select-Object -First $batchSize | ConvertTo-Json) -Headers (Get-RequestHeaders -token $DestintationToken)
            $skip += $batchSize
        } until ($skip -ge $body.Count)
        
        $SourceUri = ($response.Content | ConvertFrom-Json).'@odata.nextLink'
        $count += 1
    } until ($null -eq $SourceUri)
}

#Connect Azure Powershell module via Service Principal.
$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $appId, (ConvertTo-SecureString $appSecret -AsPlainText -Force)
Connect-AzAccount -ServicePrincipal -TenantId $tenantId -Credential $credential -Subscription $lawResourceId.Split('/')[2]

#Get Log Analytics workspace Id.
$lawId = (Get-AzOperationalInsightsWorkspace -ResourceGroupName $lawResourceId.Split('/')[4] -Name $lawResourceId.Split('/')[8]).CustomerId

#Get OAuth token for Defender API.
$defenderToken = Get-AADToken -resource 'https://api.securitycenter.microsoft.com' -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"
#Get OAuth token for Azure Monitor API.
$azMonToken = Get-AADToken -scope ([System.Web.HttpUtility]::UrlEncode("https://monitor.azure.com//.default")) -clientId $appId -clientSecret $appSecret -oAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"

#Ingest Vulnerabilities by Device.
$defenderUri = "https://api.securitycenter.windows.com/api/machines/SoftwareVulnerabilitiesByMachine"
$table = 'MDVMVulnerabilitiesByDevice_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationUri $azMonUri -DestintationToken $azMonToken -TimeGenerated $snapshotTime -DataSourceName 'MDVM Vulnerabilities by Device'

#Ingest Recommendations.
$defenderUri = 'https://api.securitycenter.windows.com/api/recommendations'
$table = 'MDVMRecommendations_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationUri $azMonUri -DestintationToken $azMonToken -TimeGenerated $snapshotTime -DataSourceName 'MDVM Recommendations'

#Ingest CVE KB. Because this data largely remains the same, first we are checking to see if we need to do a delta import or a full import.
$lawQuery = 'MDVMCVEKB_CL | order by todatetime(updatedOn) desc | take 1 | project updatedOn'
$mdvmKbLastUpdate = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId  -Query $lawQuery -Timespan 730D

$lawQuery = 'MDVMCVEKB_CL | summarize min(TimeGenerated) | project OldestRecord = format_timespan(now() - min_TimeGenerated, "d")'
$mdvmKBOldestRecord = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$mdvmKbRetention = (Get-AzOperationalInsightsTable ($lawResourceId.Split('/'))[4] -WorkspaceName ($lawResourceId.Split('/'))[8] -TableName 'MDVMCVEKB_CL' | Select-Object RetentionInDays)[0].RetentionInDays

if ($null -eq $mdvmKbLastUpdate.Results.updatedOn -Or $mdvmKBOldestRecord.Results.OldestRecord -ge ($mdvmKbRetention - 5) -Or $fullImport -eq 1) {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities'
}
else {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities?$filter=updatedOn+gt+' + $mdvmKbLastUpdate.Results.updatedOn
}

$table = 'MDVMCVEKB_CL'
$azMonUri = "$dceURI/dataCollectionRules/$dcrImmutableId/streams/Custom-$table" + "?api-version=2021-11-01-preview"
Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationUri $azMonUri -DestintationToken $azMonToken -TimeGenerated $snapshotTime -DataSourceName 'MDVM CVE KB'