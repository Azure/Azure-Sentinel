﻿# Input bindings are passed in via param block.
param($Timer)

$lawResourceId = $env:LAW_RESOURCE_ID
$tenantId = $env:TENANT_ID
$appId = $env:APP_ID
$appSecret = $env:APP_SECRET
$dcrImmutableId = $env:DCR_IMMUTABLE_ID
$dceUri = $env:DCE_URI
$snapshotTime = (Get-Date -Format s) + 'Z'
$fullImport = $env:FULL_IMPORT
$maxBodySize = $env:MAX_BODY_SIZE

function Get-AADToken {
    param ($Resource, $Scope, $OAuthUri, $ClientId, $ClientSecret, $TenantId)
    if ($null -ne $Resource) {
        $OAuthUri = "https://login.microsoftonline.com/$TenantId/oauth2/token"
        $authBody = "client_id=$ClientId&resource=$Resource&client_secret=$ClientSecret&grant_type=client_credentials"
    }
    else {
        $OAuthUri = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
        $authBody = "client_id=$ClientId&scope=$Scope&client_secret=$ClientSecret&grant_type=client_credentials"
    }
    $authHeaders = @{"Content-Type" = "application/x-www-form-urlencoded" }
    $authResponse = Invoke-RestMethod -Method Post -Uri $OAuthUri -Body $authBody -Headers $authHeaders -ErrorAction Stop
    $token = New-Object PSObject
    $token | Add-Member -MemberType NoteProperty -Name AccessToken -Value $authResponse.access_token
    $token | Add-Member -MemberType NoteProperty -Name TimeGenerated -Value (Get-Date)
    $token | Add-Member -MemberType NoteProperty -Name ExpiresIn -Value $authResponse.expires_in
    return $token
}

#Function to create HTTP headers for REST API calls.
function Get-RequestHeaders {
    param ($Token)
    return @{"Authorization" = "Bearer $Token"; "Content-Type" = "application/json" }
}

#Function to get data via REST API.
function Import-Data {
    param ($SourceUri, $SourceToken, $Table, $DestinationToken, $DataSourceName, $JsonDepth, $RecommendationId, $AzureResources)
    $count = 1
    $startIndex = 0
    $queryString = ''
    $totalObjectsReceived = 0
    $totalObjectsSent = 0
    do {
        Write-Host "Getting $DataSourceName, request #" $count...
        if ($DataSourceName -eq 'NIST CVE KB') {
            $response = Invoke-RestMethod -Method Get -Uri ($SourceUri + $queryString) -MaximumRetryCount 2 -RetryIntervalSec 5
            $content = $response.vulnerabilities | Select-Object -ExpandProperty cve
        }
        else {
            if ($SourceToken.ExpiresIn - (New-TimeSpan -Start $SourceToken.TimeGenerated -End (Get-Date)).TotalSeconds -lt 120) {
                Write-Host "Access token has expired. Renewing..."
                $SourceToken = Get-AADToken -Resource 'https://api.securitycenter.microsoft.com' -ClientId $appId -ClientSecret $appSecret -TenantId $tenantId -OAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"
            } 
            $response = Invoke-RestMethod -Method Get -Uri $SourceUri -Headers (Get-RequestHeaders -Token $SourceToken.AccessToken) -MaximumRetryCount 2 -RetryIntervalSec 5
            $content = $response.value
            if ($DataSourceName -eq 'MDVM Recommendations') {
                $recommendations += $content
            }
        }
        foreach ($item in ($content)) {
            $item | Add-Member -NotePropertyName 'TimeGenerated' -NotePropertyValue $snapshotTime
            switch ($DataSourceName) {
                'MDVM Recommendations' { $item | Add-Member -MemberType NoteProperty -Name recId -Value $item.Id }
                'MDVM Recommendations Machine References' { 
                    $item | Add-Member -NotePropertyName recordId -NotePropertyValue $item.Id
                    $item | Add-Member -NotePropertyName recommendationId -NotePropertyValue $RecommendationId
                }
                'MDVM Vulnerabilities by Device' {
                    $item | Add-Member -NotePropertyName vulnId -NotePropertyValue $item.Id
                    $azSearch = $AzureResources | Where-Object deviceName -eq $item.deviceName.Substring(0, $item.deviceName.IndexOf('.')).ToLower()
                    if ($null -ne $azSearch) {
                        $item | Add-Member -NotePropertyName azResourceId -NotePropertyValue $azSearch.id
                    }
                    else {
                        $item | Add-Member -NotePropertyName azResourceId -NotePropertyValue ''
                    }
                }
                'MDVM CVE KB' { $item | Add-Member -NotePropertyName cveId -NotePropertyValue $item.Id }
                'NIST CVE KB' { $item | Add-Member -NotePropertyName cveId -NotePropertyValue $item.Id }
            }
            if ($null -ne $item.id) { $item.PSObject.Properties.Remove('id') }
        }
        $objectsReceived = $content.Count
        $totalObjectsReceived += $objectsReceived
        Write-Host "Objects Received in current Request:" $content.Count
        if ($objectsReceived -eq 0) {return}
        if ($DestinationToken.ExpiresIn - (New-TimeSpan -Start $DestinationToken.TimeGenerated -End (Get-Date)).TotalSeconds -lt 300) {
            Write-Host "Access token has expired. Renewing..."
            $DestinationToken = Get-AADToken -Scope ([System.Web.HttpUtility]::UrlEncode("https://monitor.azure.com//.default")) -ClientId $appId -ClientSecret $appSecret -TenantId $tenantId -OAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"
        }
        $objectsSent = Send-ToAzureMonitor -Content $content -MaxBodySize $maxBodySize -TimeGenerated $snapshotTime -JsonDepth $JsonDepth `
            -Headers (Get-RequestHeaders -Token $DestinationToken.AccessToken) -DceUri $dceUri -DcrImmutableId $dcrImmutableId -Table $Table
        $totalObjectsSent += $objectsSent
        Write-Host ("Total objects Received: $totalObjectsReceived / Sent: $totalObjectsSent so far.")

        if ($DataSourceName -eq 'NIST CVE KB') {
            $startIndex += $response.resultsPerPage
            if ($SourceUri -like '*lastModStartDate*') { $queryString = "&startIndex=$startIndex" } else { $queryString = "?startIndex=$startIndex" }
            if ($response.resultsPerPage -lt 2000 -Or $response.resultsPerPage -eq 0) { $loopDone = $true }
            Start-Sleep -Seconds 1
        }
        else {
            $SourceUri = $response.'@odata.nextLink'
            if ($null -eq $SourceUri) { $loopDone = $true }
        }
        $count += 1
    } until ($loopDone -eq $true)

    if ($DataSourceName -eq 'MDVM Recommendations') {
        return $recommendations
    }
}

#Function to batch send data to Azure Monitor.
function Send-ToAzureMonitor {
    param ($Content, $MaxBodySize, $TimeGenerated, $JsonDepth, $Headers, $DceUri, $DcrImmutableId, $Table)
    $azMonUri = "$DceUri/dataCollectionRules/$DcrImmutableId/streams/Custom-$Table" + "?api-version=2021-11-01-preview"
    $objectsReceived = $Content.Count
    $bodies = New-Object System.Collections.ArrayList
    $body = $Content | ConvertTo-Json -Depth $JsonDepth -AsArray
    if ([System.Text.Encoding]::UTF8.GetBytes($body).Length -gt $MaxBodySize) {
        $maxSizePercentOfBodySize = $MaxBodySize / [System.Text.Encoding]::UTF8.GetBytes($body).Length
        $estimatedBatchSize = $Content.Count * $maxSizePercentOfBodySize
        $estimatedBatchSize = $estimatedBatchSize + (0 - ($estimatedBatchSize % 100))
        if ($estimatedBatchSize -eq 0) { $estimatedBatchSize = 50 }
        Write-Host "Estimated batch size being used:" $estimatedBatchSize
        $skip = 0
        do {
            $body = $Content | Select-Object -Skip $skip | Select-Object -First $estimatedBatchSize | ConvertTo-Json -Depth $JsonDepth -AsArray
            $actualBatchSize = $estimatedBatchSize
            if ([System.Text.Encoding]::UTF8.GetBytes($body).Length -gt $MaxBodySize) {
                do {
                    if ($actualBatchSize -lt 20) {$actualBatchSize -= 1} else {$actualBatchSize -= 10}             
                    $body = $Content | Select-Object -Skip $skip | Select-Object -First $actualBatchSize | ConvertTo-Json -Depth $JsonDepth -AsArray
                    if ($actualBatchSize -eq 1 -And [System.Text.Encoding]::UTF8.GetBytes($body).Length -gt $MaxBodySize -And ($body | ConvertFrom-Json | Get-Member configurations)) {
                        Write-Error ("Object is too large, removing configurations object to reduce the size. Length:" + ([math]::round([System.Text.Encoding]::UTF8.GetBytes($body).Length / 1kb)) + ' KB')
                        $body = $body | ConvertFrom-Json
                        $body.PSObject.Properties.Remove('configurations')
                        $body = $body | ConvertTo-Json -Depth $JsonDepth -AsArray
                    }
                    elseif ($actualBatchSize -eq 1 -And [System.Text.Encoding]::UTF8.GetBytes($body).Length -gt $MaxBodySize) {
                        Write-Error ("Object is too large, skipping...")
                        $body = $null
                    }
                } until ([System.Text.Encoding]::UTF8.GetBytes($body).Length -lt $MaxBodySize -Or $actualBatchSize -lt 2)
                if ($null -ne $body) { Write-Host ("Body is too large, reducing number of objects in current batch to: $actualBatchSize" + ". New size: " + ([math]::round([System.Text.Encoding]::UTF8.GetBytes($body).Length / 1kb)) + ' KB') }
            }
            if ($null -ne $body) { $bodies.Add($body) | Out-Null }
            $skip += $actualBatchSize
        } until ($skip -ge $Content.Count)
    }
    else {
        $bodies.Add($body) | Out-Null
    }
    $totalObjectsSentInBatch = 0
    foreach ($body in $bodies) {
        $objectsSent = ($body | ConvertFrom-Json).Count
        try {
            $postResponse = Invoke-RestMethod -Uri $azMonUri -Method "Post" -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) -Headers $Headers -MaximumRetryCount 2 -RetryIntervalSec 5
            $totalObjectsSentInBatch += $objectsSent
            $percentComplete = [math]::Round(($totalObjectsSentInBatch / $content.Count), 3)
            Write-Progress -Activity "Sending objects to Azure Monitor" -Status ("Sent $totalObjectsSentInBatch out of $objectsReceived objects.") -PercentComplete ([math]::Round($percentComplete * 100))
        }
        catch {
            Write-Error ("Unable to send $objectsSent to Azure Monitor. Error details: " + $_.ErrorDetails.Message)
        }   
    }
    Write-Progress -Id 0 -Completed -Activity 'Sending objects to Azure Monitor'
    return $totalObjectsSentInBatch
}

#Connect Azure Powershell module via Service Principal.
$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $appId, (ConvertTo-SecureString $appSecret -AsPlainText -Force)
Connect-AzAccount -ServicePrincipal -TenantId $tenantId -Credential $credential -Subscription $lawResourceId.Split('/')[2]

#Get Log Analytics workspace Id.
$lawId = (Get-AzOperationalInsightsWorkspace -ResourceGroupName $lawResourceId.Split('/')[4] -Name $lawResourceId.Split('/')[8]).CustomerId

#Get OAuth token for Defender API.
$defenderToken = Get-AADToken -Resource 'https://api.securitycenter.microsoft.com' -ClientId $appId -ClientSecret $appSecret -TenantId $tenantId -OAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"
#Get OAuth token for Azure Monitor API.
$azMonToken = Get-AADToken -Scope ([System.Web.HttpUtility]::UrlEncode("https://monitor.azure.com//.default")) -ClientId $appId -ClientSecret $appSecret -TenantId $tenantId -OAuthUri "https://login.microsoftonline.com/$TenantId/oauth2/token"

#Get Azure VM inventory
$azureVMsQuery = "
resources
| where type in ('microsoft.compute/virtualmachines', 'microsoft.hybridcompute/machines')
| extend deviceName = properties.extended.instanceView.computerName
| extend deviceName = iif(deviceName == '', name, deviceName)
| project id = tolower(id), deviceName = tolower(deviceName)"

$azResources = $null
$response = $null
do {
    $response = Search-AzGraph -Query $azureVMsQuery -SkipToken $response.SkipToken -First 1000
    $azResources += $response
} until ($null -eq $response.SkipToken)

#Ingest Vulnerabilities by Device.
$defenderUri = "https://api.securitycenter.windows.com/api/machines/SoftwareVulnerabilitiesByMachine"
Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationToken $azMonToken -DceUri $dceURI -DataSourceName 'MDVM Vulnerabilities by Device' `
    -JsonDepth 2 -Table 'MDVMVulnerabilitiesByDevice_CL' -AzureResources $azResources

#Ingest Recommendations.
$defenderUri = 'https://api.securitycenter.windows.com/api/recommendations'
$recommendations = Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationToken $azMonToken -DataSourceName 'MDVM Recommendations' `
    -JsonDepth 2 -Table 'MDVMRecommendations_CL'

#Ingest Recommendations Machine References.
foreach ($recommendation in $recommendations) {
    $defenderUri = 'https://api.securitycenter.microsoft.com/api/recommendations/' + $recommendation.recId + '/machineReferences'
    Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationToken $azMonToken -DataSourceName 'MDVM Recommendations Machine References' `
        -JsonDepth 2 -Table 'MDVMRecommendationsMachineReferences_CL' -RecommendationId $recommendation.recId
}

#Ingest CVE KB. 
$lawQuery = 'MDVMCVEKB_CL | order by todatetime(updatedOn) desc | take 1 | project updatedOn'
$mdvmKbLastUpdate = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId  -Query $lawQuery -Timespan 730D

$lawQuery = 'MDVMCVEKB_CL | summarize min(TimeGenerated) | project OldestRecord = format_timespan(now() - min_TimeGenerated, "d")'
$mdvmKBOldestRecord = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$mdvmKbRetention = (Get-AzOperationalInsightsTable ($lawResourceId.Split('/'))[4] -WorkspaceName ($lawResourceId.Split('/'))[8] -TableName 'MDVMCVEKB_CL' | Select-Object RetentionInDays)[0].RetentionInDays

if ($null -eq $mdvmKbLastUpdate.Results.updatedOn -Or $mdvmKBOldestRecord.Results.OldestRecord -ge ($mdvmKbRetention - 5) -Or $fullImport -eq 1) {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities'
}
else {
    $defenderUri = 'https://api.securitycenter.windows.com/api/Vulnerabilities?$filter=updatedOn+gt+' + $mdvmKbLastUpdate.Results.updatedOn
}

Import-Data -SourceUri $defenderUri -SourceToken $defenderToken -DestinationToken $azMonToken -DataSourceName 'MDVM CVE KB' `
    -JsonDepth 2 -Table 'MDVMCVEKB_CL'

#Ingest NIST CVE KB data.
$lawQuery = 'MDVMNISTCVEKB_CL | extend LastModified = lastModified | order by todatetime(LastModified) desc | take 1 | project LastModified'
$nistKbLastUpdate = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$lawQuery = 'MDVMNISTCVEKB_CL | summarize min(TimeGenerated) | project OldestRecord = format_timespan(now() - min_TimeGenerated, "d")'
$nistKBOldestRecord = Invoke-AzOperationalInsightsQuery -WorkspaceId $lawId -Query $lawQuery -Timespan 730D

$nistKbRetention = (Get-AzOperationalInsightsTable ($lawResourceId.Split('/'))[4] -WorkspaceName ($lawResourceId.Split('/'))[8] -TableName 'MDVMNISTCVEKB_CL' | Select-Object RetentionInDays)[0].RetentionInDays

if ($null -eq $nistKbLastUpdate.Results.LastModified -Or $nistKBOldestRecord.Results.OldestRecord -ge ($nistKbRetention - 5) -Or $fullImport -eq 1) {
    $nistUri = 'https://services.nvd.nist.gov/rest/json/cves/2.0'
}
else {
    $nistUri = 'https://services.nvd.nist.gov/rest/json/cves/2.0/?lastModStartDate=' + $nistKbLastUpdate.Results.LastModified + '&lastModEndDate=' + $snapshotTime
}

Import-Data -SourceUri $nistUri -DestinationToken $azMonToken -DataSourceName 'NIST CVE KB' -JsonDepth 8 -Table 'MDVMNISTCVEKB_CL'