""" Power Platform Inventory Collector v1.0.3 """
import os
import logging
import json
import asyncio
from datetime import datetime, timedelta
from typing import Iterator
from itertools import islice
from dateutil import parser
import azure.functions as func
from azure.identity.aio import ManagedIdentityCredential
from azure.monitor.ingestion.aio import LogsIngestionClient
from azure.storage.blob.aio import BlobServiceClient, ContainerClient
from azure.core.exceptions import (
    ServiceRequestError,
    ResourceNotFoundError,
    HttpResponseError,
)

azure_http_logger = logging.getLogger(
    "azure.core.pipeline.policies.http_logging_policy"
)
azure_http_logger.setLevel(logging.WARNING)

STORAGE_ACCOUNT_URL = (os.environ["STORAGE_ACCOUNT_URL"]).rstrip("/")
TIMER_SCHEDULE_HOURS = os.environ["TIMER_SCHEDULE_HOURS"]
DCR_DCE_URL = os.environ["DCR_DCE_URL"]
DCR_IMMUTABLE_ID = os.environ["DCR_IMMUTABLE_ID"]
DCR_STREAM_NAME_POWERAPPS = os.environ["DCR_STREAM_NAME_POWERAPPS"]
DCR_STREAM_NAME_ENVIRONMENTS = os.environ["DCR_STREAM_NAME_ENVIRONMENTS"]
DCR_STREAM_NAME_CONNECTIONS = os.environ["DCR_STREAM_NAME_CONNECTIONS"]
DCR_STREAM_NAME_FLOWS = os.environ["DCR_STREAM_NAME_FLOWS"]
COLLECT_APPS = bool(os.environ["COLLECT_APPS"])
COLLECT_ENVIRONMENTS = bool(os.environ["COLLECT_ENVIRONMENTS"])
COLLECT_CONNECTIONS = bool(os.environ["COLLECT_CONNECTIONS"])
COLLECT_FLOWS = bool(os.environ["COLLECT_FLOWS"])
INVENTORY_CONTAINER_NAME = os.environ["INVENTORY_CONTAINER_NAME"]
BATCH_SIZE = int(os.environ["BATCH_SIZE"])
FULL_SYNC_INTERVAL_DAYS = int(os.environ["FULL_SYNC_INTERVAL_DAYS"])
AZURE_WEB_JOBS_STORAGE = os.environ["AzureWebJobsStorage"]
LAST_UPDATE_FILENAME = "last_update.json"
LAST_UPDATE_CONTAINER_NAME = "lastupdated"
DATA_MAPPINGS = [
    {
        "collectionEnabled": COLLECT_APPS,
        "streamName": DCR_STREAM_NAME_POWERAPPS,
        "path": "powerapps/Applications/",
    },
    {
        "collectionEnabled": COLLECT_ENVIRONMENTS,
        "streamName": DCR_STREAM_NAME_ENVIRONMENTS,
        "path": "powerapps/environments/",
    },
    {
        "collectionEnabled": COLLECT_CONNECTIONS,
        "streamName": DCR_STREAM_NAME_CONNECTIONS,
        "path": "powerapps/Connections/",
    },
    {
        "collectionEnabled": COLLECT_FLOWS,
        "streamName": DCR_STREAM_NAME_FLOWS,
        "path": "powerautomate/Flows/",
    },
]


async def get_last_updated_timestamps() -> dict:
    """Get the last updated timestamp from blob storage"""

    empty_timestamp = datetime(1970, 1, 1).isoformat()
    no_updated_timestamps = {
        "last_sync": empty_timestamp,
        "last_full_sync": empty_timestamp,
    }

    async with ContainerClient.from_connection_string(
        conn_str=AZURE_WEB_JOBS_STORAGE, container_name=LAST_UPDATE_CONTAINER_NAME
    ) as last_update_blob_container:
        if not await last_update_blob_container.exists():
            logging.info("No storage container for last update timestamp found")
            return no_updated_timestamps

        try:
            logging.info("Downloading last update timestamp file")
            last_update_blob = await last_update_blob_container.download_blob(
                LAST_UPDATE_FILENAME
            )
            last_updated_timestamps = json.loads(await last_update_blob.readall())
            return last_updated_timestamps
        except ResourceNotFoundError:
            logging.info("No last update timestamp file found in blob storage.")
            return no_updated_timestamps


async def set_last_updated_timestamps(
    last_sync: datetime, last_full_sync: datetime
) -> None:
    """Set the last updated timestamp in blob storage"""
    async with ContainerClient.from_connection_string(
        conn_str=AZURE_WEB_JOBS_STORAGE, container_name=LAST_UPDATE_CONTAINER_NAME
    ) as last_update_blob_container:
        if not await last_update_blob_container.exists():
            logging.info("No storage container for last update timestamp found")
            await last_update_blob_container.create_container()

        logging.info("Updating last update timestamp file")
        await last_update_blob_container.upload_blob(
            LAST_UPDATE_FILENAME,
            json.dumps(
                {
                    "last_sync": last_sync.isoformat(),
                    "last_full_sync": last_full_sync.isoformat(),
                }
            ),
            overwrite=True,
        )


def filter_inventory_json(json_object: dict, last_collection_time: datetime) -> dict:
    """Filter JSON objects based on last modified time"""
    last_modified_string = json_object.get("lastModifiedTime") or json_object.get(
        "events_modified_timestamp"
    )
    if last_modified_string is None:
        return json_object
    elif last_modified_string != "-":
        last_modified_time = parser.parse(last_modified_string.replace("Z", ""))
        if last_modified_time >= last_collection_time:
            return json_object


def extract_json_objects(string: str) -> Iterator[dict]:
    """Extract JSON objects from line separated JSON used in Inventory"""
    lines = string.splitlines()
    for idx, line in enumerate(lines):
        try:
            yield json.loads(line)
        except json.JSONDecodeError:
            remaining_string = "\n".join(lines[idx:])
            yield from extract_json_objects_without_newline_separation(remaining_string)
            break


def extract_json_objects_without_newline_separation(string: str) -> Iterator[dict]:
    """Extract JSON objects from blob data without line separation"""
    decoder = json.JSONDecoder()
    start_idx = 0
    brace_depth = 0
    for idx, char in enumerate(string):
        if char == "{":
            if brace_depth == 0:
                start_idx = idx
            brace_depth += 1
        elif char == "}":
            brace_depth -= 1
            if brace_depth == 0:
                try:
                    yield decoder.decode(string[start_idx : idx + 1])
                except json.JSONDecodeError as exc:
                    logging.error(
                        "JSON decode error: %s, in %s", exc, string[start_idx : idx + 1]
                    )
                    continue


async def read_blob_contents(client: ContainerClient, path: str) -> str:
    """Read blob contents from blob storage"""
    try:
        blob = await client.download_blob(encoding="utf-8-sig", blob=path)
        blob_contents = await blob.readall()
    except (ServiceRequestError, ResourceNotFoundError, HttpResponseError) as exc:
        if isinstance(exc, ServiceRequestError):
            error_message = "Check blob storage URL: %s"
        elif isinstance(exc, ResourceNotFoundError):
            error_message = "Powerplatform container does not exist: %s"
        elif isinstance(exc, HttpResponseError):
            error_message = "HTTP error: %s"
        logging.error(error_message, exc)
        raise
    return blob_contents


async def read_and_parse_json(client: ContainerClient, path: str) -> list:
    """Read and parse JSON objects from blob storage"""
    content = await read_blob_contents(client=client, path=path)
    json_objects = extract_json_objects(string=content)
    return json_objects


async def collect_deltas(
    client: ContainerClient, path: str, last_collection_time: datetime
) -> list:
    """Collect recent data from blob storage"""
    json_objects = await read_and_parse_json(client, path)
    return [
        object
        for object in json_objects
        if filter_inventory_json(
            json_object=object, last_collection_time=last_collection_time
        )
    ]


async def get_inventory_json_file_names(client: ContainerClient, path: str) -> list:
    """Get the list of inventory JSON files from blob storage"""
    blobs = []
    async for blob in client.list_blob_names(name_starts_with=path):
        blobs.append(blob)
    return blobs


async def collect_full(client: ContainerClient, path: str) -> list:
    """Collect all data from blob storage"""
    return await read_and_parse_json(client=client, path=path)


async def send_data(dcr_stream: str, data: list, cred: ManagedIdentityCredential):
    """Send data to Logs Ingestion API"""
    client = LogsIngestionClient(endpoint=DCR_DCE_URL, credential=cred)
    async with client:
        try:
            await client.upload(
                rule_id=DCR_IMMUTABLE_ID, stream_name=dcr_stream, logs=data
            )
        except HttpResponseError as exc:
            logging.error("Logs Ingestion error: %s", exc)
            raise


app = func.FunctionApp()


@app.function_name(name="PowerPlatformInventoryDataConnector")
@app.schedule(
    schedule=f"0 0 */{TIMER_SCHEDULE_HOURS} * * *",
    arg_name="PowerPlatformInventoryDataConnector",
    run_on_startup=False,
    use_monitor=True,
)

# pylint: disable=invalid-name,unused-argument
async def main(PowerPlatformInventoryDataConnector: func.TimerRequest) -> None:
    """Main function for the Azure Function App"""

    function_start_time = datetime.utcnow()
    last_updates = await get_last_updated_timestamps()
    last_full_sync = datetime.fromisoformat(last_updates["last_full_sync"])
    last_sync = datetime.fromisoformat(last_updates["last_sync"])
    full_sync = last_full_sync < function_start_time - timedelta(
        days=FULL_SYNC_INTERVAL_DAYS
    )
    if full_sync:
        logging.info(
            "Last full sync was more than %s days ago, performing full sync",
            FULL_SYNC_INTERVAL_DAYS,
        )

    credential = ManagedIdentityCredential()

    async with BlobServiceClient(
        account_url=STORAGE_ACCOUNT_URL, credential=credential
    ) as blob_service_client:
        for dcr_stream, path in (
            (mapping["streamName"], mapping["path"])
            for mapping in DATA_MAPPINGS
            if mapping["collectionEnabled"]
        ):
            container_client = blob_service_client.get_container_client(
                container=INVENTORY_CONTAINER_NAME
            )
            logging.info("Retrieving inventory list from %s", path)
            blobs = await get_inventory_json_file_names(
                client=container_client, path=path
            )
            if not blobs:
                logging.info("No inventory data found in %s", path)
                continue
            logging.info("Processing %s blobs", len(blobs))
            for i in range(0, len(blobs), BATCH_SIZE):
                blob_batch = list(islice(blobs, i, i + BATCH_SIZE))
                tasks, inventory_data = [], []
                for blob in blob_batch:
                    if blob.startswith(f"{path}data_"):
                        continue
                    collection_task = (
                        collect_full(client=container_client, path=blob)
                        if full_sync
                        else collect_deltas(
                            client=container_client,
                            path=blob,
                            last_collection_time=last_sync,
                        )
                    )
                    task = asyncio.create_task(collection_task)
                    tasks.append(task)

                for result in await asyncio.gather(*tasks):
                    inventory_data.extend(result)

                item_count = len(inventory_data)

                if len(inventory_data) > 0:
                    logging.info(
                        "Sending %s inventory items from %s",
                        item_count,
                        f"{STORAGE_ACCOUNT_URL}/{INVENTORY_CONTAINER_NAME}/{path}",
                    )
                    await send_data(
                        dcr_stream=dcr_stream, data=inventory_data, cred=credential
                    )

    if full_sync:
        last_full_sync = function_start_time
    await set_last_updated_timestamps(
        last_sync=function_start_time, last_full_sync=last_full_sync
    )
    await credential.close()
