#$script:SentinelClientId = 'api://d4230588-5f84-4281-a9c7-2c15194b28f7'
#$script:SentinelTenantId = 'cab8a31a-1906-4287-a0d8-4eef66b95f6e'
#$script:CloudEnv = 'Gov'
#$script:AwsCloudResource = 'arn:aws-us-gov'


$script:SentinelClientId = 'api://21f935c0-8092-4b62-a772-5a2afd714569'
$script:SentinelTenantId = '33e01921-4d64-4f8c-a055-5bdaffd5e33d'
$script:CloudEnv = 'Com'
$script:AwsCloudResource = 'arn:aws'