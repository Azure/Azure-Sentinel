ms_federated_endpoint="sts.windows.net/33e01921-4d64-4f8c-a055-5bdaffd5e33d"
actions_audience="api://b7c1e142-0933-4310-ba00-8b28878bfece"
role_name="OIDC_Actions_Sentinel"
policy_name="SentinelActionsPolicy"

account_id=$(aws sts get-caller-identity --query Account --output text)
trust_policy_document=$(cat << EOM
{
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "Federated": "arn:aws:iam::$account_id:oidc-provider/$ms_federated_endpoint/"
            },
            "Action": "sts:AssumeRoleWithWebIdentity",
            "Condition": {
                "StringEquals": {
                    "$ms_federated_endpoint/:aud": "$actions_audience",
                    "sts:RoleSessionName": "MicrosoftSentinel_$account_id"
                }
            }
        }
    ]
}
EOM
)
permissions_policy_document=$(cat << EOM
{
  "Statement": [
    {
      "Sid": "SentinelActionsPermissions",
      "Effect": "Allow",
      "Action": [
        "iam:GetUserPolicy",
        "iam:DeleteRolePolicy",
        "iam:PutUserPolicy",
        "iam:AttachUserPolicy",
        "iam:ListUserPolicies",
        "iam:PutRolePolicy",
        "iam:GetUser",
        "iam:DetachUserPolicy",
        "iam:GetRolePolicy",
        "iam:DeleteUserPolicy",
        "s3:PutBucketPublicAccessBlock"
      ],
      "Resource": "*"
    }
  ]
}
EOM
)

aws iam add-client-id-to-open-id-connect-provider --open-id-connect-provider-arn arn:aws:iam::$account_id:oidc-provider/$ms_federated_endpoint/ --client-id $actions_audience
aws iam create-role --role-name $role_name --assume-role-policy-document "$trust_policy_document" || aws iam update-assume-role-policy --role-name $role_name --policy-document "$trust_policy_document"
aws iam put-role-policy --role-name $role_name --policy-name $policy_name --policy-document "$permissions_policy_document"
