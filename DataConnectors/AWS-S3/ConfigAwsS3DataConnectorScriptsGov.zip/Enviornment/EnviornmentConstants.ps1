$script:SentinelClientId = 'api://21f935c0-8092-4b62-a772-5a2afd714569'
$script:SentinelTenantId = '33e01921-4d64-4f8c-a055-5bdaffd5e33d'
$script:CloudEnv = 'Gov'