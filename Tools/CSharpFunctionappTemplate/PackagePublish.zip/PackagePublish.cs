using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Generic;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Azure.WebJobs.Host;
using System.Net.Http;
using PartnerCenterPackage.Utils;
using PartnerCenterPackage.Models;
using PartnerCenterPackage.Interfaces;
using System.Linq;
using DurableTask.Core;
using System.Threading;

namespace PartnerCenterPackage
{
    public class PackagePublish
    {
        private IHttpClientWrapper _httpClientWrapper = null;
        private IBlobHelper _blobHelper = null;

        public PackagePublish(IHttpClientWrapper httpClientWrapper, IBlobHelper blobHelper)
        {
            _httpClientWrapper = httpClientWrapper;
            _blobHelper = blobHelper;
        }
        
        [FunctionName("Orchestrator")]
        public async Task<List<string>> RunOrchestrator(
            [OrchestrationTrigger] IDurableOrchestrationContext context,
            [DurableClient] IDurableOrchestrationClient orchestrationClient, ILogger log)
        {
            RequestBody request = context.GetInput<RequestBody>();
            var outputs = new List<string>();
            if(request.SolutionType.ToLower() == "update")
            {
                var productList = await context.CallActivityAsync<Products>("GetProducts", request.OfferId);
                if (productList != null && productList.value.Count() > 0 && productList.value.FirstOrDefault().name == request.SolutionName)
                {
                    Constants.ProductId = productList.value.FirstOrDefault().id;
                    Data data = new Data();
                    data.ProductId = productList.value.FirstOrDefault().id;
                    data.FileName = request.FileName;
                    data.FileVersion = request.FileVersion;
                    var createPackage = await context.CallActivityAsync<CreatePackageResult>("CreatePackage", JsonConvert.SerializeObject(data).ToString());                    
                    // Create Package result is not null then copy the package to the SAS url and make a Put request Call
                    if(!string.IsNullOrEmpty(createPackage.id))
                    {                       
                        //var createPackagestring = JsonConvert.SerializeObject(createPackage);
                            var response = await context.CallActivityAsync<CreatePackageResult>("UploadPackageStatus", JsonConvert.SerializeObject(createPackage).ToString());
                            if(string.Equals(response.state.ToLower(),"inprocessing"))
                            {
                            DateTime deadline = context.CurrentUtcDateTime.Add(TimeSpan.FromSeconds(20));
                            await context.CreateTimer(deadline, CancellationToken.None);
                            var finalResponse = await context.CallActivityAsync<CreatePackageResult>("GetPackageDetails", JsonConvert.SerializeObject(createPackage).ToString());
                                data.PackageId = finalResponse.id;
                                log.LogInformation($"Uplaoding Package State - {finalResponse.state}");
                                log.LogInformation($"GetPackageDeatils Call executed with Package Id - {data.PackageId}");
                                if (string.Equals(finalResponse.state.ToLower(), "processed"))
                                {
                                    log.LogInformation($"Packaging Uploaded Success.");
                                    var packageBranch = await context.CallActivityAsync<GetPackageBranches>("GetPackageBranches", Constants.ProductId);
                                    
                                    if(packageBranch != null)
                                    {
                                        data.PackageInstanceId =  packageBranch.value.Where(x => x.variantID != null).FirstOrDefault().currentDraftInstanceID;
                                        var packageVariant = await context.CallActivityAsync<GetPackageVariant>("GetPackageVariant", JsonConvert.SerializeObject(data).ToString());
                                        if (packageVariant != null && !string.IsNullOrEmpty(packageVariant.value.Where(x => x.id == data.PackageInstanceId).Select(x => x.id).First()))                                    
                                        {
                                            log.LogInformation($"Final Packaging Upload is in Progress Package id - {data.PackageId}");
                                            data.GetPackageVariant = packageVariant;
                                            DateTime newdeadline = context.CurrentUtcDateTime.Add(TimeSpan.FromSeconds(10));
                                            await context.CreateTimer(newdeadline, CancellationToken.None);
                                            var PackageProductVariant = await context.CallActivityAsync<PackageProductVariant>("UploadPackageProductVariant", JsonConvert.SerializeObject(data).ToString());
                                            log.LogInformation($"Package has been finally updated with the version - {PackageProductVariant.version}");
                                    }
                                    }
                            }
                          }                        
                    }

                }
            }
            return outputs;
        }

        [FunctionName("UploadPackageProductVariant")]
        public async Task<PackageProductVariant> UploadPackageProductVariant([ActivityTrigger] string packageProductVariant, ILogger log)
        {
            var packageUpdateResult = (dynamic)null;
            var data = JsonConvert.DeserializeObject<Data>(packageProductVariant);
            //bool packageStatus = await _blobHelper.CopySourceToTarget(data.fileName, "tippingpoint-1234", data.fileSasUri, log);
            //log.LogInformation($"Updating the Package Request API to uploaded status.");
            //CreatePackageResult userData = JsonConvert.DeserializeObject<CreatePackageResult>(packageResult);
            data.GetPackageVariant.value.FirstOrDefault().packageReferences.FirstOrDefault().value = data.PackageId;
            data.GetPackageVariant.value.FirstOrDefault().version = data.FileVersion;
            packageUpdateResult = await _httpClientWrapper.PutRequest<PackageProductVariant>($"v1.0/ingestion/products/{data.ProductId}/packageConfigurations/{data.PackageInstanceId}", data.GetPackageVariant.value[0], data.GetPackageVariant.value[0].etag);                          
            return packageUpdateResult;
        }

        [FunctionName("GetPackageVariant")]
        public async Task<GetPackageVariant> GetPackageVariant([ActivityTrigger] string newdata, ILogger log)
        {
            var packageVariantData = JsonConvert.DeserializeObject<Data>(newdata);
            var packageVariant = await _httpClientWrapper.GetWithoutParams<GetPackageVariant>($"v1.0/ingestion/products/{packageVariantData.ProductId}/packageConfigurations/getByInstanceID(instanceID={packageVariantData.PackageInstanceId})");
            //log.LogInformation($"Hello returned the product id - {productList.Result.value.FirstOrDefault().id}");
            return packageVariant;
        }

        [FunctionName("GetProducts")]
        public Products GetProducts([ActivityTrigger] string offerId, ILogger log)
        {
            log.LogInformation($"Saying hello to {offerId}.");
            var productList = _httpClientWrapper.Get<Products>("v1.0/ingestion/products", offerId);
            log.LogInformation($"Hello returned the product id - {productList.Result.value.FirstOrDefault().id}");
            return productList.Result;
        }

        [FunctionName("GetPackageDetails")]
        public async Task<CreatePackageResult> GetPackageDetails([ActivityTrigger] string packageResult, ILogger log)
        {
            //log.LogInformation($"Saying hello to {offerId}.");
            
            var data = JsonConvert.DeserializeObject<CreatePackageResult>(packageResult);
            var packageDetails = await _httpClientWrapper.GetWithoutParams<CreatePackageResult>($"v1.0/ingestion/products/{Constants.ProductId}/packages/{data.id}");
            //log.LogInformation($"Hello returned the product id - {productList.Result.value.FirstOrDefault().id}");
            return packageDetails;
        }

        [FunctionName("GetPackageBranches")]
        public async Task<GetPackageBranches> GetPackageBranches([ActivityTrigger] string productId, ILogger log)
        {
            //log.LogInformation($"Saying hello to {offerId}.");

            //var data = JsonConvert.DeserializeObject<GetPackageBranches>(packageResult);
            var packageBranch = await _httpClientWrapper.GetWithoutParams<GetPackageBranches>($"v1.0/ingestion/products/{Constants.ProductId}/branches/getByModule(module=Package)");
            //log.LogInformation($"Hello returned the product id - {productList.Result.value.FirstOrDefault().id}");
            return packageBranch;
        }

        [FunctionName("UploadPackageStatus")]
        public async Task<CreatePackageResult> UploadPackageStatus([ActivityTrigger] string packageResult,ILogger log)
        {
            var packageUpdateResult = (dynamic)null;
            var data = JsonConvert.DeserializeObject<CreatePackageResult>(packageResult);
            bool packageStatus = await _blobHelper.CopySourceToTarget(data.fileName, "tippingpoint-1234", data.fileSasUri, log);
            //log.LogInformation($"Updating the Package Request API to uploaded status.");
            //CreatePackageResult userData = JsonConvert.DeserializeObject<CreatePackageResult>(packageResult);
            if (packageStatus)
            {
                data.state = "Uploaded";
                packageUpdateResult = await _httpClientWrapper.PutRequest<CreatePackageResult>($"v1.0/ingestion/products/{Constants.ProductId}/packages/{data.id}", data,"");
                //log.LogInformation($"Hello returned the product id - {packageUpdateResult}");                
            }
            return packageUpdateResult;
        }

        [FunctionName("CreatePackage")]
        public CreatePackageResult CreatePackage([ActivityTrigger] string newdata,ILogger log)
        {
            Data data = JsonConvert.DeserializeObject<Data>(newdata);
            log.LogInformation($"Saying hello to {data.ProductId}.");
            CreatePackageObject createPackageObject = new CreatePackageObject();
            createPackageObject.resourceType = "AzureApplicationPackage";
            createPackageObject.fileName = data.FileName;
            var packageResult = _httpClientWrapper.PostRequest<CreatePackageResult>($"v1.0/ingestion/products/{data.ProductId}/packages", createPackageObject);
            log.LogInformation($"Created Package State is - {packageResult.Result.state}");
            return packageResult.Result;
        }

        [FunctionName("Function1_Hello")]
        public static string SayHello([ActivityTrigger] string name, ILogger log)
        {
            log.LogInformation($"Saying hello to {name}.");
            return $"Hello {name}!";
        }

        [FunctionName("HttpStart")]
        public static async Task<HttpResponseMessage> HttpStart(
            [HttpTrigger(AuthorizationLevel.Anonymous,"post")] HttpRequestMessage req,
            [DurableClient] IDurableOrchestrationClient starter,
            ILogger log)
        {
            // Function input comes from the request content.
            var content = req.Content;
            string jsonContent = content.ReadAsStringAsync().Result;
            dynamic requestPram = JsonConvert.DeserializeObject<RequestBody>(jsonContent);
            var token = Identity.GetAccessToken();
            string instanceId = await starter.StartNewAsync<RequestBody>("Orchestrator", requestPram);            
            log.LogInformation($"Started orchestration with ID = '{instanceId}'.");
            log.LogInformation($"Started orchestration with ID = '{instanceId}'.");

            var createdTimeFrom = DateTime.UtcNow.AddDays(-365);
            var creattimeto = DateTime.UtcNow.AddHours(12);
            var runtimeStatus = new List<OrchestrationStatus>
            {
                OrchestrationStatus.Completed,
                OrchestrationStatus.Failed,
                OrchestrationStatus.Terminated,
                OrchestrationStatus.Running,
                OrchestrationStatus.ContinuedAsNew,
                OrchestrationStatus.Pending,
                OrchestrationStatus.Canceled
            };

            var result = await starter.PurgeInstanceHistoryAsync(createdTimeFrom, creattimeto, runtimeStatus);
            log.LogInformation($"Scheduled Cleanup done= '{instanceId}'.", result.InstancesDeleted);

            return starter.CreateCheckStatusResponse(req, instanceId);
            //return (HttpResponseMessage)starter.CreateCheckStatusResponse(req, instanceId);
        }
    }
}
