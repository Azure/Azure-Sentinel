﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Net.Http.Headers;
using PartnerCenterPackage;
using PartnerCenterPackage.Interfaces;
using PartnerCenterPackage.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

[assembly: FunctionsStartup(typeof(Startup))]
namespace PartnerCenterPackage
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddScoped<ITelemetryProvider, TelemetryProvider>();
            builder.Services.AddApplicationInsightsTelemetry();
            builder.Services.AddHttpClient("PartnerCenter", httpClient =>
            {
                httpClient.BaseAddress = new Uri("https://api.partner.microsoft.com/");

                // using Microsoft.Net.Http.Headers;
                // The GitHub API requires two headers.
                httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", Identity.GetAccessToken());
                httpClient.DefaultRequestHeaders.Add(
                    HeaderNames.Accept, "application/json");
                //httpClient.DefaultRequestHeaders.Add(
                //    HeaderNames.UserAgent, "HttpRequestsSample");
            });
            builder.Services.AddSingleton<ITelemetryProvider, TelemetryProvider>();
            builder.Services.AddApplicationInsightsTelemetry();
            builder.Services.AddScoped<IHttpClientWrapper, HTTPClientWrapper>();
            builder.Services.AddScoped<IBlobHelper, BlobCopy>();
        }

    }
}
