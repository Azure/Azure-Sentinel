import logging
import azure.functions as func
from azure.storage.queue import QueueServiceClient
import os

def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = mytimer.schedule_status.last if mytimer.schedule_status else 'unknown'

    if mytimer.past_due:
        logging.info(f'JumpCloud timer triggered and is running late! TIME: {utc_timestamp}')
    else:
        logging.info(f'JumpCloud timer triggered and is running on time! TIME: {utc_timestamp}')

    storage_conn_str = os.getenv('AzureWebJobsStorage')
    jc_event_types = os.getenv('JumpCloudEventTypes', '').lower().replace(',', ';').replace(':', ';').replace(' ', ';').split(';')
    valid_event_types = {"all", "directory", "radius", "sso", "systems", "ldap", "mdm"}

    queue_service = QueueServiceClient.from_connection_string(storage_conn_str)
    queue_name = "jcqueue"
    queue_client = queue_service.get_queue_client(queue_name)
    queue_client.create_queue()

    for event_type in jc_event_types:
        if event_type in valid_event_types:
            queue_client.send_message(event_type)
