import logging
import azure.functions as func
import requests
import os
from azure.data.tables import TableServiceClient
from datetime import datetime
import json
import hashlib
import hmac
import base64

def build_signature(customer_id, shared_key, date, content_length, method, content_type, resource):
    x_headers = f'x-ms-date:{date}'
    string_to_hash = f'{method}\n{content_length}\n{content_type}\n{x_headers}\n{resource}'
    bytes_to_hash = bytes(string_to_hash, encoding='utf-8')
    decoded_key = base64.b64decode(shared_key)
    encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
    return f'SharedKey {customer_id}:{encoded_hash}'

def main(msg: func.QueueMessage) -> None:
    jc_service = msg.get_body().decode('utf-8')
    logging.info(f'JumpCloud: Queue trigger for work item: {jc_service}')

    jc_api_token = os.getenv('JumpCloudApiToken')
    jc_uri = os.getenv('JumpCloudUri')
    storage_conn_str = os.getenv('AzureWebJobsStorage')
    customer_id = os.getenv('workspaceId')
    shared_key = os.getenv('workspaceKey')
    jc_table_name = os.getenv('AzureSentinelTable')
    timestamp_field = "timestamp"

    table_service = TableServiceClient.from_connection_string(storage_conn_str)
    table_client = table_service.get_table_client(jc_table_name)
    try:
        entity = table_client.get_entity(partition_key=jc_api_token, row_key=jc_service)
        jc_search_after = entity.get('SearchAfter', '')
        jc_start_time = entity.get('StartTime', datetime.utcnow().strftime('%Y-%m-%dT00:00:00Z'))
    except:
        jc_search_after = ''
        jc_start_time = datetime.utcnow().strftime('%Y-%m-%dT00:00:00Z')
        table_client.create_table()
        table_client.upsert_entity({"PartitionKey": jc_api_token, "RowKey": jc_service, "SearchAfter": jc_search_after, "StartTime": jc_start_time})

    headers = {'x-api-key': os.getenv('JumpCloudApiToken')}
    jc_uri = os.getenv('JumpCloudUri')
    total_records = 0

    while True:
        body = {
            "service": [msg.get_body().decode()],
            "start_time": jc_start_time
        }
        if jc_search_after:
            body["search_after"] = json.loads(jc_search_after)

        response = requests.post(jc_uri, headers={"x-api-key": jc_api_token}, json=body)
        response.raise_for_status()

        jc_result_count = int(response.headers.get("X-Result-Count", 0))
        jc_search_after = response.headers.get("X-Search_after", "")
        records = response.json()

        if jc_result_count > 0:
            rfc1123date = datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
            body_bytes = json.dumps(response.json()).encode('utf-8')
            signature = build_signature(customer_id, shared_key, rfc1123date, len(body_bytes), "POST", "application/json", "/api/logs")
            headers = {
                "Authorization": signature,
                "Log-Type": jc_table_name,
                "x-ms-date": rfc1123date,
                "time-generated-field": timestamp_field
            }
            requests.post(f"https://{customer_id}.ods.opinsights.azure.com/api/logs?api-version=2016-04-01", headers=headers1, data=body_bytes)

            jc_search_after = response.headers.get("X-Search_after", "")
            jc_start_time = response.json()[-1][timestamp_field]

            table_client.upsert_entity({"PartitionKey": jc_api_token, "RowKey": msg.get_body().decode(), "SearchAfter": jc_search_after, "StartTime": jc_start_time})

        logging.info(f"Processed {len(response.json())} records for event type {msg.get_body().decode()}")
